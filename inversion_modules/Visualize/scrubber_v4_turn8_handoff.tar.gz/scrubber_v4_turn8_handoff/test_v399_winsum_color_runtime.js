#!/usr/bin/env node
// Runtime tests for v3.99 t14e+ Windows page coloring (TEST 67 runtime
// counterpart). Verifies the value-extractor function produces correct
// per-mode values from synthetic windows.

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

const sandbox = {
  console,
  document: {
    elements: {},
    getElementById(id) {
      if (!this.elements[id]) {
        this.elements[id] = {
          id, listeners: {}, dataset: {}, style: {},
          addEventListener: function (ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); },
          appendChild() {}, removeChild() {}, click() {},
          options: [], textContent: '', innerHTML: '', value: '',
        };
      }
      return this.elements[id];
    },
    createElement: () => ({ dataset: {}, style: {}, addEventListener() {}, appendChild() {} }),
    body: { appendChild() {}, removeChild() {} },
    documentElement: { dataset: {} },
    querySelectorAll: () => [], querySelector: () => null,
    addEventListener() {},
  },
  window: {
    addEventListener() {}, removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: () => 0, clearTimeout() {}, requestAnimationFrame: () => 0,
  localStorage: {
    _store: {}, getItem(k) { return this._store[k] || null; }, setItem(k, v) { this._store[k] = String(v); },
    removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: function () {},
  alert: () => {},
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated */ }

  console.log('\n--- t14e+ continue: Windows page coloring runtime tests ---');

  if (typeof sandbox._winSumValueForMode !== 'function') {
    ok(false, '_winSumValueForMode in sandbox global');
    process.exit(1);
  }
  ok(true, '_winSumValueForMode in sandbox global');

  // Synthetic window
  const w = {
    z: -2.7, n_snps: 142, start_bp: 1_000_000, end_bp: 1_010_000,
    lam1: 0.45, lam2: 0.05,
  };

  // Test each mode
  ok(sandbox._winSumValueForMode(w, 5, null, 'z') === 2.7,
     'z mode returns abs(z)');
  ok(sandbox._winSumValueForMode(w, 5, null, 'n_snps') === 142,
     'n_snps mode returns n_snps');
  ok(Math.abs(sandbox._winSumValueForMode(w, 5, null, 'span_kb') - 10) < 1e-9,
     'span_kb mode returns (end_bp - start_bp) / 1000 = 10');
  ok(Math.abs(sandbox._winSumValueForMode(w, 5, null, 'snp_density') - 14.2) < 1e-9,
     'snp_density mode returns n_snps / span_kb = 142/10 = 14.2');
  ok(sandbox._winSumValueForMode(w, 5, null, 'lam1') === 0.45,
     'lam1 mode returns lam1');
  ok(sandbox._winSumValueForMode(w, 5, null, 'lam2') === 0.05,
     'lam2 mode returns lam2');
  ok(Math.abs(sandbox._winSumValueForMode(w, 5, null, 'ratio') - 9) < 1e-9,
     'ratio mode returns lam1/lam2 = 9');
  ok(Math.abs(sandbox._winSumValueForMode(w, 5, null, 'mb') - 1.005) < 1e-9,
     'mb mode returns center_bp/1e6 = (start+end)/2/1e6');
  ok(sandbox._winSumValueForMode(w, 5, null, 'idx') === 5,
     'idx mode returns the passed index i');

  // Edge cases — missing fields
  const wMissingZ = { start_bp: 0, end_bp: 1000 };
  ok(sandbox._winSumValueForMode(wMissingZ, 0, null, 'z') === 0,
     'missing z falls back to 0 (Math.abs(0))');

  const wMissingLam = { start_bp: 0, end_bp: 1000 };
  ok(Number.isNaN(sandbox._winSumValueForMode(wMissingLam, 0, null, 'lam1')),
     'missing lam1 returns NaN');
  ok(Number.isNaN(sandbox._winSumValueForMode(wMissingLam, 0, null, 'lam2')),
     'missing lam2 returns NaN');
  ok(Number.isNaN(sandbox._winSumValueForMode(wMissingLam, 0, null, 'ratio')),
     'missing lam1/lam2 → ratio NaN');

  // Zero-division safety
  const wZeroLam2 = { lam1: 1, lam2: 0 };
  ok(Number.isNaN(sandbox._winSumValueForMode(wZeroLam2, 0, null, 'ratio')),
     'lam2 = 0 → ratio NaN (no Infinity)');

  // Default fallback for n_snps
  vm.runInContext(`state.windowDefaultSnps = 100;`, sandbox);
  ok(sandbox._winSumValueForMode({ start_bp: 0, end_bp: 0 }, 0, null, 'n_snps') === 100,
     'missing n_snps falls back to state.windowDefaultSnps (100)');

  vm.runInContext(`state.windowDefaultSnps = 250;`, sandbox);
  ok(sandbox._winSumValueForMode({ start_bp: 0, end_bp: 0 }, 0, null, 'n_snps') === 250,
     'fallback respects updated state.windowDefaultSnps');

  // Span 0 → density NaN (no division by zero)
  ok(Number.isNaN(sandbox._winSumValueForMode({ start_bp: 100, end_bp: 100, n_snps: 5 }, 0, null, 'snp_density')),
     'span 0 → snp_density NaN (not Infinity)');

  // Unknown mode → falls back to z
  ok(sandbox._winSumValueForMode(w, 5, null, 'unknown_xyz') === 2.7,
     'unknown mode falls back to abs(z)');

  // Null window
  ok(Number.isNaN(sandbox._winSumValueForMode(null, 0, null, 'z')),
     'null window → NaN');

  // Label function
  if (typeof sandbox._winSumColorModeLabel === 'function') {
    ok(sandbox._winSumColorModeLabel('z') === '|Z|', 'label("z") = "|Z|"');
    ok(sandbox._winSumColorModeLabel('n_snps') === 'n bi-SNPs', 'label("n_snps") = "n bi-SNPs"');
    ok(sandbox._winSumColorModeLabel('snp_density') === 'bi-SNPs / kb', 'label("snp_density") = "bi-SNPs / kb"');
    ok(sandbox._winSumColorModeLabel('lam1') === 'λ₁', 'label("lam1") = "λ₁"');
    ok(sandbox._winSumColorModeLabel('lam2') === 'λ₂', 'label("lam2") = "λ₂"');
    ok(sandbox._winSumColorModeLabel('ratio') === 'λ₁ / λ₂', 'label("ratio") = "λ₁ / λ₂"');
    ok(sandbox._winSumColorModeLabel('mb') === 'center Mb', 'label("mb") = "center Mb"');
    ok(sandbox._winSumColorModeLabel('idx') === 'window #', 'label("idx") = "window #"');
    ok(sandbox._winSumColorModeLabel('span_kb') === 'span (kb)', 'label("span_kb") = "span (kb)"');
  } else {
    ok(false, '_winSumColorModeLabel in sandbox');
  }

  // hasGradient
  if (typeof sandbox._winSumModeHasGradient === 'function') {
    ok(sandbox._winSumModeHasGradient('z') === true, 'z has gradient');
    ok(sandbox._winSumModeHasGradient('n_snps') === true, 'n_snps has gradient');
    ok(sandbox._winSumModeHasGradient('l1') === false, 'l1 has NO gradient (categorical)');
    ok(sandbox._winSumModeHasGradient('l2') === false, 'l2 has NO gradient (categorical)');
  } else {
    ok(false, '_winSumModeHasGradient in sandbox');
  }

  console.log(`\n--- v3.99 t14e+ continue Windows-page-coloring runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
