#!/usr/bin/env node
// Runtime tests for v3.99 t14e+ drawCandidateBar. We can't visually verify
// the canvas output in a vm sandbox (no real canvas), but we CAN intercept
// the canvas API calls and verify:
//   - Pending candidates trigger fillRect with the grey color
//   - Confirmed candidates trigger createLinearGradient
//   - Confirmed candidates also trigger fillText('★', ...) when wide enough
//   - Draft candidates trigger setLineDash + strokeRect (no fill)
//   - Order: pending pass before confirmed pass

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

// Recording canvas context — captures every API call so the test can
// inspect what drawCandidateBar tried to paint.
function makeRecordingCtx() {
  const calls = [];
  const styleStack = { fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', textBaseline: '' };
  const ctx = {
    _calls: calls,
    set fillStyle(v) { styleStack.fillStyle = v; calls.push({ op: 'set', prop: 'fillStyle', value: v }); },
    get fillStyle() { return styleStack.fillStyle; },
    set strokeStyle(v) { styleStack.strokeStyle = v; calls.push({ op: 'set', prop: 'strokeStyle', value: v }); },
    get strokeStyle() { return styleStack.strokeStyle; },
    set lineWidth(v) { styleStack.lineWidth = v; },
    get lineWidth() { return styleStack.lineWidth; },
    set font(v) { styleStack.font = v; },
    get font() { return styleStack.font; },
    set textAlign(v) { styleStack.textAlign = v; },
    get textAlign() { return styleStack.textAlign; },
    set textBaseline(v) { styleStack.textBaseline = v; },
    get textBaseline() { return styleStack.textBaseline; },
    fillRect(x, y, w, h) { calls.push({ op: 'fillRect', x, y, w, h, fillStyle: styleStack.fillStyle }); },
    strokeRect(x, y, w, h) { calls.push({ op: 'strokeRect', x, y, w, h, strokeStyle: styleStack.strokeStyle }); },
    fillText(text, x, y) { calls.push({ op: 'fillText', text, x, y, fillStyle: styleStack.fillStyle }); },
    createLinearGradient(x0, y0, x1, y1) {
      const g = { _stops: [], addColorStop(off, c) { this._stops.push({ off, c }); }, _type: 'gradient' };
      calls.push({ op: 'createLinearGradient', x0, y0, x1, y1, grad: g });
      return g;
    },
    setLineDash(arr) { calls.push({ op: 'setLineDash', dash: arr.slice() }); },
    beginPath() {}, moveTo() {}, lineTo() {}, closePath() {}, fill() {}, stroke() {}, scale() {}, save() {}, restore() {}, translate() {}, arc() {},
    measureText(s) { return { width: s.length * 6 }; },
  };
  return { ctx, calls };
}

const sandbox = {
  console,
  document: {
    elements: {},
    getElementById(id) {
      if (!this.elements[id]) {
        this.elements[id] = {
          id, listeners: {}, dataset: {}, style: {},
          addEventListener: function (ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); },
          appendChild() {}, removeChild() {},
          click() {},
          options: [],
          textContent: '', innerHTML: '',
          value: '',
        };
      }
      return this.elements[id];
    },
    createElement(tag) {
      return { dataset: {}, style: {}, addEventListener() {}, appendChild() {} };
    },
    body: { appendChild() {}, removeChild() {} },
    documentElement: { dataset: {} },
    querySelectorAll: () => [],
    querySelector: () => null,
    addEventListener() {},
  },
  window: {
    addEventListener() {}, removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: () => 0, clearTimeout() {}, requestAnimationFrame: () => 0,
  localStorage: {
    _store: {}, getItem(k) { return this._store[k] || null; }, setItem(k, v) { this._store[k] = String(v); },
    removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: function () {},
  alert: () => {},
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated */ }

  console.log('\n--- t14e+ continue: candidate bar runtime tests ---');

  if (typeof sandbox.drawCandidateBar !== 'function') {
    ok(false, 'drawCandidateBar function in sandbox global');
    process.exit(1);
  }
  ok(true, 'drawCandidateBar function in sandbox global');

  // Synthetic data: 100-window chromosome
  const synthData = {
    n_windows: 100,
    chrom: 'TEST_CHR',
    windows: Array.from({ length: 100 }, (_, i) => ({
      start_bp: i * 100_000, end_bp: (i + 1) * 100_000,
      center_mb: (i * 100_000 + 50_000) / 1e6,
    })),
    l2_envelopes: [],
  };
  // Need to set state.candidateList and state.data into the sandbox context
  // Since `state` is a const in the sandbox, we can't reassign it from
  // outside, but we CAN mutate it (since the const refers to an object,
  // not a frozen one). However, the const itself isn't visible from the
  // sandbox global. We mutate via a function — the simplest path is to
  // call a function that mutates state internally.
  //
  // Workaround: we invoke an eval in the sandbox to mutate state.
  function mutateState(obj) {
    const exprs = [];
    for (const k in obj) {
      exprs.push(`state.${k} = ${JSON.stringify(obj[k])};`);
    }
    vm.runInContext(exprs.join('\n'), sandbox);
  }

  // Test 1: empty list — bar paints faint baseline only
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.data = ${JSON.stringify(synthData)}; state.candidateList = []; state.candidateMode = false; state.l3Draft = null;`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7);
    const fillRects = calls.filter(c => c.op === 'fillRect');
    ok(fillRects.length === 1,
       'empty candidateList: only the faint baseline fillRect (1 call)');
    ok(fillRects[0] && /rgba\(160, 168, 180/.test(fillRects[0].fillStyle),
       'baseline uses muted ink-dim grey rgba(160,168,180,...)');
  }

  // Test 2: pending-only — baseline + grey fillRect for the candidate
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.candidateList = [{
      id: 'cand_1', start_w: 10, end_w: 30, confirmed: false
    }];`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7);
    const fillRects = calls.filter(c => c.op === 'fillRect');
    ok(fillRects.length === 2,
       'pending candidate: 2 fillRects (baseline + grey pending)');
    const greyFill = fillRects.find(c => /rgba\(120, 130, 145/.test(c.fillStyle));
    ok(!!greyFill, 'pending fillRect uses grey rgba(120,130,145, 0.55*dimAlpha)');
    // No gradient should have been created
    const gradients = calls.filter(c => c.op === 'createLinearGradient');
    ok(gradients.length === 0,
       'pending: no linear gradient created (gradient is for confirmed only)');
    // No ★ glyph
    const stars = calls.filter(c => c.op === 'fillText' && c.text === '★');
    ok(stars.length === 0, 'pending: no ★ glyph drawn');
  }

  // Test 3: confirmed-only — baseline + gradient fillRect + outline + ★
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.candidateList = [{
      id: 'cand_2', start_w: 20, end_w: 60, confirmed: true
    }];`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7);
    const gradients = calls.filter(c => c.op === 'createLinearGradient');
    ok(gradients.length === 1,
       'confirmed candidate: 1 linear gradient created');
    if (gradients.length === 1) {
      const stops = gradients[0].grad._stops;
      ok(stops.length === 3, 'gradient has 3 color stops (top/mid/bottom)');
      ok(stops[0] && stops[0].off === 0 && /rgba\(255, 230, 130/.test(stops[0].c),
         'gradient stop 0 = pale shine rgba(255,230,130)');
      ok(stops[1] && stops[1].off === 0.35 && /rgba\(245, 200, 60/.test(stops[1].c),
         'gradient stop 0.35 = mid-gold rgba(245,200,60)');
      ok(stops[2] && stops[2].off === 1 && /rgba\(190, 145, 25/.test(stops[2].c),
         'gradient stop 1 = deep gold rgba(190,145,25)');
    }
    // Outline
    const outlines = calls.filter(c => c.op === 'strokeRect');
    ok(outlines.length === 1, 'confirmed: 1 strokeRect (warm gold outline)');
    ok(outlines[0] && /rgba\(140, 95, 10/.test(outlines[0].strokeStyle),
       'outline uses rgba(140, 95, 10) deep gold');
    // ★ glyph (the bar at start_w=20, end_w=60 maps to mb=2.05..6.05, toX=mb*10 → x0=20.5..x1=60.5, w=40 ≥ 12)
    const stars = calls.filter(c => c.op === 'fillText' && c.text === '★');
    ok(stars.length === 2,
       'confirmed wide bar: 2 ★ fillTexts (drop shadow + main glyph)');
    if (stars.length === 2) {
      // First ★ is the drop shadow (offset +0.6/+0.6)
      ok(Math.abs(stars[0].x - stars[1].x - 0.6) < 1e-6,
         'shadow ★ offset +0.6 from main ★');
    }
  }

  // Test 4: confirmed bar TOO NARROW for ★ (wide < 12 px)
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.candidateList = [{
      id: 'cand_3', start_w: 50, end_w: 50, confirmed: true
    }];`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7);
    const stars = calls.filter(c => c.op === 'fillText' && c.text === '★');
    ok(stars.length === 0,
       'confirmed but narrow (<12 px): no ★ glyph');
    // Gradient still drawn (just no glyph)
    const gradients = calls.filter(c => c.op === 'createLinearGradient');
    ok(gradients.length === 1,
       'narrow confirmed: gradient still painted');
  }

  // Test 5: pass order — pending grey BEFORE confirmed gradient
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.candidateList = [
      { id: 'p1', start_w: 5, end_w: 20, confirmed: false },
      { id: 'c1', start_w: 30, end_w: 60, confirmed: true },
      { id: 'p2', start_w: 70, end_w: 85, confirmed: false }
    ];`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7);
    // Find indices: first grey fillRect should come before first gradient
    let firstGreyIdx = -1, firstGradIdx = -1;
    for (let i = 0; i < calls.length; i++) {
      if (firstGreyIdx < 0 && calls[i].op === 'fillRect' && /rgba\(120, 130, 145/.test(calls[i].fillStyle)) firstGreyIdx = i;
      if (firstGradIdx < 0 && calls[i].op === 'createLinearGradient') firstGradIdx = i;
      if (firstGreyIdx >= 0 && firstGradIdx >= 0) break;
    }
    ok(firstGreyIdx >= 0 && firstGradIdx >= 0 && firstGreyIdx < firstGradIdx,
       'pass order: pending grey paints BEFORE confirmed gradient');
    // Two pending → 2 grey fillRects; one confirmed → 1 gradient
    const greys = calls.filter(c => c.op === 'fillRect' && /rgba\(120, 130, 145/.test(c.fillStyle));
    ok(greys.length === 2, 'mixed list: 2 pending → 2 grey fillRects');
    const grads = calls.filter(c => c.op === 'createLinearGradient');
    ok(grads.length === 1, 'mixed list: 1 confirmed → 1 gradient');
  }

  // Test 6: candidate without start_w/end_w gracefully skipped
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.candidateList = [
      { id: 'broken', confirmed: true },
      { id: 'good',   start_w: 10, end_w: 20, confirmed: true }
    ];`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7);
    const grads = calls.filter(c => c.op === 'createLinearGradient');
    ok(grads.length === 1,
       'candidate without start_w/end_w: skipped, only the good one renders');
  }

  // Test 7: dimAlpha option
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.candidateList = [{ id: 'p', start_w: 10, end_w: 30, confirmed: false }];`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7, { dimAlpha: 0.5 });
    const greys = calls.filter(c => c.op === 'fillRect' && /rgba\(120, 130, 145/.test(c.fillStyle));
    ok(greys.length === 1 && /0\.275/.test(greys[0].fillStyle),
       'dimAlpha: 0.5 → grey alpha = 0.55 * 0.5 = 0.275');
  }

  // Test 8: showStar: false suppresses glyph even for wide bars
  {
    const { ctx, calls } = makeRecordingCtx();
    vm.runInContext(`state.candidateList = [{ id: 'c', start_w: 10, end_w: 80, confirmed: true }];`, sandbox);
    sandbox.drawCandidateBar(ctx, synthData, (mb) => mb * 10, 5, 7, { showStar: false });
    const stars = calls.filter(c => c.op === 'fillText' && c.text === '★');
    ok(stars.length === 0,
       'showStar: false → no ★ glyph even on wide confirmed bar');
    // Gradient still rendered though
    const grads = calls.filter(c => c.op === 'createLinearGradient');
    ok(grads.length === 1, 'showStar: false: gradient still rendered');
  }

  console.log(`\n--- v3.99 t14e+ continue candidate-bar runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
