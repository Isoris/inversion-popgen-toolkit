#!/usr/bin/env node
// Runtime tests for v3.99 t14e+ continue registry interop scaffold (TEST 71
// runtime counterpart). Verifies the parsing + identification + validation
// helpers behave correctly on realistic synthetic registry artifacts.

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

const sandbox = {
  console,
  document: {
    elements: {},
    getElementById(id) {
      if (!this.elements[id]) {
        this.elements[id] = {
          id, listeners: {}, dataset: {}, style: {},
          addEventListener: function (ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); },
          appendChild() {}, removeChild() {}, click() {},
          options: [], textContent: '', innerHTML: '', value: '',
        };
      }
      return this.elements[id];
    },
    createElement: () => ({ dataset: {}, style: {}, addEventListener() {}, appendChild() {} }),
    body: { appendChild() {}, removeChild() {} },
    documentElement: { dataset: {} },
    querySelectorAll: () => [], querySelector: () => null,
    addEventListener() {},
  },
  window: {
    addEventListener() {}, removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: () => 0, clearTimeout() {}, requestAnimationFrame: () => 0,
  localStorage: {
    _store: {}, getItem(k) { return this._store[k] || null; }, setItem(k, v) { this._store[k] = String(v); },
    removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: function () {},
  alert: () => {},
  FileReader: function () { this.readAsText = () => {}; },
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated */ }

  console.log('\n--- t14e+ continue: registry interop runtime tests ---');

  // --- _parseTSV ---
  if (typeof sandbox._parseTSV !== 'function') {
    ok(false, '_parseTSV in sandbox global');
    process.exit(1);
  }
  ok(true, '_parseTSV in sandbox global');

  const tsv1 = `group_id\tdimension\tn\tcreated
all_226\tcohort\t226\t2026-04-15 12:00:00
unrelated_81\tunrelated\t81\t2026-04-15 12:01:00
inv_LG12_17_HOM_INV\tkaryotype\t32\t2026-04-15 12:02:00`;
  const p1 = sandbox._parseTSV(tsv1);
  ok(p1 && p1.headers.length === 4, '_parseTSV reads 4 headers');
  ok(p1 && p1.rows.length === 3, '_parseTSV reads 3 data rows');
  ok(p1 && p1.rows[0].group_id === 'all_226', 'first row group_id = "all_226"');
  ok(p1 && p1.rows[2].dimension === 'karyotype', 'third row dimension = "karyotype"');

  // CRLF tolerance
  const tsv2 = "a\tb\r\n1\t2\r\n3\t4\r\n";
  const p2 = sandbox._parseTSV(tsv2);
  ok(p2 && p2.rows.length === 2, '_parseTSV tolerates CRLF line endings');

  // Empty / null
  ok(sandbox._parseTSV('') === null, '_parseTSV("") returns null');
  ok(sandbox._parseTSV(null) === null, '_parseTSV(null) returns null');
  ok(sandbox._parseTSV(123) === null, '_parseTSV(non-string) returns null');

  // --- _identifyRegistryArtifact ---
  ok(sandbox._identifyRegistryArtifact('sample_groups.tsv', '', null) === 'sample_groups',
     'identifies "sample_groups.tsv" filename');
  ok(sandbox._identifyRegistryArtifact('data/sample_registry/sample_groups.tsv', '', null) === 'sample_groups',
     'identifies "sample_groups.tsv" inside a path');
  ok(sandbox._identifyRegistryArtifact('candidate_intervals.tsv', '', null) === 'candidate_intervals',
     'identifies "candidate_intervals.tsv"');
  ok(sandbox._identifyRegistryArtifact('manifest.tsv', '', null) === 'results_manifest',
     'identifies "manifest.tsv" → results_manifest');
  ok(sandbox._identifyRegistryArtifact(
       'evidence_registry/per_candidate/LG12_17/structured/final_classification.json',
       '{}', null
     ) === 'structured_block',
     'identifies path with /structured/ as structured_block');
  ok(sandbox._identifyRegistryArtifact('random.txt', 'hello', null) === 'unknown',
     'unrecognized files → unknown');

  // Content-shape fallback for plain JSON
  const blockJson = '{"candidate_id":"LG12_17","block_type":"q5_age","age_class":"young"}';
  ok(sandbox._identifyRegistryArtifact('block.json', blockJson, null) === 'structured_block',
     'plain .json with candidate_id + block_type sniffs as structured_block');

  // Content-shape fallback for TSV with right columns
  const sniffParsed = {
    headers: ['group_id', 'members_file', 'n', 'created'],
    rows: [{ group_id: 'all_226', members_file: 'groups/all_226.txt', n: '226', created: '2026' }],
  };
  ok(sandbox._identifyRegistryArtifact('weird_name.tsv', '', sniffParsed) === 'sample_groups',
     'TSV with group_id + members_file headers → sample_groups (content sniff)');

  // --- _validateRegistryTable ---
  const v1 = sandbox._validateRegistryTable('sample_groups', p1);
  ok(v1.ok === false, 'parsed p1 missing required cols → fails validation');
  // p1 only has group_id, dimension, n, created — missing members_file
  ok(v1.errors.some(e => /members_file/.test(e)),
     'validation error mentions missing members_file');

  const goodSampleGroups = sandbox._parseTSV(
    `group_id\tmembers_file\tn\tcreated\nall_226\tgroups/all_226.txt\t226\t2026-04-15`
  );
  const v2 = sandbox._validateRegistryTable('sample_groups', goodSampleGroups);
  ok(v2.ok === true, 'complete sample_groups passes validation');

  const goodCandidates = sandbox._parseTSV(
    `candidate_id\tchrom\tstart_bp\tend_bp\tparent_id\nLG12_17\tC_gar_LG12\t12500000\t20030000\t.`
  );
  const v3 = sandbox._validateRegistryTable('candidate_intervals', goodCandidates);
  ok(v3.ok === true, 'complete candidate_intervals passes validation');

  const goodManifest = sandbox._parseTSV(
    `row_id\tkind\tfile\ttimestamp\nabc-123\tpairwise\tpairwise/fst/LG12.tsv\t2026-04-15T12:00`
  );
  const v4 = sandbox._validateRegistryTable('results_manifest', goodManifest);
  ok(v4.ok === true, 'complete results_manifest passes validation');

  const v5 = sandbox._validateRegistryTable('unknown_kind', goodSampleGroups);
  ok(v5.ok === false, 'unknown kind fails validation');

  const v6 = sandbox._validateRegistryTable('sample_groups', null);
  ok(v6.ok === false, 'null parsed fails validation');

  // --- _candidateIdFromPath ---
  ok(sandbox._candidateIdFromPath(
       'evidence_registry/per_candidate/LG12_17/structured/final_classification.json'
     ) === 'LG12_17',
     'extracts cid LG12_17 from full path');
  ok(sandbox._candidateIdFromPath(
       'per_candidate/LG28_42/structured/q5_age.json'
     ) === 'LG28_42',
     'extracts cid LG28_42 from short path');
  ok(sandbox._candidateIdFromPath('random.json') === null,
     'returns null for non-registry path');
  ok(sandbox._candidateIdFromPath(null) === null,
     'returns null for null input');

  // --- _blockTypeFromPath ---
  ok(sandbox._blockTypeFromPath(
       'per_candidate/LG12_17/structured/final_classification.json'
     ) === 'final_classification',
     'extracts block type "final_classification"');
  ok(sandbox._blockTypeFromPath(
       'per_candidate/LG28_42/structured/q3_boundaries.json'
     ) === 'q3_boundaries',
     'extracts block type "q3_boundaries"');
  ok(sandbox._blockTypeFromPath('not_a_block.json') === null,
     'returns null when not in /structured/ path');

  // --- _REG_SCHEMAS constant — validated indirectly via _validateRegistryTable behavior above ---
  // (const-scoped; not exposed to vm sandbox global. Regex test in test_v399.js
  // verifies the constant exists in source. Behavioral tests above verify the
  // required-fields lists are correct for each artifact type.)

  console.log(`\n--- v3.99 t14e+ continue registry-interop runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
