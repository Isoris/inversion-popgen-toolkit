// Runtime tests for v4 turn 4 PCA lasso wiring + L3 contingency
// stats-to-right-of-table + L1/L2 fragment separators + |Z| label
// reposition. Spins up the same lightweight DOM shim used by other
// runtime tests, sources the scrubber's <script>, and probes for
// presence/behavior of the new symbols.

const fs = require('fs');
const path = require('path');

const html = fs.readFileSync(path.join(__dirname, 'pca_scrubber_v3.html'), 'utf8');
const m = html.match(/<script>([\s\S]+?)<\/script>/);
if (!m) { console.error('no <script>'); process.exit(1); }

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; }
  else { fail++; console.log('  FAIL ' + msg); }
}

// 1) Source-level checks (no DOM eval needed):

ok(/state\.pcaLassoActive/.test(m[1]),
   'state.pcaLassoActive slot defined');
ok(/_updatePcaLassoUI/.test(m[1]),
   '_updatePcaLassoUI helper defined');
ok(/canvas\.__pcaLassoMode\s*=\s*isTrackedLasso\s*\?\s*'tracked'\s*:\s*'manual'/.test(m[1]),
   'canvas pointerdown branches between tracked-lasso and manual-lasso modes');
ok(/mode\s*===\s*'tracked'/.test(m[1]),
   'endDrag has tracked-mode branch');

// |Z| label in windows-page strip — y must be below zone bars (not at pad.t + 12).
ok(/_winSumColorModeLabel\(mode\),\s*pad\.l\s*\+\s*4,\s*pad\.t\s*\+\s*zoneH\s*\+\s*10/.test(m[1]),
   '|Z| label in drawWinSumStrip placed at y = pad.t + zoneH + 10 (below L2 bar)');

// L1/L2 separator drawing — dark red fill.
const sepCount = (m[1].match(/rgba\(140,\s*29,\s*36,\s*0\.95\)/g) || []).length;
// 6 expected: drawZ compact (L1+L2 = 2 fillStyle), drawZ main (L1+L2 = 2),
// drawWinSumStrip (L1+L2 = 2). Total = 6. Allow ≥6 in case of future adds.
ok(sepCount >= 6,
   `expected ≥ 6 dark-red fragment separators across drawZ/drawWinSumStrip; got ${sepCount}`);

// L3 stats-to-right wrapping.
ok(/<div class="ct-flex" style="display: flex; flex-wrap: wrap;/.test(m[1]),
   'ctHtml wraps table+stats in a flex row (stats-to-right layout)');

// L3 toolbar wrap fix.
ok(/#l3Panel \.l3-layout \{ display: flex; gap: 2px; flex: 0 0 auto; flex-wrap: nowrap;/.test(html),
   '.l3-layout uses flex: 0 0 auto + flex-wrap: nowrap so groups stay atomic');

// Hover styling on inline-styled L3 toolbar buttons.
ok(/#l3Panel \.l3-head button:hover,?\s*#l3Panel \.l3-head input\[type="number"\]:hover/.test(html),
   'L3 toolbar inline-style buttons get hover state via #l3Panel .l3-head button:hover rule');

// v4 turn 7: 1w/5w/10w/Nw consistent styling (min-width on the L3 unit
// buttons + sidebar stepModeBar buttons).
ok(/#l3CompareUnit > button \{ min-width: 32px;/.test(html),
   'L3 unit buttons (L2/1w/5w/10w/Nw) have min-width for consistent appearance');
ok(/#stepModeBar > button \{ min-width: 36px;/.test(html),
   'sidebar step-mode buttons have min-width for consistent appearance');

// v4 turn 7: green-flash on promote-to-candidate.
ok(/@keyframes promoteFlashGreen/.test(html),
   'promoteFlashGreen keyframe defined');
ok(/\.promote-flash-green \{[\s\S]+?animation: promoteFlashGreen 700ms/.test(html),
   '.promote-flash-green class triggers the keyframe');
ok(/_flashPromoteGreen\(_promoteBtn\)/.test(m[1]),
   'sidebar promote button flashes green on click');
ok(/_flashPromoteGreen\(_l3PromoteCandBtn\)/.test(m[1]),
   'L3 toolbar promote button flashes green on click');

// v4 turn 6: Show tracked + Clear spotlight buttons (added this turn but
// part of the earlier turn 6 spotlight feature).
ok(/id="l3SpotlightTrackedBtn"/.test(html),
   'Show tracked button defined in L3 toolbar HTML');
ok(/id="l3SpotlightClearBtn"/.test(html),
   'Clear spotlight button defined in L3 toolbar HTML');
ok(/state\.spotlightTrackedAll = !state\.spotlightTrackedAll/.test(m[1]),
   'Show tracked button toggles state.spotlightTrackedAll');
ok(/state\.spotlight = null;\s*state\.spotlightTrackedAll = false/.test(m[1]),
   'Clear spotlight button resets both spotlight + spotlightTrackedAll');

// 2) Sanity: parse the scrubber JS in a sandbox and check no top-level error.
try {
  new Function(m[1]);
  ok(true, 'scrubber JS parses cleanly');
} catch (e) {
  ok(false, 'scrubber JS parse failed: ' + e.message);
}

console.log(`\n--- v4 turn 4 PCA lasso + L3 layout runtime tests: ${pass}/${pass+fail} ---`);
process.exit(fail === 0 ? 0 : 1);
