#!/usr/bin/env node
// Runtime tests for v3.99 t14e+ continue θπ scrubber (TEST 74 runtime
// counterpart). Verifies:
//   1. _refreshThetaPiLayerStatus correctly flips empty-state indicators
//      based on state.layersPresent set membership
//   2. detectSchemaAndLayers recognizes all three new θπ layer names
//      with proper shape validation
//   3. The empty-state DOM has the expected indicator markup

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

// DOM mock with the same _autoCreate pattern that worked for chips runtime test.
function makeNode(opts) {
  opts = opts || {};
  const n = {
    id: opts.id || '',
    tagName: opts.tag || 'div',
    className: opts.className || '',
    children: [],
    listeners: {},
    dataset: {},
    style: { cssText: '' },
    attributes: {},
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    _innerHTML: '',
    textContent: '',
    get innerHTML() { return this._innerHTML; },
    set innerHTML(v) {
      this._innerHTML = v;
      this.children = [];
      // Auto-register elements with id in their markup
      const idMatches = String(v).matchAll(/id="([^"]+)"/g);
      for (const m of idMatches) {
        if (!sandboxDocument.elements[m[1]]) {
          sandboxDocument.elements[m[1]] = makeNode({ id: m[1] });
        }
      }
    },
    appendChild(child) {
      this.children.push(child);
      if (child && child.id) sandboxDocument.elements[child.id] = child;
      return child;
    },
    removeChild(child) {
      this.children = this.children.filter(c => c !== child);
      return child;
    },
    remove() {
      if (this.id && sandboxDocument.elements[this.id] === this) {
        delete sandboxDocument.elements[this.id];
      }
    },
    addEventListener() {},
    removeEventListener() {},
    click() {},
    querySelector() { return null; },
    querySelectorAll() { return []; },
    getBoundingClientRect() { return { top: 0, left: 0, right: 0, bottom: 0, width: 0, height: 0 }; },
    getContext() {
      return {
        clearRect() {}, fillRect() {}, fillText() {},
        measureText: () => ({ width: 0 }),
        save() {}, restore() {}, setLineDash() {},
        createLinearGradient: () => ({ addColorStop() {} }),
        beginPath() {}, moveTo() {}, lineTo() {}, closePath() {}, fill() {}, stroke() {},
        translate() {}, scale() {},
        fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', textBaseline: '',
      };
    },
    setAttribute() {}, getAttribute: () => null,
    width: 0, height: 0, clientWidth: 0, clientHeight: 0,
  };
  return n;
}

const sandboxDocument = {
  elements: {},
  // Phase flag — true during init, false during tests (matches real-browser semantics)
  _autoCreate: true,
  getElementById(id) {
    if (this.elements[id]) return this.elements[id];
    if (this._autoCreate) {
      this.elements[id] = makeNode({ id });
      return this.elements[id];
    }
    return null;
  },
  createElement(tag) { return makeNode({ tag }); },
  body: { appendChild() {}, removeChild() {} },
  documentElement: { dataset: {} },
  // The key method for this test — _refreshThetaPiLayerStatus calls this
  // with selector '[data-th-layer]'. We synthesize three nodes representing
  // the three indicator rows in the empty-state, with their dataset.thLayer
  // attributes set as the scrubber's empty-state markup would have them.
  querySelectorAll(sel) {
    if (sel === '[data-th-layer]') {
      return Array.from(this._thIndicatorMocks || []);
    }
    return [];
  },
  querySelector: () => null,
  addEventListener() {},
  // Test harness sets this up
  _thIndicatorMocks: [],
};

const sandbox = {
  console,
  document: sandboxDocument,
  window: {
    addEventListener() {}, removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: () => 0, clearTimeout() {}, requestAnimationFrame: () => 0,
  localStorage: {
    _store: {}, getItem(k) { return this._store[k] || null; },
    setItem(k, v) { this._store[k] = String(v); }, removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: function () {},
  alert: () => {},
  FileReader: function () { this.readAsText = () => {}; },
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document;
sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated */ }

  console.log('\n--- v3.99 t14e+ continue: θπ scrubber runtime tests ---');

  // Top-level globals
  ok(typeof sandbox._refreshThetaPiLayerStatus === 'function',
     '_refreshThetaPiLayerStatus is defined and callable');
  ok(typeof sandbox.detectSchemaAndLayers === 'function',
     'detectSchemaAndLayers is defined');

  // Switch DOM mock to strict mode now that script init has finished
  sandboxDocument._autoCreate = false;

  // ============================================================================
  // detectSchemaAndLayers — recognize the three new θπ layers
  // ============================================================================
  // theta_pi_per_window — needs samples + windows arrays + values (typed array OK)
  const data1 = {
    schema_version: 2,
    _layers_present: ['theta_pi_per_window', 'theta_pi_local_pca', 'theta_pi_envelopes'],
    theta_pi_per_window: {
      samples: ['CGA009', 'CGA010', 'CGA011'],
      windows: [{ start_bp: 0, end_bp: 50000 }, { start_bp: 25000, end_bp: 75000 }],
      values: new Float32Array(6),  // 3 samples × 2 windows
      window_size_bp: 50000,
      step_size_bp: 25000,
    },
    theta_pi_local_pca: {
      n_windows: 2, n_samples: 3, samples: ['CGA009', 'CGA010', 'CGA011'],
      z: new Float32Array(2),
      lam1: new Float32Array(2), lam2: new Float32Array(2), ratio: new Float32Array(2),
      pc1: new Float32Array(6), pc2: new Float32Array(6),
      sim_mat: new Float32Array(4),
      mds_coords: new Float32Array(4),
      method_version: 'v1',
    },
    theta_pi_envelopes: {
      l1: [{ id: 'th_L1_1', win_start: 0, win_end: 1 }],
      l2: [],
      candidate_intervals: [{ id: 'th_cand_1', start_bp: 0, end_bp: 50000 }],
    },
  };
  const det1 = sandbox.detectSchemaAndLayers(data1);
  ok(det1.schemaVersion === 2, 'schema v2 recognized');
  ok(det1.layers.has('theta_pi_per_window'),
     'theta_pi_per_window layer detected with proper shape');
  ok(det1.layers.has('theta_pi_local_pca'),
     'theta_pi_local_pca layer detected with proper shape');
  ok(det1.layers.has('theta_pi_envelopes'),
     'theta_pi_envelopes layer detected with proper shape');

  // None of the three present → none detected
  const data2 = {
    schema_version: 2,
    _layers_present: ['theta_pi_per_window', 'theta_pi_local_pca', 'theta_pi_envelopes'],
    // No actual layer data
  };
  const det2 = sandbox.detectSchemaAndLayers(data2);
  ok(!det2.layers.has('theta_pi_per_window'),
     'theta_pi_per_window NOT detected when missing from data');
  ok(!det2.layers.has('theta_pi_local_pca'),
     'theta_pi_local_pca NOT detected when missing from data');
  ok(!det2.layers.has('theta_pi_envelopes'),
     'theta_pi_envelopes NOT detected when missing from data');

  // theta_pi_per_window with malformed shape (no samples array) → not detected
  const data3 = {
    schema_version: 2,
    _layers_present: ['theta_pi_per_window'],
    theta_pi_per_window: { just_garbage: true },
  };
  const det3 = sandbox.detectSchemaAndLayers(data3);
  ok(!det3.layers.has('theta_pi_per_window'),
     'theta_pi_per_window with malformed shape (no samples array) NOT detected');

  // theta_pi_envelopes with at least candidate_intervals (any of l1/l2/candidate_intervals OK)
  const data4 = {
    schema_version: 2,
    _layers_present: ['theta_pi_envelopes'],
    theta_pi_envelopes: { candidate_intervals: [] },
  };
  const det4 = sandbox.detectSchemaAndLayers(data4);
  ok(det4.layers.has('theta_pi_envelopes'),
     'theta_pi_envelopes with only candidate_intervals (empty) still detected');

  // ============================================================================
  // SCHEMA §22.13: Shape A auto-detection — existing JSONs with w.theta
  // ============================================================================
  // Existing production JSONs (exported via export_precomp_to_json.R --theta)
  // embed per-sample θπ inside each window object as w.theta — an array of
  // n_samples values aligned with the precomp window order. The detector
  // should auto-flag theta_pi_per_window present when this shape is found,
  // even without an explicit _layers_present declaration.
  const data5 = {
    schema_version: 2,
    _layers_present: ['windows'],   // does NOT declare theta_pi_per_window
    windows: [
      { idx: 0, start_bp: 0, end_bp: 50000, z: 1.2,
        theta: [0.001, 0.002, 0.0015]  // 3-sample θπ vector inline (Shape A)
      },
      { idx: 1, start_bp: 25000, end_bp: 75000, z: 1.5,
        theta: [0.0012, 0.0018, 0.0020]
      },
    ],
  };
  const det5 = sandbox.detectSchemaAndLayers(data5);
  ok(det5.layers.has('theta_pi_per_window'),
     'Shape A auto-detection: theta_pi_per_window flagged via w.theta even without explicit _layers_present declaration');

  // Empty theta arrays → not flagged (we want non-empty)
  const data6 = {
    schema_version: 2, _layers_present: ['windows'],
    windows: [{ idx: 0, theta: [] }],
  };
  const det6 = sandbox.detectSchemaAndLayers(data6);
  ok(!det6.layers.has('theta_pi_per_window'),
     'Shape A auto-detection: empty w.theta array does NOT flag the layer');

  // Windows present but no theta field → not flagged
  const data7 = {
    schema_version: 2, _layers_present: ['windows'],
    windows: [{ idx: 0, z: 0.5 }],
  };
  const det7 = sandbox.detectSchemaAndLayers(data7);
  ok(!det7.layers.has('theta_pi_per_window'),
     'Shape A auto-detection: windows without theta field does NOT flag the layer');

  // BOTH shapes present (Shape A in windows + Shape B at top level) → still detected once
  const data8 = {
    schema_version: 2,
    _layers_present: ['theta_pi_per_window', 'windows'],
    theta_pi_per_window: {
      samples: ['CGA009'],
      windows: [{ start_bp: 0, end_bp: 50000 }],
      values: new Float32Array(1),
    },
    windows: [
      { idx: 0, theta: [0.001] },
    ],
  };
  const det8 = sandbox.detectSchemaAndLayers(data8);
  ok(det8.layers.has('theta_pi_per_window'),
     'BOTH Shape A and Shape B present → layer flagged (no double-counting issue)');

  // ============================================================================
  // _refreshThetaPiLayerStatus — flip indicators based on state.layersPresent
  // ============================================================================
  // Set up three indicator nodes mimicking the empty-state markup
  const ind1 = makeNode({ id: 'ind1' });
  ind1.dataset.thLayer = 'theta_pi_per_window';
  ind1.textContent = '⚪ not loaded';
  ind1.style.color = 'var(--ink-dimmer)';
  const ind2 = makeNode({ id: 'ind2' });
  ind2.dataset.thLayer = 'theta_pi_local_pca';
  ind2.textContent = '⚪ not loaded';
  ind2.style.color = 'var(--ink-dimmer)';
  const ind3 = makeNode({ id: 'ind3' });
  ind3.dataset.thLayer = 'theta_pi_envelopes';
  ind3.textContent = '⚪ not loaded';
  ind3.style.color = 'var(--ink-dimmer)';
  sandboxDocument._thIndicatorMocks = [ind1, ind2, ind3];

  // No layers present → all stay ⚪
  vm.runInContext(`
    if (!state) state = {};
    state.layersPresent = new Set();
  `, sandbox);
  sandbox._refreshThetaPiLayerStatus();
  ok(ind1.textContent === '⚪ not loaded',
     'ind1 stays ⚪ when no θπ layers present');
  ok(ind2.textContent === '⚪ not loaded',
     'ind2 stays ⚪ when no θπ layers present');
  ok(ind3.textContent === '⚪ not loaded',
     'ind3 stays ⚪ when no θπ layers present');

  // Only theta_pi_per_window loaded → ind1 flips, others stay ⚪
  vm.runInContext(`
    state.layersPresent = new Set(['theta_pi_per_window']);
  `, sandbox);
  sandbox._refreshThetaPiLayerStatus();
  ok(ind1.textContent === '🟢 loaded',
     'ind1 flips to 🟢 when theta_pi_per_window loaded');
  ok(ind1.style.color === 'var(--good)',
     'ind1 color flips to --good when loaded');
  ok(ind2.textContent === '⚪ not loaded',
     'ind2 stays ⚪ when only theta_pi_per_window loaded');
  ok(ind3.textContent === '⚪ not loaded',
     'ind3 stays ⚪ when only theta_pi_per_window loaded');

  // All three loaded → all flip to 🟢
  vm.runInContext(`
    state.layersPresent = new Set([
      'theta_pi_per_window', 'theta_pi_local_pca', 'theta_pi_envelopes'
    ]);
  `, sandbox);
  sandbox._refreshThetaPiLayerStatus();
  ok(ind1.textContent === '🟢 loaded',
     'ind1 = 🟢 with all three layers loaded');
  ok(ind2.textContent === '🟢 loaded',
     'ind2 = 🟢 with all three layers loaded');
  ok(ind3.textContent === '🟢 loaded',
     'ind3 = 🟢 with all three layers loaded');

  // Layers removed → indicators flip back to ⚪
  vm.runInContext(`
    state.layersPresent = new Set();
  `, sandbox);
  sandbox._refreshThetaPiLayerStatus();
  ok(ind1.textContent === '⚪ not loaded',
     'ind1 reverts to ⚪ when layers removed');
  ok(ind2.textContent === '⚪ not loaded',
     'ind2 reverts to ⚪ when layers removed');
  ok(ind3.textContent === '⚪ not loaded',
     'ind3 reverts to ⚪ when layers removed');
  ok(ind1.style.color === 'var(--ink-dimmer)',
     'ind1 color reverts to --ink-dimmer when layer removed');

  // No indicators in DOM → no-op (does not throw)
  sandboxDocument._thIndicatorMocks = [];
  let noOpThrew = false;
  try { sandbox._refreshThetaPiLayerStatus(); } catch (e) { noOpThrew = true; }
  ok(!noOpThrew, '_refreshThetaPiLayerStatus is a no-op when no indicators in DOM');

  // ============================================================================
  // Idempotency — repeated calls don't accumulate side effects
  // ============================================================================
  sandboxDocument._thIndicatorMocks = [ind1, ind2, ind3];
  vm.runInContext(`
    state.layersPresent = new Set(['theta_pi_per_window']);
  `, sandbox);
  sandbox._refreshThetaPiLayerStatus();
  sandbox._refreshThetaPiLayerStatus();
  sandbox._refreshThetaPiLayerStatus();
  ok(ind1.textContent === '🟢 loaded',
     'idempotent: ind1 stays 🟢 across multiple calls with same state');
  ok(ind2.textContent === '⚪ not loaded',
     'idempotent: ind2 stays ⚪ across multiple calls with same state');

  console.log(`\n--- v3.99 t14e+ continue θπ scrubber runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
