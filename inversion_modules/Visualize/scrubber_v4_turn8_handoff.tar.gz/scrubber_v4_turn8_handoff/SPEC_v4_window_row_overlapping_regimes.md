# SPEC v4 turn 8 — window-row, overlapping candidates, regime mapping

Concrete implementation plan for the next chat. Each deliverable is sized
and ordered so partial completion still ships value.

---

## Deliverable A: per-window row in candidate strip (smallest, ship first)

**Scope:** add a third zone-bar row to the candidate strip, visible only when
`state.candidateMode === true`. Allow window-resolution drafting.

**Files touched:** `pca_scrubber_v3.html` only.

**Changes:**

1. **State.** Extend `state.l3Draft` with `resolution`, `start_w`, `end_w`,
   `l3_cuts` per SCHEMA §24. Default `resolution: 'L2'` so existing behavior
   is unchanged.

2. **Drawing.** In `drawZ` (not drawCandidateBar — drawZ owns the row layout,
   drawCandidateBar fills one slot), reserve a new zone slot below the
   existing L2 zone bar when `state.candidateMode === true`. Slot height: 8px.
   Inside this slot, render:
   - A faint baseline strip (`rgba(160,168,180,0.10)`) across visible range
   - For windows inside the focal L2's range: vertical 1px ticks at each
     window boundary in `rgba(160,168,180,0.30)`
   - The active draft (when `state.l3Draft && resolution === 'W'`) as
     a filled amber block from `start_w` to `end_w` at 0.6 alpha
   - Drag handles: 3px-wide amber boxes at start_w and end_w edges

3. **Click handler.** Extend the existing zCanvas click handler to detect
   clicks in the W-row y-range. When candidate mode is active and the click
   is in the W row:
   - Compute nearest window index from x-coord
   - If clicked-window is inside the current draft span, no-op (or jump)
   - Otherwise: extend the draft to include the clicked window (set
     `start_w = min(start_w, w)` or `end_w = max(end_w, w)`)
   - Setting `resolution: 'W'` switches the draft from L2 mode if it wasn't
     already (and stamps `start_w/end_w` from the current L2 span)

4. **Pointer drag handlers.** When dragging from a handle, update `start_w`
   or `end_w` continuously; redraw on `requestAnimationFrame`. Capture
   pointer to follow mouse outside canvas. Release → commit.

5. **Persistence.** Window-resolution drafts persist with the candidate when
   committed (already happens — `start_w/end_w` are existing candidate
   fields).

6. **Migration.** None. Old candidates without `resolution` default to 'L2'
   on read. `l3Draft.resolution` is per-session, no localStorage entry.

**Tests** (`test_v4_window_row_runtime.js`):
- Verify W-row CSS class / draw call exists in drawZ
- Verify candidate-mode toggle shows/hides the row
- Verify state.l3Draft accepts both resolution='L2' and 'W'
- Verify candidateFromJSON/candidateToJSON round-trip with start_w/end_w/l3_cuts
- Old saved candidate (without resolution) loads as resolution='L2'

**Estimated size:** ~250 lines code, ~1.5–2 hours. Single chat turn.

---

## Deliverable B: overlapping candidates (medium)

**Scope:** the candidate-bar renderer stacks overlapping candidates vertically;
the catalogue and click handlers cope with N-candidates-per-window.

**Files touched:** `pca_scrubber_v3.html` only.

**Changes:**

1. **drawCandidateBar overhaul.** Today the bar is a single fixed-height row.
   Replace with a layout pass:

   ```js
   // Pass 0: assign each candidate to a stack lane.
   // Greedy: sort by start_w, walk through; place each cand in the
   // lowest-numbered lane whose last-occupant ended before this cand starts.
   function _assignCandidateLanes(candList) {
     const sorted = candList.slice().sort((a,b) => a.start_w - b.start_w);
     const lanes = [];   // lanes[i] = end_w of last cand in lane i
     const assignments = new Map();  // cand.id → lane index
     for (const c of sorted) {
       let placed = false;
       for (let i = 0; i < lanes.length; i++) {
         if (lanes[i] < c.start_w) {
           lanes[i] = c.end_w;
           assignments.set(c.id, i);
           placed = true; break;
         }
       }
       if (!placed) {
         lanes.push(c.end_w);
         assignments.set(c.id, lanes.length - 1);
       }
     }
     return { assignments, n_lanes: lanes.length };
   }
   ```

   Then drawCandidateBar's `h` parameter becomes a per-lane height; total bar
   grows to `h × n_lanes`. Each candidate is drawn at its lane's y-offset.

2. **Total bar height.** Caller (drawZ) uses `n_lanes × candBarH` instead of
   `candBarH`. Layout in drawZ shifts L1/L2 zones down by the extra height
   when N>1 lanes are needed.

3. **Click handler.** When clicking on the candidate bar, hit-test against
   ALL lanes; if multiple candidates contain the click x, pick the one in
   the y-lane the click landed in. This already works once lanes are
   assigned — just pass lane info to the click handler.

4. **Catalogue column.** Add a "regimes" column (initially empty for all rows
   since regimes don't exist yet — Deliverable C adds them). Behavior:
   shows a comma-separated list of regime names that include this L2 via
   any candidate. Empty if no regime assignments.

**Tests:**
- 2 non-overlapping candidates → 1 lane
- 2 overlapping candidates → 2 lanes
- 3 candidates A∩B, A∩C, B∩C disjoint → 3 lanes (chained pairwise overlap)
- 3 candidates all spanning full chrom → 3 lanes
- Click on stacked region picks correct lane

**Estimated size:** ~400 lines code (bar renderer + click handler + tests),
~3 hours. Single chat turn.

---

## Deliverable C: regime registry (largest)

**Scope:** new `state.regimeList[]`, persistence, scrubber UI for creating /
editing / deleting regimes, candidate ↔ regime linking UI.

**Files touched:** `pca_scrubber_v3.html` only.

**Changes:**

1. **State + persistence.** Per SCHEMA §25:
   - `state.regimeList = []` initialized at startup
   - `loadRegimeList()` / `persistRegimeList()` keyed
     `pca_scrubber_v3.regimes.<chrom>`
   - `regimeToJSON` / `regimeFromJSON`
   - CRUD: `createRegime(name)`, `deleteRegime(id)`, `addCandToRegime(cand_id,
     regime_id, bands, role)`, `removeCandFromRegime(cand_id, regime_id)`,
     `renameRegime(id, newName)`

2. **UI: regime list panel.** New panel on candidate page (page 3) below the
   ancestry-confound panel:

   ```
   REGIMES (chr X)
   ┌─────────────────────────────────────────────────────────┐
   │ INV_A    [one_axis_3band ▼]  3 candidates  [edit][del] │
   │ INV_B    [two_axes_indep ▼]  2 candidates  [edit][del] │
   │ + new regime                                             │
   └─────────────────────────────────────────────────────────┘
   ```

   Click [edit] → opens an inline editor showing the regime's member
   candidates with band-assignment chips: `cand_001: g0 g1 g2 [primary ▼]`.
   Click on a band chip toggles its membership; the role dropdown changes
   role. "+ link candidate" adds a new (cand, bands, role) row.

3. **UI: candidate-side reverse view.** On the active candidate's panel
   (page 3, candidate-focus block), show a "regimes" sub-section listing
   which regimes this candidate belongs to:
   ```
   REGIMES THIS CANDIDATE BELONGS TO
   • INV_A  bands: g0 g1 g2  role: primary
   • INV_B  bands: g3        role: background
   [+ link to regime]
   ```

4. **Catalogue integration.** The "regimes" column added in Deliverable B
   becomes populated. Sortable by regime name.

5. **Migration.** `regimeList = []` for chromosomes with no saved regimes.
   Old candidates with no `regime_assignments` field load as `[]`. No
   breakage.

**Tests:**
- create/rename/delete regime → state + localStorage updated
- link candidate to regime → both candidate.regime_assignments and
  regime.member_assignments are updated
- unlink → both sides cleaned up
- delete regime → all member candidates' regime_assignments cleaned up
- two regimes can share a candidate (different bands, different roles)
- catalogue regimes column reflects regime assignments

**Estimated size:** ~700 lines code (CRUD + persistence + 2 UI panels +
tests), ~5–6 hours. Likely 2 chat turns.

---

## Deliverable D: scale-stability test (toggleable L3 mode) — REFINED

**Scope:** add a toggle that repurposes the EXISTING 3-pane L3 carousel
(◆ slab focal, ← slab -1, → slab +1) into a scale-stability viewer. When
toggle is ON, the same 3 panes show 3 different scales all centered on
the focal — fine / medium / coarse. When OFF, they go back to spatial
neighbors (existing behavior). The user picks each pane's scale
independently from a unit dropdown. Sankey diagrams between adjacent
panes show fuse/split structure visually. Verdict cascade still produces
STABLE_3BAND / STABLE_6BAND / NESTED_3IN6 / OVERLAP_BREAKS_3 / UNSTABLE
labels, but the headline signal is the fuse/split count, not ARI.

**Why this matters biologically:** the K=6 case where bands {1,2,3} stay
in one row and {4,5,6} stay in another might be:

- one 3-band inversion with zoom-level substructure (K collapses 6→3 at
  coarse scale, clean nested ribbons)
- two overlapping inversions (3-band-then-6-then-3 across the candidate
  span, ribbons reshuffle in the middle)
- a stable multiband architecture (6 at every scale, parallel ribbons)
- unstable artifact (random ribbons everywhere)

The fuse/split visual answers all four cases at a glance. ARI is just
the summary number.

**Files touched:** `pca_scrubber_v3.html` only.

### Concept — reuse the existing carousel

The L3 panel already has 3 carousel panes. Today they show:

```
┌──────────────────┬──────────────────┬──────────────────┐
│ ← slab -1        │ ◆ slab focal     │ → slab +1        │
│ at compareUnit   │ at compareUnit   │ at compareUnit   │
│ (5w default)     │ (5w default)     │ (5w default)     │
│ mini-PCA + table │ mini-PCA + table │ mini-PCA + table │
└──────────────────┴──────────────────┴──────────────────┘
```

When `state.l3Mode === 'scale_stability'`, the SAME 3 panes show:

```
┌──────────────────┬──────────────────┬──────────────────┐
│ Σ₁ fine          │ Σ₂ medium        │ Σ₃ coarse        │
│ user pick (5w)   │ user pick (L2)   │ user pick (cand) │
│ mini-PCA + table │ mini-PCA + table │ mini-PCA + table │
│ all centered     │ all centered     │ all centered     │
│ on focal window  │ on focal window  │ on focal window  │
└──────────────────┴──────────────────┴──────────────────┘
        ↓ Sankey ↓                ↓ Sankey ↓
   K_fine → K_med ribbons    K_med → K_coarse ribbons
```

The carousel's drawing primitives (mini-PCA, contingency table cell,
K-counts header) work unchanged. What changes:

1. The pane labels (left header text) flip from `← slab -1 · w####-####`
   etc. to `Σ₁ fine · 5w · K=6` etc.
2. Each pane uses a different `(s_w, e_w, K)` for its `getSlabClusterAt`
   call instead of all 3 panes using `compareUnit` neighbors of focal.
3. Two new horizontal Sankey strips render BETWEEN the panes showing
   the fuse/split flow.

### Three independent scale selectors

When the toggle is ON, the existing `compareUnit` selector
(`L2 / 1w / 5w / 10w / N w`) is hidden, and three NEW dropdowns appear
in its place:

```
[Σ₁ fine: 5w  ▼]  [Σ₂ medium: L2  ▼]  [Σ₃ coarse: candidate  ▼]
```

Each dropdown offers the same set of units:

| Dropdown value | Meaning | Conversion |
|---|---|---|
| `1w` | 1 window | center on focal |
| `5w` | 5 windows | focal ±2 |
| `10w` | 10 windows | focal ±5 |
| `25w` | 25 windows | focal ±12 |
| `Nw` (custom) | N windows | uses existing `compareUnitN` field |
| `100 SNPs` | smallest contiguous range whose Σ `n_snps` ≥ 100 | center on focal, expand symmetrically until SNP target met |
| `500 SNPs` | same, 500 SNPs | constant statistical power across genome |
| `1000 SNPs` | same, 1000 SNPs | |
| `100 kb` | smallest range whose span_bp ≥ 100,000 | physical-distance unit |
| `500 kb` | same, 500 kb | |
| `L2` | the focal L2 envelope | uses focal_l2idx's `_s0` / `_e0` |
| `L1` | the focal L1 envelope | broader |
| `candidate` | full active candidate's `start_w..end_w` | only available when `state.candidate` set |

`candidate` is greyed-out when no active candidate exists. The default
triple is `5w / L2 / candidate` when a candidate is active, otherwise
`5w / L2 / L1`.

**SNP-band conversion** is the biologically meaningful unit. For target
T SNPs centered on focal window F:
```js
function _snpBandRange(focalW, targetSnps) {
  let s = focalW, e = focalW, total = state.data.windows[focalW].n_snps;
  while (total < targetSnps) {
    const canL = s > 0;
    const canR = e < state.data.windows.length - 1;
    if (!canL && !canR) break;
    // expand on the side with fewer SNPs added so far (symmetric coverage)
    if (canL && (!canR || s > 2 * focalW - e)) {
      s--; total += state.data.windows[s].n_snps;
    } else {
      e++; total += state.data.windows[e].n_snps;
    }
  }
  return [s, e];
}
```

The kb-band conversion is the same with `span_bp` instead of `n_snps`.

### Cross-scale Sankey — the fuse/split visualization

Two horizontal Sankey strips render between the panes:
- Strip 1: between Pane 1 (Σ₁ fine) and Pane 2 (Σ₂ medium)
- Strip 2: between Pane 2 (Σ₂ medium) and Pane 3 (Σ₃ coarse)

Each strip draws:
- Left side: K_fine vertical bars, height ∝ cluster size, colored by
  K-band group color
- Right side: K_coarse vertical bars, same encoding
- Ribbons connecting them: a ribbon from fine cluster `i` to coarse
  cluster `j` has width ∝ count of samples with both labels.

**Reading the diagram:**

| Visual pattern | Interpretation |
|---|---|
| Parallel ribbons, no crossings | clean nested split — coarse cluster fans into K_fine sub-clusters with no mixing → SUBSTRUCTURE / NESTED |
| Single thick ribbon per pair | identical clustering at both scales → STABLE |
| Crossing/braided ribbons | cluster identity reshuffles across scales → UNSTABLE or OVERLAP |
| Two clean families that don't mix | two independent axes (the "never meet" pattern) |

This is the headline diagnostic. The user reads the pattern in seconds.

The fuse/split count table sits below the Sankey as the numerical backup:

```
Σ₁ → Σ₂  fuse events: 3   (clusters f3+f4 → m1, f5+f6 → m2, f0+f1 → m0)
Σ₁ → Σ₂  split events: 0
Σ₂ → Σ₃  fuse events: 1   (clusters m1+m2 → c1)
Σ₂ → Σ₃  split events: 0
```

A "fuse event" is when ≥80% of two or more fine clusters' samples land in
the same coarse cluster. A "split event" is when one fine cluster's
samples land in two or more coarse clusters at ≥20% each (rare but
possible — if K is forced higher at coarse scale than fine).

### Verdict cascade (unchanged labels, refined triggers)

The verdict labels stay the same as last turn's spec. The triggers now
reference fuse/split counts rather than just ARI:

| Verdict | Trigger | Sankey signature |
|---|---|---|
| `STABLE_3BAND` | K=3 used at all 3 scales AND no fuses no splits AND ARI ≥ 0.85 pairwise | three thick parallel ribbons |
| `STABLE_6BAND` | K=6 used at all 3 scales AND no fuses no splits AND ARI ≥ 0.85 pairwise | six thick parallel ribbons |
| `NESTED_3IN6` | K=6 at fine, K=3 at coarse, fuse count = 3, split count = 0 | clean 6→3 fan-in |
| `OVERLAP_BREAKS_3` | K=3 at fine AND coarse, K=6 at medium, fuse + split events at the medium boundary | ribbons reshuffle in middle, restore at edges |
| `UNSTABLE` | otherwise | crossing/braided ribbons, ARI < 0.5 somewhere |

ARI/NMI are still computed (cheap) but rendered as a small footer chip
below the Sankey, not as the primary diagnostic. The verdict pill
itself is prominent.

### State changes

```js
// New top-level state
state.l3Mode = 'contingency' | 'scale_stability'   // default 'contingency'

// New per-pane scale config (only relevant when l3Mode === 'scale_stability')
state.scaleStabilityPanes = [
  { scale: '5w',         K: 6, custom_n: null },   // pane 1 (fine)
  { scale: 'L2',         K: 6, custom_n: null },   // pane 2 (medium)
  { scale: 'candidate',  K: 3, custom_n: null },   // pane 3 (coarse)
]

// Cache (computed lazily, invalidated on focal change or scale change)
state.scaleStabilityCache = {
  fingerprint: string,
  panes: [
    { range: [s, e], K, labels: Int8Array, n_per_group: int[],
      meanPC1: Float32Array, meanPC2: Float32Array, ok: bool, why: string },
    ...
  ],
  pairwise: [
    { from: 0, to: 1, contingency: int[][], ari, nmi,
      fuseEvents: [{ fine_clusters: int[], coarse_cluster: int }],
      splitEvents: [{ fine_cluster: int, coarse_clusters: int[] }] },
    { from: 1, to: 2, ... },
  ],
  verdict: enum,
}
```

Per-pane K is independently picked because the user might want K=6 fine /
K=3 coarse to see the collapse. Default K stays at the toolbar's `K=3+6`
setting (use both, but render the dominant one).

### UI changes summary

1. **Toolbar:** new toggle button `⤢ scale` between `b.continuity:` and
   `recluster:`. When active, hides the unit selector and shows three
   pane-scale dropdowns.
2. **Pane headers:** change from `← slab -1 · w####-####` to
   `Σ₁ fine · <unit> · K=<K>` when toggle is ON.
3. **Inter-pane area:** when toggle is ON, the gap between panes 1↔2 and
   2↔3 hosts the Sankey strip (~60px high each). When OFF, gap reverts
   to the existing thin separator.
4. **Bottom strip:** verdict pill + fuse/split count table + ARI/NMI
   footer chip.
5. **Re-clustering:** changing any pane dropdown invalidates the cache and
   re-runs `getSlabClusterAt` for that pane. Other panes stay cached.

### Computation cost

Per-pane K-means: ~10-30ms each (K-means on 226 samples × ~5w PC1/PC2
data). Sankey computation: contingency build is O(n_samples). Total per
toggle / pane change: ~100ms cold, ~10ms warm (cache hit).

When fine scale dropdown is set to `1w` (single-window K-means), the
result is noisy. Mitigation: if `Σ₁` is `1w`, ALSO show "low confidence"
chip on pane 1 when any cluster has n < 5 samples. Don't fail; just flag.

### Tests (`test_v4_scale_stability_runtime.js`)

- Toggle button toggles `state.l3Mode` and adds `.active` class
- When ON, unit selector is hidden, three pane-scale dropdowns visible
- When OFF, unit selector reactivates, dropdowns hidden
- Per-pane scale change triggers per-pane re-clustering only (cache check)
- SNP-band conversion: synthetic windows with known n_snps return the
  expected smallest range
- kb-band conversion: same with span_bp
- Sankey ribbon count = number of (fine_cluster, coarse_cluster) pairs
  with ≥1 sample in common
- Fuse-event detection: synthetic K=6→K=3 perfect collapse → 3 fuse events
- Split-event detection: synthetic K=3→K=6 perfect expansion → 3 split events
- Verdict NESTED_3IN6: synthetic 6→3 collapse with no reshuffle → label
- Verdict UNSTABLE: random labels at all scales → label
- Cache invalidation on state.cur change

**Estimated size:** ~600 lines code (3-pane scale picker + SNP/kb
band helpers + Sankey renderer + fuse/split detector + verdict cascade
+ tests). Likely 2 chat turns.

### Why this is Deliverable D and not earlier

- Depends on `getSlabClusterAt` (existing) — independent of A/B/C.
- Reuses the existing 3-pane carousel, doesn't touch the candidate
  strip (independent of A) or the candidate registry (independent of
  B/C).
- Order suggestion: **A → D → B → C** if user wants the scale-stability
  test ASAP.
- Verdict labels overlap with §26's `axis_topology` vocabulary —
  STABLE_3BAND ≈ one_axis_3band, NESTED_3IN6 ≈ one_axis_nested,
  OVERLAP_BREAKS_3 ≈ candidate-pair flag for two_axes_independent.
  When C ships, the scale-stability verdict can pre-fill a regime's
  `axis_topology` field as a suggestion (still user-confirmable).

### Critical caveats

- **The verdict thresholds are heuristic** — fuse/split count thresholds
  (≥80% mapping rate to fuse, ≥20% split mass), ARI ≥ 0.85, plus the
  K-choice logic per pane. None are validated against ground truth in
  this cohort. Document them as adjustable, NOT publication-ready calls.
- **K-means on PC1/PC2 inherits the same biases as before** — broodline
  structure, ROH effects, family LD. A "STABLE_6BAND" verdict doesn't
  prove biology; it just proves the band structure is robust to scale.
  Cross-reference with the ancestry-confound test (queued from prior
  turn) before claiming biological reality.
- **Single-window K-means is noisy.** With 226 samples and 1 window, K=6
  often finds spurious clusters. The "low confidence" chip when any
  cluster has n < 5 samples is essential. Encourage users to default
  fine scale to 5w or 100 SNPs, not 1w.
- **SNP-band conversions are sensitive to assembly gaps.** Near gaps
  the symmetric-expansion algorithm hits a chromosome boundary and
  the band becomes one-sided. Flag this in the pane header
  (`asymmetric: 50w left only` style note) so the user knows.

---

## Recommended order

A → D → B → C, with checkpoints between.

Why insert D before B/C: D is the test that distinguishes "real 6-band" from
"3-band-with-substructure," which directly informs whether the regime
registry (C) is even needed. If most candidates come back NESTED_3IN6 or
STABLE_3BAND, the many-to-many band→regime mapping is overkill — most
candidates fit the simple "one regime per candidate" model. C is then
scoped down. If candidates come back STABLE_6BAND or OVERLAP_BREAKS_3,
C is justified.

A is still first because it's smallest and unblocks fine-scale candidate
drafting — which D needs anyway (D's `Σ_min` works better when the user
can draft at window resolution).

### Checkpoints between deliverables

1. **After A**: real-data testing on LG28 — does window-resolution drafting
   help with the "candidate smaller than L2" cases? If users find
   window-mode awkward (too many ticks, hard to click precisely),
   reconsider before D.

2. **After D**: run the scale-stability verdict on every K=6 candidate in
   LG28's catalogue. If the verdict distribution is dominated by
   STABLE_3BAND / NESTED_3IN6, the many-to-many regime mapping (C) is
   overkill and can be scoped down. If STABLE_6BAND or OVERLAP_BREAKS_3
   is common, C is justified.

3. **After B**: overlapping candidates can be drawn but no UX exists for
   creating them deliberately yet. The catalogue's regimes column is
   still empty. Acceptable interim — users can create overlapping
   candidates by running the existing flow twice.

4. **C ships the rest.** After C the full data model is usable.

If only one deliverable can ship before the next data freeze: ship A.
If two: A + D.

---

## What NOT to do in these deliverables

- Do NOT auto-assign `axis_topology`. The scrubber doesn't run the
  architecture-call analysis. Keep the field user-editable.
- Do NOT introduce L3 as a hierarchical level (no `state.data.l3_envelopes`,
  no per-L3 clustering). L3 cuts live with their candidate, period.
- Do NOT migrate old candidates eagerly. Read-side migration only.
  Re-saving a candidate (any edit) writes the new shape.
- Do NOT add a per-regime page. Regimes are list+inline-editor only.
  A dedicated page is a v4.5 thing if users ask for it.
- Do NOT block the per-window row UI on the regime registry. They are
  independent features. Ship A standalone if needed.
- Do NOT publish the scale-stability verdict thresholds (D) as if they
  were validated. They're heuristic defaults; the user needs to tune
  them on a per-cohort basis. The verdict is decision support, not a
  publication-ready call.
- Do NOT auto-promote a scale-stability verdict into a regime's
  `axis_topology` without user confirmation. Suggest, don't decide.
