#!/usr/bin/env node
// =============================================================================
// v4: Diversity Atlas landing page (page13) runtime tests
// =============================================================================
// Tests the page13 layout/scaffold introduced in v4. Quentin: "Make layout
// page of diversity atlas." This page is layout-only — pure HTML, no JS
// rendering hooks — so all tests are markup checks. Phase B (toggle button)
// and phase C (per-page renderers) ship in follow-up turns.
//
// Coverage:
//   - page13 div present in DOM
//   - tab button present at end of tab bar with correct linkage
//   - 6 section cards present
//   - 7 data-layer rows have data-da-layer attribute
//   - 13 page-mapping table rows present
//   - 6 dashboard mockup panels present
//   - 4 phasing-roadmap rows present
//   - cross-references present
//   - SCRUBBER_VERSION renamed v4.1 → v4
// =============================================================================

const fs = require('fs');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; console.log('  PASS', msg); }
  else { fail++; console.log('  FAIL', msg); }
}

console.log('\n--- v4: Diversity Atlas landing page runtime tests ---');

// ============================================================================
// 1. v4 cut version markers
// ============================================================================
console.log('\n  --- v4 cut version markers ---');
ok(/const SCRUBBER_VERSION = 'v4'/.test(html),
   'SCRUBBER_VERSION = v4 (renamed from v4.1)');
ok(/<title>Local PCA Scrubber v4 — L3 Contingency Debugger<\/title>/.test(html),
   '<title> renamed to "Local PCA Scrubber v4"');
ok(/`Inversion catalogue export — local PCA scrubber v4`/.test(html),
   'catalogue export header has v4 string');
ok(/tool: 'pca_scrubber_v4'/.test(html),
   "JSON tool ID is 'pca_scrubber_v4'");
ok(/'pca_scrubber v4'/.test(html),
   'PNG watermark is "pca_scrubber v4"');

// ============================================================================
// 2. page13 DOM + tab linkage
// ============================================================================
console.log('\n  --- page13 DOM + tab linkage ---');
ok(/<div id="page13" class="page">/.test(html),
   'page13 div present');
ok(/<button data-page="page13"[^>]*>[\s\S]{0,300}<\/button>/.test(html),
   'page13 tab button present in tabBar');
ok(/Diversity Atlas \(preview \/ scaffold\)/.test(html),
   'page13 tab button tooltip contains "(preview / scaffold)" status');
ok(/<span class="num">13<\/span> diversity atlas/.test(html),
   'page13 tab button shows "13" with "diversity atlas" label');
// Tab button placed at the end — there should be no other data-page="..." button after it
// within the #tabBar nav. Scope the check to within the tabBar block, since
// "data-page=" also appears in many JS strings throughout the file.
const tabBarBlock = html.match(/<nav id="tabBar"[\s\S]+?<\/nav>/);
ok(tabBarBlock !== null, '<nav id="tabBar"> block found in DOM');
if (tabBarBlock) {
  const tb = tabBarBlock[0];
  const lastTabPosInBar = tb.lastIndexOf('data-page="page');
  const page13PosInBar = tb.indexOf('data-page="page13"');
  ok(page13PosInBar === lastTabPosInBar,
     'page13 tab button is the LAST tab in the tab bar (preserves 1-12 numbering)');
}

// ============================================================================
// 3. Six section cards present
// ============================================================================
console.log('\n  --- 6 section cards ---');
ok(/The dual-atlas idea/.test(html),
   'Section 1: dual-atlas concept card');
ok(/Required data layers/.test(html),
   'Section 2: data layers status grid');
ok(/Per-page mapping/.test(html),
   'Section 3: page-mapping table');
ok(/Diversity dashboard — planned panels/.test(html),
   'Section 4: dashboard mockup');
ok(/Phasing roadmap/.test(html),
   'Section 5: phasing roadmap');
ok(/Cross-references/.test(html),
   'Section 6: cross-references');

// ============================================================================
// 4. Data-layer rows with data-da-layer attribute (7 layers)
// ============================================================================
console.log('\n  --- data-da-layer rows ---');
const expectedLayers = [
  'theta_pi_per_window',
  'per_sample_theta_pi',
  'per_sample_froh',
  'roh_segments',
  'ancestry_q',
  'kinship_matrix',
  'family_ld',
];
for (const layer of expectedLayers) {
  const re = new RegExp(`data-da-layer="${layer}"`);
  ok(re.test(html), `data-da-layer="${layer}" row present`);
}
// All seven start at "⚪ not loaded" status
const notLoadedCount = (html.match(/data-da-layer="[^"]+"\s+style="[^"]*">⚪ not loaded</g) || []).length;
ok(notLoadedCount === 7,
   `all 7 data-layer rows show "⚪ not loaded" initial state (got ${notLoadedCount})`);

// ============================================================================
// 5. Page-mapping table — 13 rows × 4 cols
// ============================================================================
console.log('\n  --- page-mapping table (13 tabs) ---');
// Each row in the mapping table has the tab number followed by inversion mode
// description. We sniff by a few representative rows.
ok(/local PCA \|z\| \(dosage\)[\s\S]{0,200}local PCA θπ ← already shipped as page 12/.test(html),
   'page mapping row 1: inversion mode |z| → diversity mode points to page 12');
ok(/candidate focus \(per inversion\)[\s\S]{0,200}region focus \(per ROH or sweep window\)/.test(html),
   'page mapping row 3: candidate focus → region focus');
ok(/boundaries \(refine inversion intervals\)[\s\S]{0,200}ROH atlas \(per-sample ROH catalog\)/.test(html),
   'page mapping row 4: boundaries → ROH atlas');
ok(/catalogue \(L2 envelopes\)[\s\S]{0,200}region catalogue \(sweeps \+ selection scans\)/.test(html),
   'page mapping row 5: catalogue → region catalogue');
ok(/karyotype \/ tier[\s\S]{0,200}ancestry-Q stratification view/.test(html),
   'page mapping row 6: karyotype → ancestry-Q stratification');
ok(/popstats[\s\S]{0,200}atlas-shared/.test(html),
   'page mapping row 7: popstats is atlas-shared');
ok(/markers \(PCR diagnostics\)[\s\S]{0,200}hidden in diversity mode/.test(html),
   'page mapping row 11: markers hidden in diversity mode');
ok(/this page \(Diversity Atlas preview\)/.test(html),
   'page mapping row 13: this page itself referenced');

// ============================================================================
// 6. Dashboard mockup — 6 panel slots
// ============================================================================
console.log('\n  --- dashboard mockup (6 panel slots) ---');
const panelTitles = [
  'θπ overview',
  'F_ROH summary',
  'ROH atlas',
  'Ancestry-Q stratification',
  'Kinship / relatedness',
  'Family-restricted LD',
];
for (const title of panelTitles) {
  // Each panel has its title in a font-weight:600 div
  const re = new RegExp(`font-weight: 600;[^"]*"[^>]*>\\s*${title.replace(/[/]/g, '\\/').replace(/_/g, '_')}\\s*<`);
  ok(re.test(html), `dashboard panel "${title}" present`);
}
// Each panel has a "░░░ panel mockup ░░░" placeholder
const placeholders = (html.match(/░░░ panel mockup ░░░/g) || []).length;
ok(placeholders === 6,
   `6 panel mockup placeholders rendered (got ${placeholders})`);

// ============================================================================
// 7. Phasing roadmap (4 phases A B C D)
// ============================================================================
console.log('\n  --- phasing roadmap (A B C D) ---');
ok(/schema-only commitment[\s\S]{0,500}✓ shipped \(this turn\)/.test(html),
   'Phase A: schema-only commitment ✓ shipped this turn');
ok(/toggle button \+ state slot[\s\S]{0,500}⚪ next turn/.test(html),
   'Phase B: toggle button + state slot ⚪ next turn');
ok(/per-page diversity-mode renderers[\s\S]{0,500}⚪ multi-turn/.test(html),
   'Phase C: per-page renderers ⚪ multi-turn');
ok(/catalogue \+ bundle forking[\s\S]{0,500}⚪ later/.test(html),
   'Phase D: catalogue + bundle forking ⚪ later');

// ============================================================================
// 8. Cross-references
// ============================================================================
console.log('\n  --- cross-references ---');
ok(/page 12 \(local PCA θπ\)[\s\S]{0,200}orthogonal-validation tool/.test(html),
   'cross-ref to page 12 (θπ scrubber)');
ok(/page 7 \(popstats\)[\s\S]{0,200}atlas-shared/.test(html),
   'cross-ref to page 7 (popstats — atlas-shared)');
ok(/page 8 \(ancestry\)[\s\S]{0,200}atlas-shared/.test(html),
   'cross-ref to page 8 (ancestry — atlas-shared)');
ok(/SCHEMA §17/.test(html),
   'cross-ref to SCHEMA §17 (atlas-mode-switching spec)');
ok(/SCHEMA §23/.test(html),
   "cross-ref to SCHEMA §23 (this page's spec)");

// ============================================================================
// 9. state.atlas slot mentioned in card content
// ============================================================================
console.log('\n  --- state.atlas slot referenced ---');
ok(/state\.atlas[\s\S]{0,200}inversion[\s\S]{0,50}diversity/.test(html),
   'state.atlas ∈ {inversion, diversity} described in card 1');
ok(/persisted to localStorage/.test(html),
   'state.atlas localStorage persistence noted');

console.log(`\n--- v4 Diversity Atlas page13 runtime tests: ${pass}/${pass + fail} ---`);
if (fail > 0) process.exit(1);
