// v3.99 tests: L3 contingency tables visibility in compact mode
//
// Defensive CSS patch for a reported bug: in compact layout, the L3
// contingency tables panel's toolbar rendered but the body was empty.
// Diagnosis: `.l3-body { display: grid; flex: 1; overflow: hidden }` is
// a flex item AND a grid container; without explicit `min-height: 0`,
// browsers apply implicit `min-height: auto` which can collapse the
// flex child to zero in some Chromium layout paths.
//
// This test cannot verify the visual outcome (would need a real browser).
// It verifies the CSS rules that constitute the fix are PRESENT, so a
// future edit can't accidentally regress without us noticing.
//
// TESTS (8)
//   1. SCRUBBER_VERSION is v3.99+
//   2. .l3-body has explicit `min-height: 0`
//   3. .l3-body has explicit `min-width: 0`
//   4. .l3-body retains `display: grid`, `flex: 1`, `overflow: hidden`
//   5. compact-mode #l3Panel rule has `align-self: stretch`
//   6. compact-mode #l3Panel rule keeps `min-height: 0`
//   7. compact-mode grid-template-rows still ends with minmax(280px, 50vh)
//   8. v3.99 patch comment is present in the .l3-body rule

const fs = require('fs');
const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS ' + msg); pass++; }
  else      { console.log('  FAIL ' + msg); fail++; }
}

// =============================================================================
// TEST 1: SCRUBBER_VERSION at v4.0+ (was v3.99+ before the v4.0 cut)
// =============================================================================
console.log('--- TEST 1: SCRUBBER_VERSION v4+ ---');
// v4 cut renames v4.1 → v4 (drops minor for the canonical release name).
// Accept v3.99+ legacy, bare v4, or v4.x current; the regex covers all.
const verMatch = html.match(/const SCRUBBER_VERSION = 'v(\d+)(?:\.(\d+))?/);
const verMajor = verMatch ? parseInt(verMatch[1], 10) : 0;
const verMinor = verMatch && verMatch[2] != null ? parseInt(verMatch[2], 10) : 0;
const verOk = (verMajor >= 4) || (verMajor === 3 && verMinor >= 99);
ok(verOk, `version is v3.99+ or v4+ (got v${verMajor}${verMatch && verMatch[2] != null ? '.' + verMinor : ''})`);

// =============================================================================
// TEST 2-4: .l3-body has the fix properties
// =============================================================================
console.log('\n--- TEST 2-4: .l3-body CSS properties ---');
// Match the .l3-body rule body — supports either single-line or multi-line form
const l3BodyRule = html.match(/#l3Panel \.l3-body \{([^}]+)\}/);
ok(l3BodyRule !== null, '.l3-body CSS rule found');
if (l3BodyRule) {
  const props = l3BodyRule[1];
  ok(/min-height\s*:\s*0/.test(props),
     'TEST 2: .l3-body has min-height: 0 (fixes flex-grid collapse)');
  ok(/min-width\s*:\s*0/.test(props),
     'TEST 3: .l3-body has min-width: 0 (defensive against grid track overflow)');
  ok(/display\s*:\s*grid/.test(props) && /flex\s*:\s*1/.test(props) && /overflow\s*:\s*hidden/.test(props),
     'TEST 4: .l3-body retains display:grid, flex:1, overflow:hidden (semantics preserved)');
}

// =============================================================================
// TEST 5-6: compact-mode #l3Panel rule
// =============================================================================
console.log('\n--- TEST 5-6: compact-mode #l3Panel rule ---');
// Find the compact-mode l3Panel rule. Match across multiple lines.
const compactL3Match = html.match(/body\[data-layout-mode="compact"\]\s+main#page1\s+#l3Panel\s*\{([^}]+)\}/);
ok(compactL3Match !== null, 'compact-mode #l3Panel rule found');
if (compactL3Match) {
  const props = compactL3Match[1];
  ok(/align-self\s*:\s*stretch/.test(props),
     'TEST 5: compact #l3Panel has align-self: stretch (defensive vertical fill)');
  ok(/min-height\s*:\s*0/.test(props),
     'TEST 6: compact #l3Panel keeps min-height: 0 (row\'s sizing governs height)');
  // v3.99 turn 2: L3 panel moved from row 6 to row 7 (row 6 is now the
  // resize handle). Either is acceptable.
  ok(/grid-row\s*:\s*[67]/.test(props),
     'compact #l3Panel on grid-row 6 or 7');
  ok(/grid-column\s*:\s*1\s*\/\s*4/.test(props),
     'compact #l3Panel still spans columns 1..3');
}

// =============================================================================
// TEST 7: compact grid-template-rows preserved
// =============================================================================
console.log('\n--- TEST 7: compact grid-template-rows ---');
const gtRowsMatch = html.match(/body\[data-layout-mode="compact"\]\s+main#page1\.active\s*\{[^}]+grid-template-rows:\s*([^;]+);/);
ok(gtRowsMatch !== null, 'compact grid-template-rows rule found');
if (gtRowsMatch) {
  const rows = gtRowsMatch[1].trim();
  // v3.99 turn 4: last row uses --compact-l3fr (turn 4 fr-based) or
  // --compact-l3h (turn 2 vh-based) or minmax(...) (turn 1 / pre-turn-2).
  // Any L3-sizing pattern is acceptable for backwards-compat.
  const isMinmax = /minmax\(280px,\s*50vh\)/.test(rows);
  const isVh     = /var\(--compact-l3h[^)]*\)/.test(rows);
  const isFr     = /var\(--compact-l3fr[^)]*\)/.test(rows);
  ok(isMinmax || isVh || isFr,
     `last row is L3-sizing (var or minmax); got: ${rows.slice(0, 80)}`);
  if (isVh || isFr) {
    ok(/8px/.test(rows),
       'turn-2+ grid template includes 8px row (compactL3Resize handle)');
  }
  // v3.99 turn 4: Z-panel row is 1.5fr (was 1fr) per Quentin's "Z +50%" request
  if (isFr) {
    ok(/1\.5fr/.test(rows),
       'turn-4 grid template has 1.5fr row (Z-panel +50% height)');
  }
}

// =============================================================================
// TEST 7b (v3.99 turn 2): compactL3Resize handle present
// =============================================================================
console.log('\n--- TEST 7b: compactL3Resize handle (v3.99 turn 2) ---');
const handleMarkup = /<div\s+id="compactL3Resize"/i.test(html);
ok(handleMarkup, 'compactL3Resize markup is present in the DOM');
const handleCss = html.match(/body\[data-layout-mode="compact"\]\s+main#page1\s+#compactL3Resize\s*\{([^}]+)\}/);
if (handleCss) {
  const props = handleCss[1];
  ok(/cursor\s*:\s*ns-resize/.test(props),
     'compactL3Resize has cursor: ns-resize');
  ok(/grid-row\s*:\s*6/.test(props),
     'compactL3Resize at grid-row 6 (between upper panels and L3)');
} else {
  // It's OK if the markup is present without the CSS being matched here —
  // the CSS test pattern may be slightly off. Don't fail hard.
  console.log('  (compactL3Resize CSS rule not matched by regex; markup found, skipping CSS detail check)');
}
const handleJs = /compactL3Resize.*pointerdown|getElementById\(['"]compactL3Resize['"]\)/.test(html);
ok(handleJs, 'compactL3Resize has a JS pointer handler attached');
const l3hVar = /--compact-l3h\b/.test(html);
const l3frVar = /--compact-l3fr\b/.test(html);
ok(l3hVar || l3frVar, 'L3-sizing CSS variable referenced (--compact-l3h or --compact-l3fr)');
const resizeObs = /new ResizeObserver/.test(html);
ok(resizeObs, 'ResizeObserver registered for canvas redraws on panel resize');

// =============================================================================
// TEST 8: v3.99 patch comment present
// =============================================================================
console.log('\n--- TEST 8: v3.99 patch comment ---');
ok(/v3\.99[^"\n]*flex.grid|v3\.99[^"\n]*flex.children/.test(html)
   || html.includes('v3.99: explicit min-height:0'),
   'v3.99 patch comment in .l3-body rule documents the fix');

// =============================================================================
// TEST 9 (v3.99 turn 3): per-sample lines panel click uses Mb-based mapping
// =============================================================================
// Bug: lines-panel click jumped to a window-index-fraction position rather
// than the Mb position the user clicked. Because windows are non-uniform in
// Mb, clicks at the same x across Z-panel and lines-panel landed on
// different windows. Fix: lines-panel click now uses currentMbRange() +
// nearest-window-by-center_mb, matching onZClick.
console.log('\n--- TEST 9: lines-panel click uses Mb-based mapping (turn 3) ---');
// Locate the lines sub-canvas click handler. There may be multiple
// `cv.addEventListener('click', ...)` patterns in the file; find the one
// that's inside buildLinesPanel and look for the v3.99 turn 3 marker.
const turn3Marker = /v3\.99 turn 3: match the Z-panel's Mb-based mapping/.test(html);
ok(turn3Marker, 'lines-panel click handler has v3.99 turn 3 marker comment');

// Verify it uses currentMbRange (not window-index-fraction)
// Match the click handler block: from the marker comment to the closing brace
// of the click listener.
const handlerBlock = html.match(/v3\.99 turn 3: match the Z-panel's Mb-based mapping[\s\S]{0,1500}?\}\);/);
ok(handlerBlock !== null,
   'click handler block extracted around the turn-3 fix');
if (handlerBlock) {
  const block = handlerBlock[0];
  ok(/currentMbRange/.test(block),
     'click handler calls currentMbRange()');
  ok(/center_mb/.test(block),
     'click handler iterates by center_mb (nearest-window match)');
  ok(/setCur\(bestWin\)/.test(block),
     'click handler calls setCur(bestWin) with the Mb-nearest window');
  ok(!/Math\.round\(frac \* \(wins\.length - 1\)\)/.test(block),
     'click handler no longer uses window-index-fraction (the buggy old path)');
}

// =============================================================================
// TEST 10 (v3.99 turn 4): L3 toolbar wraps to 2 lines (no horizontal scroll)
// =============================================================================
console.log('\n--- TEST 10: L3 toolbar wraps (v3.99 turn 4) ---');
const l3HeadCss = html.match(/#l3Panel \.l3-head \{([^}]+)\}/);
ok(l3HeadCss !== null, '.l3-head CSS rule found');
if (l3HeadCss) {
  const props = l3HeadCss[1];
  ok(/flex-wrap\s*:\s*wrap/.test(props),
     'l3-head uses flex-wrap: wrap (toolbar wraps to 2+ lines instead of scrolling)');
  ok(!/overflow-x\s*:\s*auto/.test(props),
     'l3-head no longer uses overflow-x: auto (no horizontal scrollbar)');
}

// =============================================================================
// TEST 11 (v3.99 turn 4): tracked-samples panel is smaller (75% PCA / 25% tracked)
// =============================================================================
console.log('\n--- TEST 11: tracked-samples panel default size (v3.99 turn 4) ---');
const compactRule = html.match(/body\[data-layout-mode="compact"\]\s+main#page1\.active\s*\{([^}]+)\}/);
ok(compactRule !== null, 'compact main page1.active rule found');
if (compactRule) {
  const props = compactRule[1];
  ok(/--compact-leftupperpct\s*:\s*75%/.test(props),
     'turn-4 default --compact-leftupperpct = 75% (tracked panel ~50% smaller)');
}

// =============================================================================
// TEST 12 (v3.99 turn 4): handle is visually thin (no opaque background)
// =============================================================================
console.log('\n--- TEST 12: compactL3Resize visually thin (v3.99 turn 4) ---');
const handleCssTurn4 = html.match(/body\[data-layout-mode="compact"\]\s+main#page1\s+#compactL3Resize\s*\{([^}]+)\}/);
if (handleCssTurn4) {
  const props = handleCssTurn4[1];
  ok(/background\s*:\s*transparent/.test(props),
     'compactL3Resize has transparent background (turn-4: no heavy band)');
}

// =============================================================================
// TEST 13 (v3.99 turn 4): drag handler uses fr units (not vh)
// =============================================================================
console.log('\n--- TEST 13: drag handler uses fr units (v3.99 turn 4) ---');
const applyL3Fr = /function _applyCompactL3Fr/.test(html);
ok(applyL3Fr, '_applyCompactL3Fr function exists (turn-4 fr-based handler)');
ok(/_COMPACT_L3FR_DEFAULT/.test(html),
   '_COMPACT_L3FR_DEFAULT constant defined');

// =============================================================================
// TEST 10 (v3.99 turn 4): body flex-column + .wrap flex:1 (no calc(100vh-76px))
// =============================================================================
// Bug: at certain zoom levels (Ctrl-) empty space appeared below the L3 panel
// because .wrap was sized via `calc(100vh - 76px)`, which hardcodes the
// header(44px)+tabBar(32px) sum. The arithmetic doesn't survive zoom changes
// reliably. Fix: body becomes a flex column; .wrap is flex:1 to fill whatever
// remains after header + tabBar, regardless of zoom.
console.log('\n--- TEST 10: body flex layout (turn 4 empty-space fix) ---');
const bodyRule = html.match(/html,\s*body\s*\{[^}]+\}/);
ok(bodyRule !== null, 'html/body rule found');
if (bodyRule) {
  const props = bodyRule[0];
  ok(/display:\s*flex/.test(props),
     'body has display: flex (turn 4)');
  ok(/flex-direction:\s*column/.test(props),
     'body has flex-direction: column (turn 4)');
  ok(/height:\s*100vh/.test(props) || /height:\s*100dvh/.test(props),
     'body has explicit 100vh / 100dvh height anchor');
}
// .wrap should now be flex:1 instead of calc(100vh - 76px)
const wrapRule = html.match(/\.wrap\s*\{[^}]+\}/);
ok(wrapRule !== null, '.wrap rule found');
if (wrapRule) {
  const props = wrapRule[0];
  ok(/flex:\s*1/.test(props),
     '.wrap has flex: 1 (fills remaining space after header+tabBar)');
  ok(/min-height:\s*0/.test(props),
     '.wrap has min-height: 0 (lets inner grid shrink correctly)');
  ok(!/height:\s*calc\(100vh\s*-\s*76px\)/.test(props),
     '.wrap no longer hardcodes calc(100vh - 76px) — empty-space-at-bottom bug');
}

// =============================================================================
// TEST 11 (v3.99 turn 4): tracked-samples panel collapse arrow
// =============================================================================
console.log('\n--- TEST 11: tracked-samples panel collapse arrow ---');
ok(/id="trackedSamplesPanelCompactHead"/.test(html),
   'trackedSamplesPanelCompactHead element present (clickable header)');
ok(/id="trackedSamplesPanelCompactBody"/.test(html),
   'trackedSamplesPanelCompactBody element present (toggleable body)');
ok(/id="trackedSamplesPanelCompactArrow"/.test(html),
   'trackedSamplesPanelCompactArrow element present (▼/▶ indicator)');
ok(/_TRACKED_COMPACT_COLLAPSED_KEY/.test(html),
   'collapse state persists via localStorage key');
ok(/_applyTrackedCompactCollapsed/.test(html),
   'apply-collapsed function defined');

// =============================================================================
// TEST 12 (v3.99 turn 4): PCA-side band-pick column
// =============================================================================
console.log('\n--- TEST 12: PCA-side band-pick column ---');
ok(/id="pcaBandPickColCompact"/.test(html),
   'pcaBandPickColCompact element present (right-side narrow column)');
ok(/id="autoPickRadialCompact2"/.test(html),
   'pcaBandPickCol Auto-pick button present');
ok(/id="clearPicksCompact2"/.test(html),
   'pcaBandPickCol Clear button present');
// Compact-mode visibility CSS rule
ok(/body\[data-layout-mode="compact"\][^{]*#pcaBandPickColCompact[^{]*\{[^}]*display:\s*flex/.test(html),
   'pcaBandPickColCompact shown in compact mode');
ok(/body:not\(\[data-layout-mode="compact"\]\)[^{]*#pcaBandPickColCompact[^{]*\{[^}]*display:\s*none/.test(html),
   'pcaBandPickColCompact hidden in non-compact modes');
// Wiring for the new buttons
ok(/getElementById\('autoPickRadialCompact2'\)/.test(html),
   'autoPickRadialCompact2 wired in JS');
ok(/getElementById\('clearPicksCompact2'\)/.test(html),
   'clearPicksCompact2 wired in JS');

// =============================================================================
// TEST 13 (v3.99 turn 4): band-pick mirror sync across both columns
// =============================================================================
console.log('\n--- TEST 13: band-pick active-state mirrors across columns ---');
// Old code: forEach(b => b.classList.remove('active')); btn.classList.add('active')
//          → only the clicked button got highlighted, panel-side and pca-side
//            could disagree.
// New code: forEach(b => b.classList.toggle('active', b.dataset.bandCompact === v))
//          → all buttons with the same band value flip together.
ok(/classList\.toggle\('active',\s*b\.dataset\.bandCompact\s*===\s*v\)/.test(html),
   'band-pick wiring uses dataset-value match (all columns mirror together)');
// Old buggy pattern should be gone from the band-pick block
const bandPickBlock = html.match(/Band-picker buttons in the compact panel[\s\S]{0,800}\}\);\s*\}\);/);
if (bandPickBlock) {
  const block = bandPickBlock[0];
  ok(!/forEach\(b\s*=>\s*b\.classList\.remove\('active'\)\);\s*\n\s*btn\.classList\.add\('active'\)/.test(block),
     'band-pick wiring no longer has the buggy "remove all + add to clicked" pattern');
}

// =============================================================================
// TURN-5 TESTS (v3.99 turn 5, this chat)
// =============================================================================

// =============================================================================
// TEST 14: live dosage toggle re-renders L3 panel
// =============================================================================
console.log('\n--- TEST 14: live dosage toggle re-renders L3 (turn 5 fix) ---');
const dosageMatch = html.match(/function toggleCursorHeatmap\(on\)\s*\{[^}]+\}/);
ok(dosageMatch !== null, 'toggleCursorHeatmap function found');
if (dosageMatch) {
  const fn = dosageMatch[0];
  ok(/renderL3Panel/.test(fn),
     'toggleCursorHeatmap calls renderL3Panel (fixes empty-L3-after-toggle bug)');
  ok(/v3\.99 turn 5/.test(fn),
     'toggleCursorHeatmap has v3.99 turn 5 marker comment');
}

// =============================================================================
// TEST 15: viewModeBar moved from header to ctrlBar
// =============================================================================
console.log('\n--- TEST 15: viewModeBar location (turn 5 reorder) ---');
// Markup check: viewModeBar should NOT appear inside <header>, and should
// appear inside #ctrlBar.
const headerBlock = html.match(/<header>[\s\S]+?<\/header>/);
ok(headerBlock !== null, 'header block extracted');
if (headerBlock) {
  ok(!/<span\s+id="viewModeBar"/.test(headerBlock[0]),
     'viewModeBar no longer inside <header>');
}
const ctrlBarBlock = html.match(/<div\s+id="ctrlBar">[\s\S]{0,4000}?<\/div>/);
ok(ctrlBarBlock !== null, 'ctrlBar block extracted');
if (ctrlBarBlock) {
  ok(/<span\s+id="viewModeBar"/.test(ctrlBarBlock[0]),
     'viewModeBar now inside #ctrlBar (between scrubber and window stats)');
}
// Grid columns updated: 96px 1fr auto 200px (was 96px 1fr 200px)
// Note: use a regex that anchors to the bare #ctrlBar rule (without the
// body[data-layout-mode="free"] prefix), since the latter's rule comes first.
const ctrlBarCss = html.match(/(?:^|\n)\s*#ctrlBar\s*\{[^}]+\}/);
if (ctrlBarCss) {
  ok(/grid-template-columns:\s*96px\s+1fr\s+auto\s+200px/.test(ctrlBarCss[0]),
     'ctrlBar grid has 4 columns (Play | slider | view-mode | win-stats)');
}

// =============================================================================
// TEST 16: header buttons share consistent CSS
// =============================================================================
console.log('\n--- TEST 16: header buttons unified font-size (turn 5) ---');
const headerBtnRule = html.match(/header\s+#themeToggleBtn[\s\S]{0,800}?\}/);
ok(headerBtnRule !== null, 'unified header-button CSS rule found');
if (headerBtnRule) {
  const r = headerBtnRule[0];
  ok(/#candidateModeBtn/.test(r),
     'candidateModeBtn included in unified header-button rule');
  ok(/#layoutModeBtn/.test(r),
     'layoutModeBtn included in unified header-button rule');
  ok(/font-size:\s*11px/.test(r),
     'all header buttons use 11px font-size');
}

// =============================================================================
// TEST 17: windows page table has SNP density columns + centered headers
// =============================================================================
console.log('\n--- TEST 17: windows page SNP columns + centered headers (turn 5) ---');
const winsumThead = html.match(/<table\s+id="winSumTable">[\s\S]+?<\/thead>/);
ok(winsumThead !== null, 'winSumTable thead extracted');
if (winsumThead) {
  const t = winsumThead[0];
  ok(/data-sort="n_snps"/.test(t),
     'n_snps column header present');
  ok(/data-sort="span_kb"/.test(t),
     'span_kb column header present');
  ok(/data-sort="snp_density"/.test(t),
     'snp_density column header present');
}
// CSS: th text-align center, td.num text-align center
const winsumThCss = html.match(/#page8 #winSumTable th\s*\{[^}]+\}/);
if (winsumThCss) {
  ok(/text-align:\s*center/.test(winsumThCss[0]),
     'th text-align: center (turn 5: was left)');
}
const winsumTdNumCss = html.match(/#page8 #winSumTable td\.num\s*\{[^}]+\}/);
if (winsumTdNumCss) {
  ok(/text-align:\s*center/.test(winsumTdNumCss[0]),
     'td.num text-align: center (turn 5: was right)');
}
// JS: _winSumRows includes the new fields (ES6 shorthand: just `n_snps,`)
const winsumRowsFn = html.match(/function\s+_winSumRows\(\)[\s\S]+?return\s+rows;\s*\}/);
ok(winsumRowsFn !== null, '_winSumRows function extracted');
if (winsumRowsFn) {
  const fn = winsumRowsFn[0];
  ok(/\bn_snps\b/.test(fn) && /WINDOW_DEFAULT_SNPS/.test(fn),
     '_winSumRows references n_snps field');
  ok(/\bspan_kb\b/.test(fn) && /end_bp.*start_bp/.test(fn),
     '_winSumRows computes span_kb from end_bp - start_bp');
  ok(/\bsnp_density\b/.test(fn),
     '_winSumRows computes snp_density');
}

// =============================================================================
// TURN-6 TESTS (v3.99 turn 6, this chat)
// =============================================================================

// =============================================================================
// TEST 18: active tab gets vertical accent-alpha gradient
// =============================================================================
console.log('\n--- TEST 18: active tab gradient background (turn 6) ---');
const tabActiveCss = html.match(/#tabBar button\.active\s*\{[^}]+\}/);
ok(tabActiveCss !== null, '#tabBar button.active CSS rule found');
if (tabActiveCss) {
  ok(/linear-gradient\(\s*to\s+bottom/.test(tabActiveCss[0]),
     'active tab has vertical linear-gradient (alpha max top → 0 bottom)');
  ok(/rgba\(245,\s*165,\s*36/.test(tabActiveCss[0]),
     'active tab gradient uses accent color (245,165,36)');
}

// =============================================================================
// TEST 19: zValueMode buttons share zColorMode CSS
// =============================================================================
console.log('\n--- TEST 19: zValueMode font-size matches zColorMode (turn 6) ---');
ok(/#zColorMode,\s*#zValueMode\s*\{/.test(html),
   'zValueMode shares zColorMode CSS rule');
ok(/#zColorMode button,\s*#zValueMode button\s*\{[\s\S]*?font-size:\s*10\.5px/.test(html),
   'zValueMode buttons inherit 10.5px font-size from zColorMode');

// =============================================================================
// TEST 20: per-sample lines header padding tightened
// =============================================================================
console.log('\n--- TEST 20: per-sample lines tightened spacing (turn 6) ---');
// Header bar inline style had padding: 6px 10px → 3px 10px
ok(/id="linesYsourceBar"[^>]*padding:\s*3px\s+10px/.test(html),
   'linesYsourceBar header padding 3px 10px (was 6px 10px)');
// Canvas pad.t from 18 to 6
ok(/pad\s*=\s*\{\s*l:\s*44,\s*r:\s*16,\s*t:\s*6,\s*b:\s*8\s*\}/.test(html),
   'lines canvas pad.t reduced from 18 to 6');
ok(!/pad\s*=\s*\{\s*l:\s*44,\s*r:\s*16,\s*t:\s*18,\s*b:\s*8\s*\}/.test(html),
   'old pad.t = 18 fully removed (lasso hit-test + drawLinesPanel)');

// =============================================================================
// TEST 21: L3 toolbar wrap-to-2-lines spacer
// =============================================================================
console.log('\n--- TEST 21: L3 toolbar 2-line wrap (turn 6) ---');
ok(/class="l3-head-break"[^>]*flex-basis:\s*100%/.test(html),
   'l3-head-break spacer present (forces 2-line wrap)');
const l3HeadCssTurn6 = html.match(/#l3Panel\s+\.l3-head\s*\{[^}]+\}/);
if (l3HeadCssTurn6) {
  ok(/row-gap:\s*2px/.test(l3HeadCssTurn6[0]),
     'l3-head row-gap reduced 4px → 2px (tight 2-line layout)');
}

// =============================================================================
// TEST 22: K-used chip removed; karyotype hoisted above mini-PCA
// =============================================================================
console.log('\n--- TEST 22: karyotype above PCA + K-used chip removed (turn 6) ---');
const kSpecificFn = html.match(/function _kSpecificMetaInlineHtml[\s\S]+?\n\}/);
ok(kSpecificFn !== null, '_kSpecificMetaInlineHtml function extracted');
if (kSpecificFn) {
  const fn = kSpecificFn[0];
  // Strip JS comments before checking — the v3.99 turn 6 removal comment
  // still contains the literal string "K used" for context, but we want
  // to assert the actual chips.push call is gone.
  const fnNoComments = fn.replace(/\/\/[^\n]*/g, '').replace(/\/\*[\s\S]*?\*\//g, '');
  ok(!/chips\.push\(_metaChip\('K used'/.test(fnNoComments),
     '"K used" chips.push removed from _kSpecificMetaInlineHtml (no more "used 3" bug)');
  ok(/per group/.test(fn),
     '"per group" chip retained');
  ok(/center PC1/.test(fn),
     '"center PC1" chip retained');
}
// focalContentHtml accepts skipKSpecificMeta option
ok(/skipKSpecificMeta/.test(html),
   'focalContentHtml supports skipKSpecificMeta option (for hoisting above plot)');
// Caller passes skipKSpecificMeta: true
ok(/skipKSpecificMeta:\s*true/.test(html),
   'pane render passes skipKSpecificMeta: true (chips rendered above mini-PCA instead)');
// focalChipsAbove element name in code (sentinel for the new placement)
ok(/focalChipsAbove/.test(html),
   'focalChipsAbove DOM node created above the mini-PCA canvas');

// =============================================================================
// TURN-7 TESTS (v3.99 turn 7, this chat) — sim_mat real-size rendering
// =============================================================================

// =============================================================================
// TEST 23: sim panel max-height cap raised 900 → 2400
// =============================================================================
console.log('\n--- TEST 23: sim panel max cap (turn 7) ---');
const applySimFn = html.match(/function\s+applySimPanelHeight\(h\)[\s\S]+?\n\}/);
ok(applySimFn !== null, 'applySimPanelHeight function extracted');
if (applySimFn) {
  const fn = applySimFn[0];
  ok(/Math\.min\(2400/.test(fn),
     'applySimPanelHeight max raised to 2400 (was 900) for near-real-size heatmap');
  ok(/Math\.max\(150/.test(fn),
     'applySimPanelHeight min still 150');
  ok(!/Math\.min\(900/.test(fn),
     'applySimPanelHeight no longer caps at 900');
}

// =============================================================================
// TEST 24: populateSimScales picks highest-N scale on load
// =============================================================================
console.log('\n--- TEST 24: sim scale defaults to highest resolution (turn 7) ---');
const popSimFn = html.match(/function\s+populateSimScales\(\)[\s\S]+?(?=\n\/\/\s*Per-session)/);
ok(popSimFn !== null, 'populateSimScales function extracted');
if (popSimFn) {
  const fn = popSimFn[0];
  ok(/let bestN/.test(fn),
     'populateSimScales tracks bestN to pick highest-resolution scale');
  ok(/n > bestN/.test(fn),
     'populateSimScales selects scale with maximum n');
  ok(/v3\.99 turn 7/.test(fn),
     'populateSimScales has v3.99 turn 7 marker comment');
  // Annotate label with resolution
  ok(/\$\{lab\}\s*\(\$\{n\}×\$\{n\}\)/.test(fn) || /\${lab}\s*\(\${n}.\${n}\)/.test(fn),
     'sim scale dropdown labels show NxN resolution');
}

// =============================================================================
// TURN-7 TESTS (v3.99 turn 7, perf optimizations)
// =============================================================================

// =============================================================================
// TEST 23: renderL3Panel cache short-circuit
// =============================================================================
console.log('\n--- TEST 23: renderL3Panel cache short-circuit (turn 7 perf) ---');
ok(/_renderL3Fingerprint/.test(html),
   '_renderL3Fingerprint helper defined');
ok(/_l3CacheInvalidate/.test(html),
   '_l3CacheInvalidate helper defined');
ok(/state\._l3CacheFp/.test(html),
   'state._l3CacheFp tracks last-rendered fingerprint');
// The cache check + early return are inside renderL3Panel body.
// We assert at file-level rather than scoping to a renderL3Panel match,
// since the function has many lines.
ok(/state\._l3CacheFp\s*===\s*fp\s*&&\s*state\._l3CacheRendered\s*===\s*true/.test(html),
   'renderL3Panel checks cache fingerprint before rebuild');
ok(/return;\s*\/\/ same render/.test(html),
   'renderL3Panel short-circuits with early return on cache hit');
// Fingerprint must include all settings that affect pane content
const fpFn = html.match(/function _renderL3Fingerprint[\s\S]+?\.join\('::'\);/);
if (fpFn) {
  const fp = fpFn[0];
  for (const key of [
    'curL2', 'l3Layout', 'l3ColorMode', 'l3KMode', 'compareUnit',
    'state.k', 'aggMethod', 'mergeThr', 'alpha', 'minNGroup',
    'lockedLabels', 'l3Detailed', 'secondaryL2', 'candidateMode',
    'draftFp', 'trackedHash', 'bcScope', 'cacheKey'
  ]) {
    ok(fp.includes(key),
       `L3 fingerprint includes ${key}`);
  }
}

// =============================================================================
// TEST 24: drawLinesPanel y-matrix cache
// =============================================================================
console.log('\n--- TEST 24: drawLinesPanel y-matrix cache (turn 7 perf) ---');
ok(/state\.__linesCache/.test(html),
   'state.__linesCache present');
ok(/_linesCacheInvalidate/.test(html),
   '_linesCacheInvalidate helper defined');
const linesFn = html.match(/function drawLinesPanel\(\)\s*\{[\s\S]+?\n\}/);
if (linesFn) {
  const fn = linesFn[0];
  ok(/state\.__linesCache\[source\]/.test(fn),
     'drawLinesPanel reads/writes per-source cache');
  ok(/cached\._key\s*!==\s*cacheKey/.test(fn),
     'drawLinesPanel checks cache key before rebuild');
  ok(/cached\.yMatrix/.test(fn),
     'drawLinesPanel uses cached.yMatrix');
  ok(/cached\.xByGrid/.test(fn),
     'drawLinesPanel uses cached.xByGrid');
}
// Data load invalidates caches
const dataLoadCtx = html.match(/state\.cur\s*=\s*0;[\s\S]{0,500}_l3CacheInvalidate/);
ok(dataLoadCtx !== null,
   'data-load path invalidates _l3Cache');
const dataLoadCtx2 = html.match(/state\.cur\s*=\s*0;[\s\S]{0,500}_linesCacheInvalidate/);
ok(dataLoadCtx2 !== null,
   'data-load path invalidates _linesCache');

// =============================================================================
// TURN-8 TESTS (v3.99 turn 8)
// =============================================================================

// =============================================================================
// TEST 25: L3 body grid auto-rows fills panel height
// =============================================================================
console.log('\n--- TEST 25: L3 body grid-auto-rows: 1fr (turn 8 fill-space) ---');
const l3BodyCss = html.match(/#l3Panel \.l3-body\s*\{[^}]+\}/);
ok(l3BodyCss !== null, '.l3-body CSS rule found');
if (l3BodyCss) {
  ok(/grid-auto-rows:\s*1fr/.test(l3BodyCss[0]),
     '.l3-body has grid-auto-rows: 1fr (panes stretch to fill panel)');
}

// =============================================================================
// TEST 26: L2 zoom button + viewMode handling
// =============================================================================
console.log('\n--- TEST 26: L2 zoom view mode (turn 8) ---');
ok(/data-viewmode="l2"/.test(html),
   'L2 zoom button markup present');
ok(/🔬 L2 zoom/.test(html) || />\s*L2 zoom/.test(html),
   'L2 zoom button has visible label');
// applyViewMode accepts 'l2'
ok(/mode\s*!==\s*'l2'/.test(html) || /mode\s*===\s*'l2'/.test(html) || /\|\|\s*mode\s*!==\s*'l2'/.test(html),
   'applyViewMode validates "l2" as a valid mode');
// currentMbRange handles 'l2'
const mbRangeFn = html.match(/function currentMbRange\(\)\s*\{[\s\S]+?\n\}/);
if (mbRangeFn) {
  ok(/mode\s*===\s*'l2'/.test(mbRangeFn[0]),
     'currentMbRange branches on mode === "l2"');
  ok(/l2_envelopes/.test(mbRangeFn[0]),
     'currentMbRange L2 branch reads l2_envelopes');
  ok(/windowToL2/.test(mbRangeFn[0]),
     'currentMbRange L2 branch reads windowToL2');
}
// localStorage validation accepts 'l2'
ok(/v\s*===\s*'l2'\s*\|\|\s*v\s*===\s*'genome'/.test(html)
   || /v\s*===\s*'l1'\s*\|\|\s*v\s*===\s*'l2'/.test(html),
   'localStorage viewmode loader accepts "l2"');

// =============================================================================
// TEST 27: lines panel offscreen-canvas pre-render
// =============================================================================
console.log('\n--- TEST 27: lines panel offscreen pre-render (turn 8 perf) ---');
ok(/cached\.bgCanvas/.test(html),
   'cached.bgCanvas slot present');
ok(/cached\.bgCanvasKey/.test(html),
   'cached.bgCanvasKey tracking present');
ok(/OffscreenCanvas/.test(html),
   'OffscreenCanvas used (with fallback to <canvas>)');
ok(/ctx\.drawImage\(cached\.bgCanvas/.test(html),
   'live canvas blits the pre-rendered untracked-cloud bgCanvas');

// =============================================================================
// TURN-9 TESTS (v3.99 turn 9)
// =============================================================================

// =============================================================================
// TEST 28: header buttons no-wrap (turn 9 ask 5)
// =============================================================================
console.log('\n--- TEST 28: header buttons no-wrap (turn 9) ---');
const headerBtnRule9 = html.match(/header\s+#themeToggleBtn[\s\S]{0,800}?\}/);
if (headerBtnRule9) {
  ok(/white-space:\s*nowrap/.test(headerBtnRule9[0]),
     'header buttons have white-space: nowrap (single-line)');
  ok(/flex-shrink:\s*0/.test(headerBtnRule9[0]),
     'header buttons have flex-shrink: 0 (don\'t squeeze)');
}
const schemaBadgeRule = html.match(/header\s+#schemaBadge\s*\{[\s\S]{0,500}?\}/);
if (schemaBadgeRule) {
  ok(/white-space:\s*nowrap/.test(schemaBadgeRule[0]),
     'schemaBadge has white-space: nowrap');
}

// =============================================================================
// TEST 29: tracked-samples collapse fills PCA + hides stack-resize (turn 9 ask 1+2)
// =============================================================================
console.log('\n--- TEST 29: tracked-samples collapse → PCA fills (turn 9) ---');
ok(/data-tracked-compact-collapsed/.test(html),
   'data-tracked-compact-collapsed body attribute used');
const collapsedTrackedCss = html.match(/data-tracked-compact-collapsed="1"\][\s\S]{0,400}?#trackedSamplesPanelCompact[\s\S]{0,200}?\}/);
ok(collapsedTrackedCss !== null,
   'CSS rule for collapsed tracked panel found');
if (collapsedTrackedCss) {
  ok(/flex:\s*0\s+0\s+auto/.test(collapsedTrackedCss[0]),
     'collapsed tracked panel uses flex: 0 0 auto (releases flex space)');
}
const collapsedHandleCss = html.match(/data-tracked-compact-collapsed="1"\][\s\S]{0,400}?#compactStackResize[\s\S]{0,100}?\}/);
ok(collapsedHandleCss !== null,
   'CSS rule for collapsed stack-resize handle found');
if (collapsedHandleCss) {
  ok(/display:\s*none/.test(collapsedHandleCss[0]),
     'stack-resize handle hidden when tracked panel is collapsed');
}
const applyTrackedFn = html.match(/function _applyTrackedCompactCollapsed[\s\S]+?\n\}/);
if (applyTrackedFn) {
  ok(/setAttribute\(['"]data-tracked-compact-collapsed/.test(applyTrackedFn[0]),
     '_applyTrackedCompactCollapsed sets body attribute when collapsed');
  ok(/removeAttribute\(['"]data-tracked-compact-collapsed/.test(applyTrackedFn[0]),
     '_applyTrackedCompactCollapsed clears body attribute when expanded');
  ok(/drawPCA/.test(applyTrackedFn[0]),
     '_applyTrackedCompactCollapsed nudges drawPCA for immediate feedback');
}

// =============================================================================
// TEST 30: L3 resize handle 50% height in compact mode (turn 9 ask 4)
// =============================================================================
console.log('\n--- TEST 30: L3 resize handle 50% height (turn 9) ---');
ok(/grid-template-rows:\s*40px\s+28px\s+1\.5fr\s+auto\s+1fr\s+4px\s+var\(--compact-l3fr\)/.test(html),
   'compact grid handle row reduced 8px → 4px');
const compactL3HandleCss = html.match(/#compactL3Resize::after\s*\{[\s\S]{0,1000}?\}/);
ok(compactL3HandleCss !== null,
   '#compactL3Resize::after CSS rule extracted');
if (compactL3HandleCss) {
  ok(/height:\s*2px/.test(compactL3HandleCss[0]),
     'L3 handle grip indicator 3px → 2px (matches halved row)');
}

// =============================================================================
// TEST 31: Z-panel settings popover (turn 9 ask 3)
// =============================================================================
console.log('\n--- TEST 31: Z-panel settings popover (turn 9) ---');
ok(/id="zSettingsToggleBtn"/.test(html),
   'zSettingsToggleBtn element present');
ok(/id="zSettingsBox"/.test(html),
   'zSettingsBox wrapper present');
const zSettingsBoxMarkup = html.match(/<span\s+id="zSettingsBox"[^>]*>/);
if (zSettingsBoxMarkup) {
  ok(/display:\s*none/.test(zSettingsBoxMarkup[0]),
     'zSettingsBox default-hidden');
}
const zSettingsToggleMarkup = html.match(/<button\s+id="zSettingsToggleBtn"[\s\S]+?<\/button>/);
if (zSettingsToggleMarkup) {
  const m = zSettingsToggleMarkup[0];
  ok(/position:\s*absolute/.test(m),
     'zSettingsToggleBtn absolute-positioned');
  // v3.99 turn 14e: gear moved to bottom:28px so the collapse ▼ button can
  // sit at bottom:6px below it (turn 14d ask 5 — both buttons stack at the
  // canvas bottom-left, replacing the now-hidden header strip).
  ok(/left:\s*6px/.test(m) && /bottom:\s*28px/.test(m),
     'zSettingsToggleBtn at lower-left of canvas (bottom:28px so the ▼ collapse btn fits below it at bottom:6px)');
}
ok(/_applyZSettingsOpen/.test(html),
   '_applyZSettingsOpen function defined');
ok(/zSettingsOpen/.test(html),
   'zSettingsOpen state persisted in localStorage');
// All four color buttons + both value buttons + highlight ctrl moved INTO the box.
// We assert by checking that zColorMode and zValueMode appear AFTER zSettingsBox opens.
const boxIdx = html.indexOf('id="zSettingsBox"');
const colorIdx = html.indexOf('id="zColorMode"');
const valueIdx = html.indexOf('id="zValueMode"');
const highlightIdx = html.indexOf('id="zHighlightCtrl"');
ok(boxIdx >= 0 && colorIdx > boxIdx,
   'zColorMode buttons are inside zSettingsBox');
ok(boxIdx >= 0 && valueIdx > boxIdx,
   'zValueMode buttons are inside zSettingsBox');
ok(boxIdx >= 0 && highlightIdx > boxIdx,
   'zHighlightCtrl is inside zSettingsBox');

// =============================================================================
// TURN-10 TESTS (v3.99 turn 10) — 4 of 6 asks (asks 4 + 6 pending input)
// =============================================================================

// =============================================================================
// TEST 32: filter relatedness JSONs out of chrom dropdown (turn 10 ask 1)
// =============================================================================
console.log('\n--- TEST 32: chromosome dropdown filter (turn 10 ask 1) ---');
ok(/_isChromosomeJSON/.test(html),
   '_isChromosomeJSON helper defined');
const isChromFn = html.match(/function _isChromosomeJSON[\s\S]+?\n\}/);
if (isChromFn) {
  ok(/n_windows/.test(isChromFn[0]) && /windows/.test(isChromFn[0]),
     '_isChromosomeJSON validates n_windows + windows array');
}
const refreshFn = html.match(/function refreshChromSelect[\s\S]+?^\}/m);
if (refreshFn) {
  ok(/_isChromosomeJSON/.test(refreshFn[0]),
     'refreshChromSelect filters cache by _isChromosomeJSON');
}
const loadMultiFn = html.match(/function loadMultipleJSONs[\s\S]+?^\}/m);
if (loadMultiFn) {
  ok(/_isChromosomeJSON\(data\)/.test(loadMultiFn[0]),
     'loadMultipleJSONs only auto-displays chromosome JSONs (skips relatedness)');
  ok(/displayedFirst/.test(loadMultiFn[0]),
     'loadMultipleJSONs uses displayedFirst flag (not file index) so first chromosome wins');
}

// =============================================================================
// TEST 33: catalogue Ctrl+click + Shift+click multi-select (turn 10 ask 3)
// =============================================================================
console.log('\n--- TEST 33: catalogue multi-select (turn 10 ask 3) ---');
ok(/_anchorL2/.test(html),
   'catState._anchorL2 used for shift-range anchor');
ok(/e\.ctrlKey\s*\|\|\s*e\.metaKey/.test(html),
   'row click respects Ctrl/Cmd modifier');
ok(/e\.shiftKey/.test(html),
   'row click respects Shift modifier');
const rowClickRe = /tr\.addEventListener\(['"]click['"][\s\S]+?\}\);\s*\}\);/;
const rowClickMatch = html.match(rowClickRe);
if (rowClickMatch) {
  const fn = rowClickMatch[0];
  ok(/isShift\s*&&\s*catState\._anchorL2/.test(fn),
     'shift-range only fires when anchor exists');
  ok(/catState\.selected\.add/.test(fn),
     'shift-range adds rows to selection set');
}

// =============================================================================
// TEST 34: catalogue ⭐ favorites + L3 view buttons (turn 10 ask 5)
// =============================================================================
console.log('\n--- TEST 34: catalogue favorites + L3 buttons (turn 10 ask 5) ---');
ok(/id="catViewFav"/.test(html),
   'catViewFav button (yellow star) markup present');
ok(/id="catViewL3"/.test(html),
   'catViewL3 button markup present');
// Buttons are positioned BEFORE catViewL2 in the DOM (left-to-right order)
const favIdx = html.indexOf('id="catViewFav"');
const l3Idx  = html.indexOf('id="catViewL3"');
const l2Idx  = html.indexOf('id="catViewL2"');
ok(favIdx >= 0 && favIdx < l3Idx,
   'catViewFav appears LEFT of catViewL3 in DOM order');
ok(l3Idx >= 0 && l3Idx < l2Idx,
   'catViewL3 appears LEFT of catViewL2 in DOM order');
// Star color: gold accent
const favBtn = html.match(/<button\s+id="catViewFav"[^>]+>/);
if (favBtn) {
  ok(/#f5a524/.test(favBtn[0]) || /color:\s*#f/.test(favBtn[0]),
     'catViewFav button has gold/yellow color');
}
// Persistent favorites store
ok(/_loadCatFavorites/.test(html), '_loadCatFavorites function defined');
ok(/_saveCatFavorites/.test(html), '_saveCatFavorites function defined');
ok(/catState\.favorites/.test(html), 'catState.favorites set tracked');
ok(/_CAT_FAV_KEY_PREFIX/.test(html), 'localStorage key prefix defined for per-chromosome favorites');
// Star toggle column on each row
ok(/cat-star-cell/.test(html), 'star toggle cell class added to rows');
// L3 view shows placeholder
const renderCatFn = html.match(/function renderCatalogue\(\)\s*\{[\s\S]+?\n\}/);
if (renderCatFn) {
  ok(/L3 view.*coming soon/i.test(renderCatFn[0]) || /viewMode === 'L3'/.test(renderCatFn[0]),
     'L3 view renders a placeholder message');
  ok(/viewMode === 'fav'/.test(renderCatFn[0]),
     'fav view filters L2 rows by favorites set');
}

// =============================================================================
// TURN-11 TESTS (v3.99 turn 11) — asks 4 + 6 from turn-10 batch
// =============================================================================

// =============================================================================
// TEST 35: catalogue hover behaviors (turn 11 ask 4)
// =============================================================================
console.log('\n--- TEST 35: catalogue row hover + column flash (turn 11 ask 4) ---');
// Row hover (already existed)
ok(/#page3 table\.cat tbody tr:hover\s*\{[^}]*background:\s*var\(--panel-2\)/.test(html),
   'row hover highlights whole row (cat tbody tr:hover)');
// Column flash (new)
ok(/#page3 table\.cat tbody td\.col-hover/.test(html),
   '.col-hover CSS rule present (column-flash style)');
// JS wiring on each <th>
ok(/head\.querySelectorAll\('th'\)\.forEach/.test(html),
   'thead loop wires hover listeners to all <th>s (not just sortable)');
ok(/mouseenter[\s\S]{0,200}?col-hover/.test(html),
   'mouseenter handler adds .col-hover');
ok(/mouseleave[\s\S]{0,1500}?col-hover/.test(html),
   'mouseleave handler removes .col-hover');
ok(/cellIndex/.test(html),
   'column-flash uses th.cellIndex to identify column position');

// =============================================================================
// TEST 36: gear in tab bar replaces sidebar arrow (turn 11 ask 6)
// =============================================================================
console.log('\n--- TEST 36: global settings gear in tab bar (turn 11 ask 6) ---');
ok(/id="globalSettingsBtn"/.test(html),
   'globalSettingsBtn element present');
// Gear is at the START of #tabBar, BEFORE the first page button
const gearIdx = html.indexOf('id="globalSettingsBtn"');
const tabBarIdx = html.indexOf('<nav id="tabBar">');
const firstPageBtnIdx = html.indexOf('data-page="page1"');
ok(tabBarIdx >= 0 && gearIdx > tabBarIdx,
   'gear is INSIDE #tabBar');
ok(gearIdx >= 0 && gearIdx < firstPageBtnIdx,
   'gear appears BEFORE the first page button (leftmost position)');
// Original sidebar button is hidden (display: none)
ok(/#sidebarToggleBtn\s*\{\s*display:\s*none\s*!important/.test(html),
   'original #sidebarToggleBtn is display:none (hidden but kept in DOM)');
// Gear has the gear glyph
const gearMarkup = html.match(/<button\s+id="globalSettingsBtn"[\s\S]+?<\/button>/);
if (gearMarkup) {
  ok(/⚙/.test(gearMarkup[0]),
     'gear button uses ⚙ glyph');
  ok(/#c2410c/i.test(gearMarkup[0]) || /#9a3412/i.test(gearMarkup[0]),
     'gear styled in dark orange (Tailwind orange-700/800 hex)');
}
// Wired to fire the same applySidebarState toggle
ok(/_globalSettingsBtn[\s\S]{0,400}?applySidebarState/.test(html),
   'globalSettingsBtn click handler calls applySidebarState');

// =============================================================================
// TURN-12 TESTS (v3.99 turn 12)
// =============================================================================

// =============================================================================
// TEST 37: confirm-toggle auto-adds candidate to list (turn 12 ask 1, BUG FIX)
// =============================================================================
console.log('\n--- TEST 37: confirm auto-saves candidate (turn 12 ask 1) ---');
// Anchor on the v3.99 turn 12 comment so we extract the right confirmBtn
// handler (there are two — lines lasso confirm + candidate confirm).
const confirmFn = html.match(/v3\.99 turn 12 fix:[\s\S]+?persistCandidateList\(\)/);
ok(confirmFn !== null, 'v3.99 turn 12 confirm fix block extracted');
if (confirmFn) {
  const fn = confirmFn[0];
  // Auto-add when not in list AND user is confirming (going to true)
  ok(/!inList\s*&&\s*c\.confirmed/.test(fn) || /!inList[\s\S]{0,50}?c\.confirmed/.test(fn),
     'confirm path checks "not in list AND confirmed=true"');
  ok(/addCandidateToList\(snapshot\)/.test(fn),
     'auto-add calls addCandidateToList(snapshot)');
  ok(/candidateFromJSON\(candidateToJSON\(c\)\)/.test(fn),
     'snapshot is a deep copy via candidateFromJSON+candidateToJSON');
}
// Catalogue re-render is in the broader handler context — check separately
const fullConfirm = html.match(/v3\.99 turn 12 fix:[\s\S]+?(\n  \}\);|\n    \}\);)/);
if (fullConfirm) {
  ok(/renderCatalogue/.test(fullConfirm[0]),
     'confirm handler re-renders catalogue (so confirmed-row tint refreshes)');
}

// =============================================================================
// TEST 38: confirmed-row green tint + ID chip (turn 12 ask 2)
// =============================================================================
console.log('\n--- TEST 38: confirmed-row visual indicator (turn 12 ask 2) ---');
ok(/cand-confirmed/.test(html),
   '.cand-confirmed CSS class present');
ok(/rgba\(60,192,138,0\.06\)/.test(html),
   'confirmed-row soft green background applied');
ok(/cat-conf-chip/.test(html),
   '.cat-conf-chip class for ✓ ID chip present');
ok(/confirmed_cand_id/.test(html),
   'rows carry confirmed_cand_id field');
const buildRowsFn = html.match(/function buildCatalogueRows\(\)[\s\S]+?^\}/m);
if (buildRowsFn) {
  ok(/l2ToConfirmedId/.test(buildRowsFn[0]),
     'buildCatalogueRows builds l2_idx → confirmed_cand_id map');
  ok(/cand\.confirmed/.test(buildRowsFn[0]),
     'map only includes confirmed candidates');
}

// =============================================================================
// TEST 39: simple/detailed display toggle (turn 12 ask 3)
// =============================================================================
console.log('\n--- TEST 39: catalogue simple/detailed toggle (turn 12 ask 3) ---');
ok(/id="catDispSimple"/.test(html),
   'catDispSimple button markup present');
ok(/id="catDispDetailed"/.test(html),
   'catDispDetailed button markup present');
ok(/CAT_COLS_SECONDARY/.test(html),
   'CAT_COLS_SECONDARY set defined');
ok(/parent_l1.*silhouette.*coherence.*fam_purity.*cluster_ok.*n_windows/s.test(html)
   || /parent_l1[\s\S]{0,200}silhouette[\s\S]{0,200}coherence/.test(html),
   'CAT_COLS_SECONDARY includes the expected secondary fields');
ok(/setCatDisplayMode/.test(html),
   'setCatDisplayMode function defined');
ok(/catDisplayMode/.test(html),
   'localStorage key for display mode defined');
ok(/catState\.displayMode\s*===\s*'simple'/.test(html),
   'getCatCols filters by displayMode === "simple"');
// Default mode is 'detailed'
const catStateFn = html.match(/const catState = \{[\s\S]+?\};/);
if (catStateFn) {
  ok(/displayMode:\s*'detailed'/.test(catStateFn[0]),
     'catState.displayMode defaults to "detailed"');
}

// =============================================================================
// TEST 40: windows page bi-SNPs label rename (turn 12 ask 4)
// =============================================================================
console.log('\n--- TEST 40: windows page bi-SNPs label (turn 12 ask 4) ---');
ok(/>n bi-SNPs</.test(html),
   'header reads "n bi-SNPs"');
ok(/>bi-SNPs \/ kb</.test(html),
   'header reads "bi-SNPs / kb"');
// Old labels gone (only the visible <th> text — internal n_snps field unchanged)
ok(!/>n SNPs</.test(html),
   'old "n SNPs" label removed');
ok(!/>SNPs \/ kb</.test(html),
   'old "SNPs / kb" label removed');

// =============================================================================
// TURN-13 TESTS (v3.99 turn 13)
// =============================================================================

// =============================================================================
// TEST 41: candidate-nav-bar on popstats / ancestry / boundaries (turn 13 ask 1)
// =============================================================================
console.log('\n--- TEST 41: candidate-nav inline bar (turn 13 ask 1) ---');
ok(/_renderCandidateNavInline/.test(html),
   '_renderCandidateNavInline helper defined');
ok(/cand-nav-inline/.test(html),
   '.cand-nav-inline class used for the bar');
ok(/idPrefix\s*=\s*opts\.idPrefix/.test(html) || /opts\.idPrefix\s*\|\|\s*'cand'/.test(html),
   'helper accepts idPrefix to avoid ID collisions across pages');
// Three pages inject a nav bar
ok(/idPrefix:\s*'ps'/.test(html),
   'popstats page injects nav with prefix "ps"');
ok(/idPrefix:\s*'anc'/.test(html),
   'ancestry page injects nav with prefix "anc"');
ok(/idPrefix:\s*'bnd'/.test(html),
   'boundaries page injects nav with prefix "bnd"');
// _navigateToCandidate now also sets the cursor + refreshes the other pages
const navFn = html.match(/function _navigateToCandidate[\s\S]+?^\}/m);
if (navFn) {
  ok(/setCur/.test(navFn[0]),
     '_navigateToCandidate centers cursor on candidate midpoint');
  ok(/renderPopstatsPage/.test(navFn[0]),
     '_navigateToCandidate refreshes popstats page');
  ok(/renderAncestryPage/.test(navFn[0]),
     '_navigateToCandidate refreshes ancestry page');
  ok(/renderBoundariesPage/.test(navFn[0]),
     '_navigateToCandidate refreshes boundaries page');
}
// Whole-genome button clears state.candidate
ok(/state\.candidate\s*=\s*null/.test(html),
   'whole-genome button clears state.candidate');
// Active candidate name shown
ok(/active:[\s\S]{0,300}?activeName/.test(html) || /color: var\(--accent\)[\s\S]{0,200}c\.id/.test(html),
   'active candidate name rendered prominently');

// =============================================================================
// TEST 42: confirmed candidates as green zones in sim_mat (turn 13 ask 2)
// =============================================================================
console.log('\n--- TEST 42: confirmed-candidate zones in sim_mat (turn 13 ask 2) ---');
// Look for the confirmed-overlay block in drawSim
ok(/state\.candidateList[\s\S]{0,400}cand\.confirmed/.test(html),
   'drawSim iterates state.candidateList and filters by confirmed');
ok(/rgba\(60,192,138,0\.85\)/.test(html),
   'confirmed-zone outline color matches catalogue green tint');
// Label rendering
ok(/cand\.id/.test(html) && /shortId/.test(html),
   'confirmed-zone label uses cand.id with short-form stripping');
// Provisional candidates DO NOT get the green zone — assert with the
// existence of `cand.confirmed` filter
ok(/if\s*\(\s*!cand\s*\|\|\s*!cand\.confirmed\s*\)\s*continue/.test(html)
   || /!cand\.confirmed/.test(html),
   'provisional candidates skipped (only confirmed get green zone)');

// =============================================================================
// TEST 43: Z-panel L1/L2 labels + darker colors (turn 13 ask 3)
// =============================================================================
console.log('\n--- TEST 43: Z-panel L1/L2 labels + darker bar colors (turn 13 ask 3) ---');
// Darker blue (was rgba(79,163,255,...))
ok(/rgba\(48,116,200/.test(html),
   'L1 bar uses darker blue rgb(48,116,200)');
// Old washed-out blue should be GONE specifically from the Z-panel L1 bar
// rendering. Other usages of rgba(79,163,255,...) elsewhere (BAND_COLORS for
// K=3 PCA scatter, marker page badge, ancestry page L1 bar, tracks-container
// inL1 highlight) are unrelated and may legitimately retain the old color.
// We assert by counting occurrences — drawZ alone added 4 instances (active
// + inactive × 2 branches: collapsed + non-collapsed), so the file should
// now have FEWER than the historical baseline. Concretely: before turn 13
// drawZ had 4 such literals; turn 13 removed all 4. Other places still use
// it legitimately. Assert the count dropped.
{
  const matches = (html.match(/rgba\(79,163,255/g) || []).length;
  // Before turn 13: 4 in drawZ + ~5 elsewhere = ~9 total
  // After turn 13:  0 in drawZ + ~5 elsewhere = ~5 total
  // After turn 14c: + 2 documentation mentions in the help-page roadmap
  //                 (describes the turn-13 color change + the deferred
  //                 ancestry-page consistency fix) = 7 total. Budget bumped
  //                 to ≤9 to leave room for future doc references without
  //                 requiring the test to be relaxed every time the help
  //                 page mentions the old color.
  ok(matches <= 9,
     `washed-out L1 blue removed from drawZ — file has ${matches} usages, expect ≤9 (other places legitimate, incl. help-page docs)`);
}

// =============================================================================
// TEST 45: chrom (Mb) label moved to left edge (turn 13 ask 5)
// =============================================================================
console.log('\n--- TEST 45: chrom label moved to left edge (turn 13 ask 5 / 14e) ---');
// v3.99 turn 14e: anchor moved further left from pad.l (=44) to x=2 so
// the label sits in the y-axis margin area near the panel's left edge.
// Pre-14e expected pad.l; now expected literal 2.
ok(/fillText\(d\.chrom\s*\+\s*['"]\s*\(Mb\)['"]\s*,\s*2\s*,\s*h/.test(html),
   'chrom (Mb) label fillText anchored at x=2 (turn 14e: even further left than pad.l)');
// Confirm it's textAlign: 'left' just before that fillText
ok(/textAlign\s*=\s*['"]left['"];\s*\n?\s*ctx\.fillText\(d\.chrom/.test(html),
   'textAlign set to "left" immediately before the chrom fillText');
// Darker green (was rgba(0,230,118,...) for the bars)
ok(/rgba\(34,160,80/.test(html),
   'L2 bar uses darker green rgb(34,160,80)');
// Text labels
ok(/fillText\(['"]L1['"]/.test(html),
   '"L1" label rendered in y-axis margin');
ok(/fillText\(['"]L2['"]/.test(html),
   '"L2" label rendered in y-axis margin');

// =============================================================================
// TEST 44: lines panel npc note moved to PC tooltip (turn 13 ask 4)
// =============================================================================
console.log('\n--- TEST 44: npc note moved to per-PC tooltip (turn 13 ask 4) ---');
ok(/data-pc-tooltip/.test(html),
   'PC labels get a data-pc-tooltip marker');
ok(/npcTooltip/.test(html),
   'npcTooltip variable built once per render');
ok(/note\.style\.display\s*=\s*['"]none['"]/.test(html),
   'visible inline note hidden via display:none');

// =============================================================================
// TEST 46: tooltip discoverability — catalogue columns (turn 14b)
// =============================================================================
console.log('\n--- TEST 46: catalogue column tooltips (turn 14b) ---');
// Every CAT_COLS_BASE entry has a tooltip field
{
  const m = html.match(/const CAT_COLS_BASE\s*=\s*\[([\s\S]+?)\n\];/);
  ok(!!m, 'CAT_COLS_BASE block extractable');
  if (m) {
    const block = m[1];
    // Count entries (lines starting with "  { key:")
    const entries = block.match(/\{\s*key:/g) || [];
    const tooltipEntries = block.match(/tooltip:/g) || [];
    ok(tooltipEntries.length === entries.length,
       `every CAT_COLS_BASE entry has tooltip (${tooltipEntries.length}/${entries.length})`);
  }
}
// Dynamic columns inside getCatCols also have tooltips
{
  const m = html.match(/function getCatCols\(\)[\s\S]+?return cols;\s*\}/);
  ok(!!m, 'getCatCols block extractable');
  if (m) {
    const block = m[0];
    const entries = block.match(/\{\s*key:/g) || [];
    const tooltipEntries = block.match(/tooltip:/g) || [];
    ok(tooltipEntries.length >= entries.length - 1,
       `getCatCols dynamic columns have tooltips (${tooltipEntries.length} ≥ ${entries.length - 1})`);
  }
}
// <th> rendering wires the tooltip into title=
ok(/tipEsc/.test(html),
   'catalogue header rendering wires tooltip into <th title=> via tipEsc');
ok(/click to sort/i.test(html),
   'tooltip suffix mentions "click to sort" so users know headers are interactive');
// Star + checkbox header columns also have rich tooltips
ok(/title="Favorite — click the/.test(html),
   'star ⭐ column header has a descriptive tooltip');
ok(/Selection checkbox/.test(html),
   'checkbox column header has a descriptive tooltip');

// =============================================================================
// TEST 47: tooltip discoverability — windows page (turn 14b)
// =============================================================================
console.log('\n--- TEST 47: windows page tooltips (turn 14b) ---');
// All 11 sortable headers have a title= (data-sort with title attribute)
{
  const headerSection = html.match(/<table id="winSumTable">[\s\S]+?<tbody/);
  ok(!!headerSection, 'winSum header section extractable');
  if (headerSection) {
    const ths = (headerSection[0].match(/<th\s+data-sort=/g) || []).length;
    const titled = (headerSection[0].match(/<th\s+data-sort=[^>]+title=/g) || []).length;
    ok(titled === ths,
       `every windows-page sortable <th> has a title (${titled}/${ths})`);
  }
}
// Specific high-value columns
ok(/title="Robust \|Z\| score for the window/.test(html),
   '|Z| column tooltip explains robust Z derivation');
ok(/title="First eigenvalue/.test(html),
   'λ₁ column tooltip names the eigenvalue');
ok(/title="Eigenvalue ratio/.test(html),
   'λ₁/λ₂ ratio column tooltip explains the ratio');
// Filter controls
ok(/winSumL2Filter[\s\S]{0,200}title="Restrict the table/.test(html),
   'L2 filter dropdown has a tooltip');
ok(/winSumZFilter[\s\S]{0,200}title="Hide windows whose/.test(html),
   'min-|Z| filter input has a tooltip');

// =============================================================================
// TEST 48: tooltip discoverability — top tab bar (turn 14b)
// =============================================================================
console.log('\n--- TEST 48: top tab bar tooltips (turn 14b) ---');
// All main tabs have title= attributes (page 1, page 12 NEW θπ scrubber, then existing)
{
  // The tab bar runs from data-page="page1" through data-page="page5" (help
  // is the last). With v3.99 t14e+ continue, page12 (θπ scrubber) was
  // inserted at user-visible position 2; help moved from position 11 to 12.
  const tabBarSection = html.match(/<button data-page="page1"[\s\S]+?<button data-page="page5"[^>]+title=[^>]+><span[^>]+>12<\/span>[^<]*<\/button>/);
  ok(!!tabBarSection, 'tab bar section extractable');
  if (tabBarSection) {
    const buttons = (tabBarSection[0].match(/<button data-page=/g) || []).length;
    const titled = (tabBarSection[0].match(/<button data-page=[^>]+title=/g) || []).length;
    ok(titled === buttons,
       `every tab button has a title (${titled}/${buttons})`);
  }
}

// =============================================================================
// TEST 49: tooltip discoverability — popstats + ancestry chips (turn 14b)
// =============================================================================
console.log('\n--- TEST 49: popstats + ancestry chip tooltips (turn 14b) ---');
// Popstats chips: enriched tooltip combines yLabel + edge interpretations.
// Source uses literal template-literal text so match for the formatted
// output rather than the variable interpolation syntax.
ok(/Y axis: \$\{t\.yLabel\}/.test(html),
   'popstats chip tooltip composes from t.yLabel');
ok(/High → \$\{t\.edgeTop\}/.test(html),
   'popstats chip tooltip explains High direction');
// Ancestry chips: text inside string literal — match without smart-quotes
ok(/Heatmap field: maxQ_label/.test(html),
   'ancestry maxQ_label chip has a descriptive tooltip');
ok(/Heatmap field: delta12/.test(html),
   'ancestry delta12 chip has a descriptive tooltip');

// =============================================================================
// TEST 50: tooltip discoverability — catalogue toolbar (turn 14b)
// =============================================================================
console.log('\n--- TEST 50: catalogue toolbar tooltips (turn 14b) ---');
ok(/id="catFilter"[\s\S]{0,300}title="Free-text filter/.test(html),
   'catFilter input has descriptive tooltip');
ok(/id="catVerdictFilter"[\s\S]{0,200}title="Filter rows by σ-band-diagnostics/.test(html),
   'catVerdictFilter dropdown has descriptive tooltip');
ok(/id="catSelectAll"[^>]*title="Select all/.test(html),
   'catSelectAll button has tooltip');
ok(/id="catClearSel"[^>]*title="Clear all row/.test(html),
   'catClearSel button has tooltip');
ok(/id="catExportTSV"[^>]*title="Export the currently-visible/.test(html),
   'catExportTSV button has tooltip');
ok(/id="catExportMD"[^>]*title="Export the currently-visible/.test(html),
   'catExportMD button has tooltip');
ok(/id="catSelInfo"[^>]*title="Live counts/.test(html),
   'catSelInfo span has tooltip');

// =============================================================================
// TEST 51: tracked-samples scatter npc note → tooltip (turn 14d ask 1)
// =============================================================================
console.log('\n--- TEST 51: tracked-samples scatter npc note → tooltip (turn 14d ask 1) ---');
ok(/pcaAxisTooltip/.test(html),
   'pcaAxisTooltip variable built once per refresh');
ok(/xSel\.title\s*=\s*pcaAxisTooltip/.test(html),
   'pcaXSelect gets the npc tooltip');
ok(/ySel\.title\s*=\s*pcaAxisTooltip/.test(html),
   'pcaYSelect gets the npc tooltip');
ok(/const note = document\.getElementById\(['"]pcaAxisAvailNote['"]\)[\s\S]{0,900}note\.style\.display\s*=\s*['"]none['"]/.test(html),
   'visible #pcaAxisAvailNote span hidden via display:none');

// =============================================================================
// TEST 52: lock click triggers drawLinesPanel immediately (turn 14d ask 2)
// =============================================================================
console.log('\n--- TEST 52: lock click triggers drawLinesPanel (turn 14d ask 2) ---');
// Extract the _lockBtn click handler and assert drawLinesPanel is called
{
  const lockClickFn = html.match(/_lockBtn\.addEventListener\('click',\s*\(\)\s*=>\s*\{[\s\S]+?\}\);/);
  ok(!!lockClickFn, 'lock-button click handler extractable');
  if (lockClickFn) {
    ok(/drawLinesPanel/.test(lockClickFn[0]),
       'lock-click handler calls drawLinesPanel (was missing — caused per-sample lines to wait until next scrub before recoloring)');
  }
}

// =============================================================================
// TEST 53: PCA right margin reduced to 16 (turn 14d ask 3)
// =============================================================================
console.log('\n--- TEST 53: PCA right margin reduced 200 → 16 (turn 14d ask 3) ---');
// Both drawPCA and onPCAClick must use the same pad value for hit-detection consistency
{
  const padOccurrences = (html.match(/\{\s*l:\s*50,\s*r:\s*16,\s*t:\s*10,\s*b:\s*38\s*\}/g) || []).length;
  ok(padOccurrences === 2,
     `pad { l:50, r:16, t:10, b:38 } appears 2× (drawPCA + onPCAClick) — found ${padOccurrences}`);
  ok(!/\{\s*l:\s*50,\s*r:\s*200,\s*t:\s*10,\s*b:\s*38\s*\}/.test(html),
     'old r:200 pad removed (no leftover instances)');
}

// =============================================================================
// TEST 54: Windows button — repurposed (v4 turn 1 ask 7)
// =============================================================================
// v3.99 t14d ask 4: was a tab-jump to page8 (windows summary).
// v4 turn 1 ask 7: REPURPOSED as an arrow-key step-size cycler. Click
// cycles state.stepMode through 'win1' / 'win5' / 'win10' / 'win1'.
// Label dynamically updates to "📊 Windows (N)" so the user always
// sees the current step size. The old "jump to windows tab" function
// is gone — the regular numbered tab "9 windows" is the way to that page.
console.log('\n--- TEST 54: Windows step-cycler button (v4 turn 1 ask 7) ---');
ok(/id="jumpToWindowsBtn"/.test(html),
   '#jumpToWindowsBtn id retained for backward-compat');
ok(/jumpToWindowsBtn[\s\S]{0,800}📊\s*Windows\s*\(1\)/.test(html),
   'button initial text reads "📊 Windows (1)" (default step size)');
// New click handler: cycleStepSize, NOT a page8 tab dispatch
ok(/cycleStepSize\b/.test(html) && /addEventListener\(['"]click['"],\s*cycleStepSize\)/.test(html),
   'click handler is cycleStepSize (the new step-size cycler)');
// And the OLD tab-jump behavior should be gone
ok(!/jumpToWindowsBtn[\s\S]{0,400}data-page="page8"[\s\S]{0,200}\.click\(\)/.test(html),
   'old "jump to page8" tab-dispatch behavior removed');

// =============================================================================
// TEST 55: Z panel header strip hidden, ⚙+▼ at canvas bottom-left (turn 14d ask 5 / 14e)
// =============================================================================
console.log('\n--- TEST 55: Z panel header strip hidden + popover restructure (turn 14d ask 5 / 14e) ---');
// #zPanelLabel hidden via display:none
ok(/<div class="panel-label" id="zPanelLabel"\s+style="display:\s*none;?"/.test(html),
   '#zPanelLabel header strip is display:none');
// Panel-level title= tooltip carries the explanation
ok(/<div class="panel" id="zPanel"\s+title="Robust \|Z\|/.test(html),
   '#zPanel has the explanation tooltip on hover');
// #zSettingsBox lifted out of #zPanelLabel — should be a direct child of #zPanel,
// positioned absolute (so it shows up even when the label parent is display:none)
ok(/<span id="zSettingsBox"[\s\S]{0,300}position:\s*absolute/.test(html),
   '#zSettingsBox is absolute-positioned (lifted out of the hidden parent)');
// Collapse button moved to canvas bottom-left at bottom:6px
{
  const collapseMarkup = html.match(/<button\s+id="zCollapseBtn"[\s\S]+?<\/button>/);
  if (collapseMarkup) {
    const m = collapseMarkup[0];
    ok(/position:\s*absolute/.test(m) && /left:\s*6px/.test(m) && /bottom:\s*6px/.test(m),
       '#zCollapseBtn at canvas bottom-left (left:6px bottom:6px)');
  } else {
    ok(false, '#zCollapseBtn extractable');
  }
}
// drawZ pad.t bumped 6 → 14 to give L1/L2 bars breathing room from the top edge
// (turn 14e: hidden header strip means canvas was flush with panel top)
ok(/pad\s*=\s*\{\s*l:\s*44,\s*r:\s*16,\s*t:\s*14,\s*b:\s*22\s*\}/.test(html),
   'drawZ non-collapsed pad.t bumped 6 → 14 (L1/L2 bars no longer overflow into adjacent panels)');

// =============================================================================
// TEST 56: minimap hidden when no data loaded (turn 14e)
// =============================================================================
console.log('\n--- TEST 56: minimap hidden until data loads (turn 14e) ---');
ok(/_reapplyMinimapActiveOnDataLoad/.test(html),
   '_reapplyMinimapActiveOnDataLoad helper defined');
// setSimInMinimap guards against activating with no data
ok(/goingOn\s*&&\s*!state\.data[\s\S]{0,300}classList\.remove\(['"]active['"]\)/.test(html),
   'setSimInMinimap holds back .active class when no data is loaded');
// Helper is called from data-load path
ok(/state\.data = data;[\s\S]{0,400}_reapplyMinimapActiveOnDataLoad/.test(html),
   'data-load path calls _reapplyMinimapActiveOnDataLoad after setting state.data');

// =============================================================================
// TEST 57: compact-mode applyMainGrid skips inline gridTemplateRows (turn 14e)
// =============================================================================
console.log('\n--- TEST 57: applyMainGrid bails out in compact mode (turn 14e) ---');
// In compact mode, the row layout comes from CSS — setting an inline
// gridTemplateRows from the fixed-mode code path was beating the CSS rule
// (inline > selector specificity), collapsing the 28px anchorStripPanel
// row and making the Cramér's V bar disappear until reset-layout cleared
// the inline style. Fix: detect compact mode and clear / skip.
{
  const fnMatch = html.match(/function applyMainGrid\(\)[\s\S]+?\n\}\n/);
  ok(!!fnMatch, 'applyMainGrid function extractable');
  if (fnMatch) {
    const fn = fnMatch[0];
    ok(/layoutMode === ['"]compact['"]/.test(fn),
       'applyMainGrid checks layoutMode for compact branch');
    ok(/mainEl\.style\.gridTemplateRows = ['"]['"]/.test(fn),
       'compact branch clears inline gridTemplateRows so the CSS rule wins');
    ok(/if \(layoutMode === ['"]compact['"]\) \{[\s\S]{0,500}return;/.test(fn),
       'compact branch returns early — does NOT fall through to panelOrder logic');
  }
}

// =============================================================================
// TEST 58: empty-state enriched with tab guide (turn 14e)
// =============================================================================
console.log('\n--- TEST 58: empty-state enriched with tab guide (turn 14e) ---');
ok(/<h3>Local PCA Scrubber · v3<\/h3>/.test(html),
   '#emptyState heading reads "Local PCA Scrubber · v3"');
ok(/Browse…<\/b>\)?\s*to begin scrubbing/.test(html) || /Browse…[\s\S]{0,80}begin scrubbing/.test(html),
   'empty state references the sidebar Browse… action');
// Tab guide: each tab line is a <div> with bold tab name
const tabGuideTabs = ['1 diagnostic', '2 candidate focus', '3 boundaries', '4 catalogue',
                       '5 karyotype', '6 popstats', '7 ancestry', '8 windows',
                       '9 confirmed', '11 help'];
for (const tab of tabGuideTabs) {
  const re = new RegExp(`<b style="color: var\\(--ink\\);">${tab.replace(/ /g, '\\s+')}<\\/b>`);
  ok(re.test(html), `tab guide line for "${tab}" present in empty state`);
}
// Z canvas no-data hint
ok(/Load a precomp JSON in the sidebar \(Browse…\) to begin\./.test(html),
   'drawZ renders centered "Load a precomp JSON…" hint when state.data is null');
ok(/Robust \|Z\| profile renders here once data is loaded\./.test(html),
   'drawZ secondary hint line names the panel');

// =============================================================================
// TEST 59: K-means doctrine — bands are geometric, regimes need multi-evidence
// =============================================================================
console.log('\n--- TEST 59: K-means doctrine in UI + roadmap (turn 14e) ---');
// The l3KMode container's title= warns explicitly that K-means is geometric
ok(/id="l3KMode"[\s\S]{0,400}K-means bands are PROVISIONAL GEOMETRIC clusters/.test(html),
   '#l3KMode container tooltip warns "K-means bands are PROVISIONAL GEOMETRIC clusters"');
ok(/id="l3KMode"[\s\S]{0,800}multi-evidence convergence/.test(html),
   '#l3KMode tooltip names "multi-evidence convergence"');
ok(/id="l3KMode"[\s\S]{0,800}dosage[\s\S]{0,200}GHSL[\s\S]{0,200}heterozygosity[\s\S]{0,200}ROH[\s\S]{0,200}family/.test(html),
   '#l3KMode tooltip enumerates the five evidence layers (dosage, GHSL, heterozygosity, ROH, family)');
ok(/data-l3k="k6"[\s\S]{0,300}>K=6\s*⚠</.test(html),
   'K=6 button text has ⚠ icon (signals geometric-only / not biological)');
ok(/data-l3k="k6"[\s\S]{0,400}do NOT interpret as six biological regimes/.test(html),
   'K=6 button tooltip explicitly says "do NOT interpret as six biological regimes"');
ok(/data-l3k="k3"[\s\S]{0,400}validate with dosage\/GHSL\/het\/ROH\/family/.test(html),
   'K=3 button tooltip says "validate with dosage/GHSL/het/ROH/family"');

// Roadmap entry — Multi-evidence regime framework as TOP-PRIORITY planned item
ok(/<b>Multi-evidence regime framework<\/b>[\s\S]{0,400}\[v4\.0 doctrine, t14e\]/.test(html),
   'help-page roadmap has "Multi-evidence regime framework" entry tagged [v4.0 doctrine, t14e]');
ok(/<b>Doctrine<\/b>[\s\S]{0,300}K-means bands are <i>provisional geometric clusters<\/i>/.test(html),
   'doctrine paragraph lead reads "K-means bands are provisional geometric clusters"');
// Convergence rule — three states defined
ok(/<b>Strong regime<\/b>[\s\S]{0,400}<b>Suspect regime<\/b>[\s\S]{0,400}<b>Rejected band<\/b>/.test(html),
   'convergence rule defines Strong / Suspect / Rejected band states');
// R-side prerequisites — five emit scripts named
const rScripts = ['STEP_R30_emit_per_band_dosage', 'STEP_R31_emit_per_band_ghsl',
                  'STEP_R32_emit_per_band_het', 'STEP_R33_emit_per_band_froh',
                  'STEP_R34_emit_per_band_family', 'STEP_R35_compute_convergence_call'];
for (const s of rScripts) {
  ok(html.includes(s), `R-side prerequisite ${s} listed in roadmap`);
}
// Doctrine hard-rule: K=6 not interpreted as 6 biological regimes
ok(/K=6[\s\S]{0,200}nested substructure[\s\S]{0,200}three major regimes/.test(html),
   'roadmap explicitly states K=6 is nested substructure inside three major regimes');

// Roadmap structure didn't break — Three-axis entry still has its own row right after Multi-evidence
ok(/Multi-evidence regime framework[\s\S]+?<\/tr>[\s\S]{0,200}<tr>[\s\S]{0,200}<b>Three-axis evidence framework<\/b>/.test(html),
   'Three-axis evidence framework entry still intact (own <tr> after Multi-evidence row)');

// =============================================================================
// TEST 60: per-band layer scope refinement + new roadmap entries (turn 14e+)
// =============================================================================
console.log('\n--- TEST 60: §14.2.5 scope + §15 line modes + §16 containerization (turn 14e+) ---');
// Multi-evidence entry now mentions per-band scope
ok(/Per-band layer scope[\s\S]{0,400}low_info[\s\S]{0,400}does not push toward STRONG/.test(html),
   'multi-evidence roadmap entry has "Per-band layer scope" refinement subsection');
// GHSL informs all bands
ok(/<b>GHSL<\/b>[\s\S]{0,200}informs ALL bands/.test(html),
   'roadmap notes GHSL informs ALL bands');
// Heterozygosity primary scope is HET band
ok(/<b>Heterozygosity<\/b>[\s\S]{0,300}primary scope is the HET band/.test(html),
   'roadmap notes heterozygosity primary scope is HET band');
// Cross-link to schema §14.2.5
ok(/§14\.2\.5/.test(html),
   'roadmap cross-links to SCHEMA_V2.md §14.2.5');

// §15 line coloring modes entry exists (now updated to scaffold-shipped state in t14e+ continue)
ok(/<b>Per-sample line coloring modes<\/b>[\s\S]{0,400}\[scaffold done, v4\.0 renderers pending\]/.test(html),
   '§15 per-sample line coloring modes roadmap entry tagged [scaffold done, v4.0 renderers pending] (turn 14e+ continue promoted from "schema 2.14, t14e+")');
// All eight modes named
const lineModes = ['kmeans', 'dosage', 'ghsl', 'het', 'theta_pi', 'froh', 'family', 'confounder_alert'];
for (const mode of lineModes) {
  const re = new RegExp(`<b>${mode}<\\/b>`);
  ok(re.test(html), `line coloring mode "${mode}" listed in roadmap`);
}
// Per-window vs per-sample dispatch
ok(/_resolveSampleColorByMode\(si, gi, mode\)/.test(html),
   'roadmap names the dispatch function _resolveSampleColorByMode');
// New R-side script
ok(/STEP_R36_emit_per_sample_theta_pi\.R/.test(html),
   'roadmap names new R-side script STEP_R36_emit_per_sample_theta_pi.R');

// §16 containerization roadmap entry exists
ok(/<b>Toolkit containerization<\/b>[\s\S]{0,400}\[schema 2\.14, post-v4\.0\]/.test(html),
   '§16 toolkit containerization roadmap entry tagged [schema 2.14, post-v4.0]');
ok(/Apptainer/.test(html) && /Docker/.test(html),
   'roadmap names both Apptainer and Docker for stack split');
ok(/another lab can run it on (their own )?catfish/i.test(html),
   'roadmap captures Quentin\'s "any catfish/fish/animals/plants" goal');

// =============================================================================
// TEST 61: L1/L2 palette unification across panels (turn 14e+ "continue")
// =============================================================================
console.log('\n--- TEST 61: L1/L2 palette unification (turn 14e+) ---');
// Ancestry-page L1 bar uses turn-13 palette
ok(/i === curL1\)\s*\?\s*'rgba\(48,116,200,0\.95\)'\s*:\s*'rgba\(48,116,200,0\.50\)'/.test(html),
   'ancestry-page L1 bar uses rgba(48,116,200) palette (active 0.95 / inactive 0.50)');
// Ancestry-page L2 bar uses turn-13 palette
ok(/i === curL2\)\s*\?\s*'rgba\(34,160,80,0\.95\)'\s*:\s*'rgba\(34,160,80,0\.50\)'/.test(html),
   'ancestry-page L2 bar uses rgba(34,160,80) palette');
// Z zone color mode aligned to L1/L2 palette
ok(/inL2\)\s+color = 'rgba\(34,160,80,0\.85\)'/.test(html),
   'Z panel "zone" color mode: focal-L2 dots use rgba(34,160,80,0.85)');
ok(/else if \(inL1\) color = 'rgba\(48,116,200,0\.55\)'/.test(html),
   'Z panel "zone" color mode: focal-L1 dots use rgba(48,116,200,0.55)');
// Lines-panel mini L1/L2 strip aligned
ok(/Pre-fix: L1 was rgba\(0,66,255\)/.test(html),
   'lines-panel mini L1/L2 strip comment notes the palette unification');
ok(/fillStyle = 'rgba\(48,116,200,0\.55\)'[\s\S]{0,500}fillStyle = 'rgba\(34,160,80,0\.55\)'/.test(html),
   'lines-panel mini L1/L2 strip uses turn-13 palette for both bars');
// Candidate mini-canvas L1 tint aligned
ok(/fillStyle = 'rgba\(48, 116, 200, 0\.22\)'/.test(html),
   'candidate parent-genome mini L1 tint at rgba(48, 116, 200, 0.22)');
ok(/fillStyle = 'rgba\(48, 116, 200, 0\.18\)'[\s\S]{0,200}h \* 0\.35, w, h \* 0\.3/.test(html),
   'candidate L1 mini background bar at rgba(48, 116, 200, 0.18)');
// "L1" + "L2" labels on the ancestry page
{
  // Look for L1/L2 fillText calls inside the ancestry-page render — must be after the first occurrence
  // of the toX(d.windows[e._s0].start_bp) pattern (which is unique to the ancestry function).
  const ancestryStart = html.indexOf("toX(d.windows[e._s0].start_bp)");
  const ancestryEnd = ancestryStart + 4000;  // window of ancestry render code
  const slice = html.slice(ancestryStart, ancestryEnd);
  ok(/fillText\(['"]L1['"],\s*pad\.l - 4/.test(slice),
     'ancestry page renders "L1" label at pad.l - 4 (matching Z panel)');
  ok(/fillText\(['"]L2['"],\s*pad\.l - 4/.test(slice),
     'ancestry page renders "L2" label at pad.l - 4 (matching Z panel)');
}
// Roadmap entry promoted to SHIPPED
ok(/<b>L1\/L2 palette unification<\/b>[\s\S]{0,200}\[done v3\.99 t14e\+\]/.test(html),
   'L1/L2 palette unification entry shipped in roadmap');
// And no longer in DESIGN OPEN
ok(!/<b>Ancestry-page L1\/L2 bar consistency<\/b>/.test(html),
   'old DESIGN OPEN entry "Ancestry-page L1/L2 bar consistency" removed');

// =============================================================================
// TEST 62: lines-panel color-mode picker scaffold (turn 14e+ continue, SCHEMA §15)
// =============================================================================
console.log('\n--- TEST 62: lines-color-mode picker scaffold (turn 14e+ continue) ---');
// State slot
ok(/linesColorMode:\s*['"]kmeans['"]/.test(html),
   'state.linesColorMode initialized to "kmeans"');
// Persistence key
ok(/_LINES_COLOR_MODE_KEY\s*=\s*['"]pca_scrubber_v3\.linescolormode['"]/.test(html),
   'persistence key pca_scrubber_v3.linescolormode declared');
// Mode definitions (8 entries)
{
  const m = html.match(/_LINES_COLOR_MODES\s*=\s*\[[\s\S]+?\];/);
  ok(!!m, '_LINES_COLOR_MODES array declared');
  if (m) {
    const arr = m[0];
    const ids = ['kmeans', 'dosage', 'ghsl', 'het', 'theta_pi', 'froh', 'family', 'confounder_alert'];
    for (const id of ids) {
      ok(arr.includes(`id: '${id}'`), `mode ${id} present in _LINES_COLOR_MODES`);
    }
  }
}
// Validator function exists
ok(/function _isLinesColorModeAvailable\(modeId\)/.test(html),
   '_isLinesColorModeAvailable function defined');
ok(/function refreshLinesColorMode\(\)/.test(html),
   'refreshLinesColorMode function defined');
// Stub renderers exist
ok(/function _resolveSampleColorByMode\(si, gi, mode\)/.test(html),
   '_resolveSampleColorByMode stub defined');
ok(/function _resolveSampleScopeColor\(si, mode\)/.test(html),
   '_resolveSampleScopeColor stub defined');
// Stubs return null sentinel today
{
  const fn = html.match(/function _resolveSampleColorByMode[\s\S]+?\n\}\n/);
  ok(!!fn && /return null;/.test(fn[0]),
     '_resolveSampleColorByMode returns null sentinel (stub for v4.0)');
}
{
  const fn = html.match(/function _resolveSampleScopeColor[\s\S]+?\n\}\n/);
  ok(!!fn && /return null;/.test(fn[0]),
     '_resolveSampleScopeColor returns null sentinel (stub for v4.0)');
}
// Wiring function
ok(/function _wireLinesColorModePicker\(\)/.test(html),
   '_wireLinesColorModePicker function defined');
ok(/_wireLinesColorModePicker\(\)/.test(html),
   '_wireLinesColorModePicker called at init');
// Idempotency guard
ok(/sel\.dataset\.wired === ['"]1['"]/.test(html),
   'wiring is idempotent (dataset.wired guard)');
// Markup: <select> exists
ok(/id="linesColorModeSelect"/.test(html),
   '#linesColorModeSelect exists in markup');
// All 8 options present in markup
const expectedOpts = ['kmeans', 'dosage', 'ghsl', 'het', 'theta_pi', 'froh', 'family', 'confounder_alert'];
for (const v of expectedOpts) {
  const re = new RegExp(`<option value="${v}"`);
  ok(re.test(html), `<option value="${v}"> in markup`);
}
// kmeans + family options NOT disabled by default; others are
ok(/<option value="kmeans">/.test(html),
   'kmeans option not disabled in static markup');
ok(/<option value="family">/.test(html),
   'family option not disabled in static markup');
ok(/<option value="dosage" disabled/.test(html),
   'dosage option disabled in static markup (needs dosage_chunks layer)');
ok(/<option value="theta_pi" disabled/.test(html),
   'theta_pi option disabled in static markup (needs per_sample_theta_pi layer, schema 2.14)');
// per_sample_theta_pi added to detectSchemaAndLayers
ok(/case 'per_sample_theta_pi':[\s\S]{0,300}data\.per_sample_theta_pi/.test(html),
   'per_sample_theta_pi detected in detectSchemaAndLayers');
// refreshLinesColorMode called after data loads
ok(/buildLinesPanel\(\);[\s\S]{0,400}refreshLinesColorMode\(\)/.test(html),
   'refreshLinesColorMode called in data-load path after buildLinesPanel');
// Change handler triggers redraws
{
  const fn = html.match(/function _wireLinesColorModePicker[\s\S]+?\n\}\n/);
  ok(!!fn && /drawLinesPanel\(\)/.test(fn[0]) && /drawPCA\(\)/.test(fn[0]) && /renderL3Panel\(\)/.test(fn[0]),
     'mode-change handler triggers drawLinesPanel + drawPCA + renderL3Panel redraws');
}

// =============================================================================
// TEST 63: species portability (turn 14e+ continue, SCHEMA §16.6)
// =============================================================================
console.log('\n--- TEST 63: species portability — no hardcoded Clarias gariepinus (turn 14e+ continue) ---');
// The hardcoded "Clarias gariepinus" in the manuscript prompt template is gone
ok(!/`inversion candidates I have detected on \\`\$\{chrom\}\\` in a \*Clarias gariepinus\* hatchery cohort`/.test(html),
   'old hardcoded "Clarias gariepinus hatchery cohort" string removed from prompt template');
// _promptTemplate now reads state.data.species
{
  const fn = html.match(/function _promptTemplate\(chrom, nCand\)[\s\S]+?\n\}\n/);
  ok(!!fn, '_promptTemplate function extractable');
  if (fn) {
    ok(/state\.data\.species/.test(fn[0]),
       '_promptTemplate reads state.data.species');
    ok(/in a \*\$\{sp\}\* cohort/.test(fn[0]),
       'when species present: prompt reads "in a *{species}* cohort"');
    ok(/in the study cohort/.test(fn[0]),
       'when species absent: prompt falls back to "in the study cohort"');
  }
}
// headerMeta also surfaces species
ok(/data\.species[\s\S]{0,200}\$\{data\.species\.trim\(\)\}/.test(html),
   'headerMeta surfaces data.species when present');
// Header speciesPart formatted as italicized scientific name
ok(/<i>\$\{data\.species\.trim\(\)\}<\/i>/.test(html),
   'species rendered as <i>{species}</i> in header (scientific-name convention)');
// Roadmap entry for species portability shipped
ok(/<b>Species portability<\/b>[\s\S]{0,300}\[done v3\.99 t14e\+ continue\]/.test(html),
   'help-page roadmap has SHIPPED entry "Species portability" tagged [done v3.99 t14e+ continue]');
ok(/SCHEMA §16\.6/.test(html),
   'roadmap entry cross-links to SCHEMA §16.6');
// Comment block explains the why
ok(/no longer hardcodes "Clarias gariepinus"/.test(html) || /toolkit-portability goal/.test(html),
   'code-side comment explains the species-agnostic motivation');

// =============================================================================
// TEST 64: refined catalogue export — front-matter + JSON + filenames (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 64: refined catalogue export (turn 14e+ continue) ---');
// New helper functions
ok(/function _slugForFilename\(s\)/.test(html),
   '_slugForFilename helper defined for species filename slug');
ok(/function _exportSummaryStats\(rows\)/.test(html),
   '_exportSummaryStats helper computes K + verdict distributions + span range');
ok(/function _exportFrontMatter\(fmt, exportRows, totalAvailableRows\)/.test(html),
   '_exportFrontMatter builds the metadata header for both TSV and MD');
ok(/function _exportJsonObject\(rows, exportCols\)/.test(html),
   '_exportJsonObject builds the round-trippable {meta, columns, rows} shape');
// JSON format branch wired
ok(/} else if \(fmt === ['"]json['"]\) \{[\s\S]{0,400}JSON\.stringify/.test(html),
   'exportCatalogue handles fmt === "json" branch');
// JSON button in markup
ok(/id="catExportJSON"/.test(html),
   '#catExportJSON button in catalogue toolbar');
// JSON button has change handler wired
ok(/_catExpJSON\.addEventListener\(['"]click['"], \(\) => exportCatalogue\(['"]json['"]\)\)/.test(html),
   'JSON export button click handler wired');
// Filename includes species slug + date
ok(/const fname = `\$\{chrom\}\$\{speciesPart\}_inversion_catalogue_\$\{datePart\}\.\$\{ext\}`/.test(html),
   'export filename: chrom + speciesPart + date + ext');
ok(/const datePart = new Date\(\)\.toISOString\(\)\.slice\(0, 10\)/.test(html),
   'export filename includes ISO date stamp YYYY-MM-DD');
// Front-matter content (v4 cut: was 'v4.1' before)
ok(/`Inversion catalogue export — local PCA scrubber v4`/.test(html),
   'TSV/MD front-matter has tool identifier line');
ok(/`Generated: \$\{ts\}`/.test(html),
   'front-matter includes generation timestamp');
ok(/`K distribution: \$\{kSummary \|\| ['"]\(none\)['"]\}`/.test(html),
   'front-matter includes K distribution summary');
ok(/`σ-verdict distribution: \$\{verdictSummary \|\| ['"]\(none\)['"]\}`/.test(html),
   'front-matter includes σ-verdict distribution summary');
ok(/`Span: \$\{spanSummary\}`/.test(html),
   'front-matter includes span range summary');
// JSON shape (v4 cut: was 'pca_scrubber_v4.1')
ok(/tool: ['"]pca_scrubber_v4['"]/.test(html),
   'JSON meta includes tool="pca_scrubber_v4"');
ok(/k_distribution: stats\.kCounts/.test(html),
   'JSON meta includes k_distribution');
ok(/verdict_distribution: stats\.verdictCounts/.test(html),
   'JSON meta includes verdict_distribution');
// TSV/MD button tooltips updated
ok(/Includes a metadata header \(chromosome, species, schema version/.test(html),
   'TSV button tooltip mentions the new metadata header');
ok(/Includes a metadata blockquote header above the table/.test(html),
   'Markdown button tooltip mentions the new metadata header');

// =============================================================================
// TEST 65: gallery PNG export (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 65: gallery PNG export (turn 14e+ continue) ---');
// Gallery button in markup
ok(/id="catExportGallery"/.test(html),
   '#catExportGallery button in catalogue toolbar');
ok(/📷 export gallery PNG/.test(html),
   'gallery button text "📷 export gallery PNG"');
// Layout config
ok(/_GALLERY_LAYOUT\s*=\s*\{[\s\S]{0,400}cols:\s*4/.test(html),
   '_GALLERY_LAYOUT defined with cols: 4 default');
ok(/scale:\s*2/.test(html),
   '_GALLERY_LAYOUT scale: 2 (HiDPI / print quality)');
ok(/bgColor:\s*['"]#ffffff['"]/.test(html),
   '_GALLERY_LAYOUT white background (manuscript figures)');
// Helpers
ok(/function _galleryVerdictColor\(v\)/.test(html),
   '_galleryVerdictColor helper for print-friendly verdict colors');
ok(/function _galleryRowForCandidate\(cand\)/.test(html),
   '_galleryRowForCandidate looks up catalogue row from candidate.ref_l2');
ok(/function _galleryBandCounts\(cand\)/.test(html),
   '_galleryBandCounts counts samples per K-means group from locked_labels');
ok(/function _drawGalleryPanel\(ctx, x, y, w, h, cand, idx, total\)/.test(html),
   '_drawGalleryPanel renders one panel for one candidate');
ok(/function _buildGalleryCanvas\(confirmedCandidates\)/.test(html),
   '_buildGalleryCanvas assembles the full montage canvas');
ok(/function exportGalleryPNG\(\)/.test(html),
   'exportGalleryPNG entry point function');
// Wiring
ok(/_catExpGallery\.addEventListener\(['"]click['"], exportGalleryPNG\)/.test(html),
   'gallery button click wired to exportGalleryPNG');
// Source filtering
ok(/state\.candidateList[\s\S]{0,200}\.filter\(c => c && c\.confirmed\)/.test(html),
   'exportGalleryPNG filters state.candidateList for confirmed=true only');
// Sort by chromosomal position
ok(/confirmed\.sort\(\(a, b\) => \(a\.start_bp \|\| 0\) - \(b\.start_bp \|\| 0\)\)/.test(html),
   'gallery sorts confirmed candidates by start_bp (chromosomal order)');
// Empty state
ok(/No confirmed candidates to export/.test(html),
   'empty-state alert when no confirmed candidates');
// PNG export pathway
ok(/canvas\.toBlob\(\(blob\) =>/.test(html),
   'gallery uses canvas.toBlob() for PNG export');
ok(/canvas\.toDataURL\(['"]image\/png['"]\)/.test(html),
   'fallback to canvas.toDataURL when toBlob unavailable (test/JSDOM)');
// Filename pattern
ok(/`\$\{chrom\}\$\{speciesPart\}_inversion_gallery_\$\{datePart\}\.png`/.test(html),
   'gallery filename: chrom + speciesPart + date + .png');
// Verdict palette
ok(/v === ['"]TWO_INVERSIONS['"][\s\S]{0,40}#0a7d3a/.test(html),
   'TWO_INVERSIONS verdict gets green print color');
ok(/v === ['"]CROSSOVER_ARTIFACTS['"][\s\S]{0,40}#b54708/.test(html),
   'CROSSOVER_ARTIFACTS verdict gets orange-brown print color');

// =============================================================================
// TEST 66: Candidate bar above L1/L2 (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 66: candidate bar above L1/L2 — pending grey + confirmed gold★ (turn 14e+ continue) ---');
// New function exists
ok(/function drawCandidateBar\(ctx, d, toX, y0, h, opts\)/.test(html),
   'drawCandidateBar function defined with (ctx, d, toX, y0, h, opts) signature');
// Backward-compat alias preserved
ok(/function drawCandidateStrip\(ctx, d, toX, y0, stripH\) \{[\s\S]{0,200}drawCandidateBar/.test(html),
   'drawCandidateStrip kept as backward-compat alias forwarding to drawCandidateBar');
// Three-state rendering documented in comments
ok(/DRAFT \(state\.l3Draft/.test(html),
   'comment documents DRAFT state (amber outline, no fill)');
ok(/PENDING \(in state\.candidateList but confirmed === false\)/.test(html),
   'comment documents PENDING state (grey fill)');
ok(/CONFIRMED \(in state\.candidateList, confirmed === true\)/.test(html),
   'comment documents CONFIRMED state (gold gradient + ★)');
// Pending grey color
ok(/rgba\(120, 130, 145, \$\{0\.55 \* dimAlpha\}\)/.test(html),
   'pending candidates render in muted grey rgba(120,130,145, 0.55*dimAlpha)');
// Confirmed gradient
ok(/createLinearGradient\(0, y0, 0, y0 \+ h\)/.test(html),
   'confirmed candidates use a vertical linear gradient (top→bottom)');
ok(/grad\.addColorStop\(0,\s+`rgba\(255, 230, 130/.test(html),
   'gradient stop 0 (top): pale shine rgba(255,230,130)');
ok(/grad\.addColorStop\(0\.35, `rgba\(245, 200, 60/.test(html),
   'gradient stop 0.35: mid-gold');
ok(/grad\.addColorStop\(1,\s+`rgba\(190, 145, 25/.test(html),
   'gradient stop 1 (bottom): deep gold rgba(190,145,25)');
// ★ glyph rendering
ok(/ctx\.fillText\(['"]★['"], cx \+ 0\.6, cy \+ 0\.6\)/.test(html),
   '★ glyph drop shadow drawn (offset +0.6, +0.6)');
ok(/ctx\.fillText\(['"]★['"], cx, cy\)/.test(html),
   '★ glyph main rendering drawn at center');
ok(/showStar && w >= 12 && h >= 6/.test(html),
   '★ glyph only drawn when bar is wide enough (≥12px) and tall enough (≥6px)');
// Layout shift in non-collapsed Z mode
ok(/const candBarH = 7;[\s\S]{0,200}const candGap  = 2;[\s\S]{0,200}const zoneTop = pad\.t \+ candBarH \+ candGap;/.test(html),
   'non-collapsed Z mode reserves candBarH=7 + candGap=2; zoneTop = pad.t + 9');
// Layout shift in collapsed Z mode
ok(/state\.zCollapsed[\s\S]{0,800}const candBarH = 5;[\s\S]{0,200}const candGap  = 1;[\s\S]{0,200}const zoneTop  = pad\.t \+ candBarH \+ candGap;/.test(html),
   'collapsed Z mode reserves candBarH=5 + candGap=1');
// L1 bar uses zoneTop now (not pad.t)
ok(/if \(Array\.isArray\(d\.l1_envelopes\)\) \{\s*const y0 = zoneTop, hzone = zoneH \/ 2 - 1;/.test(html),
   'L1 bar y0 = zoneTop in non-collapsed (was pad.t)');
// L2 bar uses zoneTop
ok(/const y0 = zoneTop \+ zoneH \/ 2 \+ 1, hzone = zoneH \/ 2 - 1;/.test(html),
   'L2 bar y0 = zoneTop + zoneH/2 + 1 in non-collapsed (was pad.t + zoneH/2 + 1)');
// drawCandidateBar called at TOP of canvas
ok(/drawCandidateBar\(ctx, d, toX, pad\.t, candBarH\)/.test(html),
   'drawCandidateBar called at pad.t (top of canvas, above L1/L2)');
// Pass order: pending (grey) then confirmed (gold) so gold sits on top
ok(/Pass 1: pending \(grey\)[\s\S]{0,800}Pass 2: confirmed \(shiny gold gradient/.test(html),
   'render order: pass 1 pending grey → pass 2 confirmed gold (so gold sits on top)');
// Draft uses dashed amber outline (not solid)
ok(/setLineDash\(\[3, 2\]\);[\s\S]{0,100}strokeRect/.test(html),
   'draft renders with dashed amber outline (setLineDash([3,2]))');
// dimAlpha opt for compact-mode tweaks
ok(/dimAlpha = opts\.dimAlpha != null \? opts\.dimAlpha : 1\.0/.test(html),
   'opts.dimAlpha defaults to 1.0 (full alpha) but compact mode can dim');
// Comment quotes Quentin's exact request
ok(/Add Candidate bar on top of L1 and L2 bars in page 1/.test(html),
   'inline comment quotes the original request verbatim');

// =============================================================================
// TEST 67: Windows page column-driven histogram coloring (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 67: Windows page column-driven coloring (turn 14e+ continue) ---');
ok(/let _winSumColorMode = ['"]z['"];/.test(html),
   '_winSumColorMode state slot defined with default "z"');
ok(/function _winSumValueForMode\(w, i, d, mode\)/.test(html),
   '_winSumValueForMode helper extracts per-window value for any mode');
ok(/function _winSumColorModeLabel\(mode\)/.test(html),
   '_winSumColorModeLabel returns human-readable label per mode');
ok(/function _winSumModeHasGradient\(mode\)/.test(html),
   '_winSumModeHasGradient gates l1/l2 categorical columns');
// All 9 modes present in value extractor
const modes = ['z', 'n_snps', 'span_kb', 'snp_density', 'lam1', 'lam2', 'ratio', 'mb', 'idx'];
for (const m of modes) {
  ok(new RegExp(`case ['"]${m}['"]:`).test(html),
     `_winSumValueForMode handles mode "${m}"`);
}
// Click handler now sets BOTH sort + color mode
ok(/_winSumColorMode = ['"]z['"]/.test(html),
   'header click handler resets to "z" for categorical columns (l1/l2)');
ok(/_winSumColorMode = col;/.test(html),
   'header click handler sets color mode to clicked column for numeric ones');
// Strip label updates dynamically
ok(/<span id="winSumColorModeLabel"/.test(html),
   '#winSumColorModeLabel span exists in markup for dynamic label');
ok(/colorLab\.textContent = _winSumColorModeLabel\(_winSumColorMode/.test(html),
   'label kept in sync with active color mode after each render');
// Strip generalized — uses mode (not hardcoded |Z|)
ok(/const mode = _winSumColorMode \|\| ['"]z['"];/.test(html),
   'drawWinSumStrip reads _winSumColorMode (not hardcoded |Z|)');
// L1/L2 fall back to z
ok(/if \(col === ['"]l1['"] \|\| col === ['"]l2['"]\) \{[\s\S]{0,80}_winSumColorMode = ['"]z['"]/.test(html),
   'L1/L2 column clicks fall back to "z" coloring (categorical, no gradient)');

// =============================================================================
// TEST 68: ANGSD bi-SNP provenance info chip (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 68: ANGSD bi-SNP info chip (turn 14e+ continue) ---');
ok(/id="winSumBisnpInfoBtn"/.test(html),
   '#winSumBisnpInfoBtn info chip in markup');
ok(/ⓘ ANGSD bi-SNPs/.test(html),
   'info chip text "ⓘ ANGSD bi-SNPs"');
ok(/id="winSumBisnpInfoPanel"/.test(html),
   '#winSumBisnpInfoPanel collapsible panel in markup');
ok(/<i>C\. gariepinus<\/i> 226-sample hatchery cohort/.test(html),
   'panel header identifies the gariepinus 226-sample hatchery cohort');
// All canonical ANGSD parameters listed
const angsdParams = [
  ['-GL 1', 'SAMtools genotype-likelihood model'],
  ['-minQ 25', 'Minimum base quality'],
  ['-minMapQ 25', 'Minimum mapping quality'],
  ['-baq 1', 'BAQ recalibration'],
  ['-C 50', 'Excessive-mismatch downweight'],
  ['-setMinDepthInd 3', 'Min per-individual depth'],
  ['-setMaxDepthInd 57', 'Max per-individual depth'],
  ['-minInd 200', 'Min individuals with data per site'],
  ['-SNP_pval 1e-6', 'SNP significance threshold'],
  ['-minMaf 0.05', 'Minimum minor allele frequency'],
  ['-pest', 'Folded SFS prior'],
];
for (const [p, _expl] of angsdParams) {
  // Parameter appears as <code> in the table
  // Use a flexible regex that escapes regex metas
  const escaped = p.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  ok(new RegExp(`<code>${escaped}</code>`).test(html),
     `parameter listed: ${p}`);
}
ok(/Click to show the ANGSD parameters/.test(html),
   'info chip tooltip explains its purpose');
// Wired to toggle handler
ok(/bisnpBtn\.addEventListener\(['"]click['"], \(\) => \{[\s\S]{0,400}bisnpPanel\.style\.display/.test(html),
   'info chip click handler toggles panel display');
// Cross-reference to schema 2.15
ok(/schema 2\.15 §8\.x/.test(html),
   'mentions future schema 2.15 §8.x angsd_bisnp_params layer for non-gariepinus cohorts');

// =============================================================================
// TEST 69: Diversity Atlas / Inversion Atlas schema-only documentation
// =============================================================================
console.log('\n--- TEST 69: Atlas mode switching schema doc (turn 14e+ continue) ---');
ok(/<b>Atlas mode switching<\/b>[\s\S]{0,200}\[schema 2\.15, post-v4\.0\]/.test(html),
   'Atlas mode switching roadmap entry tagged [schema 2.15, post-v4.0]');
ok(/Inversion Atlas ⇄ Diversity Atlas/.test(html),
   'roadmap entry header shows the dual-atlas concept');
ok(/state\.atlas[\s\S]{0,40}inversion[\s\S]{0,40}diversity/.test(html),
   'roadmap entry mentions state.atlas slot with both values');
ok(/loaded but in stand by/.test(html) || /loaded in memory/.test(html),
   'roadmap entry quotes Quentin\'s "loaded but in stand by" wording');
ok(/Phase A schema-only \(now\)/.test(html),
   'roadmap entry documents Phase A/B/C/D phasing');
ok(/Toolkit containerization/.test(html) && /Atlas mode switching/.test(html),
   'BOTH containerization and atlas-switch roadmap entries present (one was lost during edit, restored)');

// =============================================================================
// TEST 70: Karyotype / Tier sub-view scaffold (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 70: Karyotype/Tier sub-view scaffold (turn 14e+ continue) ---');

// Tab renamed from "5 karyotype" to "5 karyotype / tier" (in v3.99 t14e+ continue
// turn-1 the position was 5; after the θπ scrubber inserted at position 2 in
// turn-2, it shifted to 6).
ok(/<span class="num">6<\/span> karyotype \/ tier/.test(html),
   'page 4 tab renamed to "6 karyotype / tier" (shifted from 5 after θπ scrubber inserted at position 2)');

// Sub-view toggle markup
ok(/id="candKaryoSubviewBar"/.test(html),
   '#candKaryoSubviewBar toolbar markup present');
ok(/id="candSubviewKaryoBtn"[\s\S]{0,200}data-subview="karyotype"/.test(html),
   '#candSubviewKaryoBtn with data-subview="karyotype"');
ok(/id="candSubviewTierBtn"[\s\S]{0,200}data-subview="tier"/.test(html),
   '#candSubviewTierBtn with data-subview="tier"');
ok(/id="candTierLayerStatus"/.test(html),
   '#candTierLayerStatus span present (shows layer load state)');
ok(/id="candTierContent"/.test(html),
   '#candTierContent panel present (parallel to existing #candKaryoContent)');

// karyoState.subview slot + persistence
ok(/subview: ['"]karyotype['"],/.test(html),
   'karyoState extended with subview slot, default "karyotype"');
ok(/_CAND_SUBVIEW_KEY = ['"]pca_scrubber_v3\.candSubview['"]/.test(html),
   'localStorage persistence key defined for sub-view choice');
ok(/saved === ['"]karyotype['"] \|\| saved === ['"]tier['"]/.test(html),
   'persistence restore validates value before applying');

// 14-axis constant
ok(/const _TIER_AXES = \[/.test(html),
   '_TIER_AXES constant defined');
const axes = [
  'existence_layer_a', 'existence_layer_b', 'existence_layer_c', 'existence_layer_d',
  'boundary_quality', 'group_validation', 'internal_structure', 'recombinant_class',
  'family_linkage', 'polymorphism_class', 'mechanism_class', 'age_class',
  'burden_class', 'confidence_tier',
];
for (const a of axes) {
  ok(new RegExp(`id: ['"]${a}['"]`).test(html),
     `_TIER_AXES contains axis: ${a}`);
}

// Six section groups
const groups = ['existence', 'boundary', 'groups', 'population', 'biology', 'tier'];
for (const g of groups) {
  ok(new RegExp(`group: ['"]${g}['"]`).test(html),
     `_TIER_AXES uses group: ${g}`);
}

// Section labels
ok(/EXISTENCE LAYERS/.test(html), 'section label: EXISTENCE LAYERS');
ok(/BOUNDARIES/.test(html), 'section label: BOUNDARIES');
ok(/KARYOTYPE GROUPS/.test(html), 'section label: KARYOTYPE GROUPS');
ok(/POPULATION GENETICS/.test(html), 'section label: POPULATION GENETICS');
ok(/BIOLOGY/.test(html), 'section label: BIOLOGY');
ok(/OVERALL TIER/.test(html), 'section label: OVERALL TIER');

// Helper functions
ok(/function renderCandidateTier\(\)/.test(html),
   'renderCandidateTier function defined');
ok(/function _renderCandidateKaryotypeBody\(\)/.test(html),
   '_renderCandidateKaryotypeBody helper (extracted from old renderCandidateKaryotype)');
ok(/function _refreshSubviewButtonStyles\(active\)/.test(html),
   '_refreshSubviewButtonStyles updates active/inactive button styling');
ok(/function _wireCandSubviewButtons\(\)/.test(html),
   '_wireCandSubviewButtons wires click handlers (idempotent)');
ok(/function _tierAxisValueColor\(axisId, value\)/.test(html),
   '_tierAxisValueColor returns category-appropriate color');
ok(/function _renderTierAxesGrid\(axisValues\)/.test(html),
   '_renderTierAxesGrid renders cards grouped by section (null = empty state)');

// Layer detection
ok(/case ['"]final_classification['"]:/.test(html),
   'detectSchemaAndLayers includes final_classification case');
ok(/typeof data\.final_classification === ['"]object['"]/.test(html),
   'final_classification layer detection validates object type');

// Empty-state messaging
ok(/final_classification.{0,40}JSON layer isn't loaded/.test(html),
   'empty state explains the missing layer');
ok(/14-axis schema \(read-only preview\)/.test(html),
   'empty state shows the 14-axis schema as preview');
ok(/characterize_candidate\.R/.test(html) && /classify_inversions\.R/.test(html),
   'empty state references the planned cluster-side R scripts');

// Color palette — verify key value→color mappings
ok(/'pass'.{0,80}rgba\(34,160,80/.test(html),
   'pass values render green (rgba(34,160,80,...))');
ok(/'fail'.{0,80}rgba\(224,85,92/.test(html),
   'fail values render red (rgba(224,85,92,...))');
ok(/'VALIDATED'.{0,80}rgba\(34,160,80/.test(html),
   'VALIDATED group_validation renders green');
ok(/'T1'.{0,80}rgba\(34,160,80/.test(html),
   'T1 confidence_tier renders green');
ok(/'T4'.{0,80}rgba\(245,165,36/.test(html),
   'T4 confidence_tier renders amber');
ok(/'pca_family_confounded'.{0,80}rgba\(224,85,92/.test(html),
   'pca_family_confounded family_linkage renders red (warning state)');

// Wire-up at init
ok(/_wireCandSubviewButtons\(\)/.test(html),
   '_wireCandSubviewButtons called somewhere (init or render)');
ok(/dataset\.wired = ['"]1['"]/.test(html),
   'wire fn uses dataset.wired idempotency guard');

// Read-only contract — scrubber NEVER writes
const readonlyChecks = [
  /scrubber NEVER writes to/i,
  /Read-only/i,
];
ok(readonlyChecks.some(r => r.test(html)),
   'read-only contract documented in source');

// Schema cross-reference
ok(/SCHEMA[\s\S]{0,5}§19/.test(html),
   'Tier renderer references SCHEMA §19');

// =============================================================================
// TEST 71: Registry interop scaffold (turn 14e+ continue, SCHEMA §20)
// =============================================================================
console.log('\n--- TEST 71: Registry interop scaffold (turn 14e+ continue) ---');
ok(/id="loadRegistryBtn"/.test(html),
   '#loadRegistryBtn button in markup');
ok(/📦 load registry/.test(html),
   '📦 load registry button label present');
ok(/id="loadRegistryInput"[\s\S]{0,400}multiple/.test(html),
   '#loadRegistryInput is a multi-file picker (multiple attribute)');
ok(/accept="\.tsv,\.json,\.gz/.test(html) || /accept="\.tsv,\.json/.test(html),
   'multi-file picker accepts .tsv, .json, .gz');
// Helper functions present
ok(/function loadRegistryArtifacts\(fileList\)/.test(html),
   'loadRegistryArtifacts(fileList) entry point defined');
ok(/function _parseTSV\(text\)/.test(html),
   '_parseTSV helper defined');
ok(/function _identifyRegistryArtifact\(filename, content, parsed\)/.test(html),
   '_identifyRegistryArtifact helper defined');
ok(/function _validateRegistryTable\(kind, parsed\)/.test(html),
   '_validateRegistryTable helper defined');
ok(/function _candidateIdFromPath\(filepath\)/.test(html),
   '_candidateIdFromPath helper extracts cid from per_candidate/.../structured/ paths');
ok(/function _blockTypeFromPath\(filepath\)/.test(html),
   '_blockTypeFromPath helper extracts block type from filename');
ok(/function _finalizeRegistryLoad\(summary\)/.test(html),
   '_finalizeRegistryLoad helper produces summary alert');
// Schema constants — required-column lists per artifact type
ok(/const _REG_SCHEMAS = \{/.test(html),
   '_REG_SCHEMAS constant declares required fields per artifact');
ok(/sample_groups:[\s\S]{0,200}required:[\s\S]{0,100}'group_id'[\s\S]{0,100}'members_file'/.test(html),
   'sample_groups schema requires group_id + members_file');
ok(/candidate_intervals:[\s\S]{0,200}required:[\s\S]{0,100}'candidate_id'[\s\S]{0,100}'chrom'[\s\S]{0,100}'start_bp'[\s\S]{0,100}'end_bp'/.test(html),
   'candidate_intervals schema requires candidate_id, chrom, start_bp, end_bp');
ok(/results_manifest:[\s\S]{0,200}required:[\s\S]{0,100}'row_id'[\s\S]{0,100}'kind'/.test(html),
   'results_manifest schema requires row_id + kind');
// Filename detection patterns
ok(/sample_groups\\\.tsv/.test(html),
   'identifier matches sample_groups.tsv filename');
ok(/candidate_intervals\\\.tsv/.test(html),
   'identifier matches candidate_intervals.tsv filename');
ok(/manifest\\\.tsv/.test(html),
   'identifier matches manifest.tsv filename');
ok(/\\\/structured\\\//.test(html),
   'identifier matches per_candidate/.../structured/ path pattern');
// Special handling: structured block → final_classification extraction
ok(/'final_classification' \|\| bt === 'classification'/.test(html),
   'final_classification / classification block types extract 14 axes into top-level layer');
ok(/_AXIS_KEYS = \['existence_layer_a'/.test(html),
   '_AXIS_KEYS array enumerates the 14 classification axes');
// Wiring
ok(/loadRegistryArtifacts\(e\.target\.files\)/.test(html),
   'click handler wires multi-file picker to loadRegistryArtifacts');
// Schema cross-reference
ok(/SCHEMA §20/.test(html) || /schema 2\.17/.test(html) || /SCHEMA_V2\.md §20/.test(html),
   'registry-interop UI references SCHEMA §20');
// Help-page roadmap entry
ok(/<b>Registry interop<\/b>[\s\S]{0,200}\[done v3\.99 t14e\+ continue\]/.test(html),
   'help-page SHIPPED entry "Registry interop" present');
// Honesty bullet — explicit "additive enrichment, not replacement"
ok(/additive enrichment[\s\S]{0,80}precomp JSON/.test(html) || /additive enrichment on top of a precomp/.test(html),
   'help-page entry honestly states registry-load is ADDITIVE, not a replacement for precomp JSON');
// Per-window data NOT loaded from registry
ok(/per-window local PCA[\s\S]{0,80}lives in the precomp JSON/.test(html) || /per-window local PCA[\s\S]{0,200}precomp JSON/.test(html),
   'help-page entry honestly states per-window local PCA does NOT come from registry');

// =============================================================================
// TEST 72: 18 structured block types scaffold (turn 14e+ continue, SCHEMA §21)
// =============================================================================
console.log('\n--- TEST 72: 18 structured block types (turn 14e+ continue) ---');
ok(/const _KNOWN_BLOCK_TYPES = \[/.test(html),
   '_KNOWN_BLOCK_TYPES constant declared');
// All 18 block types listed
const _BLOCK_TYPES = ['existence_layer_a', 'existence_layer_b', 'existence_layer_c',
  'existence_layer_d', 'boundary_left', 'boundary_right', 'carrier_reconciliation',
  'internal_dynamics', 'mechanism', 'age_evidence', 'frequency', 'hypothesis_verdict',
  'morphology', 'band_composition', 'burden', 'block_detect', 'triangle_insulation',
  'peel_diagnostic', 'synteny_dollo'];
for (const bt of _BLOCK_TYPES) {
  ok(new RegExp(`'${bt}'`).test(html),
     `_KNOWN_BLOCK_TYPES includes '${bt}'`);
}
// Plus the synthesis aliases
ok(/'final_classification', 'classification'/.test(html),
   'synthesis aliases (final_classification, classification) included');

// _deriveAxesFromBlock helper
ok(/function _deriveAxesFromBlock\(blockType, obj\)/.test(html),
   '_deriveAxesFromBlock(blockType, obj) helper defined');
// Specific derivation rules — spot-check key cases
ok(/case 'existence_layer_a':/.test(html) && /obj\.detected === true/.test(html),
   'existence_layer_a case derives from obj.detected');
ok(/case 'existence_layer_d':[\s\S]{0,400}fisher_p < 0\.05/.test(html),
   'existence_layer_d uses fisher_p < 0.05 threshold');
ok(/case 'carrier_reconciliation':[\s\S]{0,400}group_validation\.level/.test(html),
   'carrier_reconciliation derives group_validation from obj.group_validation.level');
ok(/case 'internal_dynamics':[\s\S]{0,800}n_recombinant/.test(html),
   'internal_dynamics derives from n_recombinant');
ok(/case 'internal_dynamics':[\s\S]{0,1500}n_gene_conversion[\s\S]{0,200}n_double_crossover/.test(html),
   'internal_dynamics derives recombinant_class from gc + dco counts');
ok(/case 'mechanism':[\s\S]{0,400}classification\.mechanism/.test(html),
   'mechanism derives from obj.classification.mechanism');
ok(/case 'age_evidence':[\s\S]{0,400}conclusion\.age_class/.test(html),
   'age_evidence derives from obj.conclusion.age_class');
ok(/'old'\) \? 'ancient'/.test(html),
   "age 'old' is normalized to 'ancient'");
ok(/case 'frequency':[\s\S]{0,300}family_linkage/.test(html),
   'frequency derives family_linkage');
ok(/case 'frequency':[\s\S]{0,1200}freq_cv_across_qgroups/.test(html),
   'frequency derives polymorphism_class from freq_cv_across_qgroups');
ok(/case 'hypothesis_verdict':[\s\S]{0,800}layers_passed/.test(html),
   'hypothesis_verdict derives confidence_tier from layers_passed');
ok(/'sv_only'[\s\S]{0,80}'SV_only'/.test(html),
   'hypothesis_verdict handles independence_class === sv_only edge case');
ok(/'layer_c_only'[\s\S]{0,80}'Layer_C_only'/.test(html),
   'hypothesis_verdict handles independence_class === layer_c_only edge case');
ok(/case 'burden':[\s\S]{0,400}'INV_ELEVATED'[\s\S]{0,200}'enriched'/.test(html),
   'burden maps INV_ELEVATED → enriched');

// Boundary reconciliation
ok(/function _reconcileBoundaryQuality\(cid\)/.test(html),
   '_reconcileBoundaryQuality helper defined');
ok(/_reconcileBoundaryQuality/.test(html) && /sharp[\s\S]{0,200}fuzzy/.test(html),
   'boundary reconciliation produces sharp/fuzzy verdicts');

// Loader integration — derive axes inline
ok(/_deriveAxesFromBlock\(bt, obj\)/.test(html),
   'registry loader calls _deriveAxesFromBlock for each loaded block');
ok(/Object\.assign\(state\.data\.final_classification\[cid\], derived\)/.test(html),
   'derived axes merge into state.data.final_classification[cid] (compose)');

// Block-type counting in summary
ok(/summary\.block_type_counts/.test(html),
   'summary tracks per-block-type counts');
ok(/summary\.unknown_block_types/.test(html),
   'summary separates known vs unknown block types');
ok(/summary\.axis_derivations/.test(html),
   'summary tracks axis_derivations count');
ok(/summary\.boundary_reconciled/.test(html),
   'summary tracks boundary_reconciled count');

// Help-page roadmap entry
ok(/<b>18 structured block types<\/b>/.test(html),
   'help-page SHIPPED entry "18 structured block types" present');
ok(/SCHEMA §21/.test(html) || /SCHEMA_V2\.md §21/.test(html),
   'help-page references SCHEMA §21');
ok(/composes? into the 14-axis/.test(html) || /Multiple blocks compose/.test(html),
   'help-page explains "multiple blocks compose" semantic');

// =============================================================================
// TEST 73: Block-presence chips + JSON inspector (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 73: Block chips + JSON inspector (turn 14e+ continue) ---');
ok(/function candidateBlockChipsHtml\(c\)/.test(html),
   'candidateBlockChipsHtml(c) function defined');
ok(/function _wireCandidateBlockChips\(\)/.test(html),
   '_wireCandidateBlockChips() function defined');
ok(/function _toggleBlockInspector\(cid, blockType, chip\)/.test(html),
   '_toggleBlockInspector(cid, blockType, chip) function defined');
// Display order constant
ok(/const _BLOCK_DISPLAY_ORDER = \[/.test(html),
   '_BLOCK_DISPLAY_ORDER constant declared');
// All 18 + synthesis present in display order
const _CHIP_BLOCKS = ['existence_layer_a', 'existence_layer_b', 'existence_layer_c',
  'existence_layer_d', 'boundary_left', 'boundary_right', 'carrier_reconciliation',
  'internal_dynamics', 'mechanism', 'age_evidence', 'frequency', 'hypothesis_verdict',
  'morphology', 'band_composition', 'burden', 'block_detect', 'triangle_insulation',
  'peel_diagnostic', 'synteny_dollo', 'final_classification'];
for (const bt of _CHIP_BLOCKS) {
  ok(new RegExp(`bt: '${bt}'`).test(html),
     `_BLOCK_DISPLAY_ORDER includes bt='${bt}'`);
}
ok(/_BLOCKS_WITH_AXIS_DERIVATION = new Set/.test(html),
   '_BLOCKS_WITH_AXIS_DERIVATION set distinguishes axis-contributing blocks');
// Color logic — 4 distinct visual states
ok(/rgba\(34,160,80,0\.18\)/.test(html),
   'green chip background for axis-contributing loaded blocks');
ok(/rgba\(48,116,200,0\.15\)/.test(html),
   'blue chip background for supportive loaded blocks');
ok(/rgba\(245,165,36,0\.18\)/.test(html),
   'gold chip background for synthesis block');
ok(/var\(--ink-dimmer\)/.test(html),
   'dim/grey foreground for missing chips');
// Chip element shape
ok(/class="cand-block-chip"/.test(html),
   '.cand-block-chip class on chip buttons');
ok(/data-block-type=/.test(html) && /data-cid=/.test(html) && /data-has=/.test(html),
   'chips carry data-block-type, data-cid, data-has attributes');
// Mount point for inspectors
ok(/id="candBlockInspectors"/.test(html),
   '#candBlockInspectors mount node in chip row markup');
// Click handler routes to inspector
ok(/_toggleBlockInspector\(\s*chip\.dataset\.cid,\s*chip\.dataset\.blockType,\s*chip\s*\)/.test(html) ||
   /_toggleBlockInspector\(\n\s*chip\.dataset\.cid, chip\.dataset\.blockType, chip\n\s*\)/.test(html),
   'chip click handler calls _toggleBlockInspector with cid + blockType + chip');
// Inspector toggle behavior
ok(/const existing = document\.getElementById\(existingId\);[\s\S]{0,80}if \(existing\) \{[\s\S]{0,120}existing\.remove\(\)/.test(html),
   'inspector toggle removes existing inspector on second click');
// Truncation for huge blocks
ok(/TRUNC_LIMIT = 200_000|TRUNC_LIMIT = 200000/.test(html),
   'inspector truncates blocks > 200 KB');
ok(/\[truncated\]/.test(html),
   'inspector shows [truncated] badge when block exceeds limit');
// Header surface fields
ok(/source_script/.test(html) && /source_version/.test(html) &&
   /computed_at/.test(html) && /validation_level/.test(html),
   'inspector surfaces common-header fields above raw JSON');
// Composition into renderCandidateMetadata
ok(/candidateBlockChipsHtml\(c\)[\s\S]{0,300}candidateRichCardHtml\(c\)/.test(html),
   'candidateBlockChipsHtml inserted between header and richCard in renderCandidateMetadata');
// Wire call in renderCandidateMetadata
ok(/_wireCandidateBlockChips\(\)/.test(html),
   '_wireCandidateBlockChips called after DOM insertion');
// Idempotent wiring guard
ok(/chip\.dataset\.wired === ['"]1['"]/.test(html),
   'wire guard checks dataset.wired === "1" for idempotency');
// Dim chips inert
ok(/if \(!has\) \{ chip\.dataset\.wired = ['"]1['"]; return; \}/.test(html),
   'dim/missing chips marked wired but no click handler attached');
// Registry-load finalizer re-renders candidate focus page
ok(/typeof renderCandidateMetadata === 'function'[\s\S]{0,80}renderCandidateMetadata\(\)/.test(html),
   '_finalizeRegistryLoad calls renderCandidateMetadata to refresh chips');
// Help-page entry
ok(/<b>Block-presence chips \+ JSON inspector<\/b>/.test(html),
   'help-page SHIPPED entry "Block-presence chips + JSON inspector" present');
// Group spacers — visual sectioning between groups
ok(/groupChange \? ['"]8px['"] : ['"]2px['"]/.test(html),
   'larger left-margin (8px) between block-display groups for visual sectioning');

// =============================================================================
// TEST 74: θπ scrubber as new page 12 (turn 14e+ continue, SCHEMA §22)
// =============================================================================
console.log('\n--- TEST 74: θπ scrubber page 12 scaffold (turn 14e+ continue) ---');

// New tab button at user-visible position 2 — Quentin's t14e+ continue rename:
// "θπ diagnostic" → "local PCA θπ" (v4 turn 3 rename — was "local PCA thetapi")
ok(/<button data-page="page12"[^>]+title=[^>]+><span class="num">2<\/span> local PCA θπ<\/button>/.test(html),
   'θπ scrubber tab button at user-visible position 2 with data-page="page12" reads "local PCA θπ"');

// Page 1 symmetric rename: "diagnostic" → "local PCA |z|"
ok(/<button data-page="page1"[^>]+><span class="num">1<\/span> local PCA \|z\|<\/button>/.test(html),
   'page 1 tab label renamed to "local PCA |z|" (symmetric with page 12)');

// Tab title mentions key concepts
ok(/<button data-page="page12"[^>]+(diversity scanner|orthogonal validation|mirroring page 1)/.test(html),
   'θπ tab title explains the page is a chromosome-wide diversity scanner');

// Tab renumbering — existing tabs shifted right by 1 in user-visible numbering
ok(/<button data-page="page2"[^>]+><span class="num">3<\/span> candidate focus/.test(html),
   'candidate focus tab shifted to position 3 (was 2)');
ok(/<button data-page="page11"[^>]+><span class="num">4<\/span> boundaries/.test(html),
   'boundaries tab shifted to position 4 (was 3)');
ok(/<button data-page="page3"[^>]+><span class="num">5<\/span> catalogue/.test(html),
   'catalogue tab shifted to position 5 (was 4)');
ok(/<button data-page="page4"[^>]+><span class="num">6<\/span> karyotype \/ tier/.test(html),
   'karyotype/tier tab shifted to position 6 (was 5)');
ok(/<button data-page="page9"[^>]+><span class="num">10<\/span> confirmed/.test(html),
   'confirmed tab shifted to position 10 (was 9)');
ok(/<button data-page="page5"[^>]+><span class="num">12<\/span> help/.test(html),
   'help tab shifted to position 12 (was 11)');

// page12 DOM block
ok(/<div id="page12" class="page">/.test(html),
   '#page12 DOM block present with class="page"');
ok(/id="thetaPiEmpty"/.test(html),
   '#thetaPiEmpty empty-state placeholder present');
ok(/local PCA θπ — chromosome-wide diversity scanner/.test(html),
   'empty-state title explains the page is a chromosome-wide diversity scanner (v4 turn 3 rename — was "local PCA thetapi")');

// Empty-state references SCHEMA §22
ok(/SCHEMA §22|SCHEMA_V2\.md §22/.test(html),
   'empty-state references SCHEMA §22');

// Empty-state lists the three required JSON layers
ok(/theta_pi_per_window/.test(html) &&
   /theta_pi_local_pca/.test(html) &&
   /theta_pi_envelopes/.test(html),
   'empty-state lists all three required θπ JSON layers');

// Empty-state shows R-side script names
ok(/STEP_R39/.test(html) && /STEP_R40/.test(html) && /STEP_R41/.test(html),
   'empty-state names the three planned R-side scripts (STEP_R39/R40/R41)');

// Layer-status indicator markup — three rows, one per layer, each with a data-th-layer attr
ok(/data-th-layer="theta_pi_per_window"/.test(html),
   'layer-status row for theta_pi_per_window');
ok(/data-th-layer="theta_pi_local_pca"/.test(html),
   'layer-status row for theta_pi_local_pca');
ok(/data-th-layer="theta_pi_envelopes"/.test(html),
   'layer-status row for theta_pi_envelopes');

// Initial status text shows ⚪ not loaded
ok(/⚪ not loaded/.test(html),
   'layer-status rows initialize with ⚪ not loaded indicator');

// _refreshThetaPiLayerStatus helper defined
ok(/function _refreshThetaPiLayerStatus\(\)/.test(html),
   '_refreshThetaPiLayerStatus() helper defined');
ok(/document\.querySelectorAll\('\[data-th-layer\]'\)/.test(html),
   '_refreshThetaPiLayerStatus queries [data-th-layer] elements');
ok(/state\.layersPresent &&[\s\S]{0,80}\.has\(layerName\)/.test(html),
   '_refreshThetaPiLayerStatus reads from state.layersPresent.has(layerName)');
ok(/🟢 loaded/.test(html),
   '_refreshThetaPiLayerStatus toggles to 🟢 loaded indicator');

// Helper called from data-load path
ok(/state\.data = data;[\s\S]{0,800}_refreshThetaPiLayerStatus/.test(html),
   'data-load path calls _refreshThetaPiLayerStatus after setting state.data');

// Empty-state mentions the panel-layout mirror
ok(/Panel layout \(mirrors page 1/.test(html),
   'empty-state shows the mirror-page-1 panel layout');
ok(/#thSimPanel/.test(html) && /#thZPanel/.test(html) && /#thLinesPanel/.test(html) &&
   /#thPcaPanel/.test(html) && /#thL3Panel/.test(html) && /#thCtrlBar/.test(html),
   'empty-state names all six future panel ids (#thCtrlBar, #thSimPanel, #thZPanel, #thLinesPanel, #thPcaPanel, #thL3Panel)');

// Layer detection extended for the three new θπ layers
ok(/case 'theta_pi_per_window':\s*ok = !!data\.theta_pi_per_window/.test(html),
   'detectSchemaAndLayers handles theta_pi_per_window');
ok(/case 'theta_pi_local_pca':\s*ok = !!data\.theta_pi_local_pca/.test(html),
   'detectSchemaAndLayers handles theta_pi_local_pca');
ok(/case 'theta_pi_envelopes':\s*ok = !!data\.theta_pi_envelopes/.test(html),
   'detectSchemaAndLayers handles theta_pi_envelopes');

// SCHEMA §22.13: Shape A (per-window-embedded w.theta) auto-detection —
// existing JSONs that pass --theta to export_precomp_to_json.R already
// carry the data the page-12 scrubber needs. The detector should flag
// theta_pi_per_window present when data.windows[0].theta is a non-empty
// array, even without an explicit declaration in _layers_present.
ok(/!actual\.has\('theta_pi_per_window'\)[\s\S]{0,200}data\.windows\[0\]\.theta/.test(html),
   'detectSchemaAndLayers Shape A auto-detection: checks data.windows[0].theta (existing per-window embedding from export_precomp_to_json.R --theta)');
ok(/SCHEMA §22\.13/.test(html),
   'Shape A auto-detection comment references SCHEMA §22.13');
ok(/Array\.isArray\(data\.windows\[0\]\.theta\)/.test(html),
   'Shape A check verifies data.windows[0].theta is an array');

// Help-page entry rewrites old description (now covers BOTH pages 1 and 12 + composition panel)
ok(/Local PCA scrubbers — page 1 \(\|z\|\) \+ page 2 \(thetapi\)/.test(html),
   'help-page entry "Local PCA scrubbers — page 1 (|z|) + page 2 (thetapi)" present');
ok(/scaffold shipped/.test(html),
   'help-page entry status shows scaffold shipped');
ok(/dosage_only/.test(html) && /theta_pi_only/.test(html) && /both_overlap_partial/.test(html),
   'help-page entry mentions cross-method validation values (dosage_only / theta_pi_only / both_overlap_partial)');
// Help-page entry mentions Q05 already produces theta_pi_per_window
ok(/STEP_Q05_aggregate_theta\.sh|Q05/.test(html),
   'help-page entry references STEP_Q05_aggregate_theta.sh as the existing data source');
ok(/Shape A/.test(html),
   'help-page entry mentions Shape A (per-window-embedded w.theta) auto-detection');
// Composition panel help entry
ok(/<b>internal_ancestry_composition panel<\/b>/.test(html),
   'help-page planned entry "internal_ancestry_composition panel" present');
ok(/L2\/L3 zoom-trigger/.test(html),
   'composition panel entry mentions L2/L3 zoom-trigger placement');

// =============================================================================
// TEST 75: Scale-lock rationale in page 12 empty-state (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 75: Scale-lock rationale in page 12 empty-state ---');

// "Scale" section heading present in empty-state
ok(/Scale — locked to <code>win50000\.step10000<\/code>/.test(html),
   'page-12 empty-state has "Scale — locked to win50000.step10000" heading');

// All four ANGSD scales documented in the comparison table
ok(/<code>win5000\.step1000<\/code>/.test(html),
   'scale comparison table mentions win5000.step1000');
ok(/<code>win10000\.step2000<\/code>/.test(html),
   'scale comparison table mentions win10000.step2000');
ok(/<code>win50000\.step10000<\/code>/.test(html),
   'scale comparison table mentions win50000.step10000 (the default)');
ok(/<code>win500000\.step500000<\/code>/.test(html),
   'scale comparison table mentions win500000.step500000');

// All three rationale points present (memory / noise floor / breakpoint resolution)
ok(/Browser memory/.test(html) && /sim_mat/.test(html),
   'rationale (1): browser memory + sim_mat size argument present');
ok(/Per-window θπ stability/.test(html) && /noise floor|noise|stable/.test(html),
   'rationale (2): per-window θπ stability / noise-floor argument present');
ok(/finer step doesn't buy you breakpoint resolution|gradient/i.test(html),
   'rationale (3): finer step ≠ breakpoint resolution / gradient argument present');

// Explicit "DEFAULT" tag on the chosen scale
ok(/win50000\.step10000[\s\S]{0,800}DEFAULT/.test(html),
   'win50000.step10000 row in comparison table is tagged DEFAULT');

// Layered design — finer scales reserved for per-candidate boundary view
ok(/per-candidate breakpoint inspection|per-candidate breakpoint detail/i.test(html),
   'finer scales reserved for per-candidate breakpoint inspection (planned, post-v4.0)');

// "Blocking" copy now correctly cites win50000 / 10 kb step (previous draft said 25 kb step)
ok(/STEP_Q05_aggregate_theta\.sh[\s\S]{0,400}win50000\.step10000/.test(html),
   'Blocking copy correctly cites STEP_Q05_aggregate_theta.sh + win50000.step10000');

// =============================================================================
// TEST 76: Boundaries page kb-tier scan-radius buttons (turn 14e+ continue)
// =============================================================================
console.log('\n--- TEST 76: Boundaries page kb-tier scan-radius buttons ---');

// All five new kb-tier buttons present with correct data-radius (in bp)
ok(/<button class="bnd-radius-btn" data-radius="1000"[\s\S]{0,400}>1 kb<\/button>/.test(html),
   'kb-tier 1 kb button present with data-radius="1000"');
ok(/<button class="bnd-radius-btn" data-radius="5000"[\s\S]{0,400}>5 kb<\/button>/.test(html),
   'kb-tier 5 kb button present with data-radius="5000"');
ok(/<button class="bnd-radius-btn" data-radius="10000"[\s\S]{0,400}>10 kb<\/button>/.test(html),
   'kb-tier 10 kb button present with data-radius="10000"');
ok(/<button class="bnd-radius-btn" data-radius="25000"[\s\S]{0,400}>25 kb<\/button>/.test(html),
   'kb-tier 25 kb button present with data-radius="25000"');
ok(/<button class="bnd-radius-btn" data-radius="100000"[\s\S]{0,400}>100 kb<\/button>/.test(html),
   'kb-tier 100 kb button present with data-radius="100000"');

// Visual separator between kb-tier and Mb-tier
ok(/class="bnd-radius-sep"/.test(html),
   '.bnd-radius-sep visual separator present between kb and Mb tiers');

// All four legacy Mb-tier buttons still present
ok(/data-radius="1000000"[\s\S]{0,400}>1 Mb</.test(html),
   'Mb-tier 1 Mb button still present with data-radius="1000000"');
ok(/data-radius="1500000"[\s\S]{0,400}>1\.5 Mb</.test(html),
   'Mb-tier 1.5 Mb button still present');
ok(/data-radius="2000000"[\s\S]{0,400}>2 Mb</.test(html),
   'Mb-tier 2 Mb button still present');
ok(/data-radius="5000000"[\s\S]{0,400}>5 Mb</.test(html),
   'Mb-tier 5 Mb button still present');

// Tooltip wording — "fundamentally kb-scale" rationale baked into one tooltip
ok(/SV-supported breakpoints with split-read evidence/.test(html),
   '1 kb tooltip explains the SV-only use case honestly');

// =============================================================================
// SUMMARY
// =============================================================================
console.log(`\n--- v3.99 tests: ${pass}/${pass + fail} ---`);
if (fail > 0) process.exit(1);
