#!/usr/bin/env node
// Runtime tests for v3.99 t14e+ continue block-presence chips + JSON
// inspector (TEST 73 runtime counterpart). Verifies
// candidateBlockChipsHtml() renders correctly for various block-presence
// patterns and that _toggleBlockInspector creates/removes inspector nodes.

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

// Lightweight DOM mock — captures innerHTML, supports the few DOM ops the
// chip code actually uses (querySelector, querySelectorAll, createElement,
// appendChild, removeChild on parent, getElementById, addEventListener).
function makeNode(opts) {
  opts = opts || {};
  const n = {
    id: opts.id || '',
    tagName: opts.tag || 'div',
    className: opts.className || '',
    children: [],
    listeners: {},
    dataset: {},
    style: { cssText: '' },
    attributes: {},
    classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    _innerHTML: '',
    get innerHTML() { return this._innerHTML; },
    set innerHTML(v) {
      this._innerHTML = v;
      // Auto-create child nodes for elements with id="..." attributes
      // referenced in the markup so getElementById can find them. This is
      // a lightweight parser — handles the patterns the chip code uses.
      this.children = [];
      const idMatches = String(v).matchAll(/id="([^"]+)"/g);
      for (const m of idMatches) {
        if (!sandboxDocument.elements[m[1]]) {
          sandboxDocument.elements[m[1]] = makeNode({ id: m[1] });
        }
      }
      // Track .cand-block-chip elements for querySelectorAll
      const chipMatches = String(v).matchAll(
        /<button[^>]+class="cand-block-chip"[^>]+data-block-type="([^"]+)"[^>]+data-cid="([^"]+)"[^>]+data-has="([^"]+)"[^>]*>([^<]*)<\/button>/g
      );
      const chips = [];
      for (const m of chipMatches) {
        const node = makeNode({ tag: 'button', className: 'cand-block-chip' });
        node.dataset.blockType = m[1];
        node.dataset.cid = m[2];
        node.dataset.has = m[3];
        node.textContent = m[4];
        chips.push(node);
      }
      this._chipChildren = chips;
    },
    appendChild(child) {
      this.children.push(child);
      // Auto-register ID'd children so getElementById finds them
      if (child && child.id) sandboxDocument.elements[child.id] = child;
      return child;
    },
    removeChild(child) {
      this.children = this.children.filter(c => c !== child);
      return child;
    },
    remove() {
      // Removed from parent — register globally so getElementById no longer finds
      if (this.id && sandboxDocument.elements[this.id] === this) {
        delete sandboxDocument.elements[this.id];
      }
    },
    addEventListener(ev, fn) {
      (this.listeners[ev] = this.listeners[ev] || []).push(fn);
    },
    removeEventListener() {},
    click() {
      (this.listeners.click || []).forEach(fn => fn({ target: this }));
    },
    querySelector(sel) {
      // Only used by inspector to find .block-inspector-close
      if (sel === '.block-inspector-close') {
        // Synthesize a close-button stub that has addEventListener
        return makeNode({ className: 'block-inspector-close' });
      }
      return null;
    },
    querySelectorAll(sel) {
      if (sel === '.cand-block-chip') return this._chipChildren || [];
      return [];
    },
    getBoundingClientRect() { return { top: 0, left: 0, right: 0, bottom: 0, width: 0, height: 0 }; },
    getContext() {
      return {
        clearRect() {}, fillRect() {}, strokeRect() {}, beginPath() {},
        moveTo() {}, lineTo() {}, closePath() {}, fill() {}, stroke() {},
        fillText() {}, strokeText() {}, measureText: () => ({ width: 0 }),
        arc() {}, ellipse() {}, save() {}, restore() {}, translate() {}, scale() {},
        rotate() {}, transform() {}, setTransform() {}, drawImage() {},
        getImageData: () => ({ data: new Uint8ClampedArray(4) }),
        putImageData() {}, createImageData() {}, setLineDash() {},
        createLinearGradient: () => ({ addColorStop() {} }),
        createRadialGradient: () => ({ addColorStop() {} }),
        createPattern: () => null,
        canvas: this,
        fillStyle: '', strokeStyle: '', lineWidth: 1, font: '',
        textAlign: '', textBaseline: '', globalAlpha: 1, globalCompositeOperation: '',
      };
    },
    setAttribute() {}, getAttribute: () => null, removeAttribute() {},
    hasAttribute: () => false, focus() {}, blur() {}, scrollIntoView() {},
    width: 0, height: 0, clientWidth: 0, clientHeight: 0,
    offsetWidth: 0, offsetHeight: 0,
  };
  return n;
}

const sandboxDocument = {
  elements: {},
  // Phase flag — auto-create nodes during top-level script init (when DOM
  // lookups reference fixed IDs the script will eventually populate). Once
  // the test phase begins, switch off so getElementById matches real
  // browser semantics (returns null for missing IDs).
  _autoCreate: true,
  getElementById(id) {
    if (this.elements[id]) return this.elements[id];
    if (this._autoCreate) {
      this.elements[id] = makeNode({ id });
      return this.elements[id];
    }
    return null;
  },
  // Test harness explicitly seeds nodes the script will look up.
  _ensure(id) {
    if (!this.elements[id]) this.elements[id] = makeNode({ id });
    return this.elements[id];
  },
  createElement(tag) { return makeNode({ tag }); },
  body: { appendChild() {}, removeChild() {} },
  documentElement: { dataset: {} },
  querySelectorAll(sel) {
    // For the wire function — find all .cand-block-chip across the document.
    // We use the chip children registered against the chip-row container.
    const out = [];
    for (const id of Object.keys(this.elements)) {
      const el = this.elements[id];
      if (el._chipChildren) out.push(...el._chipChildren);
    }
    return out;
  },
  querySelector: () => null,
  addEventListener() {},
};

const sandbox = {
  console,
  document: sandboxDocument,
  window: {
    addEventListener() {}, removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: () => 0, clearTimeout() {}, requestAnimationFrame: () => 0,
  localStorage: {
    _store: {}, getItem(k) { return this._store[k] || null; }, setItem(k, v) { this._store[k] = String(v); },
    removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: function () {},
  alert: () => {},
  FileReader: function () { this.readAsText = () => {}; },
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated */ }

  console.log('\n--- t14e+ continue: block chips + inspector runtime tests ---');

  if (typeof sandbox.candidateBlockChipsHtml !== 'function') {
    ok(false, 'candidateBlockChipsHtml in sandbox global');
    process.exit(1);
  }
  ok(true, 'candidateBlockChipsHtml in sandbox global');
  ok(typeof sandbox._toggleBlockInspector === 'function',
     '_toggleBlockInspector in sandbox global');
  ok(typeof sandbox._wireCandidateBlockChips === 'function',
     '_wireCandidateBlockChips in sandbox global');

  // ============================================================================
  // Empty state — no candidate, no blocks loaded
  // ============================================================================
  ok(sandbox.candidateBlockChipsHtml(null) === '',
     'returns empty string for null candidate');
  ok(sandbox.candidateBlockChipsHtml({}) === '',
     'returns empty string for candidate without id or ref_l2');

  // ============================================================================
  // Render with no blocks loaded for active candidate
  // ============================================================================
  vm.runInContext(`
    if (!state.data) state.data = {};
    state.data.evidence_blocks = {};
  `, sandbox);
  const c1 = { id: 'cand_LG12_17', chrom: 'C_gar_LG12', start_bp: 12500000, end_bp: 20030000 };
  const html1 = sandbox.candidateBlockChipsHtml(c1);
  ok(typeof html1 === 'string' && html1.length > 0,
     'returns non-empty string for valid candidate even with no blocks');
  ok(/>0<\/b>\/20 loaded/.test(html1),
     'header shows "0/20 loaded" when no blocks present');
  // Check all 20 chips rendered (18 numbered blocks + boundary_right + synthesis)
  const chipCount1 = (html1.match(/class="cand-block-chip"/g) || []).length;
  ok(chipCount1 === 20, `20 chip buttons rendered (got ${chipCount1})`);
  // All have data-has="0"
  const has0Count = (html1.match(/data-has="0"/g) || []).length;
  ok(has0Count === 20, `all 20 chips data-has="0" when no blocks loaded (got ${has0Count})`);
  // None should have data-has="1"
  const has1Count = (html1.match(/data-has="1"/g) || []).length;
  ok(has1Count === 0, 'no chips data-has="1" when no blocks loaded');
  // Hint message present
  ok(/load via 📦 on page 4/.test(html1),
     'hint message about loading present when no blocks loaded');

  // ============================================================================
  // Render with some blocks loaded — mix of axis-contributing + supportive + synthesis
  // ============================================================================
  vm.runInContext(`
    state.data.evidence_blocks['cand_LG12_17'] = {
      existence_layer_a: { detected: true, source_script: 'C01a.R' },
      mechanism: { classification: { mechanism: 'NAHR' } },
      morphology: { flat_inv_score: 0.82 },              // supportive only
      final_classification: { confidence_tier: 'T1' },    // synthesis
    };
  `, sandbox);
  const html2 = sandbox.candidateBlockChipsHtml(c1);
  ok(/>4<\/b>\/20 loaded/.test(html2),
     'header shows "4/20 loaded" with 4 blocks');
  // Specific chips lit
  const ela_lit = /data-block-type="existence_layer_a"[^>]*data-has="1"/.test(html2);
  ok(ela_lit, 'existence_layer_a chip data-has="1"');
  const mech_lit = /data-block-type="mechanism"[^>]*data-has="1"/.test(html2);
  ok(mech_lit, 'mechanism chip data-has="1"');
  const morph_lit = /data-block-type="morphology"[^>]*data-has="1"/.test(html2);
  ok(morph_lit, 'morphology chip data-has="1"');
  const synth_lit = /data-block-type="final_classification"[^>]*data-has="1"/.test(html2);
  ok(synth_lit, 'final_classification chip data-has="1"');
  // Other chips dim
  const elb_dim = /data-block-type="existence_layer_b"[^>]*data-has="0"/.test(html2);
  ok(elb_dim, 'existence_layer_b chip data-has="0" (not loaded)');
  // Hint message changes when blocks loaded
  ok(/click a chip to inspect raw JSON/.test(html2),
     'hint changes to "click to inspect" when blocks loaded');

  // ============================================================================
  // Color encoding — green for axis-contributing, blue for supportive, gold for synthesis
  // ============================================================================
  // Re-render to test colors. Look at chip backgrounds.
  // Find existence_layer_a chip (axis-contributing → green rgba(34,160,80,...))
  const elaChipMatch = html2.match(
    /data-block-type="existence_layer_a"[^>]*style="([^"]+)"/
  );
  ok(elaChipMatch && /rgba\(34,160,80/.test(elaChipMatch[1]),
     'existence_layer_a chip uses green background (axis-contributing)');
  // morphology chip (supportive → blue)
  const morphChipMatch = html2.match(
    /data-block-type="morphology"[^>]*style="([^"]+)"/
  );
  ok(morphChipMatch && /rgba\(48,116,200/.test(morphChipMatch[1]),
     'morphology chip uses blue background (supportive only)');
  // final_classification chip (synthesis → gold)
  const synthChipMatch = html2.match(
    /data-block-type="final_classification"[^>]*style="([^"]+)"/
  );
  ok(synthChipMatch && /rgba\(245,165,36/.test(synthChipMatch[1]),
     'final_classification chip uses gold background (synthesis)');

  // ============================================================================
  // Group spacers — verify larger margin between groups
  // ============================================================================
  // existence_layer_a is first in its group → margin-left: 2px (no group change before it,
  // since it's the very first chip overall)
  // boundary_left is first in 'bound' group, after existence_layer_d → margin-left: 8px
  const boundLChipMatch = html2.match(
    /data-block-type="boundary_left"[^>]*style="([^"]+)"/
  );
  ok(boundLChipMatch && /margin-left: 8px/.test(boundLChipMatch[1]),
     'boundary_left chip has 8px margin-left (group transition from "exist")');
  const boundRChipMatch = html2.match(
    /data-block-type="boundary_right"[^>]*style="([^"]+)"/
  );
  ok(boundRChipMatch && /margin-left: 2px/.test(boundRChipMatch[1]),
     'boundary_right chip has 2px margin-left (same group as boundary_left)');

  // ============================================================================
  // ref_l2-only candidate (no id) falls back to ref_l2_<n>
  // ============================================================================
  vm.runInContext(`
    state.data.evidence_blocks['ref_l2_42'] = {
      existence_layer_a: { detected: true },
    };
  `, sandbox);
  const c2 = { ref_l2: 42, chrom: 'C_gar_LG28' };
  const html3 = sandbox.candidateBlockChipsHtml(c2);
  ok(/>1<\/b>\/20 loaded/.test(html3),
     'ref_l2 fallback works as cid: 1/20 loaded');

  // ============================================================================
  // _toggleBlockInspector — open then close
  // ============================================================================
  // Switch DOM mock to strict mode (no auto-create on getElementById) so the
  // inspector's existence-check works correctly. Clear any auto-created
  // phantoms that the script's init might have left behind.
  sandboxDocument._autoCreate = false;
  delete sandboxDocument.elements['block-inspector-mechanism'];
  delete sandboxDocument.elements['block-inspector-existence_layer_b'];
  // Render the chip row first so #candBlockInspectors mount node exists
  sandboxDocument.elements['candBlockInspectors'] = makeNode({ id: 'candBlockInspectors' });
  const fakeChip = { dataset: { cid: 'cand_LG12_17', blockType: 'mechanism' }, style: {} };
  const inspector = sandbox._toggleBlockInspector('cand_LG12_17', 'mechanism', fakeChip);
  // Opening: should append a node with id "block-inspector-mechanism"
  const inspectorNode = sandboxDocument.elements['block-inspector-mechanism'];
  ok(inspectorNode != null, 'inspector node created with correct id on first click');
  // Chip gets visual cue
  ok(/rgba\(245,165,36,0\.35\)/.test(fakeChip.style.boxShadow || ''),
     'chip box-shadow set as visual cue when inspector open');

  // Toggle again → should close (remove)
  sandbox._toggleBlockInspector('cand_LG12_17', 'mechanism', fakeChip);
  ok(sandboxDocument.elements['block-inspector-mechanism'] == null,
     'inspector node removed on second click');
  ok(fakeChip.style.boxShadow === '',
     'chip box-shadow cleared when inspector closes');

  // ============================================================================
  // _toggleBlockInspector — block not loaded for cid → no-op
  // ============================================================================
  // existence_layer_b is not loaded for cand_LG12_17
  sandbox._toggleBlockInspector('cand_LG12_17', 'existence_layer_b', null);
  ok(sandboxDocument.elements['block-inspector-existence_layer_b'] == null,
     'no inspector created when block not loaded');

  // ============================================================================
  // _toggleBlockInspector — handles unknown candidate gracefully
  // ============================================================================
  sandbox._toggleBlockInspector('NONEXISTENT_CID', 'mechanism', null);
  ok(sandboxDocument.elements['block-inspector-mechanism'] == null,
     'no inspector for nonexistent candidate');

  // ============================================================================
  // _BLOCK_DISPLAY_ORDER ordering — verify synthesis is last
  // ============================================================================
  // Read order from rendered HTML — synthesis chip should be after all 18 others
  const allChipIdx = [];
  const re = /data-block-type="([^"]+)"/g;
  let m;
  while ((m = re.exec(html2)) !== null) allChipIdx.push(m[1]);
  ok(allChipIdx.length === 20, `20 chips found in render order (got ${allChipIdx.length})`);
  ok(allChipIdx[allChipIdx.length - 1] === 'final_classification',
     'final_classification chip rendered LAST');
  ok(allChipIdx[0] === 'existence_layer_a',
     'existence_layer_a chip rendered FIRST');
  // The 4 existence layers should be the first 4
  ok(allChipIdx[0] === 'existence_layer_a' &&
     allChipIdx[1] === 'existence_layer_b' &&
     allChipIdx[2] === 'existence_layer_c' &&
     allChipIdx[3] === 'existence_layer_d',
     'existence layers A-D are first four chips in order');

  console.log(`\n--- v3.99 t14e+ continue chips+inspector runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
