#!/usr/bin/env Rscript
# =============================================================================
# STEP_R45a_broodline_check.R
# =============================================================================
# Purpose: For ONE candidate region with K>=4 PCA structure (Hom1, Het_upper,
# Het_lower, Hom2), test whether the Het_upper vs Het_lower split is
# explained by broodline / family structure, or whether it is independent of
# kinship and therefore plausibly biological inversion-internal substructure.
#
# This is the cheapest test that decides whether axis decomposition (one
# inversion vs two overlapping) is even worth pursuing. If broodlines and
# the Het split are highly associated, the "two inversions" hypothesis loses
# evidentiary support and the simpler "one inversion + family LD" model
# wins by Occam's razor. If they are independent, you have a defensible
# basis for treating the Het subgroups as biology.
#
# Inputs (project root: /scratch/lt200308-agbsci/Quentin_project_KEEP_2026-02-04)
# ----------------------------------------------------------------------------
#   --kinship     path to NgsRelate or NAToRA broodline assignment TSV.
#                 Expected columns: sample_id, broodline (or family / cluster).
#                 Use whichever broodline labelling you trust most — the test
#                 just needs categorical labels per sample.
#   --labels      path to L2 cluster label TSV for the candidate window or
#                 region. Expected columns: sample_id, k4_label where k4_label
#                 is one of {Hom1, Het_upper, Het_lower, Hom2} OR an integer
#                 0..3 that maps in that order. The script accepts either.
#   --candidate   short candidate ID (used only in output filenames + plot title)
#   --outdir      output directory (defaults to working dir)
#
# Outputs
# ----------------------------------------------------------------------------
#   <outdir>/<candidate>_broodline_x_het.tsv   — full contingency table + stats
#   <outdir>/<candidate>_broodline_x_het.png   — heatmap + per-broodline ratio bar
#   stdout                                      — one-line verdict + key numbers
#
# Verdict thresholds (Cramer's V on the Het-only subset)
# ----------------------------------------------------------------------------
#   V < 0.10  : INDEPENDENT — Het split is not driven by broodline.
#               Two-inversion hypothesis remains viable.
#   V 0.10-0.30 : WEAK ASSOCIATION — broodline explains some but not most of
#               the Het split. Mixed signal; report both.
#   V 0.30-0.50 : MODERATE ASSOCIATION — broodline is a real contributor.
#               Two-inversion hypothesis weakens. Consider stratifying by
#               broodline and re-running PCA within each broodline.
#   V >= 0.50 : STRONG ASSOCIATION — Het split is largely a broodline artifact.
#               Drop the two-inversion hypothesis for this candidate.
#
# These thresholds are the standard Cohen-style Cramer's V cutoffs as used
# elsewhere in the scrubber (small / medium / large). They are conventional
# rather than empirical for this cohort — adjust if you have a permutation
# null specific to LG28.
#
# Scope notes
# ----------------------------------------------------------------------------
# This test ONLY answers "is the Het split a broodline artifact?" It does not
# answer "is this candidate one inversion or two." For the latter you need
# axis decomposition (STEP_R45b — separate script). But you should not run
# axis decomposition until this script returns INDEPENDENT or WEAK.
#
# Run from LANTA (account lt200308) with the assembly env Rscript:
#   /lustrefs/disk/project/lt200308-agbsci/13-programs/mambaforge/envs/assembly/bin/Rscript \
#     STEP_R45a_broodline_check.R \
#     --kinship  /path/to/MODULE_2B/structure_pruned/broodline_labels.tsv \
#     --labels   /path/to/MODULE_5A2/cand63_k4_labels.tsv \
#     --candidate cand63 \
#     --outdir   /path/to/MODULE_5C_broodline_check/
# =============================================================================

suppressPackageStartupMessages({
  # No external packages needed — base R only. Keeps the script portable on
  # any LANTA Rscript without conda/mamba env juggling.
})

# ---- CLI -------------------------------------------------------------------
# Hand-rolled --flag value parser (replaces optparse to drop the dependency).

.parse_args <- function(args, defaults = list()) {
  out <- defaults
  i <- 1
  while (i <= length(args)) {
    a <- args[i]
    if (startsWith(a, "--")) {
      key <- sub("^--", "", a)
      if (key == "help") { out$help <- TRUE; i <- i + 1; next }
      if (i + 1 > length(args)) stop(sprintf("Flag --%s expects a value", key))
      out[[key]] <- args[i + 1]
      i <- i + 2
    } else {
      i <- i + 1
    }
  }
  out
}

opt <- .parse_args(commandArgs(trailingOnly = TRUE),
                   defaults = list(candidate = "cand", outdir = "."))

if (isTRUE(opt$help) || is.null(opt$kinship) || is.null(opt$labels)) {
  cat("Usage: STEP_R45a_broodline_check.R --kinship FILE --labels FILE",
      "[--candidate ID] [--outdir DIR]\n", sep = " ")
  cat("\n  --kinship    TSV with sample_id + broodline columns\n")
  cat("  --labels     TSV with sample_id + k4_label columns\n")
  cat("  --candidate  short ID for output filenames (default: 'cand')\n")
  cat("  --outdir     output directory (default: current)\n")
  if (!isTRUE(opt$help)) quit(status = 1)
  quit(status = 0)
}
if (!file.exists(opt$kinship)) stop(sprintf("Kinship file not found: %s", opt$kinship))
if (!file.exists(opt$labels))  stop(sprintf("Labels  file not found: %s", opt$labels))
if (!dir.exists(opt$outdir))   dir.create(opt$outdir, recursive = TRUE)

# ---- Load + harmonise ------------------------------------------------------

kin <- read.table(opt$kinship, header = TRUE, sep = "\t", stringsAsFactors = FALSE,
                  check.names = FALSE)
lab <- read.table(opt$labels, header = TRUE, sep = "\t", stringsAsFactors = FALSE,
                  check.names = FALSE)

# Resolve column names defensively — accept common variants.
.find_col <- function(df, candidates) {
  hit <- intersect(tolower(candidates), tolower(colnames(df)))
  if (length(hit) == 0) {
    stop(sprintf("None of these columns found: %s. Available: %s",
                 paste(candidates, collapse = " / "),
                 paste(colnames(df), collapse = " / ")))
  }
  colnames(df)[match(hit[1], tolower(colnames(df)))]
}

kin_id_col   <- .find_col(kin, c("sample_id", "sample", "ind", "indiv", "id"))
kin_brood_col <- .find_col(kin, c("broodline", "family", "cluster", "group", "k_label"))

lab_id_col   <- .find_col(lab, c("sample_id", "sample", "ind", "indiv", "id"))
lab_k4_col   <- .find_col(lab, c("k4_label", "label", "k4", "subgroup"))

# Normalise k4 labels: accept integers 0..3 OR strings.
.normalise_k4 <- function(x) {
  if (is.numeric(x) || all(grepl("^[0-9]+$", as.character(x[!is.na(x)])))) {
    map <- c("Hom1", "Het_upper", "Het_lower", "Hom2")
    return(map[as.integer(x) + 1])
  }
  x <- as.character(x)
  x[x %in% c("hom1", "Hom_1", "HOM1", "0")] <- "Hom1"
  x[x %in% c("het_upper", "Het Upper", "het_up", "1")] <- "Het_upper"
  x[x %in% c("het_lower", "Het Lower", "het_lo", "2")] <- "Het_lower"
  x[x %in% c("hom2", "Hom_2", "HOM2", "3")] <- "Hom2"
  x
}

lab[[lab_k4_col]] <- .normalise_k4(lab[[lab_k4_col]])

# Inner join on sample_id
df <- merge(kin[, c(kin_id_col, kin_brood_col)],
            lab[, c(lab_id_col, lab_k4_col)],
            by.x = kin_id_col, by.y = lab_id_col,
            all = FALSE)
colnames(df) <- c("sample_id", "broodline", "k4_label")

if (nrow(df) == 0) stop("Sample IDs in kinship and labels files don't intersect. Check sample-id formatting.")

cat(sprintf("Joined samples: %d\n", nrow(df)))
cat(sprintf("Broodlines:     %d\n", length(unique(df$broodline))))
cat(sprintf("K4 labels seen: %s\n",
            paste(sort(unique(df$k4_label)), collapse = ", ")))

# ---- Het-only subset (the actual test) -------------------------------------
# The biology question is specifically: within the heterozygote class, does
# the upper/lower split track broodline? We restrict to Het samples for the
# primary test. The Hom1/Hom2 contingency is reported as context but not
# what the verdict is based on.

het_df <- df[df$k4_label %in% c("Het_upper", "Het_lower"), ]
if (nrow(het_df) < 10) {
  warning(sprintf("Only %d Het samples — test underpowered.", nrow(het_df)))
}

# Cramer's V helper
.cramer_v <- function(tab) {
  if (any(dim(tab) < 2)) return(0)
  cs <- suppressWarnings(chisq.test(tab))
  n <- sum(tab)
  k_min <- min(dim(tab)) - 1
  if (n == 0 || k_min == 0) return(0)
  sqrt(unname(cs$statistic) / (n * k_min))
}

het_tab <- table(het_df$broodline, het_df$k4_label)
het_V   <- .cramer_v(het_tab)
het_chi <- suppressWarnings(chisq.test(het_tab))
het_n   <- sum(het_tab)

# Verdict — empirical permutation null instead of fixed Cohen thresholds.
# Cohen-style V cutoffs (0.10 / 0.30 / 0.50) are calibrated for large samples
# and over-call association at n~100. Reviewers will rightly catch this.
# The honest test: shuffle k4_label within the Het subset, recompute V each
# time, and compare observed V to the null distribution.
N_PERM <- 2000
het_only_labels <- het_df$k4_label
het_only_brood  <- het_df$broodline
perm_V <- numeric(N_PERM)
for (i in seq_len(N_PERM)) {
  shuffled <- sample(het_only_labels)
  perm_tab <- table(het_only_brood, shuffled)
  perm_V[i] <- .cramer_v(perm_tab)
}
null_mean   <- mean(perm_V)
null_sd     <- sd(perm_V)
null_q95    <- quantile(perm_V, 0.95)
null_q99    <- quantile(perm_V, 0.99)
null_q999   <- quantile(perm_V, 0.999)
emp_p       <- mean(perm_V >= het_V)  # one-sided

# Tier the verdict by where observed V sits relative to the null. This is
# defensible because the comparison is to the actual table dimensions and
# sample size of THIS test, not to a textbook threshold.
verdict <- {
  if      (het_V <= null_q95)   "INDEPENDENT"
  else if (het_V <= null_q99)   "WEAK ASSOCIATION"
  else if (het_V <= null_q999)  "MODERATE ASSOCIATION"
  else                          "STRONG ASSOCIATION"
}

# Per-broodline ratio: how skewed is each broodline towards Het_upper or Het_lower?
brood_ratio <- as.data.frame.matrix(het_tab)
brood_ratio$total <- rowSums(brood_ratio)
brood_ratio$het_upper_frac <- ifelse(brood_ratio$total > 0,
                                     brood_ratio$Het_upper / brood_ratio$total, NA)

# Full 4-class table for context (not used for verdict)
full_tab <- table(df$broodline, df$k4_label)
full_V   <- .cramer_v(full_tab)

# ---- Print verdict to stdout -----------------------------------------------

cat("\n================ VERDICT ================\n")
cat(sprintf("Candidate:           %s\n", opt$candidate))
cat(sprintf("Het samples used:    %d\n", het_n))
cat(sprintf("Observed V:          %.3f\n", het_V))
cat(sprintf("Null V (n=%d perms): mean %.3f +/- %.3f\n",
            N_PERM, null_mean, null_sd))
cat(sprintf("Null V quantiles:    q95 = %.3f, q99 = %.3f, q99.9 = %.3f\n",
            unname(null_q95), unname(null_q99), unname(null_q999)))
cat(sprintf("Empirical p:         %.4g\n", emp_p))
cat(sprintf("Het chi-square:      chi2 = %.2f, df = %d, p = %.3g\n",
            unname(het_chi$statistic), unname(het_chi$parameter), het_chi$p.value))
cat(sprintf("Verdict:             %s\n", verdict))
cat(sprintf("Full 4-class V:      %.3f  (context, not the test)\n", full_V))
cat("=========================================\n")

if (verdict == "INDEPENDENT") {
  cat("\nInterpretation: the Het_upper / Het_lower split is NOT driven by\n")
  cat("broodline structure. The Het subgroups represent within-arrangement\n")
  cat("substructure that is independent of family / kinship.\n")
  cat("==> Axis decomposition (one inversion vs two) is worth pursuing.\n")
} else if (verdict == "WEAK ASSOCIATION") {
  cat("\nInterpretation: broodline explains some but not most of the Het split.\n")
  cat("==> Axis decomposition can proceed but report both broodline-stratified\n")
  cat("    and pooled results. Reviewers will ask.\n")
} else if (verdict == "MODERATE ASSOCIATION") {
  cat("\nInterpretation: broodline is a real contributor to the Het split.\n")
  cat("==> Stratify by broodline and re-run local PCA within the largest\n")
  cat("    broodline before claiming biological substructure.\n")
} else {
  cat("\nInterpretation: the Het split is largely a broodline artifact.\n")
  cat("==> The two-inversion hypothesis is not supported for this candidate.\n")
  cat("    Treat as one inversion + family LD.\n")
}
cat("\n")

# ---- Write TSV -------------------------------------------------------------

tsv_path <- file.path(opt$outdir, sprintf("%s_broodline_x_het.tsv", opt$candidate))
sink(tsv_path)
cat(sprintf("# STEP_R45a broodline x Het-subgroup independence test\n"))
cat(sprintf("# Candidate: %s\n", opt$candidate))
cat(sprintf("# Generated: %s\n", format(Sys.time(), "%Y-%m-%d %H:%M:%S")))
cat(sprintf("# Het samples: %d\n", het_n))
cat(sprintf("# Observed V: %.4f\n", het_V))
cat(sprintf("# Null V (n=%d permutations): mean %.4f, sd %.4f\n",
            N_PERM, null_mean, null_sd))
cat(sprintf("# Null V q95: %.4f\n", unname(null_q95)))
cat(sprintf("# Null V q99: %.4f\n", unname(null_q99)))
cat(sprintf("# Null V q99.9: %.4f\n", unname(null_q999)))
cat(sprintf("# Empirical p: %.4g\n", emp_p))
cat(sprintf("# Het chi2 stat: %.4f\n", unname(het_chi$statistic)))
cat(sprintf("# Het chi2 df:   %d\n", unname(het_chi$parameter)))
cat(sprintf("# Het chi2 p:    %.4g\n", het_chi$p.value))
cat(sprintf("# Verdict:       %s\n", verdict))
cat(sprintf("# Full 4-class V: %.4f\n", full_V))
cat("#\n# Het-only contingency (broodline x Het_upper/Het_lower):\n")
write.table(as.data.frame.matrix(het_tab), sep = "\t", quote = FALSE,
            col.names = NA, row.names = TRUE)
cat("\n# Per-broodline Het_upper fraction:\n")
write.table(brood_ratio, sep = "\t", quote = FALSE, col.names = NA, row.names = TRUE)
cat("\n# Full 4-class contingency (context):\n")
write.table(as.data.frame.matrix(full_tab), sep = "\t", quote = FALSE,
            col.names = NA, row.names = TRUE)
sink()
cat(sprintf("Wrote: %s\n", tsv_path))

# ---- Plot -------------------------------------------------------------------
# One PNG, two panels: heatmap of het_tab counts + bar of het_upper_frac per
# broodline. No ggplot dependency — base R does fine and avoids version drift
# on LANTA.

png_path <- file.path(opt$outdir, sprintf("%s_broodline_x_het.png", opt$candidate))
png(png_path, width = 1600, height = 800, res = 150)
on.exit(dev.off(), add = TRUE)

par(mfrow = c(1, 2), mar = c(8, 6, 4, 2))

# Panel 1: heatmap
hcols <- colorRampPalette(c("white", "#4fa3ff", "#2563eb"))(64)
het_mat <- as.matrix(het_tab)
image(t(het_mat[nrow(het_mat):1, ]), col = hcols, axes = FALSE,
      main = sprintf("Broodline x Het class (V = %.2f, perm-p = %.3g, %s)",
                     het_V, emp_p, verdict))
axis(1, at = seq(0, 1, length.out = ncol(het_mat)), labels = colnames(het_mat),
     cex.axis = 0.9, las = 1)
axis(2, at = seq(0, 1, length.out = nrow(het_mat)), labels = rev(rownames(het_mat)),
     cex.axis = 0.7, las = 1)
# Cell count annotations
for (i in seq_len(nrow(het_mat))) for (j in seq_len(ncol(het_mat))) {
  text((j - 1) / max(1, ncol(het_mat) - 1),
       (nrow(het_mat) - i) / max(1, nrow(het_mat) - 1),
       het_mat[i, j], cex = 0.85,
       col = ifelse(het_mat[i, j] > median(het_mat) * 1.5, "white", "black"))
}
mtext("Het subgroup", side = 1, line = 3, cex = 0.95)
mtext("Broodline",    side = 2, line = 4, cex = 0.95)

# Panel 2: per-broodline Het_upper fraction
brood_ratio2 <- brood_ratio[order(brood_ratio$het_upper_frac), ]
b <- barplot(brood_ratio2$het_upper_frac, names.arg = rownames(brood_ratio2),
             las = 2, ylim = c(0, 1), col = "#4fa3ff",
             border = NA, main = "Het_upper fraction per broodline",
             ylab = "Het_upper / (Het_upper + Het_lower)", cex.names = 0.7)
abline(h = 0.5, lty = 2, col = "grey50")
text(b, brood_ratio2$het_upper_frac + 0.04,
     labels = sprintf("n=%d", brood_ratio2$total), cex = 0.7, col = "grey30")
# Reference: a fully INDEPENDENT result has every broodline near 0.5; a fully
# CONFOUNDED result has every broodline near 0 or 1.

cat(sprintf("Wrote: %s\n", png_path))
