#!/usr/bin/env node
// Runtime tests for v3.99 t14e+ continue 18-structured-blocks scaffold (TEST 72
// runtime counterpart). Verifies _deriveAxesFromBlock produces correct
// 14-axis values for synthetic blocks of each type — including the boundary
// reconciliation logic (which runs at end-of-load via _reconcileBoundaryQuality).

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

const sandbox = {
  console,
  document: {
    elements: {},
    getElementById(id) {
      if (!this.elements[id]) {
        this.elements[id] = {
          id, listeners: {}, dataset: {}, style: {},
          addEventListener: function (ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); },
          appendChild() {}, removeChild() {}, click() {},
          options: [], textContent: '', innerHTML: '', value: '',
        };
      }
      return this.elements[id];
    },
    createElement: () => ({ dataset: {}, style: {}, addEventListener() {}, appendChild() {} }),
    body: { appendChild() {}, removeChild() {} },
    documentElement: { dataset: {} },
    querySelectorAll: () => [], querySelector: () => null,
    addEventListener() {},
  },
  window: {
    addEventListener() {}, removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: () => 0, clearTimeout() {}, requestAnimationFrame: () => 0,
  localStorage: {
    _store: {}, getItem(k) { return this._store[k] || null; }, setItem(k, v) { this._store[k] = String(v); },
    removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: function () {},
  alert: () => {},
  FileReader: function () { this.readAsText = () => {}; },
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated */ }

  console.log('\n--- t14e+ continue: 18 structured block types runtime tests ---');

  if (typeof sandbox._deriveAxesFromBlock !== 'function') {
    ok(false, '_deriveAxesFromBlock in sandbox global');
    process.exit(1);
  }
  ok(true, '_deriveAxesFromBlock in sandbox global');
  ok(typeof sandbox._reconcileBoundaryQuality === 'function',
     '_reconcileBoundaryQuality in sandbox global');

  const derive = sandbox._deriveAxesFromBlock;

  // ============================================================================
  // existence_layer_a/b/c — same shape (detected: bool)
  // ============================================================================
  const ela = derive('existence_layer_a', { detected: true });
  ok(ela.existence_layer_a === 'pass', 'existence_layer_a detected=true → pass');

  const elaFail = derive('existence_layer_a', { detected: false });
  ok(elaFail.existence_layer_a === 'fail', 'existence_layer_a detected=false → fail');

  const elaUnknown = derive('existence_layer_a', { /* no detected field */ });
  ok(!('existence_layer_a' in elaUnknown), 'existence_layer_a missing detected → no axis (left unknown)');

  ok(derive('existence_layer_b', { detected: true }).existence_layer_b === 'pass',
     'existence_layer_b detected=true → pass');
  ok(derive('existence_layer_c', { detected: true }).existence_layer_c === 'pass',
     'existence_layer_c detected=true → pass');

  // ============================================================================
  // existence_layer_d — fisher_p threshold
  // ============================================================================
  const eld1 = derive('existence_layer_d', { tested: true, fisher_p: 4.98e-06 });
  ok(eld1.existence_layer_d === 'pass', 'layer_d fisher_p=4.98e-06 → pass');

  const eld2 = derive('existence_layer_d', { tested: true, fisher_p: 0.10 });
  ok(eld2.existence_layer_d === 'fail', 'layer_d fisher_p=0.10 → fail');

  const eld3 = derive('existence_layer_d', { tested: false });
  ok(!('existence_layer_d' in eld3), 'layer_d tested=false → no axis (left unknown)');

  // ============================================================================
  // carrier_reconciliation — group_validation
  // ============================================================================
  const cr1 = derive('carrier_reconciliation', {
    group_validation: { level: 'VALIDATED', reason: 'OR_p<0.05' },
  });
  ok(cr1.group_validation === 'VALIDATED', 'carrier_reconciliation level=VALIDATED → axis VALIDATED');

  const cr2 = derive('carrier_reconciliation', {
    group_validation: { level: 'supported' },  // lowercase input
  });
  ok(cr2.group_validation === 'SUPPORTED', 'carrier_reconciliation lowercase "supported" → SUPPORTED');

  const cr3 = derive('carrier_reconciliation', {
    group_validation: { level: 'GARBAGE' },
  });
  ok(!('group_validation' in cr3), 'carrier_reconciliation invalid level → no axis');

  // ============================================================================
  // internal_dynamics — internal_structure + recombinant_class
  // ============================================================================
  const id1 = derive('internal_dynamics', {
    n_recombinant: 0,
    n_gene_conversion: 0,
    n_double_crossover: 0,
    diversity_gradient: { r2: 0.10 },
  });
  ok(id1.internal_structure === 'clean', 'no recombinants + low r2 → clean');
  ok(id1.recombinant_class === 'none', 'no gc + no dco → recombinant_class none');

  const id2 = derive('internal_dynamics', {
    n_recombinant: 5, n_gene_conversion: 5, n_double_crossover: 0,
    diversity_gradient: { r2: 0.5 },
  });
  ok(id2.internal_structure === 'gradient', '1-9 recombinants → gradient');
  ok(id2.recombinant_class === 'gene_conversion', 'gc>0 dco=0 → gene_conversion');

  const id3 = derive('internal_dynamics', {
    n_recombinant: 12, n_gene_conversion: 8, n_double_crossover: 4,
  });
  ok(id3.internal_structure === 'composite_undecomposed', '≥10 recombinants → composite_undecomposed');
  ok(id3.recombinant_class === 'mixed', 'gc>0 dco>0 → mixed');

  const id4 = derive('internal_dynamics', {
    n_recombinant: 2, n_gene_conversion: 0, n_double_crossover: 2,
  });
  ok(id4.recombinant_class === 'double_crossover', 'gc=0 dco>0 → double_crossover');

  // ============================================================================
  // mechanism — classification.mechanism
  // ============================================================================
  ok(derive('mechanism', { classification: { mechanism: 'NAHR' } }).mechanism_class === 'NAHR',
     'mechanism NAHR → axis NAHR');
  ok(derive('mechanism', { classification: { mechanism: 'nhej' } }).mechanism_class === 'NHEJ',
     'mechanism lowercase "nhej" → NHEJ (uppercase)');
  ok(derive('mechanism', { classification: { mechanism: 'MMBIR' } }).mechanism_class === 'MMBIR',
     'mechanism MMBIR → axis MMBIR');
  ok(!('mechanism_class' in derive('mechanism', { classification: { mechanism: 'unknown' } })),
     'mechanism unknown → no axis');

  // ============================================================================
  // age_evidence — conclusion.age_class with 'old' → 'ancient' normalization
  // ============================================================================
  ok(derive('age_evidence', { conclusion: { age_class: 'young' } }).age_class === 'young',
     'age_evidence young → young');
  ok(derive('age_evidence', { conclusion: { age_class: 'intermediate' } }).age_class === 'intermediate',
     'age_evidence intermediate → intermediate');
  ok(derive('age_evidence', { conclusion: { age_class: 'old' } }).age_class === 'ancient',
     "age_evidence 'old' normalized to 'ancient'");
  ok(derive('age_evidence', { conclusion: { age_class: 'ancient' } }).age_class === 'ancient',
     'age_evidence ancient → ancient');

  // ============================================================================
  // frequency — family_linkage + polymorphism_class
  // ============================================================================
  const fr1 = derive('frequency', {
    family_linkage: 'multi_family',
    per_qgroup_freq: { Q1:0.42, Q2:0.35, Q3:0.51, Q4:0.38 },
    freq_cv_across_qgroups: 0.15,   // low CV
  });
  ok(fr1.family_linkage === 'multi_family', 'frequency family_linkage=multi_family');
  ok(fr1.polymorphism_class === 'cohort_wide', 'low CV (0.15) + mean>5% → cohort_wide');

  const fr2 = derive('frequency', {
    family_linkage: 'single_family',
    per_qgroup_freq: { Q1:0.50, Q2:0.05, Q3:0.50 },
    freq_cv_across_qgroups: 0.55,   // high CV
  });
  ok(fr2.family_linkage === 'single_family', 'frequency family_linkage=single_family');
  ok(fr2.polymorphism_class === 'family_restricted', 'CV>=0.40 → family_restricted');

  const fr3 = derive('frequency', {
    family_linkage: 'few_family',
    per_qgroup_freq: { Q1:0.35, Q2:0.20, Q3:0.40 },
    freq_cv_across_qgroups: 0.30,   // intermediate CV
  });
  ok(fr3.polymorphism_class === 'lineage_restricted', 'CV in [0.20, 0.40) → lineage_restricted');

  // ============================================================================
  // hypothesis_verdict — confidence_tier
  // ============================================================================
  const hv1 = derive('hypothesis_verdict', {
    layers_tested: 4, layers_passed: 4, verdict: 'confirmed_real_inversion',
  });
  ok(hv1.confidence_tier === 'T1', '4/4 layers + confirmed → T1');

  const hv2 = derive('hypothesis_verdict', {
    layers_tested: 4, layers_passed: 3, verdict: 'likely_real_inversion',
  });
  ok(hv2.confidence_tier === 'T2', '3 layers passed → T2');

  const hv3 = derive('hypothesis_verdict', {
    layers_tested: 4, layers_passed: 2, verdict: 'partial',
  });
  ok(hv3.confidence_tier === 'T3', '2 layers passed → T3');

  const hv4 = derive('hypothesis_verdict', {
    layers_tested: 4, layers_passed: 1, verdict: 'weak',
  });
  ok(hv4.confidence_tier === 'T4', '1 layer passed → T4');

  const hv5 = derive('hypothesis_verdict', {
    layers_tested: 4, layers_passed: 1, verdict: 'sv_only',
    independence_class: 'sv_only',
  });
  ok(hv5.confidence_tier === 'SV_only', 'independence_class=sv_only → SV_only (overrides numeric tier)');

  const hv6 = derive('hypothesis_verdict', {
    layers_tested: 4, layers_passed: 4, verdict: 'confirmed',
    independence_class: 'layer_c_only',
  });
  ok(hv6.confidence_tier === 'Layer_C_only', 'independence_class=layer_c_only → Layer_C_only');

  // ============================================================================
  // burden — burden_class from verdict
  // ============================================================================
  ok(derive('burden', { verdict: 'INV_ELEVATED' }).burden_class === 'enriched',
     'burden INV_ELEVATED → enriched');
  ok(derive('burden', { verdict: 'INV_DEPLETED' }).burden_class === 'depleted',
     'burden INV_DEPLETED → depleted');
  ok(derive('burden', { verdict: 'NEUTRAL' }).burden_class === 'neutral',
     'burden NEUTRAL → neutral');
  ok(derive('burden', { verdict: 'enriched' }).burden_class === 'enriched',
     'burden lowercase enriched → enriched');

  // ============================================================================
  // morphology, band_composition, block_detect, triangle_insulation,
  // peel_diagnostic, synteny_dollo — supportive only, no axis derivation
  // ============================================================================
  for (const supBt of ['morphology', 'band_composition', 'block_detect',
       'triangle_insulation', 'peel_diagnostic', 'synteny_dollo']) {
    const result = derive(supBt, { some_field: 'whatever' });
    ok(Object.keys(result).length === 0,
       `${supBt} is supportive only (no axes derived)`);
  }

  // ============================================================================
  // final_classification / classification — copy verbatim
  // ============================================================================
  const fc = derive('final_classification', {
    existence_layer_a: 'pass',
    existence_layer_b: 'pass',
    existence_layer_c: 'pass',
    existence_layer_d: 'fail',
    boundary_quality: 'sharp',
    group_validation: 'VALIDATED',
    internal_structure: 'clean',
    recombinant_class: 'none',
    family_linkage: 'multi_family',
    polymorphism_class: 'cohort_wide',
    mechanism_class: 'NAHR',
    age_class: 'intermediate',
    burden_class: 'neutral',
    confidence_tier: 'T2',
  });
  ok(Object.keys(fc).length === 14, 'final_classification populates all 14 axes verbatim');
  ok(fc.existence_layer_a === 'pass', 'final_classification preserves existence_layer_a');
  ok(fc.confidence_tier === 'T2', 'final_classification preserves confidence_tier');

  const cls = derive('classification', { mechanism_class: 'MMBIR' });
  ok(cls.mechanism_class === 'MMBIR', 'classification (alias) works the same way');

  // ============================================================================
  // Unknown / null inputs
  // ============================================================================
  ok(Object.keys(derive('totally_unknown_block', { foo: 1 })).length === 0,
     'unknown block type → empty derivation');
  ok(Object.keys(derive('mechanism', null)).length === 0,
     'null obj → empty derivation');
  ok(Object.keys(derive(null, {})).length === 0,
     'null blockType → empty derivation');
  ok(Object.keys(derive('mechanism', 'not an object')).length === 0,
     'string obj → empty derivation');

  // ============================================================================
  // Boundary reconciliation — both sides needed
  // ============================================================================
  // Set up state.data.evidence_blocks for the helper to read
  vm.runInContext(`
    if (!state.data) state.data = {};
    if (!state.data.evidence_blocks) state.data.evidence_blocks = {};
    state.data.evidence_blocks['CAND_A'] = {
      boundary_left:  { verdict: 'confirmed_structural', hardness: 0.85 },
      boundary_right: { verdict: 'confirmed_structural', hardness: 0.90 },
    };
    state.data.evidence_blocks['CAND_B'] = {
      boundary_left:  { verdict: 'fuzzy', hardness: 0.30 },
      boundary_right: { verdict: 'confirmed_structural', hardness: 0.85 },
    };
    state.data.evidence_blocks['CAND_C'] = {
      boundary_left: { verdict: 'confirmed_structural', hardness: 0.85 },
    };
    state.data.evidence_blocks['CAND_NONE'] = {};
  `, sandbox);

  const reconcile = sandbox._reconcileBoundaryQuality;
  ok(reconcile('CAND_A') === 'sharp', 'both sides confirmed_structural + hardness>=0.7 → sharp');
  ok(reconcile('CAND_B') === 'fuzzy', 'one side fuzzy → fuzzy (overall)');
  ok(reconcile('CAND_C') === 'fuzzy',
     'one side present, hardness=0.85 alone → fuzzy (conservative — needs both sides for sharp)');
  ok(reconcile('CAND_NONE') === null, 'no boundary blocks → null');
  ok(reconcile('NONEXISTENT_CID') === null, 'unknown candidate_id → null');

  // ============================================================================
  // _KNOWN_BLOCK_TYPES — verify all 18 + aliases present
  // ============================================================================
  // const-scoped, not exposed; verified via regex test in test_v399.js TEST 72.

  console.log(`\n--- v3.99 t14e+ continue 18-blocks runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
