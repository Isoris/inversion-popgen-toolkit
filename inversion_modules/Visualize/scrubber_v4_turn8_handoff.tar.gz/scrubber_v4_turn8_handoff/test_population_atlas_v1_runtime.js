#!/usr/bin/env node
// =============================================================================
// Population Atlas v1 — runtime tests
// =============================================================================
// Standalone sibling HTML to pca_scrubber_v3.html. Layout-only scaffold.
// Tests check structure (pages, tabs, theme system, content cards),
// not data rendering (no JSON / no panel renderers in v1).
// =============================================================================

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/population_atlas_v1.html', 'utf8');

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; console.log('  PASS', msg); }
  else { fail++; console.log('  FAIL', msg); }
}

console.log('\n--- Population Atlas v1 — runtime tests ---');

// ============================================================================
// 1. File structure / parse
// ============================================================================
console.log('\n  --- structural integrity ---');
ok(/^<!doctype html>/i.test(html),
   'starts with <!doctype html>');
ok(/<title>Population Atlas v1[^<]+<\/title>/.test(html),
   'has <title>Population Atlas v1...');
const scriptBlock = html.match(/<script>([\s\S]+?)<\/script>/);
ok(scriptBlock !== null,
   '<script> block present');
if (scriptBlock) {
  try {
    new Function(scriptBlock[1]);
    ok(true, 'script parses without syntax errors');
  } catch (e) {
    ok(false, `script parse failed: ${e.message}`);
  }
}

// Tag balance — div tags must match
const divOpens = (html.match(/<div\b/g) || []).length;
const divCloses = (html.match(/<\/div>/g) || []).length;
ok(divOpens === divCloses,
   `<div> tag balance: ${divOpens} open / ${divCloses} close`);

// ============================================================================
// 2. Page system — 7 pages
// ============================================================================
console.log('\n  --- 7 pages present ---');
for (let i = 1; i <= 7; i++) {
  const re = new RegExp(`<div id="page${i}" class="page`);
  ok(re.test(html), `page${i} div present`);
}
// Default active page is page1
ok(/<div id="page1" class="page active">/.test(html),
   'page1 starts as the active page');

// ============================================================================
// 3. Tab bar — 7 tab buttons matching the 7 pages
// ============================================================================
console.log('\n  --- tab buttons ---');
const expectedTabs = [
  { id: 'page1', label: 'samples' },
  { id: 'page2', label: 'QC' },
  { id: 'page3', label: 'families &amp; clusters' },
  { id: 'page4', label: 'heterozygosity' },
  { id: 'page5', label: 'diversity' },
  { id: 'page6', label: 'inbreeding' },
  { id: 'page7', label: 'about' },
];
for (const tab of expectedTabs) {
  const re = new RegExp(`<button data-page="${tab.id}"[^>]*>[\\s\\S]{0,200}${tab.label.replace(/&/g, '&amp;').replace(/&amp;amp;/g, '&amp;')}</button>`);
  ok(re.test(html), `tab "${tab.label}" → ${tab.id}`);
}
// First tab has class="active"
ok(/<button data-page="page1" class="active"/.test(html),
   'page1 tab starts active');

// Scrubber link present at end of tab bar
ok(/<a href="pca_scrubber_v3\.html" id="scrubberLink"[^>]*>→ Inversions Atlas<\/a>/.test(html),
   'scrubber link "→ Inversions Atlas" at end of tab bar');

// ============================================================================
// 4. Header
// ============================================================================
console.log('\n  --- header ---');
ok(/<h1>Population Atlas · v1<\/h1>/.test(html),
   'header h1 = "Population Atlas · v1"');
ok(/id="atlasBadge"[^>]*>POPULATION ATLAS</.test(html),
   'atlasBadge shows "POPULATION ATLAS"');
ok(/id="themeToggleBtn"/.test(html),
   'theme toggle button present');
ok(/226-sample <i>C\. gariepinus<\/i> cohort/.test(html),
   'header meta references the 226-sample C. gariepinus cohort');

// ============================================================================
// 5. CSS variable system — accent flipped to green
// ============================================================================
console.log('\n  --- CSS theme: accent → green ---');
ok(/--accent: #3cc08a/.test(html),
   'dark theme --accent flipped from amber (#f5a524) to green (#3cc08a)');
ok(/--accent:\s*#16a34a/.test(html),
   'light theme --accent is darker green for legibility');
ok(/--accent:\s*#4f7a4d/.test(html),
   'academic theme --accent is sage green');
ok(/--pop-samples:|--pop-qc:|--pop-fam:|--pop-het:|--pop-div:|--pop-roh:/.test(html),
   'population-atlas-specific palette --pop-* variables defined');
// Tab active gradient is green-tinted
ok(/rgba\(60, 192, 138, 0\.22\)/.test(html),
   'active tab gradient uses rgba(60,192,138,...) green tint (not amber)');

// ============================================================================
// 6. Per-page content cards
// ============================================================================
console.log('\n  --- per-page content ---');
// Page 1 — Samples
ok(/page1[\s\S]{0,200}<div class="page-title">Samples</.test(html),
   'page1 has "Samples" page-title');
ok(/Planned columns[\s\S]{0,2000}<code>sample_id<\/code>/.test(html),
   'page1 lists sample_id field');
ok(/Planned columns[\s\S]{0,2000}<code>F_ROH<\/code>/.test(html),
   'page1 lists F_ROH field');
ok(/Mock-up — what the table will look like/.test(html),
   'page1 includes mock-up of the table');

// Page 2 — QC
ok(/page2[\s\S]{0,200}<div class="page-title">Quality Control</.test(html),
   'page2 has "Quality Control" page-title');
ok(/QC thresholds \(cohort defaults\)/.test(html),
   'page2 has QC thresholds card');
ok(/<code>contamination_freemix<\/code>/.test(html),
   'page2 lists contamination_freemix metric');

// Page 3 — Families & Clusters
ok(/page3[\s\S]{0,200}<div class="page-title">Families &amp; Genetic clusters</.test(html),
   'page3 has "Families & Genetic clusters" page-title');
ok(/Structure design — two rounds/.test(html),
   'page3 explains the two-round structure design (all-226 + NAToRA-pruned-81)');
ok(/NGSadmix Q-bar plot — round 1/.test(html),
   'page3 has Q-bar plot panel slot for round 1');
ok(/NGSadmix Q-bar plot — round 2/.test(html),
   'page3 has Q-bar plot panel slot for round 2');

// Page 4 — Heterozygosity
ok(/page4[\s\S]{0,200}<div class="page-title">Heterozygosity</.test(html),
   'page4 has "Heterozygosity" page-title');
ok(/Folded SFS/.test(html),
   'page4 documents folded SFS caveat (no outgroup polarization)');
ok(/H_obs vs F_ROH/.test(html),
   'page4 has H_obs vs F_ROH scatter panel');

// Page 5 — Diversity
ok(/page5[\s\S]{0,200}<div class="page-title">Diversity</.test(html),
   'page5 has "Diversity" page-title');
ok(/Available scales \(from MODULE_3\)/.test(html),
   'page5 documents the multiscale θπ file paths');
ok(/win50000\.step10000/.test(html),
   'page5 references the 50kb/10kb scale');
ok(/Per-band θπ comparison/.test(html),
   'page5 has per-band θπ panel (red/green/blue genotype tracks)');

// Page 6 — Inbreeding
ok(/page6[\s\S]{0,200}<div class="page-title">Inbreeding</.test(html),
   'page6 has "Inbreeding" page-title');
ok(/ROH bin schema/.test(html),
   'page6 documents the dual-bin ROH design (fixed + adaptive)');
ok(/ROH atlas — sample × position/.test(html),
   'page6 has the ROH atlas panel (sample × position heatmap)');

// Page 7 — About
ok(/page7[\s\S]{0,200}<div class="page-title">About this Atlas</.test(html),
   'page7 has "About this Atlas" page-title');
ok(/Three atlases — the manuscript design/.test(html),
   'page7 explains the three-atlas manuscript design');
ok(/<code>pca_scrubber_v3\.html<\/code>[\s\S]{0,200}Inversions/.test(html),
   'page7 references atlas 1/3 = scrubber for Inversions');
ok(/<code>population_atlas_v1\.html<\/code>[\s\S]{0,200}this file/.test(html),
   'page7 references atlas 2/3 = this file for Population');
ok(/<code>variants_atlas_v1\.html<\/code>[\s\S]{0,200}Variants/.test(html),
   'page7 references atlas 3/3 = variants_atlas_v1.html (planned)');

// ============================================================================
// 7. Phasing roadmap
// ============================================================================
console.log('\n  --- phasing roadmap ---');
ok(/scaffold \+ page structure[\s\S]{0,500}✓ shipped \(this turn\)/.test(html),
   'phase A: scaffold ✓ shipped this turn');
ok(/Samples page — wire to real data/.test(html),
   'phase B (next): Samples page → real data');
ok(/Cross-links with Inversions Atlas/.test(html),
   'phase D (later): cross-links between atlases');

// ============================================================================
// 8. Glossary
// ============================================================================
console.log('\n  --- glossary ---');
const glossaryTerms = ['broodline', 'F_ROH', 'ROH', 'θπ', 'NAToRA', 'NGSadmix', 'folded SFS'];
for (const term of glossaryTerms) {
  // Match the term inside a <code> in the glossary card
  const escapedTerm = term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const re = new RegExp(`<code>${escapedTerm}</code>`);
  ok(re.test(html), `glossary defines "${term}"`);
}

// ============================================================================
// 9. JS — tab switching + theme toggle + localStorage
// ============================================================================
console.log('\n  --- JS behavior hooks ---');
ok(/document\.querySelectorAll\('#tabBar button\[data-page\]'\)\.forEach/.test(html),
   'tab switching iterates over all #tabBar buttons');
ok(/localStorage\.setItem\('population_atlas_v1\.activeTab'/.test(html),
   'last-viewed tab persists to localStorage');
ok(/localStorage\.setItem\('population_atlas_v1\.theme'/.test(html),
   'theme choice persists to localStorage');
ok(/dark[\s\S]{0,100}light[\s\S]{0,100}academic/.test(html),
   'theme cycle: dark → light → academic');
ok(/document\.documentElement\.setAttribute\('data-theme'/.test(html),
   'theme applied via html data-theme attribute (matches scrubber idiom)');

// ============================================================================
// 10. Cross-references to scrubber
// ============================================================================
console.log('\n  --- cross-references to scrubber ---');
ok(/href="pca_scrubber_v3\.html"/.test(html),
   'links to scrubber HTML file');
ok(/Inversions Atlas page 12 \(local PCA θπ\)/.test(html),
   'cross-references scrubber page 12 (θπ scrubber)');
ok(/Inversions Atlas page 13 \(Diversity Atlas preview\)/.test(html),
   'cross-references scrubber page 13 (diversity atlas landing page)');

console.log(`\n--- Population Atlas v1 runtime tests: ${pass}/${pass + fail} ---`);
if (fail > 0) process.exit(1);
