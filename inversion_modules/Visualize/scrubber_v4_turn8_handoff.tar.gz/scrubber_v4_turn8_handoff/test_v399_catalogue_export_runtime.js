#!/usr/bin/env node
// Runtime behavioral tests for v3.99 t14e+ refined catalogue export +
// gallery PNG. Boots the script in a vm sandbox with a minimal DOM +
// canvas + Blob/URL stubs, then calls the export functions and inspects
// what they produce.

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const scriptMatch = html.match(/<script>([\s\S]+?)<\/script>/);
if (!scriptMatch) { console.error('no <script>'); process.exit(1); }
const code = scriptMatch[1];

// Capture what the script tries to download — instead of triggering a real
// download, we intercept blob/click and store the contents.
const captured = { blobs: [], dataURLs: [], filenames: [] };

// Minimal Blob shim — just stores text so we can inspect content
class FakeBlob {
  constructor(parts, options) {
    this.parts = parts || [];
    this.type = (options && options.type) || '';
    this.size = (parts || []).reduce((acc, p) => acc + (p ? p.length : 0), 0);
    // Store the text content for the test to inspect
    this._text = (parts || []).map(p => typeof p === 'string' ? p : '').join('');
    captured.blobs.push(this);
  }
}

// Fake canvas + 2D context
function makeFakeCanvas() {
  const ctx = {
    scale: () => {},
    fillRect: () => {},
    strokeRect: () => {},
    fillText: () => {},
    measureText: () => ({ width: 30 }),
    beginPath: () => {},
    arc: () => {},
    fill: () => {},
    stroke: () => {},
    moveTo: () => {},
    lineTo: () => {},
    setLineDash: () => {},
    save: () => {},
    restore: () => {},
    translate: () => {},
    fillStyle: '', strokeStyle: '', lineWidth: 1,
    font: '', textAlign: '', textBaseline: '',
  };
  return {
    width: 0, height: 0,
    getContext: () => ctx,
    toBlob: (cb, mime) => {
      // Synchronously call back with a blob containing a marker so the test
      // can verify the path executed
      cb(new FakeBlob(['PNG-DATA'], { type: mime || 'image/png' }));
    },
    toDataURL: (mime) => `data:${mime || 'image/png'};base64,UE5HLURBVEE=`,
  };
}

const sandbox = {
  console,
  document: {
    elements: {},
    getElementById(id) {
      // Return a stable fake element so handlers can attach listeners
      if (!this.elements[id]) {
        this.elements[id] = {
          id, listeners: {},
          dataset: {},
          style: {},
          addEventListener(ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); },
          removeEventListener() {},
          appendChild() {}, removeChild() {},
          click() {
            if (this._isDownloadAnchor && this._href && this._download) {
              captured.filenames.push(this._download);
              if (this._href.startsWith('data:')) captured.dataURLs.push(this._href);
            }
          },
          set href(v) { this._href = v; this._isDownloadAnchor = true; },
          get href() { return this._href; },
          set download(v) { this._download = v; },
          get download() { return this._download; },
          options: [],
          textContent: '', innerHTML: '',
          value: '',
        };
      }
      return this.elements[id];
    },
    createElement(tag) {
      if (tag === 'canvas') return makeFakeCanvas();
      if (tag === 'a') {
        const a = {
          listeners: {}, dataset: {}, style: {},
          addEventListener() {}, removeEventListener() {},
          click() {
            if (this._href && this._download) {
              captured.filenames.push(this._download);
              if (this._href.startsWith('data:')) captured.dataURLs.push(this._href);
            }
          },
          set href(v) { this._href = v; },
          get href() { return this._href; },
          set download(v) { this._download = v; },
          get download() { return this._download; },
        };
        return a;
      }
      return { dataset: {}, style: {}, addEventListener() {}, appendChild() {} };
    },
    body: {
      appendChild() {}, removeChild() {},
      dataset: {}, classList: { add() {}, remove() {}, toggle() {} },
    },
    documentElement: { dataset: {} },
    querySelectorAll() { return []; },
    querySelector() { return null; },
    addEventListener() {},
  },
  window: {
    addEventListener() {},
    removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: (fn) => { try { fn(); } catch (_) {} return 0; },
  clearTimeout() {},
  requestAnimationFrame: () => 0,
  localStorage: {
    _store: {},
    getItem(k) { return this._store[k] || null; },
    setItem(k, v) { this._store[k] = String(v); },
    removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  TextEncoder: typeof TextEncoder !== 'undefined' ? TextEncoder : undefined,
  TextDecoder: typeof TextDecoder !== 'undefined' ? TextDecoder : undefined,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: FakeBlob,
  Image: function () { this.src = ''; },
  alert: (msg) => { captured.alerts = captured.alerts || []; captured.alerts.push(msg); },
};
sandbox.globalThis = sandbox;
sandbox.self = sandbox;
sandbox.global = sandbox;
sandbox.window.document = sandbox.document;
sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); }
  catch (e) { /* tolerated — many init paths fail headless */ }

  console.log('\n--- t14e+ continue: catalogue export + gallery runtime tests ---');

  // -------------------------------------------------------------------------
  // _slugForFilename
  // -------------------------------------------------------------------------
  if (typeof sandbox._slugForFilename === 'function') {
    ok(sandbox._slugForFilename('Clarias gariepinus') === 'Clarias_gariepinus',
       '_slugForFilename converts space to underscore');
    ok(sandbox._slugForFilename('  Tilapia  mossambica  ') === 'Tilapia_mossambica',
       '_slugForFilename trims whitespace + collapses runs');
    ok(sandbox._slugForFilename('Anguilla anguilla (European eel)') === 'Anguilla_anguilla_European_eel',
       '_slugForFilename strips non-alphanumeric (parens become underscores)');
    ok(sandbox._slugForFilename('') === '',
       '_slugForFilename returns empty for empty input');
    ok(sandbox._slugForFilename(null) === '',
       '_slugForFilename returns empty for null');
    ok(sandbox._slugForFilename('___') === '',
       '_slugForFilename trims leading/trailing underscores entirely');
  } else {
    ok(false, '_slugForFilename function not in sandbox global');
  }

  // -------------------------------------------------------------------------
  // _exportSummaryStats
  // -------------------------------------------------------------------------
  if (typeof sandbox._exportSummaryStats === 'function') {
    const stats = sandbox._exportSummaryStats([
      { k_used: 3, verdict: 'TWO_INVERSIONS', span_mb: 1.4 },
      { k_used: 3, verdict: 'TWO_INVERSIONS', span_mb: 0.8 },
      { k_used: 6, verdict: 'CROSSOVER_ARTIFACTS', span_mb: 2.5 },
      { k_used: 4, verdict: 'NA', span_mb: 0.3 },
    ]);
    ok(stats.n === 4, '_exportSummaryStats counts rows');
    ok(stats.kCounts['3'] === 2, 'K=3 count = 2');
    ok(stats.kCounts['6'] === 1, 'K=6 count = 1');
    ok(stats.kCounts['4'] === 1, 'K=4 count = 1');
    ok(stats.verdictCounts['TWO_INVERSIONS'] === 2, 'TWO_INVERSIONS count = 2');
    ok(stats.verdictCounts['CROSSOVER_ARTIFACTS'] === 1, 'CROSSOVER_ARTIFACTS count = 1');
    ok(stats.spanRange && Math.abs(stats.spanRange.min - 0.3) < 1e-9, 'span min = 0.3');
    ok(stats.spanRange && Math.abs(stats.spanRange.max - 2.5) < 1e-9, 'span max = 2.5');
    ok(stats.spanRange && Math.abs(stats.spanRange.total - 5.0) < 1e-9, 'span total = 5.0');

    // Empty input
    const empty = sandbox._exportSummaryStats([]);
    ok(empty.n === 0, '_exportSummaryStats handles empty rows');
    ok(empty.spanRange === null, 'empty input → spanRange null');

    // Missing fields fall back to '?'
    const partial = sandbox._exportSummaryStats([{ k_used: null, span_mb: NaN }]);
    ok(partial.kCounts['?'] === 1, 'k_used null → "?" key');
    ok(partial.verdictCounts['NA'] === 1, 'verdict missing → "NA"');
  } else {
    ok(false, '_exportSummaryStats not in sandbox global');
  }

  // -------------------------------------------------------------------------
  // _galleryVerdictColor (print palette)
  // -------------------------------------------------------------------------
  if (typeof sandbox._galleryVerdictColor === 'function') {
    ok(sandbox._galleryVerdictColor('TWO_INVERSIONS') === '#0a7d3a',
       'TWO_INVERSIONS → green');
    ok(sandbox._galleryVerdictColor('CROSSOVER_ARTIFACTS') === '#b54708',
       'CROSSOVER_ARTIFACTS → orange-brown');
    ok(sandbox._galleryVerdictColor('NOISY_REGION') === '#9c1a1a',
       'NOISY_REGION → dark red');
    ok(sandbox._galleryVerdictColor('NA') === '#6b7280',
       'NA → grey');
    ok(sandbox._galleryVerdictColor('UNDETERMINED') === '#9c5b1a',
       'UNDETERMINED → amber');
    ok(sandbox._galleryVerdictColor('ANYTHING_ELSE') === '#0e1116',
       'unknown verdict → ink default');
  } else {
    ok(false, '_galleryVerdictColor not in sandbox global');
  }

  // -------------------------------------------------------------------------
  // _galleryBandCounts
  // -------------------------------------------------------------------------
  if (typeof sandbox._galleryBandCounts === 'function') {
    const labels = new Int8Array([0, 0, 1, 1, 1, 2, 0, 1, -1]);
    const c = sandbox._galleryBandCounts({ K: 3, locked_labels: labels });
    ok(Array.isArray(c) && c.length === 3, 'returns array length K=3');
    ok(c[0] === 3 && c[1] === 4 && c[2] === 1, 'counts correct (3, 4, 1) — ignores -1');

    ok(sandbox._galleryBandCounts(null) === null, 'null candidate → null');
    ok(sandbox._galleryBandCounts({ K: 3 }) === null, 'no locked_labels → null');
  } else {
    ok(false, '_galleryBandCounts not in sandbox global');
  }

  // -------------------------------------------------------------------------
  // exportGalleryPNG: empty-state + actual export
  // -------------------------------------------------------------------------
  if (typeof sandbox.exportGalleryPNG === 'function') {
    // Case 1: no state.data
    captured.alerts = [];
    sandbox.exportGalleryPNG();
    ok((captured.alerts || []).some(m => /Load a JSON first/.test(m)) ||
       (captured.alerts || []).some(m => /No confirmed candidates/.test(m)),
       'gallery: no data OR no candidates → alert fires (no crash)');
  } else {
    ok(false, 'exportGalleryPNG not in sandbox global');
  }

  // -------------------------------------------------------------------------
  // _buildGalleryCanvas with synthetic candidates — verifies the canvas
  // pathway runs end-to-end without throwing.
  // -------------------------------------------------------------------------
  if (typeof sandbox._buildGalleryCanvas === 'function') {
    const synthCands = [
      { id: 'cand_d17L2_0001_03', K: 3, ref_l2: 0,
        start_bp: 12_450_000, end_bp: 14_120_000, confirmed: true,
        locked_labels: new Int8Array([0,0,0,1,1,1,1,1,1,2,2,2,2,2]) },
      { id: 'cand_d17L2_0008_03', K: 6, ref_l2: 8,
        start_bp: 22_000_000, end_bp: 24_500_000, confirmed: true,
        locked_labels: new Int8Array([0,1,2,3,4,5,0,1,2]) },
    ];
    let canvas, threw = false;
    try { canvas = sandbox._buildGalleryCanvas(synthCands); }
    catch (e) { threw = true; console.error('  _buildGalleryCanvas threw:', e.message); }
    ok(!threw, '_buildGalleryCanvas runs without throwing');
    ok(canvas && canvas.width > 0 && canvas.height > 0,
       '_buildGalleryCanvas returns sized canvas');
  } else {
    ok(false, '_buildGalleryCanvas not in sandbox global');
  }

  console.log(`\n--- v3.99 t14e+ continue catalogue runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
