# SCHEMA_V2 — JSON layers contract for the local PCA scrubber

**Version:** 2.10 (2026-04-28)
**Status:** Specification — scrubber implements detection in v3.20, two-level
candidate promotion in v3.80, K=6 substructure in v3.81–v3.87. Marker /
PCR assay module (phase 13, §10) is specification-only — not yet
implemented. Band diagnostics module (§11) has scrubber-side compute and
UI in v3.92–v3.93; the three source layers (`theta_pi_panel`,
`roh_intervals`, `sample_froh`) are spec-only — emitted-from-R-side not
yet written. Het-shape sub-module (§11.1) shipped in v3.93 with three
in-scrubber placements (inline ridgeline column, candidate-page figure,
hover popover) using existing GHSL panel data. Live dosage heatmap
rendering contract added in v2.5; **v2.6 substantially extends it** with
the FIG_C08-style visual contract from `STEP28_candidate_marker_heatmap.R`
(5 left tracks + 1 top track), two new planned source layers
(`candidate_sample_coherence`, `candidate_marker_polarity`), and a
region-binding contract that supports both static (candidate-bound) and
live (cursor-bound, ±5 windows) views. **v2.7** adds the hover-tooltip
contract — overlay-only updates (no redraws), one-line format
"sample · marker (bp) · dosage=N · group · quality · flipped", with cell-
stable suppression and RAF coalescing. **v2.8** adds the boundary-zone
refinement contract (§12): an optional `boundary_evidence` layer,
per-candidate `boundary_left`/`boundary_right` records with weighted
score + support tracks + support_class, a candidate-level
`breakpoint_status` enum, and a strict terminology contract — "boundary
zone" is the default; "exact breakpoint" is reserved for junction-level
evidence only. **v2.9** flips three planned-status flags to shipped:
the v3.94 dosage heatmap has its R-side emit (STEP_M04 + STEP_M05 in
v3.95); v3.97's `boundary_evidence` layer has its R-side emit
(STEP_M06 in v3.99); the v3.98 NULL_CONCORD K=6 fix is documented in
the band-diagnostics module. No new contract surface in 2.9 — it's a
status-reconciliation bump. **v2.10** adds the within-regime
subclustering contract to §10: per-regime split → SVD-rotate `(u, v)`
→ standardize → DBSCAN/HDBSCAN — never raw `(u, v)` across all
samples. Four `cluster_mode` values defined: `none` (**default** —
subclustering not run, current scrubber behaviour preserved),
`rotated_within_regime` (opt-in production mode), and two named
diagnostic alternatives `raw_uv` and `one_dimensional_rotated_axis`.
Subcluster labels (`HOMO_1_sub2`, `HET_sub_noise`, etc.) ride on the
`candidate_sample_coherence` layer's `coarse_group_refined` column;
new optional `u_rot`/`v_rot`/`cluster_mode` columns. **Subclusters are
diagnostic, not paper-level inversion states** — manuscripts report
HOMO_1 / HET / HOMO_2 only.

This document defines the canonical JSON shape that flows between
`export_precomp_to_json_v3.R` (LANTA cluster), the scrubber (browser),
and the downstream cluster phases 6–12 of the inversion-popgen-toolkit.

---

## 1. Why a versioned schema

Until now, each scrubber feature was added by extending the JSON shape
without a version field. That worked while the scrubber was the only
consumer. Now that the scrubber emits a **candidate registry** that
cluster phases 6+ depend on, the shape becomes a contract — and
contracts need versions.

**Versioning rules:**

- `schema_version: 1` is the legacy shape (no `_layers_present` field).
  The scrubber **infers** which layers are present by checking which
  top-level keys exist.
- `schema_version: 2` is the new shape. It declares `_layers_present`
  explicitly so the scrubber doesn't have to infer.
- **Adding a new layer or column** → bump to 2.1, 2.2, etc. Backwards
  compatible; older readers ignore unknown fields.
- **Renaming or removing** a layer/column → bump to 3.x. Breaking change;
  cluster scripts must be updated in lockstep.

The scrubber accepts both v1 and v2 input. It writes v2 only.

---

## 1.5. File staging convention — the "chapter end" pattern

The scrubber doesn't talk to the cluster directly. It reads JSON files
that the user drag-drops into the browser. To make this manageable
across 28 chromosomes and many phases, all per-chromosome JSONs land in
**one staging area**, organized by chromosome.

### The pattern

```
inversion_modules/
└── scrubber/
    └── data/
        ├── README.md
        ├── LG01/
        │   ├── LG01_phase2_precomp.json        ← end of phase 2
        │   ├── LG01_phase3_proposals.json      ← end of phase 3
        │   ├── LG01_phase4a_ghsl.json          ← end of phase 4a
        │   ├── LG01_phase4b_theta.json         ← end of phase 4b
        │   ├── LG01_phase4c_dip.json           ← end of phase 4c
        │   ├── LG01_phase4d_concordance.json   ← end of phase 4d
        │   ├── LG01_phase4e_subcandidates.json ← end of phase 4e
        │   ├── LG01_phase5_consolidated.json   ← end of phase 5
        │   ├── LG01_phase9_classification.json ← end of phase 9
        │   └── LG01_phase12_cargo.json         ← end of phase 12
        ├── LG02/
        │   └── ... (same structure)
        ...
        └── LG28/
            └── ...
```

### Why one staging area

Reviewing 28 chromosomes is real work. The user shouldn't have to hunt
across `phase_2_discovery/2c_precomp/output/`, `phase_3_catalog_assembly/output/`,
`phase_4_resolution_and_classification/4d_dual_clustering/output/`, etc.
to find the JSONs for one chromosome. Everything for `LG14` lives in
`scrubber/data/LG14/`. Drag the folder's JSONs in, get to work.

### The chapter-end pattern

Each phase is a "chapter." Cluster scripts run, do their work, and
write their *own* outputs (RDS files, intermediate TSVs, audit logs)
to their *own* phase folders during the chapter. At the **end** of the
chapter — when the phase has finished — one designated emit script
distills what the scrubber needs and writes a single JSON to
`scrubber/data/<chrom>/`.

This means each phase has exactly one "emit-for-scrubber" step as its
last action. Not every script writes to `scrubber/data/`. Not even most
scripts. Just the chapter-closing emit script.

| Phase | Emit script (chapter-end)              | Output filename                              |
|-------|----------------------------------------|----------------------------------------------|
| 2     | `export_precomp_to_json_v3.R`          | `<chrom>_phase2_precomp.json`                |
| 3     | `STEP_X02_emit_proposals_for_scrubber.R` | `<chrom>_phase3_proposals.json`            |
| 4a    | `STEP_R03_emit_ghsl_for_scrubber.R`    | `<chrom>_phase4a_ghsl.json`                  |
| 4b    | `STEP_T06_emit_theta_for_scrubber.R`   | `<chrom>_phase4b_theta.json`                 |
| 4c    | `STEP_DT02_emit_dip_for_scrubber.R`    | `<chrom>_phase4c_dip.json`                   |
| 4d    | `STEP_DC05_diagnostic_panel.R`         | `<chrom>_phase4d_concordance.json`           |
| 4e    | `STEP_SC02_emit_subcandidates.R`       | `<chrom>_phase4e_subcandidates.json`         |
| 5     | `STEP_Q99_emit_consolidated.R`         | `<chrom>_phase5_consolidated.json`           |
| 9     | `STEP_CL99_emit_classification.R`      | `<chrom>_phase9_classification.json`         |
| 12    | `STEP_GC99_emit_cargo.R`               | `<chrom>_phase12_cargo.json`                 |
| 13    | `STEP_M99_emit_markers.R`              | `<chrom>_phase13_markers.json`               |

The naming convention is `<chrom>_<phase>_<role>.json`:

- `<chrom>` matches the JSON's `chrom` field exactly. Used for cross-chrom safety in the scrubber.
- `<phase>` is `phase2`, `phase3`, `phase4a`–`phase4e`, `phase5`, `phase9`, `phase12`.
- `<role>` is short and descriptive (`precomp`, `proposals`, `concordance`, `consolidated`).

The scrubber doesn't care what the file is named. It reads
`schema_version` and `_layers_present` from the JSON contents to know
what's inside. The naming convention is for human navigation, not for
the scrubber's parsing.

### Why "chapter end" not "every script"

Two architectural considerations:

**1. Audit trail vs. working area separation.** The phase folder is the
audit trail — it accumulates RDS files, intermediate TSVs, log files,
all the cluster's working outputs. The scrubber doesn't read any of
this. The `scrubber/data/<chrom>/` folder is the *working area* for
human review — only the distilled JSONs the scrubber needs.

You can `rm -rf scrubber/data/LG28/` and rebuild it by re-running each
phase's chapter-end script (no expensive recomputation needed if the
phase folder is preserved). You can't easily do the reverse — phase
folders are the source of truth.

**2. One emit step per phase = one place to change the schema.** When
the scrubber's expected JSON shape changes (a new layer, a renamed
field), only the chapter-end emit script needs updating, not every
script in the phase. This is what makes versioned schema viable.

### What if a phase wants to emit multiple files?

It can. Phase 4 has five sub-phases (4a–4e), each with its own emit
script and its own JSON. That's still "chapter end" — each sub-phase
is its own chapter. The user sees five files for phase 4 in
`scrubber/data/<chrom>/` and can drag them in independently as each
sub-phase finishes on the cluster.

What's not allowed: a single sub-phase emitting multiple JSONs
(e.g., `phase4d_concordance_part1.json`, `phase4d_concordance_part2.json`).
One sub-phase, one emit script, one JSON. If the data is too big for
one file, that's a sign the layer needs splitting into two
sub-phases or two distinct layer names.

---

## 2. The layer model

A v2 JSON file is a collection of optional layers, each owned by one
phase of the inversion-popgen-toolkit pipeline. Layers accumulate
monotonically: phase N's output preserves phase N-1's output and adds
its own keys.

**Top-level required fields (always present):**

```jsonc
{
  "schema_version": 2,
  "chrom": "C_gar_LG28",
  "n_windows": 4302,
  "n_samples": 226,
  "_layers_present": ["windows", "envelopes", "tracks", "sv_evidence",
                      "candidates_registry"],
  "_generated_at": "2026-04-27T14:30:00Z",
  "_generator": "export_precomp_to_json_v3.R"
}
```

`_layers_present` is the truth. If a layer name is in the array, the
corresponding top-level keys are guaranteed to exist and be valid.
If it is absent, the keys may be missing entirely.

**Layer ownership (corrected 2026-04-27 per parallel-chat architecture):**

The pipeline runs in this order. Each phase emits its own enrichment JSON
file per chromosome. Files don't merge on disk — the scrubber unions them
in-session as the user drag-drops them.

| Layer name              | Phase  | Owned by             | Written by                              | Status        |
|-------------------------|--------|----------------------|-----------------------------------------|---------------|
| `windows`               | 1+2    | precompute           | `export_precomp_to_json_v3.R`           | exists (v1)   |
| `envelopes`             | 1+2    | landscape            | `export_precomp_to_json_v3.R`           | exists (v1)   |
| `tracks`                | 1+2    | C++ pop-stats engine | `export_precomp_to_json_v3.R`           | exists (v1)   |
| `samples`               | 1+2    | sample registry      | `export_precomp_to_json_v3.R`           | exists (v1)   |
| `candidate_proposals`   | 3      | cluster GHSL+staging | `STEP_X01_emit_proposals.R` (planned)   | planned       |
| `cluster_labels_ghsl`   | 4a     | GHSL Part C          | `STEP_R01_ghsl_interval_kmeans.R`       | planned       |
| `cusum_ghsl`            | 4a     | GHSL Part D          | `STEP_R02_ghsl_cusum.R`                 | planned       |
| `ghsl_karyotype_runs`   | 4a     | GHSL Part B          | `export_ghsl_to_json_v2.R`              | exists (v1)   |
| `ghsl_heatmap`          | 4a     | GHSL panel (slim)    | `export_ghsl_to_json_v1.R` (deprecated) | superseded    |
| `ghsl_panel`            | 4a     | GHSL dense panel     | `export_ghsl_to_json_v2.R`              | exists        |
| `ghsl_kstripes`         | 4a     | per-K stripe assigns | `export_ghsl_to_json_v2.R`              | exists        |
| `cluster_labels_theta`  | 4b     | θπ Part C1+C2        | `STEP_T03+T04_theta_clustering.R`       | planned       |
| `cusum_theta`           | 4b     | θπ Part D            | `STEP_T05_theta_cusum.R`                | planned       |
| `dosage_dip`            | 4c     | Hartigan dip         | `STEP_DT01_dip_per_band.R`              | planned       |
| `concordance_tables`    | 4d     | dual-clustering      | `STEP_DC05_diagnostic_panel.R`          | planned       |
| `cusum_concordance`     | 4d     | DC06 cross-signal    | `STEP_DC06_cusum_concordance.R`         | planned       |
| `subcandidates_emitted` | 4e     | cell-mean cliff-walk | `STEP_SC01_emit_subcandidates.R`        | planned       |
| `candidates_registry`   | (user) | **scrubber**         | scrubber's "📋 export registry" button  | exists (v3.20)|
| `sv_evidence`           | 5      | Layer D OR test      | `STEP_D03_statistical_tests_*.py`       | exists, moves |
| `bnd_rescue`            | 5      | BND-paired junctions | `STEP_B06_bnd_rescue.py`                | exists, moves |
| `boundaries_refined`    | 5      | Q07d/Q07e cohort     | `STEP_Q07d_fst_boundary_refine.R`       | partial       |
| `qc_flags`              | 5      | Q01–Q11 battery      | `phase_5_qc_triage/`                    | partial       |
| `groups_validated`      | 5      | tier upgrade         | (rolled-up phase 5 output)              | planned       |
| `classification`        | 9      | terminal class       | `assign_structural_class_v7.py`         | exists        |
| `gene_cargo`            | 12     | gene content         | (planned)                               | planned       |
| `marker_catalogue`      | 13     | regime-diagnostic markers | `STEP_M01_emit_marker_catalogue.R` | planned       |
| `marker_primers`        | 13     | primer designs       | `STEP_M02_emit_marker_primers.R`        | planned       |
| `marker_panel_summary`  | 13     | panel rollup         | `STEP_M03_emit_marker_panel_summary.R`  | planned       |
| `theta_pi_panel`        | 4b     | dense θπ matrix      | `STEP_T06_emit_theta_pi_panel.R`        | planned (v3.92) |
| `roh_intervals`         | 3 (MODULE_3 ROH) | per-sample ROH spans | `STEP_R12_emit_roh_intervals.R`         | planned (v3.92) |
| `sample_froh`           | 3 (MODULE_3 ROH) | genome-wide FROH per sample | `STEP_R13_emit_sample_froh.R`     | planned (v3.92) |
| `candidate_sample_coherence` | 13 follow-up | per-(candidate × sample) coherence + `stripe_quality` | `STEP_M05_emit_step29_layers.R` (wraps `STEP29_candidate_coherence_and_polarity.R` TSVs) | shipped v3.95 |
| `candidate_marker_polarity`  | 13 follow-up | per-(candidate × marker) polarity (L1, L2, final flip, support class, block id) | `STEP_M05_emit_step29_layers.R` (wraps `STEP29_candidate_coherence_and_polarity.R` TSVs) | shipped v3.95 |
| `dosage_chunks`         | 13 follow-up | per-region dosage matrix tiles (LRU loaded by scrubber on demand) | `STEP_M04_emit_dosage_chunks.R` | shipped v3.95 |
| `boundary_evidence`     | 12 (boundary refinement) | per-candidate FST + per-regime θπ + discordant_pair_pileup + sv_anchors at 5 kb scan-window resolution | `STEP_M06_emit_boundary_evidence.R` | shipped post-v3.98 |
| `bam_evidence`          | 12 (boundary refinement) | per-candidate IGV-derived BAM signals at **1 kb** scan-window resolution: coverage_dip + 3× orientation classes (FF/RR/RF) + tlen_anomaly + split_read_density + clip_density + mapq_drop + pair_orient_inv_rate composite | `STEP_M07_emit_bam_evidence.R` | **planned (schema 2.11)** |
| `completion`            | 13 (three-axis framework) | per-candidate registry-key fill statistics: total_keys, filled, NA, pct_overall, pct_by_question (Q1..Q7 + shelf), registry_version | `STEP_R20_compute_candidate_completion.R` | **planned (schema 2.12)** |
| `characterization`      | 13 (three-axis framework) | per-candidate, per-question convergence status (ANSWERED / PARTIAL / MEASURED / CONTRADICTED / EMPTY) + label + evidence_for/against counts; Q7 also exports n_layers_passed | `STEP_R21_characterize_candidate.R` | **planned (schema 2.12)** |
| `confidence_tier`       | 13 (three-axis framework) | per-candidate Tier 1 / 2 / 3 / 4 / SV-only from layer A/B/C/D independence | `STEP_R22_compute_confidence_tier.R` | **planned (schema 2.12)** |

**Architecture notes:**

- **Layer D (SV/breakpoint) lives in phase 5, not phase 3.** This was clarified in the parallel-chat decision: phase 3 is pure catalogue assembly (no validation), and Layer D needs intervals as input so it violates the phase-3 contract. SV evidence becomes a phase-5 QC validation step.
- **Two distinct candidate layers:**
  - `candidate_proposals` — cluster-authored, automated dedup of phase-2 streams. Read-only from the scrubber's perspective; loaded on phase-3 enrichment import to populate `state.candidateList` as a starting point.
  - `candidates_registry` — scrubber-authored, the user's curated list (proposals + edits + accept/reject). Emitted by the "📋 export registry" button. This is what cluster phases 4+ read as their candidate input.
- **The dual-clustering page (page 6 concordance)** lights up when `concordance_tables` is in `_layers_present` — i.e., after phase 4d output is loaded.
- **The validation banner on page 6** lights up when `sv_evidence` is in `_layers_present` — i.e., after phase 5 output is loaded.
- **CUSUM layers (`cusum_ghsl`, `cusum_theta`, `cusum_concordance`)** carry per-sample changepoint tables, per-candidate boundary distributions (5'/3' median + IQR + spread_class tight/ragged), and sub-system clusters. These are manuscript-grade observations.
- **`ghsl_panel` is the dense back-end for L2-as-triangle aggregation.** It carries the full (sample × window × scale) divergence matrix plus per-sample rank and rank-band at each scale. Browser-side helpers (`ghslDivAt`, `ghslAggregateRange`, `ghslAggregateFocal`, `ghslAggregateInterval`) compute per-L2 aggregates on click without a cluster round-trip. JSON size 50–300 MB per chromosome; loads fine locally.
- **`ghsl_kstripes` carries per-K stripe assignments** (K=2..6) at the primary rolling scale. Stripe 1 is always the lowest-rank stripe; per-stripe mean and median ranks are pre-computed for instant catalogue summaries.
- **Focal-with-flanks aggregation:** for wide L2s, mean GHSL across the full L2 range can dilute the signal (gene-conversion erosion, sub-systems). The focal±N viewer (`ghslAggregateFocal`, `ghslAggregateInterval`) takes a focal window plus a half-flank radius (default 5 windows = 11 windows total) and aggregates only that. Used by tracked-samples view and per-L2 inspection. Range-aggregation (`ghslAggregateRange`) stays available for catalogue stats where the full-L2 view is the right question.

The scrubber renders UI conditional on `_layers_present`. Layers it does
not recognize are silently ignored (so future expansions don't break it).

---

## 2.5. Interval Collector (planned, session 3)

The Interval Collector is a **passive accumulator** of candidate intervals
derived from the interaction between tracked samples and the GHSL panel.
It runs automatically when tracked samples change; the user does not have
to open a page for collection to happen. A page exists for inspection but
collection is not gated on it.

### Data flow

```
tracked_samples (user-driven, changes as user clicks ⭐ on samples)
   +
ghsl_panel (loaded from phase 4a JSON)
   +
ghsl_kstripes (loaded from phase 4a JSON)
   ↓
collectorEngine() — runs in scrubber, no I/O
   ↓
state.collectedIntervals = [
  { interval_id, start_bp, end_bp, start_w, end_w,
    n_supporting_pairs, mean_strength,
    captured_at, source: "tracked_pair_disagreement",
    derived_from_samples: ["CGA042", "CGA107"],
    K_used: 3 }
  ...
]
```

### Algorithm sketch (session 3 implementation)

For each pair of currently-tracked samples (s_i, s_j):

1. Look up `ghsl_kstripes.by_k["3"].stripe_per_sample[i]` and `[j]`.
2. If samples are in different stripes globally, scan windows: at each
   window w, compute `rank_band[s_i][w]` and `rank_band[s_j][w]` (LOW/MID/HIGH).
3. Find consecutive runs where the pair agrees (same band) and disagrees
   (different bands). Boundaries are at the agree↔disagree transitions.
4. Each transition window contributes one boundary signal for this pair.

Then aggregate across all tracked pairs:

5. For each window w, count how many pairs have a boundary signal at w
   (or within ±2 windows for smoothing).
6. Find local maxima in this count vector. Each maximum above a threshold
   becomes a captured boundary.
7. Consecutive captured boundaries define intervals — each interval gets
   an entry in `state.collectedIntervals`.

### Storage and persistence

- `state.collectedIntervals` is per-chromosome (keyed by chrom).
- Persisted to `localStorage` like the candidate list.
- Cleared when chromosome changes (separate per chrom; can be browsed back).
- Exported with the candidate registry as a separate column or as
  derived-from rows.

### What goes into the registry export

Two options for review at session 3 time:

- **Option A.** Collector intervals are auto-promoted into the candidate
  registry as `discovery_method = "scrubber_collector"` candidates, alongside
  user-promoted L2 candidates. The cluster phase 4 picks them up as proposals.
- **Option B.** Collector intervals stay in a separate "candidates_collected"
  layer. The user reviews them on a page and can promote individual ones
  into the registry. More conservative.

Default leans toward (B) — collector signals can be noisy without further
QC and we don't want auto-promotion to pollute the registry. User decides
per interval.

### Why "no need to open the page"

The collector runs whenever:
- A sample is added/removed from tracked_samples
- The user changes K (k-stripes choice)
- A new ghsl_panel/ghsl_kstripes is loaded

The output (`state.collectedIntervals`) is queryable from any page —
it's just state. The collector page exists to visualize the captured
intervals (positions, supporting pairs, strength) but UI rendering is
not on the critical path. Other pages can show "N intervals collected"
in the header.

---

## 3. v1 → v2 inference

When the scrubber loads a v1 file (no `schema_version` field, or
`schema_version: 1`), it **infers** the layers from top-level keys:

```js
function inferLayersFromV1(json) {
  const layers = [];
  if (json.windows && json.n_windows > 0)        layers.push('windows');
  if (json.l1_envelopes || json.l2_envelopes)    layers.push('envelopes');
  if (json.tracks && Object.keys(json.tracks).length > 0) layers.push('tracks');
  if (json.samples && json.samples.length > 0)   layers.push('samples');
  // sv_evidence, breakpoints_refined, etc. were not produced by v1 exporters
  return layers;
}
```

This means a v1 JSON behaves identically to a v2 JSON with
`_layers_present: ['windows', 'envelopes', 'tracks', 'samples']` —
which is exactly the case today.

---

## 4. The candidates_registry layer (the scrubber's contract output)

This is the **canonical candidate list** that cluster phases 6+ consume.
It is written by the scrubber when the user clicks
*"📋 export candidate registry"* on page 4.

Two parallel files are produced:

- `<chrom>_candidate_registry.tsv` — canonical, one row per candidate.
  Easy to read in R / Python / Excel. **This is what cluster phases read.**
- `<chrom>_candidate_registry.json` — same data as JSON. For tools that
  prefer JSON (e.g. embedded in a v2 layer JSON).

### TSV columns (canonical, fixed order)

| Column                  | Type    | Source           | Description                                                                                       |
|-------------------------|---------|------------------|---------------------------------------------------------------------------------------------------|
| `candidate_id`          | string  | scrubber         | Unique id (e.g. `cand_lg28_142_a`); stable across reruns of the scrubber                          |
| `chrom`                 | string  | scrubber         | Chromosome (matches the JSON's `chrom`)                                                           |
| `start_bp`              | integer | scrubber         | Candidate start, 1-based inclusive                                                                |
| `end_bp`                | integer | scrubber         | Candidate end, 1-based inclusive                                                                  |
| `start_w`               | integer | scrubber         | First window index (0-based)                                                                      |
| `end_w`                 | integer | scrubber         | Last window index (0-based, inclusive)                                                            |
| `n_windows`             | integer | scrubber         | end_w - start_w + 1                                                                               |
| `span_mb`               | float   | scrubber         | (end_bp - start_bp) / 1e6, 3 decimals                                                             |
| `K`                     | integer | scrubber         | Number of bands (karyotype groups)                                                                |
| `source`                | string  | scrubber         | `l2_single` / `l2_merge` / `lock_promote` (how the candidate was created)                         |
| `l2_indices`            | string  | scrubber         | Comma-separated L2 indices (e.g. `"3,4,5"`)                                                       |
| `ref_l2`                | integer | scrubber         | The L2 used as the band reference                                                                 |
| `ref_window`            | integer | scrubber         | Window index where bands were anchored                                                            |
| `sigma_verdict`         | string  | scrubber         | `TWO_INVERSIONS` / `CROSSOVER_ARTIFACTS` / `NOISY_REGION` / `NA` / `UNDETERMINED`                  |
| `sigma_q50`             | float   | scrubber         | 50th percentile of per-sample σ across the candidate span                                         |
| `n_drifters`            | integer | scrubber         | Samples with σ > 2·q50                                                                            |
| `top_family_largest_band` | string | scrubber         | Family ID (e.g. `F4`) of the dominant family in the largest band                                  |
| `top_family_pct`        | float   | scrubber         | Fraction of the largest band held by `top_family_largest_band`                                    |
| `n_supporting_intervals` | integer | scrubber (v3.80) | Number of L2 intervals that support this candidate (= length of `l2_indices`)                    |
| `aggregate_concordance` | float   | scrubber (v3.80) | Mean Hungarian-aligned K=3 concord between each supporting L2 and the anchor (`ref_l2`)          |
| `band_continuity_pct`   | float   | scrubber (v3.80) | `same_rate + adj_rate` from `bandContinuity` — fraction of (sample × adjacent-L2-pair) where the K=3 PC1-rank label stays the same or moves by one |
| `band_continuity_verdict` | string | scrubber (v3.80) | `NESTED` / `INTERMEDIATE` / `UNSTABLE` / `NO_DATA` (thresholds: `cont ≥ 0.85 + far ≤ 0.05` → NESTED; `cont ≤ 0.50 OR far ≥ 0.20` → UNSTABLE) |
| `regime_counts`         | string  | scrubber (v3.80) | Per-K=3-regime fish counts: `g0:N0;g1:N1;g2:N2`. Excludes ambiguous fish.                        |
| `n_ambiguous_fish`      | integer | scrubber (v3.80) | Number of fish with `confidence < ambiguous_threshold` (default 0.5)                              |
| `subband_nesting_status` | string | scrubber (v3.81) | K=6 → K=3 nesting verdict: `NESTED` (all K=6 groups pure ≥ 0.80) / `MIXED` (some pure, some not) / `CROSS_CUTTING` (none pure) / `NA` (no K=6 pass) |
| `n_k6_groups`           | integer | scrubber (v3.81) | Count of K=6 groups with at least one supporting observation                                      |
| `n_k6_pure`             | integer | scrubber (v3.81) | Count of K=6 groups with purity ≥ `purity_threshold` (default 0.80)                              |
| `qc_status`             | string  | scrubber         | `accepted` / `rejected` / `review` (set by user; default `accepted` for saved candidates)         |
| `notes`                 | string  | scrubber         | Free-text notes (newlines and tabs replaced with spaces)                                          |
| `created_at`            | string  | scrubber         | ISO 8601 timestamp                                                                                |
| `scrubber_version`      | string  | scrubber         | The scrubber that wrote this row (e.g. `v3.20`)                                                   |

**Stability promise:** column names will not change without a schema bump.
New columns may be appended (with a 2.x bump). Existing columns will not
be reordered.

### JSON mirror

```jsonc
{
  "schema_version": 2,
  "chrom": "C_gar_LG28",
  "scrubber_version": "v3.20",
  "exported_at": "2026-04-27T14:30:00Z",
  "n_candidates": 12,
  "candidates": [
    {
      "candidate_id": "cand_lg28_142_a",
      "chrom": "C_gar_LG28",
      "start_bp": 13240000,
      "end_bp": 17110000,
      // ... all TSV columns as object keys
      "locked_labels": [0, 0, 1, 2, 0, ...]   // also retained for round-trip into scrubber
    }
  ]
}
```

The `locked_labels` field is JSON-only (not in TSV). It lets the user
reload the registry into the scrubber and have the bands restored
exactly as decided.

---

## 5. The downstream contract for cluster phases 6+

A cluster script that wants to enrich the candidate registry must:

1. **Read** `<chrom>_candidate_registry.tsv` (or `.json`).
2. **Compute** its layer's payload, keyed by `candidate_id`.
3. **Emit** an enrichment JSON with at minimum:

```jsonc
{
  "schema_version": 2,
  "chrom": "C_gar_LG28",
  "_layers_present": ["breakpoints_refined"],          // just the new layers added
  "_generator": "STEP_PHASE6_breakpoint_refine.R",
  "_generated_at": "2026-04-27T17:30:00Z",
  "breakpoints_refined": {
    "cand_lg28_142_a": {
      "start_bp_refined": 13241827,
      "end_bp_refined":   17109934,
      "start_ci_low": 13241500, "start_ci_high": 13242100,
      "end_ci_low":   17109800, "end_ci_high":   17110300,
      "method": "DELLY_PR_split_consensus",
      "n_supporting_reads": 47
    },
    // ...
  }
}
```

The scrubber then loads this enrichment file (drag-and-drop, alongside
the original precomp JSON) and detects `breakpoints_refined` in
`_layers_present`. The corresponding UI (column on page 3 / panel on
page 2 / its own page) becomes available.

**Layer files do not need to be merged on disk.** The scrubber is happy
to load multiple JSONs and union their `_layers_present` arrays. This
keeps each cluster phase's output as its own audit-able artifact.

---

## 6. Versioning checklist for the maintainer (you, future-you, me)

When making a change:

- [ ] **Adding a column to candidates_registry** → bump to 2.1, append column at end of TSV.
- [ ] **Renaming or removing a column** → bump to 3.0, document which cluster scripts need updating.
- [ ] **Adding a brand-new layer** (e.g. `gene_cargo`) → bump to 2.1, document in §2 table.
- [ ] **Changing the meaning of an existing field** (e.g. start_bp from 1-based to 0-based) → bump to 3.0, document.
- [ ] **Internal scrubber refactor that doesn't change JSON shape** → no bump needed.

Keep this file updated. The scrubber's `console.log` on JSON load
should also report the schema version it detected.

---

## 7. Two-level candidate promotion (v3.80, schema 2.1)

The candidate registry was originally a flat per-candidate row. v3.80
restructured the export around a **two-level promotion model**:

- **Level 1 (interval → candidate)** — supporting L2 intervals are merged
  into one `candidate_registry` row with aggregate evidence (concordance,
  band continuity, regime counts).
- **Level 2 (fish → regime within candidate)** — each fish gets one row
  per candidate it appears in, with a consensus K=3 regime call,
  confidence, and (when K=6 substructure is computed) a sub-band path.

**Why two levels.** The fish does not "belong to interval L2_03." The fish
belongs to a *regime* (g0/g1/g2) inside a *candidate*. Conflating those two
operations was the original sin of the v3.20 schema — `top_family_pct` and
`locked_labels` were doing duty as both per-candidate aggregates and
per-fish summaries. v3.80 separates them:

```
Chromosome
└── Inversion candidate                              (Level 1 row in candidate_registry.tsv)
    ├── supporting L2/L3 intervals                   (rows in interval_support.tsv)
    ├── evidence summary                             (columns on candidate_registry.tsv)
    └── fish regime calls                            (rows in fish_regime_calls.tsv)
        ├── g0 / g1 / g2     ← primary K=3 regime
        └── g0a/g0b/g1a/...  ← K=6 sub-band annotation (v3.81)
```

### Three-table export

When the user clicks *"📋 export candidate registry"*, the scrubber writes
**four files** (was two in v3.20):

| File                                       | Rows                                  | Level | Added in |
|--------------------------------------------|---------------------------------------|-------|----------|
| `<chrom>_candidate_registry.tsv`           | one per candidate                     | 1     | v3.20    |
| `<chrom>_candidate_registry.json`          | round-trippable mirror + `locked_labels` | 1  | v3.20    |
| `<chrom>_fish_regime_calls.tsv`            | one per (fish × candidate)            | 2     | v3.80    |
| `<chrom>_interval_support.tsv`             | one per (interval × candidate)        | 1     | v3.80    |

### `<chrom>_fish_regime_calls.tsv` (v3.80, extended in v3.81)

One row per `(sample × candidate)` pair. Records the consensus regime
call — what cluster phases will read as the fish's karyotype call for
that candidate.

| Column              | Type    | Description                                                                                       |
|---------------------|---------|---------------------------------------------------------------------------------------------------|
| `sample_id`         | string  | Sample identifier (CGA / individual)                                                              |
| `candidate_id`      | string  | Candidate this row belongs to                                                                      |
| `regime`            | string  | `g0` / `g1` / `g(K-1)` for the consensus regime, or `ambiguous` when `confidence < ambiguous_threshold` |
| `major_regime`      | string  | (v3.81) Alias of `regime` for K=3 majority. Empty string for ambiguous. Made explicit so downstream consumers don't need to remember which is the major. |
| `confidence`        | float   | Fraction `n_supporting / n_intervals` for the modal K=3 regime                                    |
| `n_intervals`       | integer | Number of supporting L2 intervals where the fish had a valid call                                 |
| `n_supporting`      | integer | Count of intervals voting for the modal regime                                                    |
| `ambiguous`         | string  | `TRUE` / `FALSE`                                                                                  |
| `subband_path`      | string  | (v3.81) Pipe-separated K=6 sub-bands across supporting intervals: `g0a|g0b|g0a`. Empty when K=6 unavailable. |
| `subband_stability` | float   | (v3.81) Fraction of intervals where the fish's K=6 sub-band's parent matches the K=3 regime. `1.0` = fish stays inside one major regime; `<1` = K=6 path crosses parents. `NA` when no K=6 pass. |
| `votes`             | string  | Pipe-separated per-interval aligned K=3 labels: `g0|g0|g1` for audit                              |

**Consensus rule.** For each fish, collect its Hungarian-aligned K=3
label at every supporting L2. The consensus regime is the modal label;
confidence is `count(mode) / n_valid`. If the max-fraction drops below
`ambiguous_threshold` (default 0.5), the fish is flagged `ambiguous` and
its regime is set to the empty string in `major_regime` and the literal
`"ambiguous"` in `regime`.

**PC1-rank ordering.** Before Hungarian alignment, every L2's labels are
ranked by PC1 centroid so `g0` always means "lowest-PC1 cluster" and
`g(K-1)` always means "highest-PC1 cluster". This makes regime labels
biologically stable across L2s and across candidates.

### `<chrom>_interval_support.tsv` (v3.80)

One row per `(interval × candidate)` pair. Records which L2 intervals
back each candidate and what role each plays.

| Column            | Type    | Description                                                                          |
|-------------------|---------|--------------------------------------------------------------------------------------|
| `candidate_id`    | string  | Candidate this row belongs to                                                         |
| `l2_idx`          | integer | L2 envelope index in the source `precomp.json`                                       |
| `l2_label`        | string  | L2 envelope's `candidate_id` from precomp (e.g. `L2_0001/03`)                        |
| `role`            | string  | `core` (the anchor L2, used as Hungarian-alignment basis) / `support` (others)        |
| `start_bp`        | integer | L2 envelope `start_bp`                                                               |
| `end_bp`          | integer | L2 envelope `end_bp`                                                                  |
| `n_windows`       | integer | `_e0 - _s0 + 1`                                                                      |
| `concord_to_ref`  | float   | Hungarian-aligned K=3 concord vs the anchor `ref_l2`. `1.0` for the core L2 itself.  |

The `concord_to_ref` column is a per-supporting-L2 read of the same
quantity that's *averaged* into `aggregate_concordance` on the candidate
registry — useful for deciding which L2s are tightly aligned vs loosely
when reviewing why a candidate's aggregate is below 1.

---

## 8. K=6 nested substructure semantics (v3.81, schema 2.1)

K=3 is the **primary regime** call (the karyotype). K=6 is **substructure**
inside K=3. K=6 only gets promoted to a separate inversion call when it
fails to nest cleanly inside K=3.

### The nesting decision rule

For each L2 interval, cluster at K=6 in addition to K=3, then map K=6
groups to their K=3 parents by max-overlap:

```
K=6 group | parent K=3 regime
k0        | g0  (most samples in k0 are g0 in K=3)
k1        | g0
k2        | g1
k3        | g1
k4        | g2
k5        | g2
```

Each K=6 group's **purity** is `max_overlap / total_in_group`. A K=6
group with purity ≥ `purity_threshold` (default 0.80) is *cleanly nested*
in its K=3 parent. The candidate's `subband_nesting_status` is then:

| Verdict          | Definition                                          | Interpretation                              |
|------------------|-----------------------------------------------------|---------------------------------------------|
| `NESTED`         | All K=6 groups with data have purity ≥ threshold    | One inversion with substructure. Keep K=6 as `g0a/g0b/...` annotation. Do NOT promote K=6 groups to separate inversions. |
| `MIXED`          | Some K=6 groups pure, others not                    | Partial nesting. Review per-K6-group purity before deciding.                                |
| `CROSS_CUTTING`  | No K=6 groups pure                                  | Possible second system / independent inversion overlapping this candidate.                  |
| `NA` / `NO_DATA` | K=6 cluster pass unavailable                        | Older candidate written before v3.81 OR cluster failed at K=6                              |

### Sub-band labels: `g{parent}{letter}`

Within each K=3 parent, K=6 groups are ranked by PC1 centroid and
assigned ordinal letters (`a`, `b`, ...). So a fish's per-L2 sub-band
path looks like `g0a → g0b → g0a` (stayed within g0) or
`g0a → g1a → g0b` (crossed parents — `subband_stability < 1`).

### Why K=3 is the primary call

The biology is the K=3 regime: a fish is a homozygous or heterozygous
karyotype call. K=6 captures finer haplotype variation within those
regimes — useful for diagnostic atlas work and the manuscript's "nested
arrangements" framing, but not the karyotype call itself.

The published wording for this:

> *Major K=3 regimes were used as candidate-level arrangement classes.
> Higher-K clusters were retained as within-regime sub-bands and were not
> interpreted as independent inversions unless they cut across the K=3
> structure or showed independent PC-axis support.*

That sentence's preconditions (the cut-across detection) are exactly what
`subband_nesting_status` exposes.

### The `k6_substructure` field on the JSON-mirror

The round-trippable `<chrom>_candidate_registry.json` retains a per-
candidate `k6_substructure` object (in addition to the TSV's flat
columns) so the scrubber can rehydrate a saved candidate's substructure
without re-running clustering:

```jsonc
"k6_substructure": {
  "K6": 6,
  "parent_of_k6": [0, 0, 1, 1, 2, 2],   // K=3 parent for each K=6 group
  "purity": [1.0, 0.95, 1.0, 0.88, 1.0, 0.97],
  "n_pure": 6, "n_with_data": 6,
  "verdict": "NESTED",
  "purity_threshold": 0.80,
  "subband_letter": ["a", "b", "a", "b", "a", "b"]   // ordinal letter per K=6 group
}
```

### Computation cost

Computed once at candidate-commit time (`commitL3Draft` in scrubber).
Two passes per candidate (K=3 + K=6) over the Hungarian-aligned per-L2
labels. Total cost is O(n_intervals × n_samples × K!) — small for the
typical few-L2 candidate. Subsequent loads of saved candidates rehydrate
the stored `k6_substructure` without recomputing.

### When to flag CROSS_CUTTING for biological review

The verdict alone isn't biology. Use `subband_nesting_status =
CROSS_CUTTING` as a **filter** for which candidates need extra scrutiny,
not as evidence by itself. A cross-cutting K=6 in a region where the
breakpoint geometry, σ profile, and concordance tables all support a
single inversion may simply mean K=6 over-clusters at that K — review
the K-mode 'both' L3 panel and the per-fish `subband_path` patterns
before splitting into two candidates.

---

## 9. Versioning history

| Schema | Date       | Scrubber | Changes                                                        |
|--------|------------|----------|----------------------------------------------------------------|
| 1      | (legacy)   | <v3.20   | No version field; layers inferred from key presence             |
| 2      | 2026-04-27 | v3.20    | `_layers_present` declared; candidate registry contract         |
| 2.1    | 2026-04-28 | v3.80–v3.87 | Two-level promotion: candidate (L1) + fish regime (L2). Added 9 columns to candidate_registry; added 2 sibling TSV files (fish_regime_calls.tsv + interval_support.tsv). Added K=6 nested substructure (v3.81) with NESTED/MIXED/CROSS_CUTTING verdict and `g0a/g0b/...` sub-band annotation. |
| 2.2    | 2026-04-28 | (planned)   | Marker / PCR assay module (phase 13). Added three layers (`marker_catalogue`, `marker_primers`, `marker_panel_summary`) and three sibling TSVs for hatchery-deployable diagnostic panels per inversion candidate. |
| 2.3    | 2026-04-28 | v3.92       | Band diagnostics module (§11). Per-band confounder/support metrics computed on focal L2 and stored on candidate at commit time. Added three planned source layers (`theta_pi_panel`, `roh_intervals`, `sample_froh`) and a sibling TSV (`<chrom>_band_diagnostics.tsv`). Scrubber-side compute + render + export are live; R emit scripts for the three new layers are planned. Existing GHSL panel and dosage het reads are wired today. |
| 2.4    | 2026-04-28 | v3.93       | Het-shape sub-module (§11.1). `computeBandDiagnostics` returns a new `het_shape` field with 16-bin histograms per band + support-ratio (K=3 → middle / mean(flanks); else max / min spread). Three in-scrubber placements share one renderer: inline SVG ridgeline column in the L3 contingency tile diagnostics table, FIG_C07-style stacked ridgeline figure on the candidate page, click-popover from the het mini-chip pill. TSV got 4 new columns (`het_support_ratio`, `het_support_kind`, `het_support_passes`, `het_hist_bins`). No new source-layer requirement — uses existing GHSL panel. |
| 2.5    | 2026-04-28 | (planned)   | Live dosage heatmap rendering contract added to §10 (Marker module). Forward spec — no scrubber implementation yet. Defines: visible-region = current 5–10 local PCA windows; default 200 markers, hard cap 500; selection cascade (missingness filter → diagnostic_score → dosage variance fallback); per-region dosage chunk JSON shape (`<chrom>_dosage_chunk_<start>_<end>.json`); LRU chunk cache; explicit redraw triggers (K, row order, visible window, cap, chunk-load); 150 ms debounce on scrub. No implementation, no test impact. |
| 2.6    | 2026-04-28 | (planned)   | Substantial expansion of the dosage heatmap contract (still planned) using `STEP28_candidate_marker_heatmap.R` as the visual reference. Five left-side annotation tracks (K=3 PCA group, K=6 sub-band, Quality, GHSL, het) and one top-side track (Polarity). Sample order = `coarse_group_refined, u`. Dosage ramp `#2166AC / #F7F7F7 / #B2182B`. Two view modes share one renderer: candidate-bound (static) and cursor-bound (live, ±5 windows). Marker cap independent of region source. Stripe-quality button when coherence layer absent (faithful port of STEP29 algorithm). Two new planned source layers: `candidate_sample_coherence`, `candidate_marker_polarity` (both have R-side reference in `STEP29_candidate_coherence_and_polarity.R`). Placement (popup vs docked vs floating) deliberately undecided — to be chosen during v3.94 implementation. |
| 2.7    | 2026-04-28 | v3.96       | Hover-tooltip contract added to §10 ("Hover affordances"). One-line format `sample · marker (bp) · dosage=N · group · quality · flipped` with absent-field omission (no `null` placeholders). NA dosage shown as `dosage=NA`; the `-1` sentinel is never user-facing. Schema-mandated as overlay updates only — never a redraw. Cell-stable suppression and RAF coalescing for performance. Two hover contexts (`hover_static`, `hover_cursor`) on `state.__dosageHm`, both reset on every redraw. Annotation tracks (left + top) do not currently tooltip — only the dosage matrix. R-side unchanged. |
| 2.8    | 2026-04-28 | (planned)   | Boundary zone refinement module (§12). New optional `boundary_evidence` layer (cluster-side R emit, planned, with FST/theta-pi/discordant-pair/SV-anchor tracks). Per-candidate `boundary_left`/`boundary_right` records carrying zone bp range, weighted score 0..1, contributing tracks list, support_class (strong/moderate/weak/ambiguous), source (auto/manual/auto_plus_manual), and SV anchors in zone. Candidate-level `breakpoint_status` enum: boundary_zone_only / SV_supported / junction_supported. Auto-propose algorithm: per-track step magnitude in MAD units → weighted combined score → strongest edges in left/right halves → ±5 window zones. Manual override via E/F keys at cursor; B saves; R resets. New "boundaries" page (page 11 internally, displayed as tab "3 boundaries") wedged between candidate-focus and catalogue. 14 new TSV columns (`left_boundary_zone_start` ... `boundary_notes`); registry width 31 → 45. **Terminology contract enforced**: "boundary zone" is default; "exact breakpoint" reserved for junction-level evidence only. |
| 2.9    | 2026-04-28 | v3.98 (+ R-side STEP_M06 post-v3.98) | Status-reconciliation bump — no new contract surface. Three flags flipped from "planned" to "shipped": (1) v3.94 dosage heatmap layer (`dosage_chunks`, `candidate_sample_coherence`, `candidate_marker_polarity`) has its R-side emit (`STEP_M04_emit_dosage_chunks.R` + `STEP_M05_emit_step29_layers.R`, shipped v3.95); (2) v3.97 boundary refinement layer (`boundary_evidence`) has its R-side emit (`STEP_M06_emit_boundary_evidence.R`, shipped post-v3.98) with FST + per-regime θπ (homo1/het/homo2) + discordant_pair_pileup + sv_anchors; track-by-track availability — each track independently optional based on inputs supplied; (3) v3.98 NULL_CONCORD K=6 → 0.24 (was incorrectly 0.30 fallback) documented in band-diagnostics module. v3.80 UI text rewrite (intervals → promoted → candidates; fish → assigned → regimes) shipped in v3.98 with new help-page Vocabulary section. **Still planned in v3.x**: `STEP_T06_emit_theta_pi_panel.R`, `STEP_R12_emit_roh_intervals.R`, `STEP_R13_emit_sample_froh.R` (band-diagnostics §11 source layers); marker module phase-13 R pipeline (§10). |
| 2.10   | 2026-04-28 | (planned)   | Within-regime subclustering contract added to §10 (dosage heatmap module). DBSCAN/HDBSCAN must NOT run on raw `(u, v)` across all samples — the major-regime axis dominates and within-regime structure gets washed out. Per-regime contract: split by `coarse_group` (HOMO_1 / HET / HOMO_2) → SVD-rotate within-regime `(u, v)` to `(u_rot, v_rot)` → z-score standardize → DBSCAN/HDBSCAN. Subcluster labels are within-regime, dense, 1-based: `HOMO_1_sub1`, `HOMO_1_sub_noise`, `HET_sub2`, etc. **Subclusters are diagnostic within-regime haplotype backgrounds, NOT paper-level inversion states** — manuscript reports `HOMO_1 / HET / HOMO_2` only. New `cluster_mode` parameter with four values: `none` (**default** — subclustering not run, preserves current scrubber behaviour), `rotated_within_regime` (opt-in production mode — the 5-step contract), `raw_uv` (diagnostic alternative — DBSCAN on raw `(u, v)`; almost always recovers the major-regime split), `one_dimensional_rotated_axis` (diagnostic alternative — per-regime split + 1D `u_rot` only, fallback for low-coverage where `v_rot` is noise-dominated). Default may flip to `rotated_within_regime` in a future schema bump after calibration on the 226-sample LG28 cohort. Labels ride on `candidate_sample_coherence` layer's existing `coarse_group_refined` column; new optional `u_rot`/`v_rot`/`cluster_mode` columns. Heatmap K=3 PCA group track gains an inner sub-stripe under the two rotated modes. Recompute trigger: candidate commit time; changing `cluster_mode` invalidates stored labels. |
| 2.11   | 2026-04-28 | (planned)   | **Schema-only — vocab lock for IGV-derived BAM evidence tracks.** New optional `bam_evidence` layer planned for §12 boundaries module. Bins per-cohort BAM signals at 1 kb resolution: `coverage` + `coverage_dip` (z-score normalized); per-orientation pair counts (`discordant_orient_FF`, `discordant_orient_RR`, `discordant_orient_RF` — FF/RR clusters are inversion-specific, RF informational); `tlen_anomaly` (count of pairs with \|TLEN−mean\| > 3·sd); `split_read_density` (reads with SA tag); `clip_density` (reads with soft/hard clip ≥20 bp); `mapq_drop` (fraction reads with MAPQ<20 — the **only down-weighter**, penalizes repetitive regions); `pair_orient_inv_rate` (composite (FF+RR)/(FF+RR+RF+FR) — single most useful inversion-specific track). Per-cohort normalization fields: `expected_coverage`, `expected_tlen_mean`, `expected_tlen_sd`. **Provisional weights** for boundary scoring: `pair_orient_inv_rate` 0.10, `split_read_density` 0.08, `coverage_dip` 0.06, `discordant_orient_FF/RR` 0.04 each, `clip_density` 0.04, `tlen_anomaly` 0.03, `mapq_drop` 0.03, `discordant_orient_RF` 0.01 (renormalized with existing 12 tracks at load). **NOT YET LOCKED** — final weights pending real-data calibration on 226-sample LG28 cohort. R-side emit `STEP_M07_emit_bam_evidence.R` planned (uses `mosdepth` + `samtools view` flag filters); R-side helper `STEP_M08_extract_region_bams.sh` planned for per-candidate ±50 kb BAM slices feeding an embedded **igv.js** viewer panel on the boundaries page (igv.js loaded via CDN or vendored inline; 3 deployment options for BAM access — local-file, local-server, pre-extracted slices — recommended default = pre-extracted slices). The igv.js panel is schema-adjacent (not part of JSON contract) but documented in §12 for completeness. **Motivation**: reviewer-style inspection of inversion calls expects coverage drop + colored discordant-pair clusters, both derivable from existing 9× Illumina BAMs but not currently computed. |
| 2.12   | 2026-04-28 | (planned)   | **Schema-only — three-axis evidence framework for inversion candidates** (new §13). Pulled forward from cluster-side registry work: a single tier number is a category error; three independent axes matter — Axis 1 **Confidence tier** (discovery, pathway-based: Tier 1/2/3/4/SV-only from independence layers A=local PCA, B=SV callers, C=GHSL haplotype divergence, D=Fisher genotype-breakpoint association); Axis 2 **Completion** (administrative, ~320–370 registry keys per candidate, % filled, per-question breakdown for Q1–Q7 + Q_QC_SHELF); Axis 3 **Characterization** (biological, 7-question convergence engine with five statuses ANSWERED / PARTIAL / MEASURED / CONTRADICTED / EMPTY). The seven questions: Q1 What is it · Q2 What's happening inside · Q3 What are the boundaries doing · Q4 How did it form · Q5 How old · Q6 How common · Q7 Is it real. Convergence rules live in `CHARACTERIZATION_CONVERGENCE_RULES.md` (planned sibling spec). New JSON blocks on `candidates_registry`: `completion` (10 fields incl. per-Q% breakdown + `registry_version` provenance), `characterization` (per-Q status+label+evidence counts + summary string + engine_version). Counter-evidence (`evidence_against`) is a first-class concept — CONTRADICTED is the most valuable status because it surfaces internal inconsistency. TSV mirror gains 19 columns (11 completion flat + 1 characterization JSON blob + 7 char_Qn_status flat); registry width 45 → 64. Locked status icons + tier color palette for scrubber UI. Critical boundary contract: cluster pipeline COMPUTES the three axes (R-side STEP_R20–R23 planned in parallel chat); scrubber DISPLAYS them. Mid-flight candidates with `completion=20%, no tier, 0/7 ANSWERED` are valid intermediate states, not errors. Final values + thresholds NOT YET LOCKED — pending per-cohort calibration on 226-sample LG28; this version reserves only the contract surface. |
| 2.13   | 2026-04-28 | (planned, v4.0 doctrine, t14e) | **Schema-only — multi-evidence regime framework** (new §14). Doctrine: K-means bands are PROVISIONAL GEOMETRIC clusters, not biological regimes. Final regime calls require multi-evidence convergence across six independent layers: K-means (geometric proposal), dosage (per-band marker dose), GHSL (per-band haplotype divergence), heterozygosity (per-band het level), ROH/F\_ROH (IBD confounder check), family/relatedness (kinship confounder check). Each layer produces a per-(L2, K-band) verdict in {validates, neutral, rejects}; convergence rule emits status STRONG / SUSPECT / REJECTED. Six new optional JSON layers (`per_band_dosage`, `per_band_ghsl`, `per_band_het`, `per_band_froh`, `per_band_family`, `per_band_convergence`). Six new R-side emit scripts planned: `STEP_R30_emit_per_band_dosage.R` … `STEP_R35_compute_convergence_call.R`. Registry adds ~6 keys × n\_bands × n\_candidates under `characterization.q1` (regime\_call\_method, per-band convergence status + validating/rejecting/neutral layer arrays + dominant\_confounder + confounder\_share). Registry width 64 → ~70. Catalogue gains `regime_evidence` summary column. Scrubber gains a planned mode-switcher (K-means / Dosage / GHSL / Het / ROH / Family) above L3 panes for v4.0; in v3.99 t14e only the doctrine is shipped (K=3/K=6/K=3+6 button tooltips warn that K-means is geometric, K=6 button shows ⚠ icon, help-page roadmap documents the framework). Extends §8 (K=6 nested substructure) by formalizing what was already implicit: K-means at any K is one layer, not the answer. Critical implication for hatchery cohorts: ROH and family LD can produce visually-clean K-means bands that are NOT inversions — checking confounders before regime calls protects against a known peer-review failure mode. v4.0 gating: real-data calibration of layer thresholds + R-side emits + UI mode switcher + sibling spec `CHARACTERIZATION_CONVERGENCE_RULES.md` extension covering per-layer thresholds + catalogue column + end-to-end test on ≥5 calibration candidates. |
| 2.14   | 2026-04-28 | (planned, v4.0+, t14e refinements) | **Schema-only — three refinements layered on 2.13.** (1) **§14.2.5 layer scope** — captures Quentin's t14e clarification that not all evidence layers inform all bands equally. Heterozygosity is mostly informative for the HET band (homozygous bands are ~0% het by definition); GHSL informs ALL bands (every band has a haplotype signature); θπ informs HET + cross-band asymmetry checks; ROH is a confounder check primarily for HOMO bands. New per-band-per-layer `scope` field ∈ {primary, supportive, low\_info}. The convergence rule (§14.3) is now scope-aware: a layer marked `low_info` for a band does not push toward STRONG nor toward SUSPECT. New status `STATUS_INSUFFICIENT_EVIDENCE` for bands with too few in-scope layers. (2) **§15 per-sample line coloring modes** — the per-sample lines panel + L3 contingency panes + tracked-samples scatter all share a UI-wide coloring mode. Eight modes: kmeans (default), dosage, ghsl, het, theta\_pi, froh, family, confounder\_alert. Per-window vs per-sample dispatch handled inside `_resolveSampleColorByMode`. New persisted state key `state.linesColorMode`. New R-side script `STEP_R36_emit_per_sample_theta_pi.R` planned. Modes serve as visual layer-by-layer evidence display for §14. The mode picker UI is a horizontal button row above the lines panel; greyed-out buttons for modes whose source layer isn't loaded. (3) **§16 toolkit containerization roadmap** — high-level pin for the post-v4.0 goal of making the entire inversion-discovery pipeline portable enough that another lab can run it on catfish / fish / animals / plants. Schema-neutral (no JSON contract impact). Sketches the order: MODULE\_2/3 first → R emits → MODULE\_4 SV → MODULE\_5A2 → catalogue. Apptainer for HPC, Docker for single-machine. NOT a contract — a directional pin. **All three refinements are planned-only; nothing in v3.99 t14e or earlier turns is invalidated. Nothing here gates the scrubber's existing behavior.** |
| 2.15   | 2026-04-28 | (planned, post-v4.0, t14e+ continue) | **Schema-only — Atlas mode switching + ANGSD bi-SNP provenance** (new §17, §8.x optional layer). (1) **§17 Atlas modes** — Quentin's t14e+ continue request: a single button toggles the scrubber between *Inversion Atlas* (current default — every page focuses on chromosomal inversion candidates) and *Diversity Atlas* (planned — every page focuses on genome-wide diversity, ROH, F\_ROH, ancestry-Q stratification, kinship). Same JSON, different interpretation layer. JSON stays loaded in memory (not freed); only the rendering layer flips. Per-page mapping table documents what each tab means in each atlas. New UI-only `state.atlas` slot ∈ {`inversion`, `diversity`}, persisted to localStorage. NO new required JSON fields — both atlases read existing layers (windows, tracks, l1/l2 envelopes, candidates, ancestry, relatedness, theta\_pi\_panel, sample\_froh, roh\_intervals). What changes is *emphasis*. Catalogue forks per atlas: inversion catalogue (today) vs region catalogue (regions of interest by diversity-stratification engine). Manuscript bundles fork per atlas. Phasing A/B/C/D: schema-only now (Phase A); toggle button + state slot (Phase B); per-page Diversity-mode renderers (Phase C, multiple chats); catalogue + bundle forking (Phase D). Estimated 3-5 weeks of post-v4.0 work to ship the full Diversity Atlas. (2) **ANGSD bi-SNP provenance** — Windows page (page 8) gains an inline info chip ⓘ ANGSD bi-SNPs that surfaces the ANGSD parameters used to call the bi-SNP count shown in the table's `n bi-SNPs` column. For the *C. gariepinus* 226-sample cohort, the parameters are hard-coded in the scrubber UI (recovered from MODULE_2A history): `-GL 1`, `-minQ 25`, `-minMapQ 25`, `-baq 1`, `-C 50`, `-setMinDepthInd 3`, `-setMaxDepthInd 57`, `-minInd 200`, `-SNP_pval 1e-6`, `-minMaf 0.05`, `-pest <folded SFS prior>`. For other cohorts, the precomp export script (planned, schema 2.15 §8.x) will write these parameters as a top-level `angsd_bisnp_params` object so the scrubber reads them generically rather than hard-coding per project. (3) **Windows page column-driven coloring** (shipped, t14e+ continue) — page 8 strip above the table now re-colors its bars by the active sort column (one click sets both sort + color). New `_winSumColorMode` state slot. Modes: z, n_snps, span_kb, snp_density, lam1, lam2, ratio, mb, idx. String columns (l1/l2) fall back to z coloring. Strip label updates dynamically. **All three additions are schema-additive; legacy JSONs continue to work.** |
| 2.16   | 2026-04-28 | (planned, post-v4.0, t14e+ continue) | **Two additions: Thai i18n architecture + 14-axis classification contract** (new §18, §19). (1) **§18 Thai i18n** — UI translation architecture for Thai-reading lab members. Quentin's request was tagged "later" + "lab can read English" + "Thai font is a challenge but if it's easy." Schema-only documents the architecture: `state.lang` ∈ {`en`, `th`}, `data-i18n` attribute pattern, `t(key)` lookup helper, font fallback chain (`Noto Sans Thai`, `IBM Plex Sans Thai`), Thai-specific CSS (line-height 1.6, word-break keep-all). Six tier rollout (T1 nav → T6 status messages); recommended MVP ships T1+T2 (~60 strings) plus the font CSS. Code identifiers, JSON field names, scientific terminology stay in English. NO new JSON fields. (2) **§19 14-axis classification** — formal contract for the Tier sub-view on page 4 (Karyotype / Tier page). Recovered from past chat history of `characterize_candidate.R` + `classify_inversions.R` (planned cluster-side R-pipeline). The 14 axes: existence layers A-D, boundary_quality, group_validation, internal_structure, recombinant_class, family_linkage, polymorphism_class, mechanism_class, age_class, burden_class, confidence_tier. New optional JSON layer `final_classification` (top-level, keyed by candidate_id). Sibling TSV `final_catalog.tsv`. Read-only — the scrubber NEVER writes to this layer. Coexists with §13 three-axis framework: §19 confidence_tier === §13 Axis 1; §13 is the WORKFLOW (Q1-Q7 questions) and §19 is the catalog OUTPUT. **Scrubber-side UI scaffold IS shipped** (page 4 renamed "Karyotype / Tier", sub-view toggle, `renderCandidateTier`, 14-axis empty-state rendering, layer detection). **R-side emit IS NOT shipped** — Tier view renders empty state with axis schema until `final_classification` layer arrives. Both additions are schema-additive; legacy JSONs continue to work. |
| 2.17   | 2026-04-28 | v3.99 t14e+ continue (partial scaffold shipped) | **Registry interop — loading cluster registry artifacts directly** (new §20). Quentin's question: "our registry its JSON ?? No?? So I wonder if by any luck. We can just load it." Honest partial answer documented: the cluster-side registry has four tables (sample_registry, interval_registry, evidence_registry, results_registry per chat-16 design); three are TSV-mirrors of JSON schemas, one is per-candidate JSON blocks. The scrubber CAN load: `sample_groups.tsv`, `candidate_intervals.tsv`, `manifest.tsv`, and `evidence_registry/per_candidate/<cid>/structured/*.json` files. The scrubber CANNOT (and doesn't need to) load: per-window local PCA data (`windows[]` with z, lam1, lam2, ...), `sim_mat`, `dosage_chunks` — these live in the precomp JSON outside the registry. Registry-load is **additive enrichment** on top of a precomp JSON, not a replacement for it. New 📦 load registry button on page 4 candidate-list pane opens a multi-file picker; `loadRegistryArtifacts(fileList)` parses, identifies type by filename + content shape, light-validates against the 4 registry schemas, and merges into `state.data` as four new optional top-level layers: `sample_groups`, `candidate_intervals`, `results_manifest`, `evidence_blocks` (keyed by candidate_id, then by block_type). Special handling for `final_classification` / `classification` block types: the 14-axis values are auto-extracted into `state.data.final_classification[<cid>]` so the Tier sub-view (page 4 §19) populates immediately. Light validation only — required columns/fields checked; full JSON Schema validation is a cluster-side concern. Browser-side gunzip not yet wired (`.tsv.gz`/`.json.gz` need pre-extraction). All four new layers additive — legacy precomp JSONs continue to work unchanged. SCHEMA §20 documents the full mapping table including out-of-scope artifacts (per-candidate Q matrices, FST tracks) reserved for chat-17+ backlog. |
| 2.18   | 2026-04-28 | v3.99 t14e+ continue (partial scaffold shipped) | **18 structured block types — formal contracts** (new §21). Per Quentin's t14e+ continue paste of the cluster-side spec: the per-candidate evidence_registry emits 18 distinct JSON block types (one per major analysis), each with a common header (block_type, candidate_id, region, source_script, source_version, computed_at, groups_used, keys_produced, raw_files) plus block-specific fields. The 18 blocks: `existence_layer_a/b/c/d`, `boundary_left`, `boundary_right`, `carrier_reconciliation`, `internal_dynamics`, `mechanism`, `age_evidence`, `frequency`, `hypothesis_verdict`, `morphology`, `band_composition`, `burden`, `block_detect`, `triangle_insulation`, `peel_diagnostic`, `synteny_dollo`. Each block maps to one or more of the 7 questions (Q1-Q7) and has explicit group-requirements (NONE / UNCERTAIN / SUPPORTED / VALIDATED). 12 of the 18 blocks (and the optional `final_classification` synthesis block) map directly to one or more of the §19 14-axis values; 6 are supportive-only (no axis derivation). **§21.6 axis derivation table** documents per-block rules: `existence_layer_*` → pass/fail from `detected` field; `boundary_left` + `boundary_right` reconcile to `boundary_quality` (both sides verdict~structural AND hardness≥0.7 → 'sharp'); `carrier_reconciliation` → `group_validation` from `obj.group_validation.level`; `internal_dynamics` → `internal_structure` + `recombinant_class` from recombinant counts; `mechanism` → `mechanism_class` from `obj.classification.mechanism`; `age_evidence` → `age_class` from `obj.conclusion.age_class` ('old' normalized to 'ancient'); `frequency` → `family_linkage` + `polymorphism_class` (CV-of-Q-frequencies thresholds); `hypothesis_verdict` → `confidence_tier` (T1=4 layers + confirmed; T2=3; T3=2; T4≥1; SV_only / Layer_C_only edge cases); `burden` → `burden_class`. **Scrubber-side scaffold IS shipped**: `_KNOWN_BLOCK_TYPES` constant (21 entries), `_deriveAxesFromBlock(bt, obj)` helper applying §21.6 rules, `_reconcileBoundaryQuality(cid)` end-of-load helper for left+right pairing, registry loader extended to recognize all 18 types and compose partial axes into `state.data.final_classification[cid]`, summary alert breakdown by block type. **Multiple blocks compose**: drop any subset of question blocks → Tier view populates whatever axes can be derived; drop final synthesis block → all 14 axes overwrite (synthesis authoritative). NOT YET WIRED (chat-17+ backlog): per-block renderer panels on candidate focus page, block-presence indicator chips, stale-group warnings (groups_used.version vs sample_groups.tsv created timestamp), per-block JSON inspector, manuscript bundle integration that uses block content for prose generation. NO new required JSON fields — all blocks optional, all additive. |
| 2.19   | 2026-04-28 | v3.99 t14e+ continue (chips shipped; θπ scrubber scaffold shipped) | **Two additions: block-presence chips + JSON inspector on candidate focus page (extends §21); θπ scrubber as new page mirroring page 1 (rewritten §22).** (1) **Block chips shipped** — Page 2 candidate focus page now shows a horizontal row of 20 chips at top (18 numbered question blocks + `boundary_right` sibling + `final_classification` synthesis), one per known structured block. Each chip is lit when its block is loaded for the active candidate, dim when missing. Color encoding: green for axis-contributing blocks (per §21.6), blue for supportive-only blocks (`morphology`, `band_composition`, `block_detect`, `triangle_insulation`, `peel_diagnostic`, `synteny_dollo`), gold for the synthesis `final_classification` block. Click a lit chip → toggles inline JSON inspector below the chip row showing block raw content with header fields (`source_script`, `source_version`, `computed_at`, `groups_used.validation_level`) surfaced separately, then scrollable `<pre>` with full JSON. Multiple inspectors can be open simultaneously. Truncates at 200 KB stringified with `[truncated]` badge. New `candidateBlockChipsHtml(c)`, `_wireCandidateBlockChips()`, `_toggleBlockInspector(cid, blockType, chip)` functions; new `_BLOCK_DISPLAY_ORDER` constant (20 entries with `bt`/`label`/`group`); new `_BLOCKS_WITH_AXIS_DERIVATION` Set. Block ordering follows §21.3 logical groups with 8px margin between groups and 2px within. Registry-load finalizer (§20) re-renders candidate-focus page so chips light up immediately after files dropped. Wire is idempotent (`dataset.wired` guard); dim chips marked wired but inert. Mount: `#candBlockInspectors` div for inspector nodes. State source of truth: `state.data.evidence_blocks[cid][block_type]`. (2) **§22 θπ scrubber — chromosome-wide diversity scanner mirroring page 1.** Originally drafted as a per-candidate concordance sub-view; **rewritten** after Quentin's feedback: "Honestly it needs to be on its own page... Mirroring page (1)... page (1) copy but instead of local PCA of dosage its local PCA of theta pi." The page runs the SAME pipeline as page 1 (per-window analysis → window×window similarity → MDS → cluster → candidate intervals) but on θπ data instead of dosage. This is genuinely Quentin's discovery — there's no standard pipeline for diversity-based local-PCA candidate scanning. New DOM page `#page12` at user-visible tab position 2 ("θπ diagnostic"); existing pages 2-11 shift one slot right in user-visible numbering (DOM ids unchanged so no code references break). Three new optional top-level JSON layers, structurally mirroring page 1: `theta_pi_per_window` (samples × windows × θπ values, R-side STEP_R39 planned), `theta_pi_local_pca` (z, lam1, lam2, ratio, pc1, pc2, sim_mat, mds_coords — same shapes as page 1's top-level dosage arrays, R-side STEP_R40 planned), `theta_pi_envelopes` (l1, l2, candidate_intervals — same structure as page 1's envelopes, R-side STEP_R41 planned). What's shipped now (v3.99 t14e+ continue): structural scaffold only — DOM page with class `page`, tab-bar button at user-visible position 2, empty-state placeholder explaining purpose + required layers + future panel-mirror architecture, layer detection extended for the three new layers, help-page roadmap entry under PLANNED · post-v4.0. Panel renderers, the cross-method candidate-list merge in the catalogue (dosage-only / theta_pi_only / both / both_overlap_partial), the per-candidate concordance sub-view (the original figure mockups A-F now demoted to secondary surface §22.7), and the three R-side scripts are all post-v4.0 backlog. The orthogonal-validation payoff (drop both candidate lists side-by-side, dosage∩θπ candidates are ~certain real biology) lives in the catalogue extension once both scrubbers have real candidate lists to compare. NO new required JSON fields; all three new layers optional and additive. |
| 2.19+  | 2026-04-28 | v3.99 t14e+ continue (tab renames + data-source clarification + composition panel doc) | **Three additions to §22 — tab renames, data-source clarification, internal_ancestry_composition planned panel.** Per Quentin's feedback after the page-12 scaffold landed: (1) **Tab renames for symmetry** — "diagnostic" (page 1) → "**local PCA \|z\|**"; "θπ diagnostic" (page 12) → "**local PCA thetapi**". The two tabs now read symmetrically as the two scrubbers — same pipeline, two different signals. Quentin's framing: "Idk if it will work but if we don't try we will never know we invent new methods on way its side quests. Lol" — the symmetric naming reflects that. (2) **Data source pipeline clarified (new §22.13)** — Quentin pasted three existing scripts and asked which produces what θπ data: `STEP_Q05_aggregate_theta.sh` (in `phase_5_qc_triage/`) ALREADY produces per-sample per-window θπ at the right resolution (`win50000.step10000`), and `export_precomp_to_json.R --theta` ALREADY embeds it as `w.theta` per-window inside production JSONs. So `theta_pi_per_window` (one of the three §22.4 layers) is **not new** — only its top-level repackaging would be. The scrubber's reader now accepts BOTH shapes transparently: Shape A = per-window-embedded `w.theta` (existing pattern), Shape B = top-level `theta_pi_per_window` layer (planned packaging). New auto-detection logic in `detectSchemaAndLayers` flags Shape A present even without an explicit `_layers_present` declaration — so legacy JSONs with `--theta` already trigger 🟢 on the page-12 empty-state's first-layer indicator. `STEP_Q07_popstats.sh` + `region_popstats.c` (Engine F) produce a DIFFERENT layer (per-window per-GROUP pooled stats, not per-sample) — useful for the deferred §22.7 per-candidate concordance figure (the figure-mockup view), NOT the page-12 chromosome-wide scrubber. The remaining two §22 layers (`theta_pi_local_pca`, `theta_pi_envelopes`) genuinely don't exist yet and need new R-side scripts (STEP_R40/R41). Net effect: 1 of 3 layers exists in production, 2 of 3 still need to be written. (3) **§22.14 — internal_ancestry_composition.py as planned panel.** Quentin asked: "Maybe it can be for page 1 and page 2 like activate nested composition detection ?? When in L2 or L3 or ?" — yes. Per-sample composition classifier (existing Python: `internal_ancestry_composition.py`, formerly `nested_composition.py`) classifies each sample's internal Q-window pattern within a parent interval as one of 6 classes (homogeneous / dominant_plus_secondary / two_block_composite / continuous_gradient / multi_block_fragmented / diffuse_mixed). Two render paths planned: (a) page 1 + page 12 zoom-trigger panel that activates when `state.viewMode === 'l2'` or `'l3'`; (b) page 3 candidate-focus persistent panel. Same algorithm, two render placements. Reads the same `data.ancestry_sample` matrix already loaded by `export_precomp_to_json.R --ancestry_samples`. Algorithm is ~100 lines of pure-function port from Python. Naming care: the script's own docstring carefully separates "internal ancestry composition" (data structure: Q windows nested inside parent intervals) from "nested inversion" (the stronger biological claim) — the panel respects this distinction. When §21 `internal_dynamics` block is loaded via §20 registry interop, the panel will prefer the precomputed result over re-running the classifier in JS. NOT shipped this turn — schema-only documentation in §22.14. NO new required fields; all additive. Tests: 727 → **731** (+4 for tab renames + Shape A auto-detection); θπ scrubber runtime 28 → **32** (+4 for Shape A logic). |
| 2.19++ | 2026-04-28 | v3.99 t14e+ continue (scale lock + rationale shipped) | **§22.4.1 added — Scale locked to `win50000.step10000` for the page-12 chromosome-wide θπ scrubber.** Decision crystallized in this turn after Quentin asked whether finer step (`win5000.step1000` or `win10000.step2000`) would give better breakpoint resolution. Answer documented in §22.4.1 with three rigorous reasons: (1) **Browser memory** — `sim_mat` is `n_windows²`, so on a 33 Mb chromosome the four ANGSD-emitted scales produce sim_mat sizes ranging from ~4.4 GB (`win5000`) → ~1.1 GB (`win10000`) → ~44 MB (`win50000`) → trivial (`win500000`). Page 1 already runs at the upper limit at ~5 000 windows ≈ 100 M cells ≈ 400 MB; doubling that crashes most browsers. The 5 kb and 10 kb scales are infeasible at chromosome scale. (2) **Per-window θπ stability** — at 9× coverage with ~10–40 callable sites/kb, a 5 kb window has only ~50–200 callable sites; per-sample θπ variance at that count is large enough that local-PCA mostly captures noise rather than biology. At 50 kb you have ~500–2 000 sites per window and the per-sample estimates are stable enough to PCA meaningfully. Below ~30 kb you embed noise, not biology — which is why MODULE_3's main physical-window default is 500 kb / 500 kb and even the multiscale "fine" scale stops at 5 kb / 1 kb step. (3) **Finer step doesn't buy breakpoint resolution** — page 1's breakpoints are sharp because the local-PCA clustering signal is BINARY (in/out of inversion). The θπ analog is GRADIENT-shaped: nucleotide diversity drops smoothly across an inversion's flanks, not in a step. Even at 1 kb step the θπ-PCA breakpoint is diffuse over 20–50 kb of genomic space — the underlying biological gradient sets the floor regardless of scale. **Layered design**: chromosome-wide θπ scrubber locks to `win50000.step10000` (page 12, this scaffold); per-candidate breakpoint detail uses `win10000.step2000` and `win5000.step1000` (boundaries page, post-v4.0 θπ track addition); genome-wide ideogram tracks use `win500000.step500000` (popstats page). NO SCALE selector is exposed on page 12 — the lock is hard. Schema constraint: `theta_pi_per_window.window_size_bp` must equal `50000` and `step_size_bp` must equal `10000` for the page-12 scrubber's input layer; the per-candidate boundary view, when it ships, will use a separate top-level layer (`theta_pi_per_window_fine` or per-candidate slices loaded on demand) so the two scales never share a JSON key. Page-12 empty-state placeholder updated with a "Scale" section showing the four scales side-by-side as a colored table (red = infeasible / amber = marginal / green = DEFAULT) plus prose rationale for each of the three reasons. NO new required fields; the scale field is a constraint on existing optional layer. |
| 2.19+++ | 2026-04-28 | v3.99 t14e+ continue (boundaries kb-tier shipped + HOBS role documented) | **Two additions: kb-tier scan-radius buttons on the boundaries page, and §12 documentation of the HOBS role for the LG28 hatchery cohort.** (1) **Boundaries page kb-tier buttons** — Quentin: "in boundaries we need to have buttons to change the scale because now the buttons are like Mb but in reality boundary is more like Kb and smaller... add more like 100Kb 25kb 10kb 5kb 1kb." Implemented: 5 new kb-scale scan-radius buttons (`1 kb / 5 kb / 10 kb / 25 kb / 100 kb`) added to the boundaries toolbar's `.bnd-radius-group`, alongside the existing Mb-tier buttons (`1 Mb / 1.5 Mb / 2 Mb / 5 Mb`). Visual separator (`.bnd-radius-sep` 1px-wide vertical rule) divides the two tiers so the two scales of action are immediately legible. Existing JS wiring works unchanged: each button has `data-radius` (in bp) and the click handler stores `bs.scan_radius_bp`. SCHEMA §12 extended with a "Scan-radius scales" subsection documenting the 9-button toolbar, each scale's use case, and which other module's scale it matches (e.g. ±5 kb matches MODULE_3 `win5000.step1000` θπ scale; ±100 kb matches §21 `hobs_profile.distances_kb` default). Each button has a tooltip explaining its specific use case, including the honest caveat that ±1 kb is mainly useful for SV-supported breakpoints (most PCA tracks won't render meaningfully at sub-window scale). Default `BOUNDARY_DEFAULTS.SCAN_RADIUS_BP` stays at the existing Mb-tier default; kb-scale opt-in. (2) **§12 HOBS role for hatchery cohort** — Quentin asked: "for us Hobs it works or not?? Because our catfish is strange?" Answered with a rigorous schema subsection. HOBS works as **secondary confirmation only**, NOT as primary discovery, for three reasons: family structure inflates apparent HWE violation everywhere (NAToRA work confirmed extensive sibling / half-sibling relationships in the 226-sample broodstock); inversion-heterozygote Hobs spikes ARE real but only detectable above the family-noise floor when frequency × family-spread × size are favorable; patched ANGSD (`Isoris/angsd_fixed_HWE`) is non-negotiable for low-MAF sites at 9× coverage. Practical use-case table: primary discovery on page 1 / page 12 → don't trust Hobs alone; boundary refinement on page 11 → Hobs adds value, already wired via §21 `boundary_left/right.hobs_profile`; per-candidate diagnostics → Hobs profile is one of the cheats already in §21 boundary blocks; manuscript-reportable independent test → probably not (family structure too strong a confound). The cluster-side `MODULE_CONFIRMATION_HOBS_HWE` already exists (Mérot adapted, multiscale, subset-aware); integration work is wiring its output into §21 `boundary_*.hobs_profile` for the scrubber to consume. NO new required fields; both additions schema-additive. Tests: 742 → **748** (+6 for kb-tier button regex assertions). |
| **v4.0 cut** | **2026-04-28** | **v3.99 t14e+ continue → v4.0 cut ceremony** | **═══════════════════ THIS ROW MARKS THE v4.0 CUT ═══════════════════** Closes the long t14e+ continue arc. Everything above this row (schemas 2.0 through 2.19+++) is **v4.0 contract surface**; everything below would be v4.1+ work. The cut bumps `SCRUBBER_VERSION` from `'v3.99'` → `'v4.0'`, page `<title>` to `Local PCA Scrubber v4.0`, catalogue export header line to `local PCA scrubber v4.0`, JSON meta tool ID to `pca_scrubber_v4.0`, and PNG watermark to `pca_scrubber v4.0`. Test regexes broadened across 8 suites to accept both v3.x legacy and v4.x current. **What v4.0 ships**: registry interop (§20), 18 structured block types (§21), block-presence chips + JSON inspector on candidate-focus page, θπ scrubber as new page 12 (§22, scaffold + scale lock at `win50000.step10000`), boundaries page kb-tier scan-radius buttons (1/5/10/25/100 kb), HOBS role documented (§12.3, secondary confirmation only). Schema state: **2.19+++**. Tests: **753/753 main + 261/261 across 14 specialized suites + all 6 e2e suites green**. **What v4.0 explicitly does NOT ship**: panel renderers for page 12 θπ scrubber (empty-state only, awaiting STEP_R39/R40/R41 cluster-side), per-candidate concordance sub-view (the figure mockups A-F), cross-method candidate-list merge in catalogue, MODULE_CONFIRMATION_HOBS_HWE → §21 `boundary_*.hobs_profile` wiring, multi-evidence regime convergence implementation (§14, schema-only), real-data validation on 226-sample LG28 cohort. Most v4.0 features are **scaffold-complete** — UI + schema + tests in place, R-side data ingestion ships in v4.x follow-up turns. |
| 2.20   | 2026-04-28 | v4.1 (partition-comparison metrics + L3 reclustering picker scaffold) | **First feature release on top of v4.0 cut. Two additions in response to Quentin reading the Dune (Bézieux et al. BMC Bioinformatics 2024) cluster-merging paper and asking whether (a) Cramér's V + Fisher's exact are robust enough for L3 contingency tables and (b) whether alternative re-clustering modes would catch 'K=3 too coarse' merge errors.** (1) **NMI / AMI / ARI alongside Cramér's V (§11.x)**. Three new pure-JS functions: `nmiFromTable(table, K)` (Strehl-Ghosh geometric-mean Normalized Mutual Information, [0,1]), `amiFromTable(table, K)` (Vinh-Epps-Bailey 2010 Adjusted Mutual Information with exact hypergeometric E[MI] calculation — chance-correction matters for the imbalanced 180/30/16-style hatchery K=3 splits), `ariFromTable(table, K)` (Hubert-Arabie 1985 Adjusted Rand Index, [-1,1] with 0 = chance, counts agreeing sample-pairs across both partitions). All three are *partition-comparison* metrics — they answer 'how similar are these two clusterings?' and are permutation-invariant by construction (relabeling groups doesn't change the value). Cramér's V is an *association* metric — it answers 'are the row and column variables associated?' and is NOT permutation-invariant. The two metric families measure different things; v4.1 surfaces both via a click-to-cycle chip on the L3 contingency display. **UX**: the existing Cramér's V row becomes a clickable chip (`class="l3-metric-chip"`, `cursor: pointer`); clicking cycles through Cramér's V → NMI → AMI → ARI → Cramér's V. All four values are pre-computed and stashed in `data-cramer/data-nmi/data-ami/data-ari` attrs on the chip, so cycling is instant (no recomputation). State persists to `localStorage[pca_scrubber_v3.l3SecondaryMetric]`; default = `'cramer'` to preserve pre-v4.1 screenshots and habits. Each metric has independent effect-size bands (NMI 0.30/0.50/0.75; AMI 0.20/0.40/0.65; ARI 0.20/0.40/0.65; Cramér's V unchanged at 0.10/0.30/0.50) and its own tooltip explaining what it measures and when it's the right number to read. (2) **L3 re-clustering mode picker scaffold (§11.x)**. Quentin's request: 'sometimes K=3 is too coarse, the next 2 bands are on each other relative to focal band, says merge when really they're not the same.' New `<select id="l3ReclusterSel">` next to the band-continuity scope chip in the L3 toolbar. **Three modes shipped enabled** (`kmeans-K3` default = current behavior; `kmeans-K6` = sub-resolves nested haplotype-level clusters; `distance-uv` = projects samples onto centroid axis, kmeans1D on 1D distance — catches 'two bands collapsed onto axis' cases that 2D K-means treats as identical). **Six modes shipped disabled with planning tooltips**: `gmm-3/4/5/6` (Gaussian Mixture Model with diagonal covariance EM, ~80 lines of pure JS, queued for a follow-up turn — better for elongated/overlapping bands than K-means hard assignment); `dbscan` (density clustering after u/v rotation, auto-eps via k-distance graph elbow; produces variable-K contingency tables which need uneven Hungarian alignment or noise-cluster handling); `dosage` (re-cluster on the per-sample dosage matrix instead of PC space — needs `dosage_chunks` JSON layer from R-side STEP_R30, planned). State slot `state.l3ReclusterMode` defaults to `'kmeans-K3'`; persists to `localStorage[pca_scrubber_v3.l3ReclusterMode]`; the change handler stores state but does NOT yet drive a rebuild of the contingency — that's post-v4.1 work because re-clustering means injecting alternative labels into the `compareL2Pair` flow which is called from many places. Today: state slot, UI scaffold, dispatch hook documented, tests in place. **What v4.1 ships**: 7 new pure-JS functions (all tested), metric-cycle UI working end-to-end, recluster-mode picker visible with 3 of 9 modes enabled, version markers all bumped to v4.1, 64/64 dedicated v4.1 metric tests. **What v4.1 does NOT ship**: actual rebuild of the contingency table when recluster mode changes; GMM-EM convergence; DBSCAN auto-eps; dosage re-clustering (needs new R-side layer). NO new required JSON fields; both additions strictly additive. Tests: v4.1 dedicated suite **64/64**; existing 18 suites still all green. |
| 2.20+  | 2026-04-28 | v4.1 continue (recluster picker → contingency rebuild WIRED) | **The recluster-picker integration shipped scaffold-only in 2.20 is now WIRED end-to-end.** Quentin: "continue." The L3 contingency table rebuilds against the chosen recluster mode when the picker changes. Three new pure-JS functions complete the dispatch chain: (1) **`clusterL2_DistanceUV(l2idx)`** — runs K-means2D at K=3 to find centroids, picks the pair with maximum Euclidean distance (the `u-v` principal axis), projects each sample's mean (PC1, PC2) onto that axis as a signed scalar, then K-means1D at K=3 on the projected distance. Catches the "two bands collapsed onto axis relative to focal band" case Quentin specifically called out. Returns the same cluster shape as `clusterL2AtK` (labels, n_per_group, fam_purity, fixedKLabels, etc.) so dispatcher consumers don't need special-cases. (2) **`_wrapKmeansResultAsCluster(result, l2idx, K, reasonOverride)`** — helper that wraps a raw kmeans1D/2D result in the cluster object shape, including family-purity computation. Reused for distance-uv now and queued for GMM/DBSCAN/dosage when those ship. (3) **`getL2ClusterByMode(l2idx, mode)`** — dispatcher that returns the appropriate cluster shape based on `state.l3ReclusterMode`. Routes `kmeans-K3` → existing `getL2Cluster` (default, current behavior preserved); `kmeans-K6` → existing `getL2ClusterAt(l2idx, 6)`; `distance-uv` → `clusterL2_DistanceUV`. Per-mode caching via new `state.l2GroupCacheByMode` Map keyed by `${l2idx}_${mode}`, invalidated when chrom/window-count changes. Unknown modes (`gmm-3`, `dbscan`, `dosage`, etc.) fall back to default — defensive against stale localStorage. (4) **`compareL2Pair_byMode(leftIdx, rightIdx, mode)`** — recluster-aware version of `compareL2Pair`. Routes label fetch through `getL2ClusterByMode` instead of `getL2Cluster`. K is mode-dependent: `kmeans-K6` uses K=6, all others use `state.k` (=3). Returns the same `cmp` shape as `compareL2Pair` plus a `reclusterMode` field for debugging. **L3 panel wiring**: `_renderL3Fingerprint` (line 13901) now includes `state.l3ReclusterMode` and `state.l3SecondaryMetric` in the cache fingerprint so the render-skip cache invalidates automatically when either changes. The neighbor-vs-focal contingency build site (line 14328 in `_renderL3Fingerprint`'s `offset != 0` branch) now reads `reMode = state.l3ReclusterMode \|\| 'kmeans-K3'` and routes through `compareL2Pair_byMode(l2idx, curL2, reMode)` when `reMode !== 'kmeans-K3'`. The conservation-calculation site (line ~15028) uses the same recluster-aware path so the conservation %% in the focal pane's stats matches the contingency table's clustering — otherwise users would see contradictory numbers. The picker change handler now calls `renderL3Panel()` after the state flip so the rebuild actually happens. Architecture preserved: ALL OTHER `compareL2Pair` callers (catalogue conservation column, boundaries-page merge proposals, candidate-mode draft assembly, page-3 catalogue rendering) keep using the unmodified `compareL2Pair` — recluster mode is OPT-IN and ONLY for the L3 contingency display panel. NO new required JSON fields. Tests: v4.1 metrics suite **64/64** (unchanged); new dedicated **31/31 v4.1 continue runtime suite** (`test_v41_recluster_rebuild_runtime.js`) covers function existence, `_wrapKmeansResultAsCluster` shape on synthetic data + minNGroup edge cases + reasonOverride precedence, `clusterL2_DistanceUV` algorithm verification on synthetic 60-sample diagonal-axis data (verifies max-distance pair is centroids 0 and 2 after PC1-sort), `getL2ClusterByMode` dispatcher accepts all 7 valid mode strings, `compareL2Pair_byMode` null-input handling, UI wiring markup (renderL3Panel call after state flip, route through `compareL2Pair_byMode` for non-default mode, conservation uses recluster-aware path), fingerprint includes both new state slots, per-mode cache exists, version unchanged at v4.1. **What's next** (post-2.20+): GMM-3/4/5/6 implementation (~80 lines of pure-JS diagonal-covariance EM each, plus convergence testing) ships when Quentin needs them; DBSCAN with auto-eps + variable-K Hungarian; dosage re-clustering (blocked on `dosage_chunks` R-side layer). The infrastructure is now in place — `getL2ClusterByMode` and `compareL2Pair_byMode` are the integration points; new modes plug into `getL2ClusterByMode`'s switch. |
| 2.20++ | 2026-04-28 | v4.1 continue (distance-uv corrected to true u/v rotation) | **`distance-uv` algorithm rewritten to match the cluster-side R `rotate_to_stripe_axis()` from `STEP20b_anchor_geometry_module.R`.** Quentin's correction: "distance-uv is like we fix het group. We position it at 0 degrees and then it makes other groups look different. It cannot work with PC1 only — needs PC2." My initial v4.1 implementation projected samples onto the centroid axis as a 1D scalar then ran K-means1D — that throws PC2 information away entirely, which is exactly what Quentin said the algorithm must NOT do. The corrected algorithm: (1) **K-means2D at K=3** on aggregated (PC1, PC2) per L2 to identify Hom1 / Het / Hom2 centroids. The existing `kmeans2D` sorts centroids by `cx` ascending, so `cx[0]` = Hom1, `cx[1]` = Het (bracketed middle), `cx[2]` = Hom2. (2) Compute the Hom1→Hom2 axis: `dx = cx[2]-cx[0]`, `dy = cy[2]-cy[0]`, `angle = atan2(dy, dx)`. (3) **Rotate the whole (PC1, PC2) plane by -angle** so the Hom1↔Hom2 axis becomes horizontal. Rotation matrix: `[[cos(angle), sin(angle)], [-sin(angle), cos(angle)]]`. After rotation, both Hom1 and Hom2 centroids share the same `v` (they define the u-axis); Het centroid sits between them; samples deviating perpendicular to the karyotype stripe line have non-zero `v`. (4) **K-means2D at K=3 in rotated (u, v) space** — keep BOTH dimensions. The v-axis carries real biological information: samples that deviate perpendicular signal recombinants, rare alleles, second overlying inversions, or gene-conversion tracts. K-means2D in (u, v) keeps that perpendicular signal instead of projecting it away. **Why this matters**: in raw (PC1, PC2) space, two bands sitting on top of each other relative to the focal band can look identical because PC1 doesn't separate them. In rotated (u, v), the perpendicular axis (v) reveals samples deviating from the stripe line. The Het anchor at u≈0 makes Hom1 and Hom2 symmetric around it. Picker tooltip rewritten to accurately describe the algorithm. Initial bug + correction documented in inline comments. Cluster-side R reference: `STEP20b_anchor_geometry_module.R::rotate_to_stripe_axis()` — same algorithm Quentin already validated in the production R pipeline; scrubber now mirrors it. **Tests**: 5 new rotation-math tests added to `test_v41_recluster_rebuild_runtime.js`: (1) kmeans2D centroids sorted ascending by cx, (2) Hom1→Hom2 angle ≈45° on diagonal data, (3) after rotation Hom1 and Hom2 share same v (Δv < 0.01), (4) Hom2 has greater u than Hom1, (5) Het u lies between Hom1 u and Hom2 u, (6) 45°-rotation of (0,1) gives (√2/2, √2/2), (7) 45°-rotation of (1,1) gives (√2, 0). The (1,1) → (√2, 0) test is the unambiguous mathematical anchor — failed in the original buggy implementation (sign error in `sin_a` assignment), passes with corrected math. Test count: v4.1 continue suite **31 → 38**. NO new schema fields; the dispatch chain (getL2ClusterByMode, compareL2Pair_byMode) is unchanged — only the algorithm inside `clusterL2_DistanceUV` was rewritten. |
| 2.20+++| 2026-04-28 | v4.1 continue full-scope (4 new u/v modes wired end-to-end) | **All four planned u/v modes shipped enabled. Quentin: "All but prioritize speed for compute."** The single `distance-uv` mode expands into a family of five rotation-based modes, all sharing a cached u/v rotation for speed. The picker dropdown now offers seven enabled modes plus six planned/disabled (gmm-3/4/5/6, dbscan-raw, dosage). **New shipped modes (all K=3, all use shared rotation cache):** (1) **`uv-rotated`** (alias for `distance-uv`, value preserved for localStorage compat; display label "uv-rotated (distance-uv)"). Same algorithm as 2.20++ — K-means2D in rotated (u, v). Now refactored to use the shared rotation cache, faster on repeated calls. (2) **`uv-denoise`** — DBSCAN as PRE-filter on rotated (u, v) space; auto-eps = median 5-NN × 0.8 (matches STEP22); minPts = max(3, floor(N×0.08)). K-means3 runs on survivors; noise samples assigned to nearest centroid for final K=3 contingency. Use case: filter family outliers / rare admixed samples that drag K-means centroids before the main clustering pass. (3) **`uv-dbscan`** — K-means3 first to identify coarse stripes in (u, v); then DBSCAN within each stripe on `v` values (matches STEP22's within-stripe DBSCAN pattern). Dominant-subcluster samples keep stripe label; minority-subcluster + noise samples get reassigned to second-closest stripe centroid — visible as off-diagonal contingency mass when DBSCAN finds internal structure that K-means hard-assignment hid. (4) **`uv-dist-rank`** — K-means3 in (u, v); within each Hom stripe, samples sorted by Euclidean distance to Het centroid in rotated space; closest tercile relabeled as Het. Reveals samples DRIFTING toward Het (recombinants, intermediate states, admixture) by moving them into the Het cell of the contingency. (5) **`uv-dist-fuzzy`** — soft inverse-distance weights to all three centroids `w_j = (1/(d_j+eps)) / sum(1/(d_k+eps))`; hard label = argmax(w); but when max(w) < 0.45 (sample within ~10%% of equidistant from two centroids), reassign to second-best. Reveals contingency cells where K-means hard assignment was forced on truly ambiguous samples. **Speed-first architecture (Quentin's explicit constraint)**: shared `state.l2UVRotationCache` Map stores `{xs, ys, us, vs, angle, hom1_xy/het_xy/hom2_xy, hom1_uv/het_uv/hom2_uv, baseLabels, baseN, degenerate}` per L2. The expensive aggregation + K-means3-for-centroid-identification + rotation runs ONCE per L2 across all five u/v modes — switching modes in the picker is then ~1ms (just runs the mode-specific clustering on cached rotated coordinates). DBSCAN primitive `_dbscan(pointsObj, eps, minPts)` is pure-JS O(N²) — at N=226 cohort size, 51k pairwise comparisons finish in ~0.5ms in V8, so kd-tree overhead exceeds savings. Auto-eps via `_kDistAutoEps(pointsObj, k)` = median k-NN × 0.8, matching STEP22. Cache invalidates on chrom/window-count change (same key as `l2GroupCacheByMode`). Per-mode result cache (`l2GroupCacheByMode`) sits ON TOP of the rotation cache — first call to a mode computes labels from cached rotation; subsequent calls hit the per-mode cache. **§21 registry consumer (planned-fallback shipped now)**: dispatcher checks `state.candidateUVModes._byL2Mode.get(${l2idx}_${mode})` BEFORE running on-the-fly clustering. When the planned R-side script `STEP_R??_emit_uv_modes_per_candidate.R` ships and emits `candidate_uv_modes.json` (one blob per promoted candidate, containing all 5 modes × all L2s within the candidate's span), loading that JSON populates `state.candidateUVModes` and the dispatcher prefers precomputed results. On-the-fly stays as backup for L2s outside any candidate or for live exploratory scrolling between candidates. Schema for the planned JSON: `{ candidate_id, l2_envelopes: [{ l2idx, modes: { mode_name: { labels: int8[], n_per_group: int[3], fam_purity, fam_per_cluster, ok, reason } } }] }`. **What v4.1 continue full-scope ships**: 5 new clustering functions (clusterL2_UVRotated, clusterL2_UVDenoise, clusterL2_UVDBSCAN, clusterL2_UVDistRank, clusterL2_UVDistFuzzy), 3 supporting primitives (_getOrComputeUVRotation, _dbscan, _kDistAutoEps), expanded dispatcher with §21 registry-consumer fallback path, picker UI with 7 enabled + 6 disabled options, expanded validity allow-list, new dedicated test suite **38/38** (`test_v41_uv_modes_runtime.js`) covering function existence, _dbscan ground-truth on synthetic 1D + 2D well-separated data + edge cases (tight blob → 1 cluster, sparse → all noise), _kDistAutoEps math verification (uniform unit spacing → eps=0.8), all picker UI markup, all dispatcher routing cases, §21 registry consumer hooks, shared rotation cache. **What v4.1 continue full-scope does NOT ship**: R-side STEP_R??_emit_uv_modes_per_candidate.R (deferred to follow-up turn — needs Quentin's R toolchain + real candidate data to validate); GMM-3/4/5/6 (still planned-disabled); dbscan-raw (still planned-disabled); dosage mode (blocked on dosage_chunks layer). Test count: v4.1 metrics suite **64 → 68** (+4 new picker tests); v4.1 continue suite stable at **38**; new u/v modes suite **38**. All 18 prior suites still green. NO new required JSON fields in `candidate_uv_modes` — strictly additive optional layer. |
| 2.21   | 2026-04-29 | v4 cut + Diversity Atlas landing page (page13) | **Two changes this turn. (1) v4 cut.** Quentin: "Change name to v4." `SCRUBBER_VERSION` renamed `'v4.1'` → `'v4'` (drops minor for the canonical release name). `<title>` to "Local PCA Scrubber v4". Catalogue export header to "local PCA scrubber v4". JSON tool ID to `pca_scrubber_v4`. PNG watermark to `pca_scrubber v4`. Test regexes updated: main `test_v399.js` version regex now accepts bare `v4` plus `v4.x` and `v3.99+` for backwards compat; v4.1 metric + recluster suites' SCRUBBER_VERSION assertions updated to match. The intermediate v4.1 / v4.1-continue / v4.1-continue-full-scope work (NMI/AMI/ARI metrics, recluster picker wiring, full u/v mode family expansion, distance-uv → uv-rotated rotation correction) all rolls into the v4 release. v4 ships: 7 enabled clustering modes (kmeans-K3 default, kmeans-K6, uv-rotated/distance-uv, uv-denoise, uv-dbscan, uv-dist-rank, uv-dist-fuzzy), four partition-comparison metrics on the L3 contingency (cycle-on-click chip), shared u/v rotation cache for speed, §21 registry-consumer fallback path for planned `candidate_uv_modes` JSON, plus the new Diversity Atlas landing page (below). **(2) Diversity Atlas landing page (page13).** Quentin: "Make layout page of diversity atlas." New tab at user-visible position 13, DOM id `page13`. Layout-only scaffold previewing the planned dual-mode design (Inversion Atlas vs Diversity Atlas — same JSON, different interpretation lens). Six section cards: (a) Vision/dual-mode concept with `state.atlas` slot description; (b) Required data layers status grid (theta_pi_per_window, per_sample_theta_pi, per_sample_froh, roh_segments, ancestry_q, kinship_matrix, family_ld) — each row marked `⚪ not loaded` with `data-da-layer` attribute for future renderers to flip to loaded state; (c) Per-page mapping table (13 rows × 4 columns) showing how each tab forks between Inversion mode and Diversity mode (e.g. tab 4 boundaries → ROH atlas; tab 5 catalogue → region catalogue; tab 6 karyotype → ancestry-Q stratification; tab 11 markers hidden in diversity mode); most tabs are atlas-shared (no fork); (d) Top-level dashboard mockup — six panel slots (θπ overview, F_ROH summary, ROH atlas, Ancestry-Q stratification, Kinship/relatedness, Family-restricted LD), each with title, description, dashed-border placeholder, and "feeds: layer · related: page" footer; (e) Phasing roadmap (A schema-only ✓ shipped, B toggle button + state slot ⚪ next, C per-page renderers ⚪ multi-turn, D catalogue+bundle forking ⚪ later); (f) Cross-references to page 12 (already-shipped diversity scrubber), page 7 (popstats — atlas-shared), page 8 (ancestry — atlas-shared), SCHEMA §17 (atlas-mode-switching spec), help-page entry. Tab button placed at the END of the tab bar so existing tabs 1-12 numbering is preserved; can be promoted to a more prominent position when phase B (toggle) ships. Tooltip explains "(preview / scaffold)" status. **What this page is**: a structural commitment Quentin can click into to see the planned Diversity Atlas. The data-availability grid uses the `data-da-layer` attribute pattern (matches the existing page12 `data-th-layer` pattern) so when the R-side scripts ship and the corresponding JSON layers load, the status pill flips from ⚪ to ✓. The dashboard mockup grid is the canvas where the per-panel renderers will plug in during phase C. **What this page is NOT**: live data rendering. No rendering hooks fire when the page activates (CSS-only `.page.active { display: block }`). The page is pure HTML, no JS state. That's intentional — phase A is the schema/visible commitment; phase B+C ship the actual flips. **Tests**: new dedicated runtime suite `test_v41_diversity_atlas_runtime.js` covering: page13 div present, tab button present at the end with correct DOM linkage, all 6 section cards present, all 7 data-layer rows have the `data-da-layer` attribute, all 13 page-mapping table rows present, all 6 dashboard mockup panels present, all 4 phasing-roadmap rows present, cross-references to page 12 / SCHEMA §17 / SCHEMA §23 present. Regression: all 18+ prior suites green. **What's deferred**: phase B (toggle button + state slot) — single follow-up turn. Phase C (per-page renderers) — multi-turn, one renderer per forked page. Phase D (catalogue + bundle forking) — later. Estimated 3-5 weeks of post-v4 work to ship the full Diversity Atlas. NO new required JSON fields; the new layers are all optional / consumed-when-present. |
| 2.22   | 2026-04-29 | Population Atlas v1 — sibling deliverable (separate HTML file) | **Quentin: "Yeah like make a different html then. But use same menus same style same everything."** Architectural pivot from the in-scrubber atlas-mode-switching design (schema 2.21 / SCHEMA §17) to a **multi-file sibling-deliverable design**. Three HTML files, one per perspective: (1) `pca_scrubber_v3.html` (Inversions Atlas, the existing v4 scrubber), (2) `population_atlas_v1.html` (this turn — Population Atlas), (3) `variants_atlas_v1.html` (planned — deleterious burden / catfish toxic mutations). Each file is a single-purpose deliverable that opens in its own browser tab. The teacher / committee opens all three; each is one focused view. **Why the pivot**: in-scrubber mode-switching (2.21 / §17) was multi-week phase B+C+D work to fork ~12 pages. Sibling-file deliverables let each atlas exist as its own self-contained file with same chrome but tailored content. Faster to ship, cleaner to demo, and does not entangle the production scrubber's complex state machine with new rendering logic. The scrubber's page13 (Diversity Atlas landing page from 2.21) stays as the in-scrubber preview / cross-reference; the actual Population Atlas content lives in `population_atlas_v1.html`. **What `population_atlas_v1.html` is**: standalone HTML file (~54 KB), zero scrubber dependencies. Lifts the scrubber's design language verbatim (CSS variable system, header layout, `#tabBar` structure, page system, three themes — dark/light/academic). Accent color flipped from amber `#f5a524` to muted green `#3cc08a` (reuses scrubber's existing `--good` hex) to make the two atlases visually distinguishable at a glance. Population-atlas-specific palette adds `--pop-samples` / `--pop-qc` / `--pop-fam` / `--pop-het` / `--pop-div` / `--pop-roh` (six green shades) for per-page color coding via card border-left stripes. Active-tab gradient also re-tinted from amber to green (`rgba(60,192,138,…)` instead of `rgba(245,165,36,…)`). **Page set (7 tabs)**: (1) Samples — sortable table with sample_id / family_id / broodline / mean_coverage / callable_fraction / genome_het / F_ROH / ancestry_Q_top / natora_status / qc_pass; includes mock-up of the planned table with 6 example rows; (2) Quality Control — coverage histogram + missingness scatter, QC thresholds card (mean_coverage ≥5×, callable ≥90%, missingness ≤10%, contamination FREEMIX ≤0.03, NAToRA π̂ <0.0884); (3) Families & Genetic clusters — six panel slots (NGSadmix Q-bar round 1 + round 2, kinship heatmap, NAToRA pruning diagram, PCAngsd PCA, evalAdmix residuals); explains the two-round structure design (all-226 + 81-NAToRA-pruned) and that K reflects hatchery broodline structure not species admixture (cohort is pure C. gariepinus); (4) Heterozygosity — four panel slots (cohort het distribution, per-chromosome heatmap, H_obs vs F_ROH scatter, ranked bars); folded-SFS caveat documented; (5) Diversity — chromosome θπ atlas (28 stacked tracks), multiscale view, per-band θπ comparison; documents the four available scales from MODULE_3 (500kb, 50kb, 10kb, 5kb) with file paths; (6) Inbreeding — F_ROH ranked, ROH length distribution, ROH atlas (sample × position heatmap); explains the dual-bin ROH design (fixed literature bins + adaptive empirical-quantile bins); (7) About — three-atlas manuscript design table, data sources by page, phasing roadmap, glossary (broodline, family, F_ROH, ROH, θπ, H_obs, NAToRA, NGSadmix, folded SFS, callable genome), cross-references to scrubber pages 7/8/12/13. **All seven pages are layout-only scaffold this turn** — like the scrubber's page13 pattern; planning grids, panel-slot mockups (`░░░ panel mockup ░░░` placeholders), no JSON loading, no rendering. Phase B (next turns) wires individual pages to real data. **Minimal JS**: tab switching (~20 lines, click handler iterates `#tabBar button[data-page]`, toggles `.active` on tab + `.page` element), theme toggle (cycles dark → light → academic, persists to `localStorage[population_atlas_v1.theme]`), last-viewed-tab persistence (`localStorage[population_atlas_v1.activeTab]`). No external dependencies, no charting libs, no JSON fetchers. Pure HTML+CSS+vanilla-JS. **Cross-link to scrubber**: `<a href="pca_scrubber_v3.html">→ Inversions Atlas</a>` at the right end of the tab bar; matching link added to scrubber's page13 (planned for phase B turn). **Tests**: new dedicated runtime suite `test_population_atlas_v1_runtime.js` (75/75) covering: file structure / parse / div tag balance, all 7 pages present + page1 starts active, all 7 tab buttons with correct labels and DOM linkage, scrubber link at tab-bar end, header h1 / atlasBadge / theme button / 226-sample reference, CSS theme system (dark `--accent: #3cc08a`, light `#16a34a`, academic `#4f7a4d`, six --pop-* palette variables, green-tinted active-tab gradient), per-page content cards (Samples planned columns including sample_id and F_ROH, Mock-up table, QC thresholds + contamination_freemix metric, Structure two-rounds + Q-bar plot panels for both rounds, Folded SFS caveat + H_obs vs F_ROH panel, multiscale θπ scales documenting win50000.step10000, dual-bin ROH design + ROH atlas panel, three-atlas table + glossary 7-term coverage), phasing roadmap (phase A ✓ shipped + phase B+D documented), JS hooks (tab switching + theme toggle + localStorage persistence + html data-theme attribute), cross-references (href to scrubber, references to scrubber pages 12 + 13). Regression: all 20 prior suites green (753+68+38+38+51 main + 261 t14e+ + 6 e2e). **What v1 ships**: standalone HTML file, 7 pages of structural scaffold, full chrome lifted from scrubber, tested. **What v1 does NOT ship**: any JSON loading, any panel renderers, any cross-atlas state sharing, any data-driven content. All deferred to phase B+C (multi-turn, ~3-5 weeks). **Manuscript-deliverable angle**: the teacher / committee opens three browser tabs, scrolls through each, the thesis is visible. No headache. NO new required JSON fields anywhere. NO changes to scrubber state, schema, or runtime behavior. |

---

## 10. Marker / PCR assay module (planned, schema 2.2)

The marker module closes the loop from inversion discovery to farm-usable
diagnostic assays. For each high-confidence inversion candidate, it
designs a small panel of PCR markers that distinguish K=3 regimes
(g0/g1/g2), letting hatchery staff assign arrangement classes from
low-cost genotyping rather than from whole-genome sequencing.

### Why "candidate-regime diagnostic markers", not "breakpoint PCR"

Breakpoint PCR requires exact junction sequences on both inversion
arrangements. We do not have those — short-read assemblies in the
226-sample cohort were not built for breakpoint-resolution work, and the
F1 hybrid reference's breakpoint coordinates carry assembly-level
uncertainty. What we **do** have, robustly, is the regime call per fish
per candidate (`fish_regime_calls.tsv`, schema §7) and dense per-sample
allele information from the resequencing.

So the marker logic is variant-frequency-driven, not junction-driven:

```
candidate inversion regime calls
       ↓
find SNPs/indels enriched in each regime (g0 / g1 / g2)
       ↓
select robust markers (specificity, MAF, family-spread, locus quality)
       ↓
design primer pairs around each marker
       ↓
rank and assemble panels (3–10 markers per candidate)
       ↓
export hatchery genotyping sheet
```

The output framing for the manuscript:

> *For each high-confidence candidate structural haplotype regime, we
> designed candidate diagnostic PCR marker panels to support low-cost
> screening of arrangement classes in hatchery populations.*

This phrasing is deliberate. We are not claiming breakpoint detection or
direct structural assays — the panels are *diagnostic of the regime call*,
which is itself a population-genomics product. The panels are validated
by whether they reproduce the K=3 regime call from the genome data, not
by whether they detect a junction.

### Four marker classes

For each candidate the module attempts four marker classes:

| Class                         | What it tags                                  | Required prerequisite                          |
|-------------------------------|-----------------------------------------------|-------------------------------------------------|
| **Regime-specific**           | Variant common in one regime, rare in others  | `freq_target ≥ 0.80` AND `freq_others ≤ 0.10`   |
| **Heterozygote-pattern**      | Variant whose g1 frequency is intermediate    | `0.35 ≤ freq_g1 ≤ 0.65` AND extremes for g0/g2 |
| **Internal diagnostic**       | SNP/indel inside the candidate interval, no breakpoint claim required | inside `[start_bp, end_bp]` |
| **Breakpoint-proximal**       | Marker close to the inferred breakpoint zone (when available) | requires `boundaries_refined` from phase 5 |

The first three are always attempted; the fourth is opportunistic and
only fires when phase 5 has refined boundaries. None of these is
"breakpoint PCR" in the strict sense — even the breakpoint-proximal class
is just a regime-correlated marker that happens to sit near the
breakpoint.

### Panel construction rules

A marker is **not** an assay. A panel is. The minimum and recommended
panel sizes are:

- **Minimum panel**: 3–5 markers per candidate
- **Recommended panel**: 5–10 markers per candidate
- **Multiplex constraint**: per-panel Tm spread ≤ 4 °C, no primer-dimer
  hits at default tolerance, similar amplicon size buckets (small / mid)

A single marker can fail in the field (local mutation, family
background, PCR failure). Panels of 3+ markers tolerate one failure and
return a probabilistic regime call rather than a hard call. The panel's
output is:

```
predicted_regime + confidence
```

### Module placement (phase 13)

The marker module is **phase 13** — runs after phase 12 (gene cargo)
because gene cargo informs which markers to avoid (don't design primers
inside critical gene exons or repetitive regions). Phase 13 reads
`fish_regime_calls.tsv` (schema §7), the source VCFs, and the gene_cargo
JSON. It writes three TSVs and one `<chrom>_phase13_markers.json`.

### Three exported TSVs

#### `<chrom>_candidate_marker_catalogue.tsv`

One row per (candidate × marker). The "marker discovery" output —
all variants that passed filtering as plausible markers, with their
allele frequencies in each regime.

| Column                | Type    | Description                                                                                       |
|-----------------------|---------|---------------------------------------------------------------------------------------------------|
| `candidate_id`        | string  | Joins to `candidate_registry.tsv`                                                                  |
| `marker_id`           | string  | Stable ID (e.g. `cand_lg28_142_a_M001`)                                                          |
| `chr`                 | string  | Chromosome                                                                                        |
| `pos`                 | integer | 1-based position                                                                                  |
| `variant_type`        | string  | `SNP` / `INDEL` / `MNP`                                                                          |
| `ref`                 | string  | Reference allele                                                                                 |
| `alt`                 | string  | Alt allele (or pipe-joined alts)                                                                |
| `marker_class`        | string  | `regime_specific` / `het_pattern` / `internal_diagnostic` / `breakpoint_proximal`               |
| `target_regime`       | string  | `g0` / `g1` / `g2` / `g0_or_g2` (the regime(s) this marker preferentially tags)                  |
| `freq_g0`             | float   | Alt-allele frequency in fish called g0 by `fish_regime_calls.tsv`                                |
| `freq_g1`             | float   | Alt-allele frequency in fish called g1                                                           |
| `freq_g2`             | float   | Alt-allele frequency in fish called g2                                                           |
| `n_g0`                | integer | Number of fish (called g0) genotyped at this site (excludes ambiguous + missing)                 |
| `n_g1`                | integer | Same for g1                                                                                      |
| `n_g2`                | integer | Same for g2                                                                                      |
| `specificity_score`   | float   | `freq_target − max(freq_others)`. Range [-1, 1]. Higher = more discriminative.                   |
| `family_spread_score` | float   | Fraction of breeding families that contain ≥1 fish carrying the alt allele. Penalizes family-private markers. |
| `locus_quality_score` | float   | Composite of read-depth quartile, mappability, and proximity to repeats. Range [0, 1].          |
| `selected_for_panel`  | string  | `TRUE` / `FALSE` — passed all filters AND chosen by panel-assembly step                         |
| `panel_id`            | string  | The panel this marker belongs to (e.g. `cand_lg28_142_a_panel1`); empty if not selected         |

**Specificity rule.** A marker is *discriminative* when
`specificity_score ≥ 0.50` for `regime_specific` class (the alt allele's
frequency in the target regime is at least 0.50 higher than in the next-
highest regime). Lower thresholds may be admitted for `het_pattern` —
those are evaluated by absolute distance from 0.50 in the heterozygous
regime, not by max-of-others margin.

**Family-spread rule.** `family_spread_score ≥ 0.50` (allele present in
at least half of contributing families) avoids family-private markers
that look discriminative on the cohort but won't generalize. This rule
is critical for hatchery cohorts where breeding structure can fake
regime-specificity.

#### `<chrom>_candidate_marker_primers.tsv`

One row per primer pair. A marker can have multiple primer-pair
attempts (different windows around the variant); the best is selected
into a panel.

| Column                  | Type    | Description                                                                                       |
|-------------------------|---------|---------------------------------------------------------------------------------------------------|
| `candidate_id`          | string  | Joins to `candidate_registry.tsv`                                                                  |
| `marker_id`             | string  | Joins to `candidate_marker_catalogue.tsv`                                                          |
| `primer_pair_id`        | string  | Stable ID (e.g. `cand_lg28_142_a_M001_P1`)                                                       |
| `forward_primer`        | string  | 5'→3' DNA sequence                                                                                |
| `reverse_primer`        | string  | 5'→3' DNA sequence                                                                                |
| `forward_pos`           | integer | Forward primer's 5' bp position                                                                   |
| `reverse_pos`           | integer | Reverse primer's 5' bp position                                                                   |
| `tm_forward`            | float   | Predicted melting temperature, °C                                                                 |
| `tm_reverse`            | float   | Predicted melting temperature, °C                                                                 |
| `gc_forward`            | float   | GC fraction                                                                                       |
| `gc_reverse`            | float   | GC fraction                                                                                       |
| `amplicon_size`         | integer | Expected product size in bp                                                                       |
| `amplicon_seq`          | string  | Reference sequence of the amplicon (uppercase)                                                    |
| `target_regime`         | string  | Same as marker's `target_regime`                                                                  |
| `panel_id`              | string  | Panel this primer pair was assigned to                                                            |
| `selected`              | string  | `TRUE` / `FALSE` — chosen as the active pair for this marker in the panel                        |
| `primer_dimer_score`    | float   | Higher = more dimer risk; pairs with score ≥ 8 are rejected                                      |
| `off_target_hits`       | integer | Count of in-silico off-target hits across the genome (≤ 3 mismatches)                            |
| `warning`               | string  | Pipe-separated warnings: `repeat_region`, `near_gene_exon`, `low_mappability`, `tm_mismatch`, `large_amplicon`, ... Empty when clean. |

Empty `warning` is the goal. A primer pair with any warning is still
listed but is unlikely to be `selected = TRUE` unless no clean
alternative exists.

#### `<chrom>_candidate_marker_panel_summary.tsv`

One row per panel — the rollup the hatchery actually uses.

| Column                     | Type    | Description                                                                                       |
|----------------------------|---------|---------------------------------------------------------------------------------------------------|
| `candidate_id`             | string  | Joins to `candidate_registry.tsv`                                                                  |
| `panel_id`                 | string  | Stable ID (e.g. `cand_lg28_142_a_panel1`)                                                        |
| `n_markers`                | integer | Number of markers in the panel (3–10)                                                            |
| `n_g0_diagnostic`          | integer | Markers tagging g0                                                                                |
| `n_g1_diagnostic`          | integer | Markers tagging g1 (heterozygote-pattern)                                                         |
| `n_g2_diagnostic`          | integer | Markers tagging g2                                                                                |
| `panel_class`              | string  | `minimum` (3–4 markers) / `recommended` (5–10) / `extended` (>10, rare)                          |
| `tm_min`                   | float   | Minimum primer Tm in panel                                                                        |
| `tm_max`                   | float   | Maximum primer Tm                                                                                 |
| `tm_spread`                | float   | `tm_max − tm_min`. Multiplex-friendly when ≤ 4 °C.                                              |
| `amplicon_size_min`        | integer | Smallest amplicon, bp                                                                             |
| `amplicon_size_max`        | integer | Largest amplicon, bp                                                                              |
| `panel_specificity_mean`   | float   | Mean of selected markers' `specificity_score`                                                     |
| `panel_specificity_min`    | float   | Worst marker's specificity                                                                        |
| `expected_call_accuracy`   | float   | Probability the panel reproduces the genome-based regime call. Computed by leave-one-fish-out validation against `fish_regime_calls.tsv`. |
| `confidence_tier`          | string  | `HIGH` (≥ 0.95) / `MEDIUM` (0.85 – 0.95) / `LOW` (< 0.85)                                       |
| `warnings`                 | string  | Panel-level warnings: `low_family_coverage`, `single_diagnostic_for_regime`, `tm_spread_high`, `multiplex_unsafe`, `no_g1_marker` |
| `recommended_for_export`   | string  | `TRUE` / `FALSE` — panel is hatchery-deployable as written                                       |

**Confidence tiers.** `expected_call_accuracy` is the clearest
hatchery-facing number — *given the cohort we calibrated on, how often
does the panel agree with the genome-based regime call?*. Computed by
leave-one-fish-out: drop fish *i*, predict its regime from its alt-
allele dosage on the panel's markers (using the remaining cohort's
allele frequencies), compare to the genome call. Repeat for all fish.
The fraction that match is the tier number.

**Why not validate against true karyotype.** True karyotype is
unavailable for the 226-sample cohort (no cytology). The genome-based
regime call (`fish_regime_calls.tsv`) is the ground truth for panel
validation. This is documented honestly in the manuscript: panels
reproduce the genome-based regime call at confidence X, not the
underlying biological karyotype.

### Page 7 — marker page (planned scrubber UI)

The scrubber gains a new tab/page that activates when
`marker_panel_summary` is in `_layers_present`. Per-candidate view shows:

- **Header**: candidate ID, chr / start / end / span_mb, regime counts
  from `candidate_registry`
- **Recommended panel card**: panel ID, marker count, confidence tier,
  expected call accuracy, panel-level warnings
- **Marker table**: per-marker rows with marker_id, position, target
  regime, specificity score, primer pair (forward / reverse), amplicon
  size, Tm, warning chips
- **Interpretation block**: human-readable rules for the panel — e.g.
  *"Marker A supports g0; Marker B supports g2; Marker C separates
  g0/g2 from g1. Combined panel assigns a fish to a candidate regime
  with 96% accuracy on the 226-sample calibration cohort."*
- **Export buttons**: download the three TSVs filtered to this candidate
  (handy for sending one panel to a collaborator without exporting the
  whole atlas)

### Live dosage heatmap rendering (planned, schema 2.5 → revised 2.6)

A per-marker dosage heatmap is part of the §10 module's view.
**v2.6 substantially extends the v2.5 spec** with the FIG_C08-style
visual contract from `STEP28_candidate_marker_heatmap.R` (the existing
R-side reference plot), plus a region-binding contract that supports
both static (per-candidate) and live (cursor-following) views.

Naming convention: this is the "dosage heatmap"; in R-side and
manuscript contexts it is **FIG_C08**.

#### Visual layout (FIG_C08-style, expanded)

The heatmap is a Canvas matrix of **samples (rows) × markers (columns)**.
Cells are colored by per-sample dosage at that marker on a 3-stop
diverging ramp:

```
0 (HOMO_REF)  → #2166AC  (blue)
1 (HET)       → #F7F7F7  (near-white)
2 (HOMO_ALT)  → #B2182B  (red)
NA            → #FFFFFF  (white) or no fill (transparent)
```

Sample order within the matrix is `coarse_group_refined, u` — group
block first (so HOMO_1 / HET / HOMO_2 form clean horizontal bands),
then by anchor-PC1 score within group. v3.94 may approximate `u` with
raw PC1 within band when the anchor-rotated geometry from STEP20b is
unavailable (acceptable as v0; gives qualitatively the same ordering).

#### Within-regime subclustering (schema 2.10, post-v3.99)

When sub-structure exists *inside* a major regime — e.g. two distinct
HOMO_1 haplotype backgrounds carrying different ancestral arrangements
or recombination histories — running density-based clustering naively
on raw `(u, v)` across all samples conflates this signal with the
top-level HOMO_1 / HET / HOMO_2 split. The major-regime axis dominates
distances and the minor within-regime axis gets washed out.

**Contract: subclustering is per-regime, in a within-regime rotated
frame.** Per regime separately:

1. Extract local PCA coordinates `(u, v)` for samples in that regime.
   Source: `cand.fish_calls[si]` for K=3 candidates (regime-aware), or
   the per-window `cl.labels[]` for cursor-mode regions outside any
   committed candidate.
2. **Rotate.** Run PCA / SVD on the within-regime `(u, v)` matrix.
   Project each sample onto the rotated axes:
   - `u_rot` = projection on the within-regime PC1 (the dominant axis
     of variation *inside* this regime)
   - `v_rot` = projection on the within-regime PC2 (orthogonal)
3. **Standardize.** Z-score `u_rot` and `v_rot` independently to unit
   variance so DBSCAN's `eps` parameter behaves the same way along
   both axes. Mean-centering is implicit in the SVD step.
4. **Cluster.** Run DBSCAN (or HDBSCAN when `min_cluster_size` is more
   useful than `eps`) on the standardized `(u_rot, v_rot)`. Recommended
   defaults — DBSCAN: `eps = 0.5`, `min_samples = 3`. HDBSCAN:
   `min_cluster_size = 3`, `min_samples = 1`.
5. **Label.** Subcluster IDs are within-regime, dense, 1-based:
   `HOMO_1_sub1`, `HOMO_1_sub2`, ..., `HET_sub1`, `HET_sub2`, ...,
   `HOMO_2_sub1`, `HOMO_2_sub2`, ... DBSCAN noise points (label `-1`)
   become `<REGIME>_sub_noise` (e.g. `HOMO_1_sub_noise`).

**Subclusters are DIAGNOSTIC, not paper-level.** They are within-regime
haplotype backgrounds — useful for spotting recombinants, hybrid
ancestry, or sub-broodline structure inside what looks like a clean
homozygous block. The paper-level inversion regime call remains
`HOMO_1 / HET / HOMO_2`. Manuscript text should never report
"`HOMO_1_sub2` carries 12 samples" as a primary finding — that is a
description of within-regime broodline structure, not of the inversion
itself. Subclusters surface as a refinement annotation track in the
heatmap (between K=3 PCA group and K=6 sub-band), not as an
inversion-state label anywhere.

**`cluster_mode` parameter.** Four values are defined. The scrubber UI
exposes a primary toggle between the two production modes (`none` ↔
`rotated_within_regime`); the other two are named diagnostic
alternatives that exist in the contract but are not primary user
toggles.

| Mode | Default? | Description | When to use |
|---|---|---|---|
| `none` | **default** | Subclustering is not run. `coarse_group_refined == coarse_group` (no `_sub<N>` suffix). Heatmap K=3 track renders its existing solid-color cells. `u_rot`/`v_rot` are null. | Default until within-regime subclustering has been calibrated against real cohort data. Matches the current scrubber behaviour (no DBSCAN runs anywhere). |
| `rotated_within_regime` | opt-in | The 5-step contract above. Per-regime split → SVD-rotate `(u, v)` → standardize → DBSCAN/HDBSCAN. | The standard subclustering mode once calibrated. Surfaces within-regime haplotype backgrounds while preserving the paper-level regime call. |
| `raw_uv` | diagnostic alternative | DBSCAN on raw `(u, v)` across all samples (no per-regime split, no rotation). Equivalent to "ignore the major-regime split entirely". | Diagnostic only — to see what naive clustering would have produced. Almost always recovers the major-regime split as the dominant clusters and misses within-regime structure. Not a recommended production mode. |
| `one_dimensional_rotated_axis` | diagnostic alternative | Per-regime split → SVD-rotate, but cluster only on `u_rot` (1D). Discard `v_rot`. | When `v_rot` is dominated by sequencing noise rather than haplotype-background signal — produces cleaner clusters at the cost of losing any 2D structure. Useful as a fallback when low coverage makes the second within-regime axis non-informative. |

**Why `none` is the default.** Subclustering is a *new* analytical
contract introduced in schema 2.10. Until it has been calibrated on
the 226-sample LG28 cohort (and any per-regime sample-size lower
bounds tuned), the safe default is to leave the existing heatmap
behaviour unchanged: rows are sorted by `coarse_group_refined, u`
where `coarse_group_refined == coarse_group`, no sub-stripe renders,
no labels ship in the TSV. Once validated, the default may flip to
`rotated_within_regime` in a future schema bump — that change is
explicitly out of scope for 2.10.

**JSON shape.** Subcluster labels ship in the
`candidate_sample_coherence` layer as an additional column
`coarse_group_refined` (already promised by the v3.94 contract;
schema 2.10 makes the value space explicit):

```jsonc
{
  "candidate_id": 48,
  "sample": "CGA037",
  "coarse_group": "HOMO_1",                    // unchanged: paper-level regime
  "coarse_group_refined": "HOMO_1_sub2",       // NEW: within-regime subcluster (== coarse_group when cluster_mode=='none')
  "cluster_mode": "rotated_within_regime",     // NEW: which mode produced the label ('none' | 'rotated_within_regime' | 'raw_uv' | 'one_dimensional_rotated_axis')
  "u_rot": -0.83,                              // NEW: within-regime rotated coords (z-scored); null if cluster_mode in {'none', 'raw_uv'}
  "v_rot":  0.41,                              // NEW; null if cluster_mode in {'none', 'raw_uv', 'one_dimensional_rotated_axis'}
  "agreement_fraction": 0.83,
  "coherence_class": "coherent",
  "dist_to_centroid": 0.42,
  "centroid_z_score": 1.1,
  "stripe_quality": "core",
  "tier_rule": "coherence=coherent;z=1.1;group=HOMO_1",
  "n_informative_markers": 47
}
```

When `cluster_mode == "none"` (the default — subclustering not run),
`coarse_group_refined` falls back to `coarse_group` (no `_sub<N>`
suffix), `u_rot`/`v_rot` are null, and the `cluster_mode` column
records `"none"` so downstream consumers can tell "subclustering was
skipped" from "subclustering ran and produced this label". The dosage
heatmap row sort (`coarse_group_refined, u`) still works — it's just
that the within-regime ordering uses anchor-PC1 `u` instead of `u_rot`.

When `cluster_mode == "raw_uv"`, `coarse_group_refined` carries the
raw-clustering label (e.g. `cluster_3`) and `u_rot`/`v_rot` are null —
the rotation step was skipped.

When `cluster_mode == "one_dimensional_rotated_axis"`, `u_rot` is
populated; `v_rot` is null.

When `cluster_mode == "rotated_within_regime"`, both `u_rot` and
`v_rot` are populated.

**Heatmap rendering.** When subcluster labels are present *and*
`cluster_mode != "none"` *and* `cluster_mode != "raw_uv"` (i.e. only
under `rotated_within_regime` or `one_dimensional_rotated_axis`), the
K=3 PCA group track gains an inner sub-stripe showing the subcluster
assignment (one sub-color per `_sub<N>`, monotone within each major
regime's hue). Otherwise — labels absent, `cluster_mode == "none"`,
or `cluster_mode == "raw_uv"` (which produces global-clustering labels
not within-regime sub-labels) — the K=3 track renders its existing
solid-color cells unchanged.

**Recompute trigger.** Subcluster labels are computed at candidate
commit time (same as `band_diagnostics` and `het_shape`) and stored on
the candidate. Changing `cluster_mode` invalidates the stored labels;
the candidate page surfaces a "recompute subclusters" button.

#### Annotation tracks

**Five left-side annotation tracks**, drawn outermost (left edge of
canvas) to innermost (adjacent to dosage matrix):

| Track | Source | Cell rendering |
|---|---|---|
| **K=3 PCA group** | `cl.labels` per L2 OR `cand.fish_calls[si].regime` per candidate | Solid color from `groupColor(k)` (existing v3 palette: g0 / g1 / g2). |
| **K=6 sub-band** | `cand.k6_substructure.parent_of_k6` + per-fish K=6 path | Solid color from K=6 palette. Empty (background) when region does not overlap an active candidate or no K=6 pass for the candidate. |
| **Quality** (`stripe_quality`) | `candidate_sample_coherence` layer if loaded; otherwise scrubber-computed via the v3.94 button (see "Stripe-quality button" below) | Categorical: `core` `#1B7837` (green), `peripheral` `#F4A582` (peach), `junk` `#D73027` (red), `unknown` `#BDBDBD` (grey). Empty when no source. |
| **GHSL** | `ghsl_panel`, mean across all available scales over the visible region | Continuous viridis ramp. v3.94 ships this and `Het` reading from the same primary-scale matrix; the two diverge automatically when a dedicated multi-scale GHSL aggregate or a separate het matrix ships. |
| **Het** | `ghsl_panel` primary scale only | Continuous viridis ramp, distinct visual treatment (slightly different ramp endpoints or single-color saturation). |

**One top-side annotation track**:

| Track | Source | Cell rendering |
|---|---|---|
| **Polarity** (`final_flip_decision`) | `candidate_marker_polarity` layer if loaded | Binary: `FALSE` `#2166AC` (blue, "matches dominant orientation"), `TRUE` `#D73027` (red, "marker flipped"). Empty when polarity layer not loaded — top track simply doesn't render. |

**Why two GHSL/het tracks today when they share a source.** Two reasons:
(1) future-proofing — when a dedicated het matrix or a multi-scale GHSL
aggregate ships, the two tracks already exist as separate visual
channels and just diverge automatically; (2) the GHSL primary scale by
construction *is* phased-SNP heterozygosity, so calling them the same
thing today is honest, but operationally they answer different
questions (GHSL = "how diverged is this sample's haplotype block from
others?", het = "how heterozygous is this sample at this locus?").
Surfaced as two tracks now to avoid a confusing rename later.

#### Region binding — two view modes share one renderer

The heatmap's region (`{ start_bp, end_bp }`) is one of two sources:

**(a) Candidate-bound (static).** Region = `cand.start_bp..cand.end_bp`.
Recomputed only when the active candidate changes. Equivalent to the R
reference (one heatmap per candidate, full candidate span).

**(b) Cursor-bound (live).** Region = the bp range covered by the 11
local-PCA windows centered on `state.cur` (i.e. `state.cur ± 5`,
inclusive). Recomputed every time `state.cur` changes — including when
arrow keys advance the L3 contingency carousel, since the carousel and
the scrubber share `state.cur` already. The window radius is **fixed
at ±5** in v3.94 (not user-adjustable yet); this matches the existing
`stepMode === 'win5'` arrow-key step.

**Marker cap is independent of region source.** Whether region comes
from (a) or (b), the marker-selection cascade applies the same way
(see "Marker selection within the visible region" below). Region
defines *where*, the cap defines *how many*.

#### Marker selection within the visible region

When the region contains more markers than the user-selected display
cap, the scrubber selects which to show, in this priority order:

1. Collect every marker whose position lies inside the region.
2. Drop markers exceeding a missingness threshold (default `0.20`).
3. Rank the remaining markers by `diagnostic_score` from
   `marker_catalogue.tsv` if loaded.
4. Otherwise, rank by per-marker dosage variance across the cohort
   (computed once per chunk, cached).
5. Take the top `N` markers, where `N` is the user-selected display
   cap. Default `N = 200`; toolbar offers `100 / 200 / 500` (hard cap
   500 — no option for more).

If the region has fewer than `N` markers passing the missingness
filter, show all available — never synthesize, never duplicate.

#### Stripe-quality button

The Quality track requires per-(candidate × sample) `stripe_quality`
classification (`core` / `peripheral` / `junk` / `unknown`). Two
sources:

1. **`candidate_sample_coherence` layer loaded** (preferred). Track
   reads directly from this layer's `stripe_quality` column.
2. **Layer not loaded.** A button on the heatmap toolbar — "Compute
   stripe quality (~1 s)" — runs the scrubber-side equivalent of
   STEP29's coherence algorithm on the currently-loaded dosage chunk.
   Result is cached on `cand.__stripeQuality` for the active
   candidate. Re-runs when the candidate or chunk changes. Computed
   silently for the active candidate; not pre-computed for all
   candidates.

The scrubber-side coherence algorithm is a faithful port of STEP29
lines 200–278: agreement_fraction with group-specific thresholds (HET
uses `0.55 / 0.40` cuts because expected intermediate; HOMO_1/HOMO_2
use `0.70 / 0.45`); `centroid_z` from PC1 score relative to the band's
centroid in MAD units; tier from the conjunction of coherence_class +
centroid_z. Implementation note: the algorithm is O(n_samples ×
n_informative_markers), where n_informative_markers is the top quartile
by |Δ_HOMO|. On 226 samples × ~50 informative markers this runs in
single-digit ms — the "~1 s" message accounts for chunk fetch + DOM
work, not the algorithm itself.

#### Placement (deliberately undecided)

The heatmap's home in the scrubber UI is **not specified by this
schema**. v3.94 will decide between:

- **Popup** (modal-like overlay, dismissable, similar to the v3.93 het
  popover but larger)
- **Docked strip** below the L3 contingency row on page 1 (always-on,
  follows the cursor when in cursor-bound mode)
- **Floating panel** (resizable, draggable, persistent across page
  changes)
- **Section on candidate page 2** for the static view + a separate
  placement for the live view

This is a UI decision that depends on what feels right when seen on
real data. The schema fixes the **visual contract** (tracks, colors,
sample order, region binding) but explicitly leaves the **container**
to implementation.

#### Redraw triggers

The Canvas heatmap MUST redraw on, and only on:

1. User changes `K` (re-clusters → row order changes).
2. User changes the row or column sort.
3. Region changes (candidate switch in static mode, `state.cur`
   change in live mode).
4. User changes display cap `N`.
5. Dosage chunk for a newly-visible region finishes loading.
6. `candidate_sample_coherence` layer finishes loading (Quality track
   appears).
7. `candidate_marker_polarity` layer finishes loading (Polarity top
   track appears).
8. Stripe-quality button completes (Quality track populates from
   scrubber-side compute).

Avoid redraw on hover, tooltip events, or any selection that doesn't
change the marker set or sort order. Hover affordances (e.g. "sample
CGA037, marker M0124, dosage 1") MUST be implemented as overlay
updates on the cached Canvas image data, never as full redraws.

In **cursor-bound mode**, redraws are debounced **150 ms** after the
last `state.cur` change to avoid thrashing during rapid arrow-key
pressing or scrubber drag.

#### Dosage chunk file shape (R emit shipped v3.95)

The R emit script `STEP_M04_emit_dosage_chunks.R` (shipped v3.95) writes
per-region chunks under a predictable URL pattern:

```
<chrom>_dosage_chunk_<region_start_bp>_<region_end_bp>.json
```

Chunks are aligned to L1 boundaries (so chunks line up with the
scrubber's natural windowing). Loaded on demand by the scrubber as the
region changes; LRU-cached in memory (cap ~50 chunks ≈ a few hundred
MB max for the 226-sample cohort).

Each chunk JSON:

```jsonc
{
  "chrom": "C_gar_LG28",
  "region_start_bp": 12000000,
  "region_end_bp": 14000000,
  "n_markers": 412,
  "n_samples": 226,
  "samples": ["CGA001", "CGA002", ...],
  "markers": [
    { "marker_id": "M0001", "pos_bp": 12018473,
      "diagnostic_score": 0.92, "missingness": 0.04 },
    ...
  ],
  "dosage": [
    [0, 1, 2, 0, 1, ...],   // marker 0, length n_samples (0/1/2 or -1 = NA)
    [1, 1, 0, 2, 1, ...],
    ...
  ]
}
```

#### `candidate_sample_coherence` layer (R emit shipped v3.95)

Per-(candidate × sample) row, faithful mirror of STEP29's
`candidate_sample_coherence.tsv` output. Emitted by
`STEP_M05_emit_step29_layers.R`:

```jsonc
{
  "candidate_sample_coherence": [
    {
      "candidate_id": 48,
      "sample": "CGA037",
      "coarse_group": "HOMO_1",          // 'HOMO_1' | 'HET' | 'HOMO_2'
      "agreement_fraction": 0.83,        // 0..1
      "coherence_class": "coherent",     // 'coherent' | 'intermediate' | 'discordant' | 'insufficient'
      "dist_to_centroid": 0.42,
      "centroid_z_score": 1.1,
      "stripe_quality": "core",          // 'core' | 'peripheral' | 'junk' | 'unknown'
      "tier_rule": "coherence=coherent;z=1.1;group=HOMO_1",
      "n_informative_markers": 47
    },
    ...
  ]
}
```

Detection: presence of `data.candidate_sample_coherence` as an array.
Layer name: `candidate_sample_coherence`. Activates the Quality track
in heatmap mode (a) static — the live mode (b) requires per-window
recompute against the live region's dosage, not stored coherence, so
it always uses the button-computed path.

#### `candidate_marker_polarity` layer (R emit shipped v3.95)

Per-(candidate × marker) row, faithful mirror of STEP29's
`candidate_marker_polarity.tsv` output. Emitted by
`STEP_M05_emit_step29_layers.R`:

```jsonc
{
  "candidate_marker_polarity": [
    {
      "candidate_id": 48,
      "chrom": "C_gar_LG28",
      "pos": 13782104,
      "marker_id": "M0124",
      "raw_mean_HOMO_1": 0.21,
      "raw_mean_HOMO_2": 1.78,
      "raw_mean_HET": 0.95,
      "delta_hom_mean": 1.57,
      "abs_delta_hom": 1.57,
      "polarity_L1_sign": 1,
      "polarity_L1_confidence": 1.0,
      "polarity_L1_ambiguous": false,
      "polarity_L1_reversed": false,
      "block_id": 7,
      "polarity_L2_sign": 1,
      "polarity_L2_confidence": 0.95,
      "polarity_L2_reversed": false,
      "final_flip_decision": false,
      "flip_source": "L2_block",          // 'L2_block' | 'L1_marker'
      "support_class": "strong"           // 'strong' | 'moderate' | 'weak' | 'ambiguous'
    },
    ...
  ]
}
```

Detection: presence of `data.candidate_marker_polarity` as an array.
Layer name: `candidate_marker_polarity`. Activates the top Polarity
track when present.

#### Failure modes (must handle gracefully)

- **Region with zero markers** → empty heatmap with a "no markers in
  this region" placeholder. No error.
- **Dosage chunk fetch fails** → toolbar shows "(loading failed)";
  rest of UI unaffected.
- **Scrub faster than chunks load** → 150 ms debounce; cancel
  in-flight fetches no longer for the current region.
- **Display cap larger than markers in region** → show all available.
- **Stripe-quality button pressed but no dosage chunk loaded yet** →
  button disabled with hint "load dosage first".
- **Active candidate switches while heatmap rendered in cursor-bound
  mode** → K=6 sub-band track may change content; redraw normally.
- **Cursor scrubs outside any active candidate** in cursor-bound mode
  → K=6 sub-band track shows empty / background; other tracks render
  normally; no error.

#### Why the specific numbers

- **±5 windows** ≈ 50 kb to 1 Mb of genome at typical local-PCA window
  sizes; matches the existing `stepMode === 'win5'` arrow step. Wider
  blurs fine structure; narrower lacks enough markers to fill the
  matrix.
- **200 default markers** × 226 samples at typical pane width gives
  ~3-px cells — readable per cell, no zoom needed.
- **500 hard cap** is the empirical break-point where K-change redraws
  start dropping frames on the 13" laptop hardware the scrubber runs
  on routinely.
- **150 ms debounce** matches the v3.91 click-debounce idiom and is
  short enough not to feel laggy during arrow-key scrubbing.

This contract is forward spec — the heatmap component does not yet
exist in the scrubber. v3.94 will implement it. The contract is
sufficient for the R emit script (`STEP_M04_emit_dosage_chunks.R`)
and the scrubber-side renderer to be built in parallel without
further design loops.

#### Hover affordances (v3.96, schema 2.7)

A one-line tooltip appears next to the cursor when hovering any cell
of the dosage matrix. Tooltip MUST be implemented as overlay updates
on the cached Canvas image data, never as full redraws. The renderer
already returns the layout fields needed for hit-testing
(`{ matX, matY, matW, matH, cellW, cellH }`); the tooltip pipeline
consumes those.

**Format.** Components space-`·`-space separated; absent fields
omitted (no `null` placeholders, no double separators):

```
sample · marker (bp) · dosage=N · group · quality · flipped
```

Example with all fields populated:

```
CGA037 · M0124 (12,018,473 bp) · dosage=1 · HOMO_1 · core
```

The `flipped` segment appears only when `final_flip_decision === true`.
The `quality` segment is omitted when value is `unknown` or absent.
The `group` segment is omitted when sample-group lookup returns null
(e.g. cursor-bound bare-genome mode without an active candidate).
NA dosage cells render `dosage=NA`; the `-1` sentinel encoding is
never exposed in user-facing strings.

**Annotation tracks** (left + top) do not currently tooltip — only the
dosage matrix proper. Hit-tests outside the matrix's `[matX, matY,
matX+matW, matY+matH)` half-open rectangle return null and the tooltip
hides. This is the v3.96 behaviour; annotation-track tooltips may be
added in a later increment if requested.

**Performance contract.**

- Cell-stable suppression: when the cursor stays in the same cell
  across multiple `mousemove` events, no DOM writes occur. The check
  is on `(marker_idx, sample_idx)` equality.
- RAF coalescing: at most one DOM write per frame. Multiple
  `mousemove` events between frames coalesce into a single tooltip
  update via `requestAnimationFrame`.
- Tooltip element is reused (one per canvas, lazily created on first
  mount). `pointer-events: none` on the tooltip prevents the cursor
  from flickering between hit/no-hit at cell boundaries that overlap
  the tooltip.

**Hover state lifecycle.**

The state object `state.__dosageHm` carries two hover contexts:
`hover_static` (page-2 candidate heatmap) and `hover_cursor` (L3
docked strip), each shaped `{ last_cell, raf_handle }`. Both reset
to `{ null, null }` whenever the heatmap redraws (the layout the
prior `last_cell` referred to is now stale).

**Position clamping.**

Default offset is +12 px right and +4 px below the cursor. When the
tooltip would overflow the canvas wrapper, it flips to left or above
respectively, then clamps to a 4 px margin from the wrapper bounds.

### Cross-references

- Phase 13 reads `fish_regime_calls.tsv` (schema §7) as ground truth for
  per-regime allele-frequency computation — the marker logic is meaningless
  without those calls.
- Phase 13 may consult `gene_cargo` (phase 12) to avoid designing primers
  inside annotated exons.
- Phase 13 may consult `boundaries_refined` (phase 5) to attempt
  breakpoint-proximal markers; falls back to internal-diagnostic when
  unavailable.
- The page activation in the scrubber is conditional on
  `marker_panel_summary` being in `_layers_present`. The other two layers
  are not strictly required for page rendering (the page can show
  "panel summary present, marker detail not loaded" if only the summary
  is dragged in).

---

## 11. Band diagnostics module (v3.92, schema 2.3)

For each PCA band/regime in the focal L2 envelope (or any contiguous
interval), the band diagnostics module computes per-band summary
statistics across up to five data layers. The result is a
**confounder/support check**: it tells the user whether a band is likely
a real structural haplotype regime, or whether it might be influenced
by ROH/inbreeding, unusual heterozygosity, local diversity, or GHSL
haplotype-divergence signal.

### Why "diagnostics", not "validation"

A band that fails one of these checks is not automatically wrong — but
it is worth pausing on. Real inversion regimes typically:

- Show some GHSL spread between bands (one arrangement carries longer
  haplotype blocks than the other).
- Show a θ/π shift if the regimes have different effective population
  sizes, recombination histories, or sample-size imbalances.
- Show elevated dosage heterozygosity in the **middle** band of a K=3
  fit when the inversion is heterozygous-on-the-middle (the classic
  inversion-Hardy-Weinberg pattern).
- Show no excess ROH overlap in any one band — ROH is a per-sample
  property, not a structural one, so a band with much higher ROH
  overlap suggests inbreeding-driven LD, not inversion-driven LD.

The diagnostics panel makes those expectations visible per candidate.

### Two render paths sharing one compute

`computeBandDiagnostics(cl, env, l2idx)` is the single source of truth.
It returns a structured object that drives both render paths:

- **Mini-chips** (always-visible per L2 tile in the L3 contingency
  panel). Per band, a row of four small colored rectangles in the
  band's color, white text inside: `GHSL <value>`, `θπ <value>`,
  `het <value>`, `ROH <pct>`. Quick visual scan across bands without
  expanding anything.
- **Full panel** (`<details>`-collapsible per L2 tile, default
  collapsed). 14-column table with all 12 metrics + flags column.

### The 12 metrics per band

| Metric                          | Source layer       | Notes |
|---------------------------------|--------------------|-------|
| `n_samples`                     | cluster labels     | Per-band sample count from `cl.labels`. |
| `mean_GHSL`, `median_GHSL`      | `ghsl_panel`       | Per-sample mean over panel windows whose midpoint falls inside `env.start_bp..env.end_bp`, then mean/median across samples in the band. Uses `panel.primary_scale`. |
| `mean_theta_pi`, `median_theta_pi` | `theta_pi_panel` | Same shape and aggregation as GHSL. **Layer planned, not yet emitted by R.** |
| `mean_dosage_heterozygosity`, `median_dosage_heterozygosity` | `ghsl_panel` (same scale) | By construction in `STEP_C04_snake3_ghsl_v6.R`, the GHSL primary-scale matrix is per-sample phased-SNP heterozygosity rate. We treat het as a separate metric for clarity even though it currently shares the same source. |
| `roh_overlap_pct`               | `roh_intervals`    | % of band's samples with at least one ROH span overlapping the interval. **Layer planned.** |
| `mean_ROH_fraction_of_interval`, `median_ROH_fraction_of_interval` | `roh_intervals` | Per-sample fraction = clipped ROH bp inside interval / interval length, capped at 1. Samples with no overlapping ROH contribute 0 (not NaN). **Layer planned.** |
| `mean_FROH_of_samples_in_band`, `median_FROH_of_samples_in_band` | `sample_froh` | Genome-wide FROH per sample, mean/median across band's samples. Independent of the interval. **Layer planned.** |

When a source layer is missing, the corresponding metrics are `null`,
which the renderer displays as `?`. **Missing data does not break the
app and does not cause spurious flag firing** — flags are only
evaluated against metrics that are present.

### Six flags

| Flag                  | Fires when                                                                                | Source needed |
|-----------------------|-------------------------------------------------------------------------------------------|---------------|
| `het_high`            | One band's `het_mean` > 1.5 × max of other bands' `het_mean`                              | het           |
| `middle_het_support`  | K=3, middle PC1-rank band has highest het AND > 1.2 × both flanking bands                 | het           |
| `GHSL_support`        | Spread `max(ghsl_mean) / min(ghsl_mean)` > 1.3 across bands. Marked on the max band.      | GHSL          |
| `theta_pi_shift`      | Same logic, on `theta_pi_mean`. Marked on the max band.                                   | θ/π           |
| `ROH_confounded`      | One band's `roh_overlap_pct` > 2 × max of other bands AND > 5 % absolute floor            | ROH           |
| `FROH_high`           | One band's `froh_mean` > 1.5 × max of other bands                                         | FROH          |

Flags attach to the band they describe. Reading a band's row tells you
every flag that fires on that band.

### `<chrom>_band_diagnostics.tsv` — sibling TSV (v3.92)

One row per (candidate × band). Emitted alongside the candidate
registry / fish_regime / interval_support TSVs when at least one
candidate carries band diagnostics.

| Column                   | Type    | Notes |
|--------------------------|---------|-------|
| `candidate_id`           | string  | Matches `candidate_registry.id`. |
| `band`                   | string  | `g0`, `g1`, `g2`, ... (PC1-ranked).
| `n_samples`              | int     | Per-band sample count. |
| `ghsl_mean`              | float   | `NA` if GHSL panel not loaded. |
| `ghsl_median`            | float   | `NA` if missing. |
| `theta_pi_mean`          | float   | `NA` if θπ panel not loaded. |
| `theta_pi_median`        | float   | `NA` if missing. |
| `het_mean`               | float   | `NA` if GHSL panel not loaded (shares source). |
| `het_median`             | float   | `NA` if missing. |
| `roh_overlap_pct`        | float   | 0–100 with two decimal places, `NA` if ROH layer not loaded. |
| `roh_frac_mean`          | float   | 0–1, `NA` if missing. |
| `roh_frac_median`        | float   | 0–1, `NA` if missing. |
| `froh_mean`              | float   | 0–1 (genome-wide), `NA` if FROH layer not loaded. |
| `froh_median`            | float   | 0–1, `NA` if missing. |
| `flags`                  | string  | Pipe-separated flag names, e.g. `het_high\|GHSL_support`. Empty when no flags. |
| `has_ghsl`               | int     | 0 / 1. Reflects `data_status.ghsl` at compute time. Lets consumers tell missing-data from genuine zero. |
| `has_theta_pi`           | int     | 0 / 1. |
| `has_het`                | int     | 0 / 1. (Same as `has_ghsl` until θπ panel ships a separate het channel.) |
| `has_roh`                | int     | 0 / 1. |
| `has_froh`               | int     | 0 / 1. |

**Numeric format note.** Because the metrics span six orders of magnitude
(`theta_pi` ~ 1e-3, `roh_overlap_pct` ~ 1e1), the TSV uses
`Number.toExponential(4)` for all metric values except `roh_overlap_pct`
(plain `.toFixed(2)`). This keeps the TSV machine-parseable without per-metric
locale-specific formatting.

### `band_diagnostics` field on candidate (JSON-mirror)

The full `computeBandDiagnostics` return object (with `bands` array and
`data_status`) is attached to each candidate at commit time, computed
at the candidate's `ref_l2`. Round-trips intact through the
candidate-list JSON export/import path.

### What the diagnostic does NOT replace

- **It is not a structural call.** A band with `GHSL_support` flag is
  more likely to be a structural regime; a band without is not
  necessarily wrong. Use in conjunction with the K=6 nesting verdict
  (§8) and the band continuity (NESTED / MIXED / CROSS_CUTTING /
  UNSTABLE).
- **It is not a fish-level karyotype call.** That is `fish_regime_calls.tsv`
  (§7).
- **It is not a population-level diversity scan.** That is the rolling
  `tracks` block (phase 1+2). Band diagnostics restricts to one
  interval and asks, "do the bands behave plausibly here?"

### Why the source layers are still "planned"

Two of the four source layers wired today are real
(`ghsl_panel` is exists, dosage het rides on the same matrix); the other
three (`theta_pi_panel`, `roh_intervals`, `sample_froh`) are speced and
detected by the scrubber but no R emit script has been written. When
those scripts ship, the panel automatically lights up — no scrubber-side
change needed. The contract here is sufficient for a parallel-chat R
implementation when the user is ready.

---

## 11.1. Het-shape sub-module (v3.93, schema 2.4)

A single-number heterozygosity ratio hides the **shape** of the
distribution. Inversion regimes have qualitatively different
heterozygosity shapes — the heterozygote band shows a tight peak near
0.5 (or wherever the ploidy makes the expected het cluster), while
homozygote bands show broader low-het distributions sometimes with
outlier tails or bimodality from sub-systems. Capturing shape requires
a histogram, not just a mean.

### What the sub-module adds

`computeBandDiagnostics` was extended to return a new `het_shape` field
alongside `bands` and `data_status`. Renderer plumbing has three
placements that all consume this one structure.

### `het_shape` field on the diag

```jsonc
{
  "n_bins": 16,
  "bin_lo": 0.0,
  "bin_hi": 1.0,
  "bin_edges": [0.0, 0.0625, 0.125, ..., 1.0],   // length n_bins+1
  "counts_per_band": [
    [0, 2, 8, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],   // band 0
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 8, 1],   // band 1 (HET-like)
    [0, 0, 4, 5, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]    // band 2
  ],
  "support_ratio": 5.667,
  "support_kind": "middle_vs_flanks",   // or 'max_min_spread' or 'none'
  "support_passes": true,                // ratio >= 1.5
  "support_marginal": false              // ratio in [1.2, 1.5)
}
```

### The support ratio

A single quick-glance summary number that rolls up the K-band
heterozygosity spread.

- **K = 3** uses `support_kind = "middle_vs_flanks"`:
  `median(g1) / mean(median(g0), median(g2))`. This is the
  inversion-Hardy-Weinberg test in disguise — does the middle PC1-rank
  band carry a heterozygosity peak relative to the homozygote flanks?
- **K ≠ 3 (or K=3 fallback when middle/flanks medians missing)** uses
  `support_kind = "max_min_spread"`: `max(median) / min(median)` across
  bands.
- **support_passes** at `ratio ≥ 1.5` (✓ glyph, strong signal)
- **support_marginal** at `1.2 ≤ ratio < 1.5` (?? glyph, weak signal)
- **No glyph** otherwise (or `none` support_kind when fewer than 2 bands
  have het data)

### Three placements

The renderer ships three views; all read from the same `het_shape`:

1. **Inline ridgeline column** (placement A) — small SVG sparkline
   (~80×14 px) in the band-diagnostics `<details>` table inside each
   L3 contingency tile. One row per band. Visible only when the user
   expands the panel. Tiny but enough to see narrow vs broad vs
   bimodal.
2. **FIG_C07-style stacked ridgeline figure** (placement B) — full
   readable figure on the candidate page (page 2), styled like the
   existing `FIG_C07 — Heterozygosity by group` plot. Per-band median
   tick on the baseline; X axis 0..1 with 0.0 / 0.25 / 0.5 / 0.75 /
   1.0 labels. Computed at the candidate's `ref_l2`. Falls back to
   on-the-fly recompute when a candidate predates v3.92 (no
   `band_diagnostics` saved on the object).
3. **Hover-popover from the het mini-chip** (placement C) — clicking
   any `het` pill in the L3 tile mini-chips row pops a floating panel
   with the same full ridgeline figure. Click-outside or `×` button
   dismisses. No persistent screen real-estate cost.

### One-line summary text

`Het: 5.4× ✓ · g0=0.15 | g1=0.84 | g2=0.16` — rendered above the
`<details>` table when the het layer is loaded, and inside the
candidate-page section. Same data the popover uses (no `<details>`
expand needed for the line).

### Shared SVG ridgeline kernel

`_hetRidgelineSvg(binCounts, color, width, height)` is the single
shape-drawing primitive. Builds an area path under the histogram +
top-edge stroke, with band-color fill at 0.55 opacity. Used at 80×14
for placement A, embedded at larger size inside `_hetRidgelineFigureHtml`
for placements B and C. Ratio of width to height is left to the caller —
inline cells stay tiny; figure rows are ~36 px tall with stacked
baselines.

### Histogram round-trip in TSV

The sibling TSV (`<chrom>_band_diagnostics.tsv`) gained 4 columns at the
end so downstream R code can re-render the ridgeline without recomputing
from raw GHSL panel data:

| Column                | Type   | Notes |
|-----------------------|--------|-------|
| `het_support_ratio`   | float  | Same value as `het_shape.support_ratio`. `NA` when not computed. |
| `het_support_kind`    | string | `middle_vs_flanks` \| `max_min_spread` \| `none`. |
| `het_support_passes`  | int    | 0 / 1. Reflects `support_passes`; `support_marginal` is not separately encoded — interpret a `support_passes=0` row alongside the ratio to recover marginal status (`1.2 ≤ ratio < 1.5`). |
| `het_hist_bins`       | string | Pipe-separated 16 integers, `0\|2\|0\|...` covering `[0, 1]` in 16 equal bins. Empty when het not loaded for this candidate. |

**Total TSV columns are now 24** (was 20 in v2.3).

### Numerical conventions

- 16 bins on `[0, 1]` is fixed for v3.93. The heterozygosity domain is
  bounded by construction (it's a rate), so a fixed extent works
  cleanly. Future versions may extend (e.g. 32 bins or auto-binning)
  if the panel resolution warrants — but downstream consumers should
  read `het_shape.n_bins` and `het_shape.bin_edges`, not assume 16.
- All bands share the same bin grid, so per-band counts are directly
  comparable and stackable.
- The Y-axis of the rendered ridgeline normalizes per-band by the
  band's own max bin count (placement A inline) or by the global max
  across bands (placement B / C figure) — the former optimizes for
  shape-comparison-within-row; the latter optimizes for sample-count
  comparison across bands. This is a deliberate dual choice; both have
  legitimate interpretive uses.

### Threshold rationale

The 1.5×/1.2× thresholds for `support_passes` and `support_marginal`
were chosen empirically from FIG_C07-equivalent plots in the
manuscript: candidates that read visually as "real inversion regimes"
sit comfortably above 1.5×, while genuinely ambiguous candidates fall
in the 1.2–1.5× band. This mirrors the existing `middle_het_support`
flag in §11 (which fires at K=3 middle band > 1.2× both flanks and is
preserved unchanged for backwards compatibility).

---

## 12. Boundary zone refinement (v3.97, schema 2.8)

After candidates are promoted on the Candidate Builder (page 2), the
**Boundaries page** (page 11 internally; displayed as tab "3
boundaries", wedged between candidate-focus and catalogue) refines each
promoted candidate's `[start_bp, end_bp]` interval into approximate
left and right *boundary zones* using multiple evidence tracks.

### Terminology contract — CRITICAL, locked

The schema enforces three terms with strict semantic boundaries.
Implementations MUST NOT conflate them.

| Term | Meaning | When used |
|---|---|---|
| **boundary zone** | An *interval* `[zone_start_bp, zone_end_bp]` of plausible breakpoint locations, derived from population-genetic signal transitions (PCA, dosage, FST, GHSL, etc.). | Default. Always emitted when boundary refinement runs. |
| **exact breakpoint** | A single bp position with sub-100bp resolution. | Only when junction-level evidence exists (split reads at a specific position, or an assembly junction). NEVER inferred from population statistics alone. |
| **SV anchor** | A DELLY/Manta/etc. SV call near the boundary zone. Adds confidence; does NOT alone justify "exact". | Bonus signal — when its bp position falls inside the auto-detected zone, confidence increases. When SV anchor is the *only* evidence beyond population signal, status is `SV_supported` not `junction_supported`. |

The status enum on each candidate encodes the strongest available
evidence:

```
breakpoint_status :=
  'boundary_zone_only'   -- population signal only; default for all auto-detected zones
  'SV_supported'         -- SV anchor (DELLY/Manta INV/BND/DEL) falls inside the zone
  'junction_supported'   -- split-read or assembly junction at sub-100bp resolution
```

The candidate-level field is the *minimum* of the two edges' statuses
(the candidate is `junction_supported` only if both edges are). Per-edge
status lives in `boundary_left.support_class` (orthogonal axis: how
much *track* support, not what *kind* of evidence).

### Why "boundary zone" not "exact breakpoint"

Local PCA, dosage, FST, GHSL all report population-genetic signals
that change *across* a transition zone of variable width — typically
5–50 kb depending on recombination suppression strength. They CANNOT
pinpoint a single bp. Reporting an "exact breakpoint" from these
signals would be a category error.

Exact breakpoints come from:

- Split-read alignment at the breakpoint (BWA-MEM soft-clipped reads
  with mate at the inversion's other end)
- Assembly junctions in long-read assemblies (PacBio HiFi, ONT)
- Sanger sequencing of PCR products spanning the junction

When that evidence ships, the schema upgrades `breakpoint_status` to
`junction_supported` and an additional field
`boundary_left.exact_breakpoint_bp` (integer) appears alongside the
zone. Until then, all `_bp` fields are zone-bounded.

This terminology discipline is enforced at two layers:

- TSV column names use `*_boundary_zone_*` (not `*_breakpoint_*`)
- UI strings use "boundary zone" not "breakpoint" — except in the
  `breakpoint_status` field name itself, which describes what *kind*
  of breakpoint evidence we have (including `boundary_zone_only` for
  "none beyond zone")

### `boundary_evidence` layer (optional R-side input — shipped via STEP_M06)

When R-side has precomputed boundary-relevant signals (FST, theta-pi,
discordant-pair pileups, SV anchors), they ship as a new layer.
**Emitted by `STEP_M06_emit_boundary_evidence.R`** (post-v3.98); the
v3.97 scrubber detects and consumes the layer when present, including
optional `theta_pi_het` (third regime track):

```jsonc
{
  "boundary_evidence": [
    {
      "candidate_id": 48,
      "chrom": "C_gar_LG28",
      "scan_start_bp": 11000000,        // candidate ± scan_radius
      "scan_end_bp":   15000000,
      "scan_window_bp": 5000,           // bp resolution of arrays below
      "tracks": {
        "fst": [0.02, 0.03, 0.05, 0.18, 0.21, ...],         // length = (scan_end-scan_start)/scan_window
        "theta_pi_homo1": [0.0014, 0.0013, ...],
        "theta_pi_het":   [0.0021, 0.0019, ...],            // optional; populated when g1 has >= 2 fish
        "theta_pi_homo2": [0.0011, 0.0012, ...],
        "discordant_pair_pileup": [3, 5, 12, 89, 102, ...],  // count per scan window
        "sv_anchors": [
          { "kind": "DELLY_INV", "ct": "3to3", "pos_bp": 12345670, "qual": 80 },
          { "kind": "Manta_INV5", "pos_bp": 14250130, "qual": 95 }
        ]
      }
    }
  ]
}
```

Detection: `Array.isArray(data.boundary_evidence)` AND first row has
`candidate_id` and `tracks`. Layer name: `boundary_evidence`. The
boundaries page works **without** this layer — it falls back to
in-scrubber scoring from existing layers (precomp, GHSL panel, dosage
chunks, candidate_marker_polarity). The layer is purely additive;
presence increases auto-propose confidence.

The `scan_window_bp` resolution is intentionally coarser than the
local-PCA window step (typical 5–10 kb) — boundary scoring benefits
from already-smoothed input that the scrubber doesn't re-blur further.

### `bam_evidence` layer (optional R-side input — PLANNED, schema-reserved 2.11)

> **Status: schema-reserved only.** No R-side emit yet. The vocabulary is
> locked here so that scrubber UI scaffolding, R-side `STEP_M07_emit_bam_evidence.R`,
> and an embedded igv.js viewer can each be implemented independently
> without name collisions.
>
> **Motivation.** Reviewer Quentin noted in turn-13 work (April 2026) that
> reviewers familiar with IGV-style inspection of inversion calls expect
> two specific signals to be visualizable: (1) the **coverage drop at
> the breakpoint**, and (2) **discordant-pair colored read clusters**.
> Both are derivable from the existing 226-sample 9× Illumina BAMs on
> LANTA but are not currently computed. This layer reserves names + bin
> conventions for those signals so they can be added incrementally.
>
> **Design philosophy.** Per-base resolution is unrealistic for 226
> samples × ~30 candidates × ±50 kb scan = 300 Mb of dense values. Instead
> we bin to **1 kb resolution** (10× finer than the existing
> `boundary_evidence.scan_window_bp = 5000`), which preserves the sharp
> breakpoint signal (typical inversion breakpoint is bracketed within
> ±500 bp by split-read evidence) while keeping JSON sizes manageable.
> Per-sample arrays are NOT stored here — only **cohort-aggregate** per-bin
> counts. Per-sample inspection happens via the embedded igv.js viewer
> (planned, see "IGV.js embedding" below) which reads the actual BAM slice.

```jsonc
{
  "bam_evidence": [
    {
      "candidate_id": 48,
      "chrom": "C_gar_LG28",
      "scan_start_bp": 11000000,
      "scan_end_bp":   15000000,
      "scan_window_bp": 1000,             // 1 kb bin resolution (FINER than boundary_evidence's 5 kb)
      "n_samples": 226,                   // cohort size that contributed; for normalization
      "expected_coverage": 9.2,           // mean coverage across cohort, used for `coverage_dip` z-score
      "expected_tlen_mean": 425,          // library insert size mean (for tlen-anomaly normalization)
      "expected_tlen_sd":   88,           // library insert size SD
      "tracks": {
        // ── COVERAGE TRACKS ─────────────────────────────────────────
        "coverage":       [9.1, 9.0, 8.9, 1.2, 1.0, 9.3, ...],   // mean cohort coverage per 1 kb bin
        "coverage_dip":   [0.0, 0.0, 0.1, 7.7, 7.8, 0.0, ...],   // z-score of (expected_coverage - observed); peaks at breakpoints

        // ── DISCORDANT PAIR ORIENTATION TRACKS ──────────────────────
        // Counts of read pairs whose inferred orientation disagrees with the
        // expected FR (forward-reverse) orientation typical of paired-end
        // Illumina libraries. The **cluster of FF or RR pairs** at a position
        // is the most inversion-specific signal — deletions show RF, insertions
        // show short FR, only inversions reliably produce FF/RR clusters at
        // breakpoints. Counts are summed across the cohort (so a 226-sample
        // cohort with one FF pair per sample at a breakpoint = 226 in that bin).
        "discordant_orient_FF": [0, 0, 0, 178, 195, 12, ...],    // FF (both forward) — peaks at right breakpoint of inversion
        "discordant_orient_RR": [0, 0, 0, 12, 195, 178, ...],    // RR (both reverse) — peaks at left breakpoint of inversion
        "discordant_orient_RF": [0, 1, 0, 4, 3, 2, ...],         // RF (deletion-like; informational only — usually flat for inversions)
        "tlen_anomaly":        [0, 0, 0, 156, 168, 8, ...],      // count of pairs with |TLEN - expected_tlen_mean| > 3·expected_tlen_sd

        // ── SPLIT-READ TRACKS ───────────────────────────────────────
        // Reads with the SA tag (supplementary alignment) — meaning a single
        // read whose two halves mapped to different positions. These are the
        // sharpest breakpoint signal Illumina can give (peak narrows to
        // ±50 bp around the actual junction). Both endpoints of the split
        // contribute: `split_read_density` peaks at BOTH the left and right
        // breakpoints (split reads cross the junction in both directions).
        "split_read_density":  [0, 0, 1, 234, 12, 178, ...],     // count of reads with SA tag per bin
        "clip_density":        [0, 0, 2, 187, 8, 142, ...],      // count of reads with soft/hard clip > 20 bp per bin (often co-localizes with split_read_density)

        // ── MAPPING QUALITY TRACK ───────────────────────────────────
        "mapq_drop":           [0.0, 0.0, 0.05, 0.65, 0.7, 0.05, ...],  // fraction of reads with MAPQ < 20 per bin (peaks where reference repeats confuse mapping; helps DOWN-WEIGHT false positives in repetitive regions)

        // ── COMBINED INVERSION-SPECIFIC TRACK ───────────────────────
        // Convenience composite: rate of FF+RR pairs vs. expected FR rate
        // at this bin. Locked formula: (FF + RR) / (FF + RR + RF + FR) where
        // FR is inferred from coverage and expected_tlen. Values 0..1.
        // 0 = all pairs in expected FR orientation; 1 = all pairs inverted.
        // This is the single most useful track for boundary scoring — peaks
        // at BOTH breakpoints of an inversion AND nowhere else (deletions
        // and insertions don't elevate it).
        "pair_orient_inv_rate": [0.01, 0.01, 0.02, 0.78, 0.85, 0.04, ...]
      }
    }
  ]
}
```

**Detection.** `Array.isArray(data.bam_evidence)` AND first row has
`candidate_id` and `tracks` AND tracks include at least one of
`coverage_dip`, `pair_orient_inv_rate`, or `split_read_density`. Layer
name: `bam_evidence`. The boundaries page works **without** this layer
— same fallback rule as `boundary_evidence`: presence is purely additive,
absence does not block boundary refinement.

**Track polarity (locked).** Each new track gets a polarity entry in
`BOUNDARY_TRACK_POLARITY` per the convention "+1 means rises INSIDE
the inversion, −1 means falls INSIDE":

| Track                    | Polarity | Where it peaks                      | Inversion-specificity |
|--------------------------|---------:|-------------------------------------|-----------------------|
| `coverage_dip`           | +1       | AT both breakpoints (~500 bp)       | low (any SV)          |
| `discordant_orient_FF`   | +1       | AT right breakpoint                 | **high** (inversion-specific) |
| `discordant_orient_RR`   | +1       | AT left breakpoint                  | **high** (inversion-specific) |
| `discordant_orient_RF`   | +1       | AT both breakpoints (informational) | low (deletion-like)   |
| `tlen_anomaly`           | +1       | AT both breakpoints                 | medium                |
| `split_read_density`     | +1       | AT both breakpoints (sharpest peak) | high                  |
| `clip_density`           | +1       | AT both breakpoints                 | high                  |
| `mapq_drop`              | −1       | INSIDE repetitive regions           | **down-weighter**     |
| `pair_orient_inv_rate`   | +1       | AT both breakpoints                 | **highest** (single best track) |

The `mapq_drop` track is the **only down-weighter** in the BAM evidence
set — it's used to penalize boundary scores in regions of poor
mappability (the inversion is more likely to be a mapping artifact than
a real call). The others are all up-weighters in the standard direction.

**Provisional weights (NOT YET LOCKED).** When R-side ships and the
combined scoring is recalibrated, weights for the new tracks fold into
`BOUNDARY_TRACK_WEIGHTS` summing to 1.0 with the existing 12 tracks.
Suggested starting values pending real-data calibration on the 226-sample
LG28 cohort:

```
pair_orient_inv_rate:   0.10   ← single most useful BAM-derived signal
split_read_density:     0.08
coverage_dip:           0.06
discordant_orient_FF:   0.04
discordant_orient_RR:   0.04
clip_density:           0.04
tlen_anomaly:           0.03
mapq_drop:              0.03
discordant_orient_RF:   0.01
```

(sum = 0.43; existing 12 tracks would be renormalized down to sum = 0.57
when bam_evidence is loaded). Final weights are locked at v3.x scrubber
release post-calibration; until then the scrubber's
`_renormalizeBoundaryWeights()` handles arbitrary subsets.

**Computation contract.** The R-side `STEP_M07_emit_bam_evidence.R`
(planned) follows the same idempotency pattern as STEP_M04/M05/M06: takes
a candidate list + path to per-sample BAMs (or a merged cohort BAM if
preferred) + the `<chrom>_phase14_bam_evidence.json` output path. Per-bin
counts use `samtools view` flag filters:

```bash
# Coverage track (mosdepth; already in pipeline for callable BED)
mosdepth --by 1000 --no-per-base out.coverage.regions.bed.gz cohort.bam

# FF discordant pairs (samtools view flag combinations)
samtools view -f 0x40 -F 0x10 ... | awk 'mate-also-forward' | bin1kb

# RR discordant pairs
samtools view -f 0x10 -f 0x40 ... | awk 'mate-also-reverse' | bin1kb

# Split reads (SA tag)
samtools view -F 0x100 cohort.bam | grep -c '\bSA:Z:' | bin1kb

# Clip density (CIGAR contains S or H ≥ 20 bp)
samtools view ... | awk 'cigar matches /[2-9][0-9]+[SH]/' | bin1kb

# MAPQ drop (low-quality reads)
samtools view -q 0 -Q 20 ... | bin1kb
```

The expected-value normalization fields (`expected_coverage`,
`expected_tlen_mean`, `expected_tlen_sd`) come from a one-pass over a
clean genomic region (typically 10 Mb of euchromatic single-copy
sequence) at the start of `STEP_M07`; they're per-cohort constants that
let `coverage_dip` and `tlen_anomaly` use z-score-style normalization.

### IGV.js embedding (PLANNED, schema-adjacent)

> **Status: schema-adjacent placeholder.** Not part of the JSON contract;
> documented here because boundary inspection is incomplete without the
> ability to render the actual BAM slice. Implementation deferred to a
> later turn (likely v4.x).

The boundaries page (page 11 in the scrubber) reserves a panel below
the existing tracks for an embedded **igv.js** browser. When rendered,
it shows:

- **Reference track** (the cohort's haplotype-resolved gariepinus
  reference, served as `.fasta + .fasta.fai`)
- **Per-sample alignment slices** for the candidate's scan region
  (`scan_start_bp ± 50 kb`), pre-extracted as small per-candidate BAMs
  by a planned `STEP_M08_extract_region_bams.sh`
- **Coverage track** computed live by igv.js from the slice
- **Variant track** rendered from the existing schema's `boundary_left`
  and `boundary_right` zones as a custom IGV track (BED format)
- **DELLY+Manta SV anchors** rendered as a custom IGV track from the
  existing `sv_anchors_in_zone` field on each candidate

igv.js consumes BAM via byte-range HTTP or local-file `<input>`. The
**three deployment options** (decided at integration time):

1. **Local-file mode**: user picks BAM + BAI files via file input; igv.js
   reads them in-browser. Works for power users; slow on big files.
2. **Local-server mode**: a tiny `serve.py` runs on LANTA and the user
   port-forwards via SSH. Cleanest for the cohort-wide case but adds an
   external dependency.
3. **Per-candidate slice BAMs**: `STEP_M08_extract_region_bams.sh`
   pre-extracts ±50 kb slices per candidate; ships alongside the
   chrom JSON. **Recommended default** — slot into the existing JSON
   delivery flow with no extra infrastructure.

The igv.js library is loaded via CDN (`https://cdn.jsdelivr.net/npm/igv@2.x/dist/igv.min.js`)
or vendored into `pca_scrubber_v3.html` as an inline script (size ~600
KB; would push HTML to ~1.7 MB which is acceptable). No data flows
through any external service; the CDN is loaded once and IGV reads
files locally from then on.

The IGV.js panel reads the same `bam_evidence.scan_start_bp` /
`scan_end_bp` for its initial viewport so the view is consistent with
the computed tracks above it.

### Per-candidate boundary fields (extends `candidates_registry`)

Each promoted candidate gains nested boundary records on its JSON
representation (and flattened columns in the TSV mirror):

```jsonc
{
  "candidate_id": 48,
  // ... existing fields ...

  "boundary_left": {
    "zone_start_bp": 11820000,
    "zone_end_bp":   11860000,
    "score":         0.78,            // 0..1; weighted sum of contributing tracks
    "support":       ["pca_drop", "dosage_transition", "ghsl_step", "polarity_change"],
                                       // sorted, deduped; subset of TRACK_NAMES
    "support_class": "strong",        // 'strong'|'moderate'|'weak'|'ambiguous'
    "source":        "auto",          // 'auto'|'manual'|'auto_plus_manual'
    "sv_anchors_in_zone": [           // copies from boundary_evidence.tracks.sv_anchors
      { "kind": "DELLY_INV", "pos_bp": 11842300 }
    ],
    "notes": "",
    "set_at":  "2026-04-29T14:32:11+0700",
    "set_by":  "scrubber_auto"        // or 'scrubber_manual' for E/F overrides
  },

  "boundary_right": { /* same shape */ },

  "breakpoint_status": "boundary_zone_only",   // candidate-level min of both edges
  "boundary_notes":    ""                       // optional free text per candidate
}
```

**TSV mirror columns** (added to `REGISTRY_TSV_COLUMNS` after the
`subband_nesting_status` block, before `qc_status`):

```
'left_boundary_zone_start',          // integer bp; '' if unset
'left_boundary_zone_end',
'left_boundary_score',               // 0..1, 4dp; '' if unset
'left_boundary_support',             // pipe-separated track names
'left_boundary_support_class',       // strong|moderate|weak|ambiguous|''
'left_boundary_source',              // auto|manual|auto_plus_manual|''
'right_boundary_zone_start',
'right_boundary_zone_end',
'right_boundary_score',
'right_boundary_support',
'right_boundary_support_class',
'right_boundary_source',
'breakpoint_status',                 // boundary_zone_only|SV_supported|junction_supported|''
'boundary_notes',
```

That's **14 new columns**. Total registry width was 31 (post-v3.93);
becomes 45. Backward compatibility: missing values emit as `''` (empty
string, NOT `'NA'`) so tools that parse "header row defines shape" don't
break.

### `support_class` derivation

Confidence on each edge comes from how many evidence tracks back the
proposed boundary zone. Tracks whose contribution exceeded a per-track
threshold get listed in `support[]`. `support_class` is derived from
`|support|` (the count) AND the weighted `score`, because an edge with
one very strong track is qualitatively different from an edge with
three moderate tracks:

```
support_class :=
  'strong'      |support| >= 3   AND  score >= 0.60
  'moderate'    |support| == 2   OR  (|support| >= 3 AND 0.40 <= score < 0.60)
  'weak'        |support| == 1   OR  (|support| >= 2 AND score < 0.40)
  'ambiguous'   |support| == 0
```

### `TRACK_NAMES` enum (canonical set)

Values that may appear in `support[]`, with their **polarity** — `+1`
means "rises INSIDE the inversion" (so a rising step at the boundary
is a left-edge-like signal); `-1` means "falls inside" (the step gets
sign-flipped before the combined sum, so a falling step is correctly
treated as edge-like for ALL tracks):

```
'pca_drop'                +1   |Δ PVE1| or |Δ PC1| Z-score across the edge
'dosage_transition'       +1   |Δ mean dosage| between flanking windows
'band_continuity_drop'    -1   precomp band-continuity DROPS inside (regimes recluster)
'polarity_change'         +1   candidate_marker_polarity sign flip near edge
'similarity_edge'         -1   precomp similarity DROPS inside (haplotypes diverge)
'ghsl_step'               +1   |Δ ghsl_div_median| from ghsl_panel
'het_transition'          +1   |Δ het rate| from ghsl_panel primary scale
'fst_edge'                +1   FST between regimes is HIGH inside
'theta_pi_step'           -1   theta-pi within regime DROPS inside (suppressed recombination)
'discordant_pile'         +1   discordant-pair pileup spikes AT boundary
'sv_anchor'               +1   SV anchor density spikes AT boundary
'snp_density_quality'     —    QUALITY FILTER ONLY — never appears in support[]
```

The polarity convention solves a real-data issue: tracks like band
continuity and theta-pi *drop* inside the inversion because of
recombination suppression, while tracks like PCA and GHSL *rise*. The
algorithm sign-flips falling-inside tracks' steps so all four `support[]`
contributions add coherently into the combined-left and combined-right
summations.

`snp_density_quality` is a filter, not a contributor: when SNP density
falls below threshold within the candidate scan region, auto-propose
flags those windows as low-quality and excludes them from edge
detection. It is recorded as a quality flag on the boundary record but
NEVER appears in the `support[]` list.

### Scan region

Default scan region: `[start_bp - 1.5 Mb, end_bp + 1.5 Mb]`, clamped to
chromosome bounds. Configurable via toolbar in v3.97 (1 / 2 / 5 Mb).
The candidate's interior `[start_bp, end_bp]` IS scanned (so an inner
edge that's actually the true boundary can be detected when the
committed candidate was over-large), but flagged with an
"interior_edge" note when the proposed zone falls inside the
candidate's pre-existing interval.

When the candidate spans more than 3 Mb, the scan region expands to
`start_bp - 0.5 * span, end_bp + 0.5 * span` to keep the interior /
flanking ratio sensible.

### Auto-propose algorithm (scrubber-side)

For each candidate `c` with promoted `[start_bp, end_bp]`:

**Step 1 — Build per-track score arrays.** For each available track,
compute a per-window score over the scan region. Local-PCA window
grid is the natural unit (matches `state.data.windows`).

**Step 2 — Smooth scores with rolling median (width 3 windows).**
Suppresses single-window noise. Width 3 chosen because typical
local-PCA window step is 20 markers ≈ 1 kb; smoothing at 3 windows
≈ 3 kb ≪ scan_window_bp from the optional R-side layer.

Smooth the *score* (not the step) — smoothing the step array would
erase clean single-window transitions entirely (median of `[0, spike, 0]`
= 0), which is the opposite of what we want.

**Step 3 — Per-track signed step on the smoothed series:**

```
step[t][w] = smoothed[t][w+1] - smoothed[t][w]
```

**Step 4 — Per-track normalized magnitude (MAD scaling).** Divide each
step by the track's median absolute deviation over the scan region.
Tracks become comparable on a unitless 0..∞ scale where steps > 2 are
"interesting".

**Step 5 — Combined score per window per side:**

```
left_combined[w]  = Σ_t  weight[t] * max(0,  step[t][w])
right_combined[w] = Σ_t  weight[t] * max(0, -step[t][w])
```

Default `weight` (sums to 1.0):

```
pca_drop:               0.20
dosage_transition:      0.18
band_continuity_drop:   0.14
ghsl_step:              0.12
polarity_change:        0.10
het_transition:         0.06
similarity_edge:        0.05
fst_edge:               0.05    (only when boundary_evidence loaded)
theta_pi_step:          0.04    (only when boundary_evidence loaded)
discordant_pile:        0.04    (only when boundary_evidence loaded)
sv_anchor:              0.02    (only when boundary_evidence loaded)
```

When optional tracks are absent, their weights are removed and the
remaining weights are renormalized to sum to 1.0.

**Step 6 — Pick edge windows.** Strongest left-edge window in the left
half of the scan region; strongest right-edge window in the right half.
The two halves are searched independently. Each half's search excludes
the outermost 10% of the scan region (avoids edge artifacts at scan
boundaries).

**Step 7 — Build boundary zones.** Each picked window `w*` becomes a
zone `[windows[w*-radius].start_bp, windows[w*+radius].end_bp]` where
`radius = 5` windows by default. This matches the `state.cur ± 5`
cursor radius used elsewhere — consistent mental anchor.

**Step 8 — Populate `support[]`.** For each track `t` whose contribution
to `combined[w*]` exceeds 0.5 × the median nonzero contribution within
the scan, append `t` to `support[]`. Sort and dedupe.

**Step 9 — Compute `score` and `support_class`** per the formulas above.
Emit `boundary_left` and `boundary_right`. Set `breakpoint_status` to
`boundary_zone_only`. Auto-propose NEVER sets `SV_supported` or
`junction_supported` — the user must explicitly promote to those
statuses via the UI to acknowledge they have reviewed the underlying
evidence.

**Step 10 — SV anchor bonus.** When `boundary_evidence.tracks.sv_anchors`
contains an SV with `pos_bp` inside the auto-detected zone, copy it
into `boundary_left.sv_anchors_in_zone` (or right).

### Manual override (page-scoped hotkeys)

Hotkeys are page-scoped — they fire only when the boundaries page is
active and no text input has focus.

| Key | Action |
|---|---|
| **E** | Set `boundary_left` zone centered on `state.cur`, radius=5 windows. `source` becomes `manual` (or `auto_plus_manual` if right was auto-set). `support[]` is computed fresh against the user-chosen window using the same step-magnitude rules. |
| **F** | Symmetric — `boundary_right`. |
| **B** | Persist current boundary annotation (commit staging state into `state.candidates[i]` so it survives navigation). Auto-detected zones are *staged* but not *committed* until the user explicitly accepts. |
| **R** | Reset both `boundary_left` and `boundary_right`; `breakpoint_status` reverts to `''`. |

The page also provides explicit buttons for users who prefer mouse:

- "Auto-propose"           — runs the algorithm (re-runs if already done)
- "Accept auto boundaries" — stages → commits both edges (= B after auto)
- "Override left at cursor"  — equivalent to E
- "Override right at cursor" — equivalent to F
- "Reset boundaries"       — equivalent to R
- "Save"                   — equivalent to B
- `breakpoint_status` dropdown — `boundary_zone_only` /
  `SV_supported` / `junction_supported`. Defaults to
  `boundary_zone_only`. User manually promotes to stronger statuses
  when they have reviewed the evidence.

### Display

The boundaries page shows the candidate's scan region with stacked
evidence tracks on a shared bp axis:

| Track | Source | Always shown? |
|---|---|---|
| Local PCA (PVE1 + PC1 Z-score) | precomp | yes |
| Dosage heatmap (compact strip) | dosage_chunks | when loaded |
| Band continuity | precomp | yes |
| Marker polarity | candidate_marker_polarity | when loaded |
| GHSL change | ghsl_panel | when loaded |
| Heterozygosity | ghsl_panel | when loaded |
| FST | boundary_evidence | when loaded |
| Theta-pi (per regime) | boundary_evidence | when loaded |
| Discordant-pair pileup | boundary_evidence | when loaded |
| SV anchors | boundary_evidence | when loaded |
| Combined boundary score | computed scrubber-side | yes |

Proposed left/right boundary zones drawn as **shaded vertical bands**
across all tracks, color-coded by `support_class`:

| support_class | Hex | Opacity |
|---|---|---|
| strong    | `#1B7837` (green) | 0.20 |
| moderate  | `#F4A582` (amber) | 0.18 |
| weak      | `#FDDBC7` (peach) | 0.16 |
| ambiguous | `#BDBDBD` (grey)  | 0.10 |

SV anchors inside zones drawn as small triangles above the dosage
heatmap track. The candidate's pre-existing `[start_bp, end_bp]`
drawn as faint dashed vertical lines on each side — the *anchor* the
boundaries refine *from*.

The dosage heatmap on this page is the **same renderer as page 2** —
`drawDosageHeatmap` with the candidate scan region bound, capped at
the user-selected marker count. This means hover tooltips work
identically (v3.96 spec) and the visual idiom is the same across
pages.

### Failure modes (must handle gracefully)

1. **No layers loaded beyond precomp.** Auto-propose runs with the
   minimum tier (PCA drop only, possibly with GHSL/dosage if those
   load). `support_class` will be `weak` or `ambiguous`. UI shows a
   "limited evidence" notice with the list of layers that would
   improve the result.
2. **Scan region clipped at chromosome bounds.** Zones near chrom ends
   may be one-sided — fine, just displayed as such.
3. **Candidate larger than scan region (>3 Mb).** Scan expands to
   `start - 0.5*span, end + 0.5*span`. Toolbar can override.
4. **All track scores flat.** No edge detected; zones not proposed;
   UI shows "no clear boundary signal — manual annotation required".
5. **User presses E or F outside the candidate.** Allowed — the zone
   is created at that window. The candidate's pre-existing
   `[start_bp, end_bp]` is NOT updated (boundaries refine *toward*
   the true edges; the original interval stays as a reference).
6. **Saved boundaries when candidate already had boundaries.** New
   values overwrite. Previous values survive in candidate-history (a
   sibling array maintained for QC; spec out of scope here).
7. **`boundary_evidence` layer present but `candidate_id` not found.**
   Auto-propose falls back to the layer-absent path; no error.

### Cross-references

- §4 (`candidates_registry`) — the boundary fields extend the
  registry shape and add 14 TSV columns
- §10 (Marker module) — the dosage heatmap renderer is reused on
  this page; hover tooltips (§10 Hover affordances, schema 2.7)
  apply unchanged
- §11 (Band diagnostics) — `band_continuity_pct` from band
  diagnostics is the source of `band_continuity_drop` track when
  available; precomp's window-level `band_continuity_score` is the
  fallback
- DELLY/Manta integration: `STEP_M06_emit_boundary_evidence.R` (shipped
  post-v3.98) produces the `boundary_evidence` layer from existing SV
  pipeline outputs (MODULE_4x series; `inversion_codebase_v8.5`).
  Track-by-track availability: `--dosage` + `--fish_regimes` enables
  `fst` + per-regime θπ; `--sv_vcf` enables `sv_anchors`;
  `--discordant_bed` enables `discordant_pair_pileup`. Each track is
  independently optional.

### Open tuning parameters (v3.97 implementation)

These are settings, not contract:

- `track_weight` map — defaults given above; tunable after real-data
  validation
- `radius = 5` windows for zone half-width — matches cursor scrubber
  step; adjustable
- 0.5×median threshold for `support[]` inclusion — empirical default
- `support_class` thresholds — locked in schema, but documenting that
  v3.97 may surface tuning knobs for power users

### Scan-radius scales — kb-tier added (v3.99 t14e+ continue)

The boundaries page toolbar exposes **9 scan-radius buttons** in two
visually-separated tiers:

```
scan radius:  [1 kb] [5 kb] [10 kb] [25 kb] [100 kb]  |  [1 Mb] [1.5 Mb] [2 Mb] [5 Mb]
              └─────── kb-tier (v3.99 t14e+ continue) ─────┘     └─── Mb-tier (legacy) ───┘
```

The kb-tier was added per Quentin's observation that "boundary work is
fundamentally kb-scale, not Mb-scale" — the previous Mb-only buttons
forced users to view ±1 Mb minimum even for breakpoints with sub-50 kb
uncertainty. Each scale corresponds to a specific use case:

| Radius   | Visible window | Use case                                                                  | Match to other modules                    |
|----------|----------------|---------------------------------------------------------------------------|-------------------------------------------|
| ±1 kb    | 2 kb           | SV-supported breakpoints with split-read evidence; most PCA tracks won't render meaningfully (50 kb window contains the whole view) | finest possible inspection                |
| ±5 kb    | 10 kb          | fine breakpoint inspection                                                | MODULE_3 `win5000.step1000` θπ scale       |
| ±10 kb   | 20 kb          | boundary zone refinement                                                  | MODULE_3 `win10000.step2000` θπ scale      |
| ±25 kb   | 50 kb          | typical working scale for `boundary_zone_only` verdicts                   | half of the page-1 / page-12 window       |
| ±100 kb  | 200 kb         | broader boundary context                                                  | matches `hobs_profile.distances_kb` and `fst_profile.distances_kb` defaults in §21 boundary blocks |
| ±1 Mb    | 2 Mb           | whole-region context when SV calls and PCA boundaries disagree            | MODULE_3 main `win500000.step500000` ×4   |
| ±1.5 Mb  | 3 Mb           | broader context                                                           |                                           |
| ±2 Mb    | 4 Mb           | broad context                                                             |                                           |
| ±5 Mb    | 10 Mb          | broadest scan; auto-applied for very large or hugely-asymmetric candidates via `_boundaryScanRange`'s `CANDIDATE_HUGE_BP / CANDIDATE_HUGE_RATIO` rule | whole-arm view                            |

The wiring is unchanged: each button still has `data-radius` (in bp)
and the click handler stores `bs.scan_radius_bp`. Only the button
inventory and visual grouping changed. The default
`BOUNDARY_DEFAULTS.SCAN_RADIUS_BP` stays at the existing Mb-tier
default; users opt into kb scales explicitly.

### Hobs role for the LG28 226-sample hatchery cohort

This subsection answers the recurring question "does HOBS work for our
catfish?" — explicitly because the hatchery cohort violates standard
HWE assumptions in ways that affect what HOBS can and cannot do.

#### What HOBS measures

For each site, `Hobs` = observed heterozygous-genotype frequency among
the 226 samples (from patched ANGSD `-doHWE 1 -doHetFreq 1` on the
`Isoris/angsd_fixed_HWE` fork — the patch fixes a real numerical bug
in standard ANGSD that mishandles low-MAF sites). `Hexp` is the
HWE-expected heterozygosity given the observed allele frequency.
`F = (Hexp − Hobs) / Hexp` is Wright's inbreeding coefficient per site;
positive F means heterozygote deficit, negative F means heterozygote
excess.

#### The catfish-specific complications

Three issues affect Hobs interpretation in this cohort, all flagged in
the manuscript text ("No Hardy–Weinberg equilibrium filtering was
applied, as the hatchery population contains extensive family
structure that violates HWE assumptions"):

1. **Family structure inflates apparent HWE violation everywhere.**
   The 226-sample broodstock has extensive sibling and half-sibling
   relationships (NAToRA-pruned 81 unrelated subset reflects this).
   Family LD raises Hobs above HWE expectation across most of the
   genome — not just at inversions. So per-site F isn't a clean
   inversion-specific signal.

2. **Inversion heterozygotes do produce a real, detectable Hobs spike**
   inside the inverted segment, because suppressed recombination
   preserves ancestral diversity. This is the classical Mérot signal.
   Whether it's detectable above the family-noise floor depends on
   inversion frequency (rare = few heterozygotes = weak), family
   clustering of carriers (if all carriers in one family, can't tell
   inversion from family LD), and inversion size (small = too few
   SNPs for stable per-window estimate).

3. **Patched ANGSD is non-negotiable.** Without
   `Isoris/angsd_fixed_HWE` the per-site F values at low-MAF sites are
   numerically unstable, which compounds the low-coverage cohort
   problem (~9× median).

#### Practical answer per use case

| Use                                  | Hobs role                                                          |
|--------------------------------------|---------------------------------------------------------------------|
| Primary inversion discovery (page 1, page 12) | **Don't trust Hobs alone.** Use local-PCA scrubber (page 1) and θπ scrubber (page 12) as primary; treat Hobs spike as 3rd corroborating signal. |
| Boundary refinement (page 11)        | **Hobs adds value** — local Hobs spikes can sharpen the breakpoint zone, especially when SV calls and PCA boundaries disagree. Already wired via §21 `boundary_left/right.hobs_profile` field. |
| Per-candidate diagnostics            | Hobs profile across ±100 kb of the boundary IS one of the cheats already in `boundary_left.json` / `boundary_right.json` (§21). The 100 kb scan radius option matches this layer's `distances_kb` default range. |
| Manuscript-reportable independent test | **Probably not.** Family structure is too strong a confound for cohort-level HWE deviation to count as independent evidence. Scrubber should not surface Hobs in the 14-axis classification (§19) as a primary axis; it lives as supportive evidence in `boundary_left/right` blocks (§21). |

#### Where Hobs lives in the schema

- §21 `boundary_left.hobs_profile` and `boundary_right.hobs_profile` —
  per-side profile across the boundary zone (already in the
  block contract)
- §21 `boundary_left/right.cheats_supporting.cheat4_fst_step` is the
  Fst analog; the Hobs-step analog is `cheats_supporting.cheat_NN`
  (cheat number TBD when MODULE_CONFIRMATION_HOBS_HWE results land)
- Page 11 boundaries view will surface Hobs spikes alongside the
  existing FST / depth / clip-count tracks once the cheat result lands

The cluster-side `MODULE_CONFIRMATION_HOBS_HWE` already exists (Mérot
adapted, multiscale, subset-aware) — the integration work is just
wiring its output into the §21 `boundary_*.hobs_profile` layer for
the scrubber to consume.

---

## 13. Three-axis evidence framework — registry, questions, tiering (planned, schema 2.12)

> **Status: schema-reserved only.** No scrubber implementation, no R-side
> emit yet. The vocabulary, axis structure, and key counts are locked
> here so a parallel chat can build the registry → characterization →
> tiering pipeline without renames. Pulled forward from the cluster-side
> registry work in chats from April 2026 (originally documented in
> `INVERSION_REGISTRY_SPECIFICATION.md` and `INVERSION_CLASSIFICATION_SYSTEM.md`).

### Why three axes (not one tier number)

The cluster-side registry experience surfaced a fundamental insight: a
single "tier" number is a category error. **Three independent things
matter for an inversion candidate**, and conflating them produces
misleading rankings:

1. **Did we find something?** Whether the detection methods agree the
   candidate exists. This is methodology-driven and asks how confident
   the *signal detection* is.
2. **What did we measure?** How much of the analysis pipeline has
   actually run for this candidate. This is administrative and asks
   what work is *complete*.
3. **What do we know biologically?** Whether the measurements collected
   converge on a coherent biological story. This asks whether the
   evidence *interprets*.

These can disagree in informative ways:

- Tier 1 (detection confident) + 40% completion (lots pending) +
  2/7 questions answered (interpretation incomplete) = "obviously real,
  but we haven't characterized it yet"
- Tier 3 (detection uncertain) + 80% completion (we measured everything)
  + 0/7 questions answered (nothing converges) = "we tried and it's
  probably not real"
- Tier 2 (good detection) + 90% completion + 6/7 ANSWERED + Q4
  CONTRADICTED = "the measurements themselves are telling us the
  mechanism story is internally inconsistent — flag for review"

The third pattern is the *most valuable* one — it's evidence-driven
contradiction surfacing as a status flag, not as a hidden problem.

### Axis 1 — Confidence tier (discovery)

Pathway-based, derived from how many *independent evidence layers*
support the candidate. Layers are independent in the sense that each
is computed from a different data modality / algorithm, so agreement
across layers is non-circular.

**Independence layers (locked):**

- **Layer A — Local PCA structure**: triangle/insulation block in
  sim_mat + K≥3 PC1 trimodality + λ₁/λ₂ ratio. From the existing
  `local_pca` and `triangle_intervals` layers.
- **Layer B — SV caller agreement**: DELLY and/or Manta calls for
  inversion within the candidate's bp range, with at least one CT=3to3
  or CT=5to5 anchor. From the existing `sv_anchors` field on
  `boundary_evidence`.
- **Layer C — Haplotype divergence**: GHSL panel shows within-sample
  haplotype contrast inside the candidate exceeds the cohort baseline.
  From the existing `ghsl` layer.
- **Layer D — Genotype-breakpoint association**: Fisher's exact test
  on (PCA-derived karyotype × DELLY-derived genotype) contingency
  table, p<0.001 with consistent direction. From planned
  `breakpoint_evidence_audit` (R-side, parallel chat).

**Tier mapping (locked enum):**

| Tier   | Layers passed | Typical pattern                                                  |
|--------|--------------:|------------------------------------------------------------------|
| Tier 1 | 4             | A + B + C + D — full convergence; manuscript-ready            |
| Tier 2 | 3             | A + C + D (no SV calls but Fisher links PCA carriers to a region's discordant reads) — strong PCA, weak SV |
| Tier 3 | 2             | A + C OR A + B — partial; review needed                       |
| Tier 4 | 1 (A only)    | PCA-only signal; could be family LD or noise                  |
| SV-only | B only       | DELLY/Manta found breakpoints but local PCA shows no structure (rare; usually means low MAF — heterozygotes too few to drive PC1 trimodality) |

The tier is **stored as `confidence_tier` on each candidate**, separate
from the existing scrubber-side `verdict` (which is band-diagnostics
verdict from §11) and `breakpoint_status` (which is junction evidence
from §12). All three are independent dimensions; none reduces to
another.

**Anti-circularity rule.** Layer A and Layer B must not both be
implicitly used to detect the candidate. The typical pipeline detects
candidates from Layer A only (local PCA), then *evaluates* the other
layers post-hoc. SV-only candidates require a separate detection path
seeded from DELLY+Manta directly, which is why they get their own
tier rather than being Tier 4.

> ⚠ **Name-collision note.** `confidence_tier` is already used in §10
> (markers module) for *marker panel* call-accuracy tiers (HIGH /
> MEDIUM / LOW from leave-one-fish-out validation). When implementing
> §13, the inversion-level tier should use a distinct field name —
> options: `inv_confidence_tier`, `discovery_tier`, or
> `evidence_tier` — to avoid ambiguity. Recommend `discovery_tier`
> since it cleanly mirrors the axis name ("Axis 1: Confidence tier
> (discovery)"). The §10 field stays unchanged.

### Axis 2 — Completion (collection)

Administrative. Every candidate has a slot for **approximately 320–370
registry keys** (the count grows as the pipeline matures). Each key is
either:

- **Filled** — the analysis script that produces it has run and emitted
  a value (number, string, JSON blob)
- **NOT_APPLICABLE** — the analysis isn't relevant for this candidate
  (e.g., HET-only metrics for a candidate where no fish carry the
  HET arrangement)
- **EMPTY** — the analysis hasn't been run yet, or it failed

```
completion_pct = filled / (total - not_applicable) × 100
```

**Per-question breakdown.** The 320–370 keys are partitioned across
seven biological questions (Axis 3 below) plus a `Q_QC_SHELF` bucket
for keys that don't belong to any question (cross-cutting QC,
provenance, audit hashes). Per-question completion is reported
independently:

```
completion = {
  Q1_pct: 67,    // 33/49 keys filled (16 EMPTY, 0 NA)
  Q2_pct: 90,    // 36/40 keys filled
  Q3_pct: 78,    // 57/73 keys filled
  Q4_pct: 45,    // 21/47 keys filled (mechanism analysis pending)
  Q5_pct: 33,    // 13/39 keys filled (age estimation pending)
  Q6_pct: 100,   // 28/28 keys filled
  Q7_pct: 88,    // 36/41 keys filled
  shelf_pct: 80
}
```

**Storage.** Per-candidate keys live in
`evidence_registry/per_candidate/<cid>/keys.tsv` — a flat TSV with
columns `key, value, source_script, timestamp, ci_lo, ci_hi,
not_applicable_reason`. The schema's `candidates_registry` JSON layer
gains a new optional `completion` block:

```jsonc
{
  "candidate_id": 48,
  // ... existing fields ...
  "completion": {
    "total_keys":        352,
    "filled":            274,
    "not_applicable":    18,
    "empty":             60,
    "pct_overall":       82,
    "pct_by_question":   { "Q1": 67, "Q2": 90, "Q3": 78,
                            "Q4": 45, "Q5": 33, "Q6": 100, "Q7": 88,
                            "shelf": 80 },
    "registry_version":  "v2.12",
    "last_computed":     "2026-04-28T10:34:00Z"
  }
}
```

The TSV mirror gains 11 new columns (`completion_total`,
`completion_filled`, `completion_NA`, `completion_pct_overall`,
`completion_pct_Q1` … `completion_pct_Q7`); registry width 45 → 56.

### Axis 3 — Characterization (biology)

Convergence-based. For each candidate, evaluate **seven biological
questions** by checking whether the filled keys agree on a conclusion.
Output is one of five statuses per question:

| Status            | Meaning                                                                          |
|-------------------|----------------------------------------------------------------------------------|
| **ANSWERED**      | Multiple independent evidence lines converge on a single conclusion              |
| **PARTIAL**       | Some evidence exists and is consistent, but not enough to converge               |
| **MEASURED**      | Numbers exist but interpretation is pending (no convergence rule has fired yet)  |
| **CONTRADICTED**  | Evidence lines conflict — flag for human review                                  |
| **EMPTY**         | No relevant analysis has been run                                                |

**The seven questions (locked):**

| #  | Question                          | Convergence target                                                | Approx keys |
|----|-----------------------------------|-------------------------------------------------------------------|-------------|
| Q1 | What is it?                       | type label: simple_polymorphic / nested / overlapping / complex   | ~49         |
| Q2 | What's happening inside?          | internal class: clean / edge_conversion / interior_recombination / mixed | ~40   |
| Q3 | What are the boundaries doing?    | boundary class: hard_hard / hard_soft / soft_soft / inner_only    | ~73 (largest — Fst/Hobs profiles at fixed distances) |
| Q4 | How did it form?                  | mechanism: NAHR / NHEJ / TE-mediated / unknown                    | ~47         |
| Q5 | How old is it?                    | age class: recent / intermediate / old (derived from divergence + diversity) | ~39 |
| Q6 | How common is it?                 | frequency class: rare (<5%) / intermediate / common (>30%) / fixed_in_subpopulation | ~28 |
| Q7 | Is it real?                       | independence class — drives Axis 1 tier                          | ~41         |

Plus `Q_QC_SHELF` (~10–20 keys) for cross-cutting provenance / audit.

**Counter-evidence is recorded.** When evidence AGAINST a conclusion
exists, it's stored alongside the evidence FOR. Example for Q5
(age = "old"):

```jsonc
{
  "Q5_status":     "PARTIAL",
  "Q5_label":      "old",
  "Q5_evidence_for": [
    "GDS_gap p90 (q5_gds_gap_p90 = 0.092 ≥ threshold 0.07)",
    "Fst_arrangements top tertile (q5_fst_arr = 0.34 ≥ 0.30)",
    "diversity_U_shape detected (q5_diversity_shape = 'U')"
  ],
  "Q5_evidence_against": [
    "zero fixed differences between arrangements (q5_n_fixed_diff = 0) — inconsistent with old age"
  ],
  "Q5_status_reason": "3 lines for, 1 against — falls short of ANSWERED"
}
```

The status downgrades from ANSWERED to PARTIAL because the counter-
evidence is real and material, even though the majority of evidence
points to "old".

**Convergence rules** are stored as a separate spec
(`CHARACTERIZATION_CONVERGENCE_RULES.md`, planned to ship as a sibling
to `SCHEMA_V2.md`). Each question's rules reference specific key
names; when a key is missing, the rule that depends on it cannot fire,
which limits the maximum achievable status for that question.

**JSON schema addition.** The `candidates_registry` layer gains
`characterization`:

```jsonc
{
  "candidate_id": 48,
  // ... existing fields ...
  "characterization": {
    "Q1": { "status": "ANSWERED",     "label": "simple_polymorphic",
            "evidence_for_count": 3, "evidence_against_count": 0 },
    "Q2": { "status": "ANSWERED",     "label": "edge_conversion",
            "evidence_for_count": 4, "evidence_against_count": 0 },
    "Q3": { "status": "ANSWERED",     "label": "hard_hard",
            "evidence_for_count": 4, "evidence_against_count": 0 },
    "Q4": { "status": "PARTIAL",      "label": "likely_NAHR",
            "evidence_for_count": 2, "evidence_against_count": 0 },
    "Q5": { "status": "MEASURED",     "label": null,
            "evidence_for_count": 2, "evidence_against_count": 0 },
    "Q6": { "status": "ANSWERED",     "label": "intermediate",
            "evidence_for_count": 3, "evidence_against_count": 0 },
    "Q7": { "status": "ANSWERED",     "label": "confirmed",
            "evidence_for_count": 5, "evidence_against_count": 0,
            "n_layers_passed":   4 },     // drives confidence_tier
    "summary": "5/7 ANSWERED, 1 PARTIAL, 1 MEASURED",
    "engine_version": "v1"
  }
}
```

The TSV mirror gains 16 columns: `char_Q1_status`, `char_Q1_label`,
`char_Q1_for`, `char_Q1_against` × 7 questions = 28 columns... that's
too wide. **Compromise: TSV gets a JSON-encoded blob in a single
`characterization_json` column**, plus seven flat helper columns
`char_Q1_status` … `char_Q7_status` for filtering. Registry width
56 → 64.

### Display contract — three independent visual channels

The scrubber's UI surfaces all three axes in a single dashboard panel
without conflating them:

```
┌─ candidate LG12_inv17 ──────────────────────────────────────────┐
│ [TIER 1]   completion 78%   characterization 5/7 ANSWERED       │
│  ████      ░░░░░░░░ Q1 67%  Q2 90% Q3 78% Q4 45% Q5 33% Q6 100% │
│            Q1✅ simple_polymorphic   Q2✅ edge_conversion       │
│            Q3✅ hard_hard            Q4⚠ likely_NAHR            │
│            Q5⬜ pending              Q6✅ intermediate          │
│            Q7✅ confirmed (4 layers)                            │
└─────────────────────────────────────────────────────────────────┘
```

**Status icons (locked):**

- **ANSWERED**: ✅  green  `#2D7D3A`
- **PARTIAL**: ⚠   amber  `#D4A535`
- **MEASURED**: ⬜  light grey `#C8C8C8`
- **CONTRADICTED**: ❌ red `#C43535`
- **EMPTY**: ⬛ white border, empty fill

**Tier badge colors (locked):**

- Tier 1 — `#2D5016` forest green
- Tier 2 — `#7B8C3B` olive
- Tier 3 — `#C4A035` gold
- Tier 4 — `#B0B0B0` grey
- SV-only — `#4A7B9D` steel blue

These will appear in the catalogue as new columns, on the candidate-focus
page as a header dashboard, and as filters in the catalogue toolbar
(filter by tier, filter by Q4_status, etc).

### R-side scripts planned (parallel chat)

- `STEP_R20_compute_candidate_completion.R` — reads
  `evidence_registry/per_candidate/<cid>/keys.tsv` for every candidate,
  emits per-candidate `completion` block + per-question breakdown.
  Output: `<chrom>_phase15_completion.json`.
- `STEP_R21_characterize_candidate.R` — applies convergence rules from
  `CHARACTERIZATION_CONVERGENCE_RULES.md`. Output:
  `<chrom>_phase15_characterization.json`.
- `STEP_R22_compute_confidence_tier.R` — combines Layer A/B/C/D
  evidence, emits `confidence_tier` per candidate. Output:
  `<chrom>_phase15_tiers.json`.
- `STEP_R23_three_axis_dashboard.R` — composite figure for manuscript
  (panels for tier distribution, completion heatmap, characterization
  status grid).

### Detection vs scrubber boundary

This is critical and explicit:

- **The cluster pipeline computes the three axes.** The scrubber
  *displays* them; it does not compute tiers, evaluate convergence
  rules, or fill registry keys.
- **The scrubber adds rows to the registry only via candidate
  promotion.** When a user promotes an L2 to a candidate (page 1
  ⬆ button) or marks confirmed (page 2), the scrubber writes the
  candidate's `start_bp/end_bp/K/locked_labels` to a draft entry. The
  cluster pipeline then runs all R-side STEP_R20+ scripts to populate
  the rest.
- **Mid-flight:** a candidate exists with completion=20% (just promoted),
  no characterization, and no tier. The display shows "TIER pending,
  completion 20%, 0/7 ANSWERED" — and that's correct, not an error.

This boundary keeps the scrubber stateless on the registry side. The
scrubber is a viewer; the registry is the database; the R pipeline is
the writer.

### Why this isn't yet shipped

Two reasons:

1. **The seven-question convergence rules are pipeline-version-dependent.**
   Different chromosomes / cohorts / coverage levels produce different
   key value distributions, so threshold values inside the rules need
   per-cohort calibration. Locking them in schema 2.12 without
   calibration would waste the version slot.

2. **The "approximately 320–370 keys" count is intentionally fuzzy.** As
   the pipeline matures, new analysis steps emit new keys. The schema
   needs a `registry_version` field on each candidate's completion
   block to track which key list version was current when that
   candidate was last analyzed — older candidates may have completion
   computed against a smaller key list.

So schema 2.12 reserves the contract surface (axis structure, status
enum, JSON shapes, R script names, scrubber display semantics). The
actual values + thresholds + key list ship in subsequent versions
once calibrated on the 226-sample LG28 cohort.

### Cross-references

- §11 (band diagnostics) — `verdict` field is independent of `Q1` label
  but feeds Q2 evidence
- §12 (boundaries) — `breakpoint_status` is independent of tier but
  feeds Q3 evidence; `boundary_evidence` keys feed Q3 keys
- §11 (band-diagnostics, het-shape sub-module) — `het_support_kind`
  feeds Q2 evidence
- §10 (markers) — marker classes don't feed any question directly;
  they're a downstream output gated by Q7=ANSWERED

---

## 14. Multi-evidence regime framework (planned, schema 2.13, v4.0 doctrine, t14e)

### 14.1 Doctrine

K-means bands (whether at K=3, K=6, or any K) are **provisional geometric
clusters** derived from local PCA. They are NOT, by themselves, biological
regimes. Final regime calls (paper-level) require **multi-evidence
convergence** across independent layers. The K-means assignment becomes a
*component* of the regime answer, not the answer itself.

This doctrine extends §8 (K=6 nested substructure) by formalizing what's
already implicit there: the K=3 / K=6 nesting check is a *single layer*
of evidence (cluster geometry). The full framework adds five more layers
that must be checked before declaring a regime real.

**Key implication for the manuscript**: in hatchery cohorts (such as the
226-sample pure C. gariepinus LG28 dataset), ROH (inbreeding) and family
LD can both produce visually-clean K-means bands that are **NOT
inversions**. Treating K-means as terminal regime evidence is a
known peer-review failure mode. This framework explicitly checks each
confounder before promoting a band to a regime.

K=6 as a default biological interpretation is rejected: K=6 frequently
represents nested substructure inside three major regimes (per §8). The
paper-level call should usually use major regimes (K=3-equivalent);
higher K values are diagnostic / substructure layers.

### 14.2 The six evidence layers

| Layer                  | What it measures                                           | When it validates a band               | When it rejects a band                                     |
|------------------------|------------------------------------------------------------|------------------------------------------|------------------------------------------------------------|
| **K-means** (geometric) | PCA-space cluster assignment from local PCA                | Always present — the proposal            | NEVER — geometric clustering can't reject; only validate    |
| **Dosage**             | Mean / median marker dose per K-means band                 | Bands separable as REF (~0) / HET (~1) / INV (~2)-like | Bands have similar dose distributions → not orientation     |
| **GHSL**               | Mean within-band vs between-band haplotype divergence      | Within < between → bands diverge in haplotype space | Within ≈ between → bands aren't haplotypically distinct    |
| **Heterozygosity**     | Per-band dosage heterozygosity                             | HET band sits between two homozygous bands | All bands have same het level → no orientation contrast    |
| **ROH / F\_ROH**       | Per-band mean / max F\_ROH                                 | Bands have similar (low) F\_ROH         | One band is dominated by high-F\_ROH samples → IBD cluster, not regime |
| **Family / relatedness** | Per-band family composition + `fam_purity`               | `fam_purity` < 0.5 (mixed families)     | `fam_purity` > 0.85 (one family dominates) → family LD      |

Each layer produces a per-(L2 × K-band) verdict in
`{validates, neutral, rejects}`. The convergence rule consumes these
verdicts.

### 14.2.5 Layer scope — which bands does each layer actually inform?

Not all evidence layers are equally informative across all K-means bands.
The framework MUST honor this when computing verdicts — applying a layer
outside its informative scope and getting `neutral` is meaningless and
shouldn't penalize the convergence call.

| Layer                  | Informs HOMO_REF (g0) | Informs HET (g1)   | Informs HOMO_INV (g2) | Notes |
|------------------------|------------------------|--------------------|-----------------------|-------|
| K-means (geometric)    | ✅ proposes the band    | ✅ proposes the band | ✅ proposes the band    | The proposal — by definition spans all bands |
| Dosage                 | ✅ should be ~0         | ✅ should be ~1     | ✅ should be ~2         | Discriminates all three bands cleanly when present |
| **GHSL**               | ✅ haplotype signature  | ✅ haplotype signature | ✅ haplotype signature | **Informs ALL bands.** Each band has its own haplotype divergence profile |
| **Heterozygosity**     | ⚠ low-info (expected ~0) | ✅ should be elevated | ⚠ low-info (expected ~0) | **Mostly informs the HET band.** Homozygotes have ~0% het by definition; any apparent het-band differentiation in HOMOs is dosage noise, not signal |
| ROH / F\_ROH            | ✅ confounder check     | ⚠ context-dependent | ✅ confounder check     | High F\_ROH inside a homozygous band could mask the band identity (IBD lookalike). The HET band is rarely confounded by ROH |
| Family / relatedness   | ✅ confounder check     | ✅ confounder check  | ✅ confounder check     | Family LD can produce any band, in any zygosity |
| θπ (per-band)          | ⚠ context-dependent    | ✅ should be elevated | ⚠ context-dependent    | π is a polymorphism statistic — informative for HET (mixing two haplotype families) and as a cross-band asymmetry probe (e.g., reduced π in INV-fixed bands) |

**Implication for the convergence rule (§14.3 below)**: when a layer's
scope-flag for a given band is "low-info" or "context-dependent", that
layer's verdict for that band is folded into the convergence call as
`neutral_due_to_scope`, not `neutral_with_information`. A layer that is
"low-info" by scope should NOT contribute to STRONG (because we have no
information from it) but should also NOT push the call toward SUSPECT
(because `neutral` from a low-info layer is the expected result).

The implementation contract:

```
per_band_verdict[(l2, band, layer)].verdict        ∈ {validates, neutral, rejects}
per_band_verdict[(l2, band, layer)].scope          ∈ {primary, supportive, low_info}
per_band_verdict[(l2, band, layer)].verdict_reason : string
```

The convergence call (§14.3) treats `(layer, band)` pairs marked
`scope = low_info` as informationless for that band, regardless of
verdict — they do not lift to STRONG nor demote to SUSPECT. This
prevents penalizing a band because, e.g., heterozygosity returned
`neutral` for HOMO_REF (which it always will).

### 14.3 The convergence rule

The convergence rule is **scope-aware** (per §14.2.5): a layer that is
`scope = low_info` for a given band does not count for or against that
band's status. It contributes neither to STRONG nor to SUSPECT.

For each (L2, K-band) pair, the engine first filters its layer verdicts
to the subset where `scope ∈ {primary, supportive}` for this band, then
applies the rule:

| Status        | Rule (over the in-scope layer subset for this band)                                                                                                  |
|---------------|------------------------------------------------------------------------------------------------------------------------------------------------------|
| `STRONG`      | K-means + dosage + GHSL all `validates` AND any in-scope confounder layers (ROH, family) are `neutral`                                                |
| `SUSPECT`     | K-means `validates` but ≥1 in-scope layer is `rejects` OR ≥1 layer that should be in-scope (per band-type) is missing from the JSON                   |
| `REJECTED`    | An in-scope confounder layer (ROH or family) is `rejects` AND the "fully explains" composition test below is satisfied                                |
| `STATUS_INSUFFICIENT_EVIDENCE` | Fewer than 2 in-scope layers besides K-means returned a verdict — the band has too little corroboration to call STRONG, and no confounder rejected |
| `STATUS_PROVISIONAL`           | Layer thresholds are still pre-calibration (default for v3.99 → v4.0 transition)                                                          |

The "fully explains" test for `REJECTED` (ROH or family case): if removing
samples that drive the confounder (high-F\_ROH samples for ROH, dominant-family
samples for family) collapses the K-means band into another band, the band is
rejected as a regime.

**Concrete examples** of how scope changes the call:

- A HOMO_REF band where K-means + dosage + GHSL all `validates`, F\_ROH is
  `neutral`, family is `neutral`, **heterozygosity is `neutral` (low-info
  by scope for HOMO bands)** → STRONG. Het neutral is NOT held against
  this band.

- A HET band where K-means + dosage `validates`, GHSL `validates`,
  **heterozygosity is `validates` (primary scope here)**, ROH `neutral`,
  family `neutral` → STRONG. Het lifts the call here, where it can.

- A HOMO_INV band where K-means `validates`, dosage `validates`, GHSL
  `validates`, F\_ROH `rejects` AND removing high-F\_ROH samples collapses
  the band → REJECTED. The IBD lookalike test fires.

- A HET band where K-means `validates` but heterozygosity is unexpectedly
  `rejects` (HET sits at the same het level as the homozygous bands) →
  SUSPECT. Het is primary-scope here, so its rejection lands.

**Calibration note**: the layer-level `validates / neutral / rejects`
thresholds AND the `scope` table itself are PROVISIONAL. Final values
lock after the 226-sample LG28 calibration. Until then, the scrubber
displays evidence layer-by-layer and lets the user judge convergence
visually; the `compute_convergence_call` step emits `STATUS_PROVISIONAL`
rather than committed values.

### 14.4 Per-band JSON layers (R-side emit pipeline)

The convergence rule consumes six per-band JSON layers, one per evidence
type. All keyed by `[l2_idx, k_used, band_idx]` for cross-referencing.

```json
{
  "per_band_dosage": {
    "by_l2": [
      {
        "l2_idx": 5,
        "k_used": 3,
        "bands": [
          { "band_idx": 0, "band_label": "g0", "n_samples": 98,
            "dose_mean": 0.04, "dose_median": 0.0, "dose_q25": 0.0, "dose_q75": 0.06,
            "verdict": "validates", "verdict_reason": "tight near 0; HOMO_REF-like" },
          { "band_idx": 1, "band_label": "g1", "n_samples": 95,
            "dose_mean": 0.95, "dose_median": 0.92, "dose_q25": 0.85, "dose_q75": 1.05,
            "verdict": "validates", "verdict_reason": "near 1.0; HET-like" },
          { "band_idx": 2, "band_label": "g2", "n_samples": 33,
            "dose_mean": 1.92, "dose_median": 1.95, "dose_q25": 1.85, "dose_q75": 2.0,
            "verdict": "validates", "verdict_reason": "tight near 2; HOMO_INV-like" }
        ]
      }
    ]
  },
  "per_band_ghsl":  { "by_l2": [ /* same structure, GHSL fields */ ] },
  "per_band_het":   { "by_l2": [ /* per-band het stats */ ] },
  "per_band_froh":  { "by_l2": [ /* per-band F_ROH stats */ ] },
  "per_band_family":{ "by_l2": [ /* per-band family composition */ ] },
  "per_band_convergence": {
    "by_l2": [
      {
        "l2_idx": 5,
        "k_used": 3,
        "bands": [
          { "band_idx": 0, "status": "STRONG",   "validating_layers": ["kmeans","dosage","ghsl","het"], "rejecting_layers": [], "neutral_layers": ["roh","family"] },
          { "band_idx": 1, "status": "STRONG",   "validating_layers": ["kmeans","dosage","ghsl","het"], "rejecting_layers": [], "neutral_layers": ["roh","family"] },
          { "band_idx": 2, "status": "SUSPECT",  "validating_layers": ["kmeans","dosage"],              "rejecting_layers": ["family"], "neutral_layers": ["ghsl","het","roh"], "rejecting_reason": "fam_purity=0.91 → likely family LD" }
        ]
      }
    ]
  }
}
```

### 14.5 R-side emit scripts (NOT YET WRITTEN — parallel chat needed)

| Script                                         | Inputs                                          | Output JSON layer            |
|------------------------------------------------|-------------------------------------------------|------------------------------|
| `STEP_R30_emit_per_band_dosage.R`              | dosage matrix, K-means labels                   | `per_band_dosage`            |
| `STEP_R31_emit_per_band_ghsl.R`                | GHSL matrix, K-means labels                     | `per_band_ghsl`              |
| `STEP_R32_emit_per_band_het.R`                 | dosage matrix (counts het sites), K-means labels| `per_band_het`               |
| `STEP_R33_emit_per_band_froh.R`                | MODULE_3 F\_ROH, K-means labels                  | `per_band_froh`              |
| `STEP_R34_emit_per_band_family.R`              | family table, K-means labels                    | `per_band_family`            |
| `STEP_R35_compute_convergence_call.R`          | All five above                                  | `per_band_convergence`       |

All six layers are OPTIONAL in the JSON; missing layers are reflected as
`STATUS_INSUFFICIENT_EVIDENCE` in the convergence call, not crashes.

### 14.6 Registry impact

Adds the following keys to the candidates_registry under `characterization.q1`:

| Key                                              | Type   | Notes                                                                     |
|--------------------------------------------------|--------|---------------------------------------------------------------------------|
| `q1.regime_call_method`                          | string | `multi_evidence_convergence` for v4.0+; `kmeans_only` for legacy           |
| `q1.bands[i].convergence_status`                 | string | `STRONG` / `SUSPECT` / `REJECTED` / `STATUS_INSUFFICIENT_EVIDENCE` / `STATUS_PROVISIONAL` |
| `q1.bands[i].validating_layers`                  | array  | List of layer names that voted `validates`                                |
| `q1.bands[i].rejecting_layers`                   | array  | List of layer names that voted `rejects`                                  |
| `q1.bands[i].neutral_layers`                     | array  | List of layer names that voted `neutral`                                  |
| `q1.bands[i].rejecting_reason`                   | string | Free-text human-readable rejection rationale                              |
| `q1.dominant_confounder`                         | string \| null | If any band rejected: `roh` / `family` / null                       |
| `q1.confounder_share`                            | float  | Fraction of bands that are REJECTED (0.0 = all good, 1.0 = no real regimes) |

Per-band registry keys: ~6 × n_bands × n_candidates, e.g. for a typical
candidate with K=3 (3 bands), this adds ~18 keys per candidate. For a
catalogue of 60 candidates, ~1100 new registry entries — well within
the ~320–370 baseline of §13. Total registry width 64 → ~70.

### 14.7 Catalogue impact

New column: `regime_evidence` — a compact summary like
`STRONG/STRONG/SUSPECT-fam` for a 3-band candidate where bands 0 and 1
are STRONG and band 2 is SUSPECT due to family confounding. Sortable;
the catalogue can filter by "any REJECTED band" or "all STRONG".

A new mode-switcher above the L3 contingency tables (planned UI, v4.0)
flips which evidence layer is rendered in the per-pane dot coloring:
K-means / dosage / GHSL / het / ROH / family. Default remains K-means
for backward compat.

### 14.8 Gating for v4.0

The framework gates v4.0 release alongside the other v4.0 items:

1. Real-data validation on 226-sample LG28 cohort (existing v4.0 gate)
2. STEP_R30..R35 emit scripts written + tested (NEW gate)
3. UI mode switcher implemented in scrubber (NEW gate)
4. CHARACTERIZATION_CONVERGENCE_RULES.md sibling spec includes the
   per-layer `validates/neutral/rejects` thresholds (extends the §13
   convergence rules document)
5. Catalogue `regime_evidence` column rendered + sortable
6. End-to-end test: load JSON → check that `per_band_convergence` agrees
   with manual layer-by-layer inspection on at least 5 calibration
   candidates

### 14.9 Cross-references

- §8 (K=6 nested substructure) — the K=3 vs K=6 nesting decision is the
  *first* layer of multi-evidence; this framework adds 5 more layers
  AND treats the K=3 call itself as provisional
- §11 (band diagnostics) — provides per-L2 het / ROH / θπ summaries that
  can feed per-band aggregation in `STEP_R32_emit_per_band_het.R` etc.
- §13 (three-axis framework) — Q1 "What is it" answer kind becomes
  multi-evidence convergence, not K-means alone. The convergence call
  is one of the answer evidence sources (with STRONG → answer firm,
  SUSPECT → answer with caveats, REJECTED → answer is "not an
  inversion regime")
- §14 IS this section

---

## 15. Per-sample line coloring modes (planned, schema 2.14, v4.0, t14e+)

### 15.1 Rationale

Today the per-sample lines panel (the central PC1/PC2 trace canvas)
colors each sample line by exactly one scheme: K-means cluster identity
inside the focal L2 (or its lock-snapshot). That works for inspecting
geometric structure, but it leaves substantial information on the table:

- **Heterozygosity per window** for each sample tells you, at a glance,
  whether any given trace is dosage-het in the current span — directly
  diagnostic of which fish are HET in the focal candidate.
- **Per-sample GHSL distance to a reference haplotype set** colors the
  trace by haplotype divergence — useful for spotting which fish share
  an inversion haplotype across multiple windows.
- **Per-sample θπ contribution** colors traces by their share of
  polymorphism — diagnostic for inversion-fixed bands (low π).
- **Per-sample dosage** colors by raw marker dose — direct read of
  REF / HET / INV-like behavior.
- **Per-sample F\_ROH** colors by IBD load — flags the IBD confounder
  visually before the user even runs the convergence call.
- **Per-sample family ID** colors traces by family — flags family-LD
  confounder visually.

Crucially, **the same scheme is desired for the focal-window L3 panes**
and **for the active selection** (lasso + tracked samples), not just
the lines panel. So the coloring axis is a UI-wide mode, not a
panel-local toggle.

### 15.2 The mode set

| Mode                | Source           | Per-sample value          | Color ramp                                   | Available when                      |
|---------------------|------------------|---------------------------|----------------------------------------------|-------------------------------------|
| `kmeans` (default)  | local PCA        | discrete band index       | Categorical (current behavior)                | Always — every JSON has K-means      |
| `dosage`            | dosage matrix    | per-window dose value     | Diverging blue (0) → grey (1) → red (2)       | `dosage_chunks` layer present        |
| `ghsl`              | GHSL panel       | per-window divergence     | Sequential viridis 0 → max                    | `ghsl` layer present                 |
| `het`               | dosage matrix    | per-window het indicator  | Categorical {0=hom, 1=het, NA=missing}        | `dosage_chunks` layer present        |
| `theta_pi`          | per-sample π     | per-sample π contribution | Sequential plasma 0 → max                     | `per_sample_theta_pi` layer present  |
| `froh`              | sample F\_ROH    | per-sample scalar         | Sequential ice low → red high                 | `sample_froh` layer present          |
| `family`            | family table     | per-sample family ID      | Categorical (one color per family)            | Always — present in every JSON       |
| `confounder_alert`  | computed         | derived flag              | Red if F\_ROH > τ\_roh OR family is dominant; grey otherwise | `sample_froh` + family table     |

`kmeans` and `family` are always available and require no new JSON. The
remaining modes activate only when their source layer is present —
the mode picker greys out unavailable choices.

### 15.3 Scope of the coloring application

The mode applies UI-wide to **three places** simultaneously:

1. **Per-sample lines panel** — each polyline traces the sample's
   PC1/PC2/etc value across the visible mb range; line color = mode value
   sampled at each window. The line is per-window-colored if the mode
   value varies per window (dosage, het, ghsl, θπ); per-sample-colored
   (one color over the whole trace) if the mode value is per-sample
   (kmeans, family, F\_ROH, confounder\_alert).
2. **L3 contingency panes** — when each pane shows the per-sample dot
   cloud at its window, dot color = mode value at THAT window for THAT
   sample. K-means stripes (the existing colored swatches) are dimmed
   when in non-K-means modes so the new coloring reads cleanly.
3. **Tracked-samples panel + main PCA scatter** — same. Tracked dots
   in the scatter inherit the mode color; halos / outlines stay K-means
   so you don't lose band identity entirely.

In `kmeans` mode, no behavior changes — the scrubber renders today's
output. New modes are additive.

### 15.4 R-side prerequisite layers

Two new optional layers need R-side emit scripts:

| Layer                      | Source                    | R-side script (planned)                  |
|----------------------------|---------------------------|------------------------------------------|
| `per_sample_theta_pi`      | π by sample, by window    | `STEP_R36_emit_per_sample_theta_pi.R`    |
| `per_sample_dosage_het`    | dosage matrix → 0/1 het   | derived in scrubber from `dosage_chunks` (no new R script) |

Existing layers reused:

- `dosage_chunks` (schema 2.6) — for `dosage` and `het` modes
- `ghsl` (schema 2.0) — for `ghsl` mode
- `sample_froh` (schema 2.3, planned) — for `froh` and `confounder_alert` modes
- family table (always present in v2 JSON via `samples[].family_id`) — for `family` mode

### 15.5 Per-band scope refinement (cross-link to §14.2.5)

The coloring modes also serve as **visual layer-by-layer evidence
display** for the multi-evidence regime framework (§14). When a user
flips the mode from K-means → het, they're literally looking at the
heterozygosity layer's signal — and per the §14.2.5 scope table, they
should expect to see contrast on the HET band but not on the homozygous
bands. If they see contrast on the homozygous bands, that's diagnostic
information (possibly a wrongly-placed sample, family LD, or dosage
miscall).

The mode picker UI MAY annotate each non-K-means mode with a small
`(primary scope: HET band)` / `(primary scope: all bands)` hint so
users don't misread expected null contrast as "the mode is broken".

### 15.6 Implementation contract (NOT YET WRITTEN — v4.0)

```
state.linesColorMode  ∈ {'kmeans','dosage','ghsl','het','theta_pi','froh','family','confounder_alert'}
                      default 'kmeans'
                      persisted to localStorage 'pca_scrubber_v3.linescolormode'
```

Three new render hooks (one per scope target):

```
function _resolveSampleColorByMode(si, gi, mode) → CSS color string
function _resolveSampleScopeColor(si, mode) → CSS color string (per-sample, no window axis)
function refreshLinesColorMode() → validates state.linesColorMode against
                                   layersPresent; falls back to 'kmeans' if
                                   the chosen mode's source isn't loaded
```

The per-window vs per-sample dispatch happens inside
`_resolveSampleColorByMode` — modes that lack a per-window axis (kmeans
in lock-snapshot; family; froh; confounder\_alert) ignore `gi` and
return the same color for every window.

Mode picker UI: a horizontal button row above the per-sample lines
panel, sibling to the existing PC checkboxes. Each button reads the
mode name; greyed-out buttons (with tooltip "needs `<layer>` JSON
layer") for modes whose source layer isn't present.

### 15.7 Gating for v4.0

1. `STEP_R36_emit_per_sample_theta_pi.R` written + tested
2. `STEP_R13_emit_sample_froh.R` (already gating §11) written + tested
3. Existing `dosage_chunks` and `ghsl` layers populated for the LG28
   calibration set
4. Lines-panel render path: per-window vs per-sample dispatch implemented
   without performance regression on 226 × 4302 W (current cache ~120 ms;
   target stays < 200 ms)
5. L3 contingency panes accept the mode without breaking the existing
   K-means dot coloring (need a fallback when mode-specific values are
   missing for individual windows)
6. End-to-end test: cycle through all eight modes on the LG28 dataset,
   verify no crashes, verify color ramps render legibly on light AND
   dark themes
7. Help-page screenshot pack updated with one image per mode

### 15.8 Cross-references

- §10 (markers / dosage heatmap) — `dosage_chunks` layer is the source
  for `dosage` and `het` modes
- §11 (band diagnostics) — provides per-L2 aggregations that the
  per-sample modes complement
- §13 (three-axis framework) — modes serve as Q1 evidence visualization
  helpers
- §14 (multi-evidence regime framework) — modes ARE the per-layer
  visual readout. Flipping mode = "show me what this layer sees" for
  the focal candidate

---

## 16. Toolkit containerization roadmap (planned, schema 2.14, post-v4.0)

### 16.1 Vision

The end-state goal Quentin set out (t14e): make the entire
inversion-discovery toolkit so turnkey that another lab can run it
on their own catfish, fish, animals, or plants without reimplementing
infrastructure. Currently the toolkit is a constellation of:

- **Cluster pipelines** — MODULE_2 (variants/structure), MODULE_3
  (ROH/F\_ROH), MODULE_4 (SV calling: DELLY + Manta), MODULE_5A2
  (inversion discovery core: snake families, GHSL, breakpoint
  validation), MODULE_6 (founder packs), CONSERVATION (deleterious
  variants), all SLURM-orchestrated on LANTA
- **Scrubber** — single-file HTML + JS, browser-side, accepts JSON
- **R emit scripts** — convert cluster outputs → JSON for the scrubber
- **Manuscript bundle** — TSV + Markdown + JSON exports

For the scrubber alone, this is fine — it's a static HTML file that
runs anywhere. For the cluster pipelines, it's heavy: SLURM scripts
hardcode account names, paths, conda envs, R binary paths.

### 16.2 Containerization scope (planned, post-v4.0)

| Component                       | Containerization plan                                     |
|---------------------------------|-----------------------------------------------------------|
| Scrubber                        | Already portable — single HTML, no infra needed           |
| R emit scripts                  | Bundle into a single `inversion-toolkit-r` Docker image   |
| MODULE_2 / 3 / 4 / 5A2 / 6      | Apptainer (Singularity) images per module — SLURM-friendly |
| Cluster orchestration           | Snakemake or Nextflow wrapper that hides the SLURM details |
| Reference genome inputs         | Auto-detect / fetch from Ensembl, NCBI, or user-supplied   |
| Configuration                   | Single YAML per project; module-level overrides            |

The split between Docker (single-machine) and Apptainer (HPC-friendly)
matters because most academic HPC clusters refuse to run rootful Docker
but accept Apptainer images.

### 16.3 Order of attack (sketch, NOT YET PRIORITIZED)

1. **MODULE_2 + MODULE_3 first** — these are the foundational
   variants/structure and ROH steps, useful even without inversions.
   Containerize both as a single `popgen-foundation` Apptainer image
   driven by a YAML config.
2. **R emit scripts second** — pure R, no SLURM, easiest to package as
   Docker. Lets users scrub their own data without running the full
   cluster pipeline.
3. **MODULE_4 (SV) third** — DELLY + Manta both have published
   containers we can inherit from; main work is the conda env
   orchestration.
4. **MODULE_5A2 (inversion discovery)** — the deepest integration
   point. Needs the dense window registry, multi-mode MDS, the snake
   families, GHSL preparator, breakpoint validation. Most code we own
   directly.
5. **L1 / L2 detection** — currently embedded in MODULE_5A2 outputs
   but distinct conceptually. Should expose them as standalone steps
   for users who only want envelope detection.
6. **Catalogue + manuscript bundle** — these are scrubber-side, already
   portable; the containerization here is just reproducible HTML
   rendering for the catalogue export.

### 16.4 What this section is NOT

This is a **roadmap pin**, not a contract. The schema doesn't impose
anything containerization-related on JSON content; it's tracked here
so the long-term direction is on record alongside the scrubber's
schema. Specific container Dockerfiles, image hashes, and YAML schemas
will live in their own repositories when built.

For the current scope: the scrubber is the only piece touched. All
other components remain in-place SLURM scripts on LANTA.

### 16.5 Cross-references

- This section deliberately has no schema implications. The candidates
  registry, JSON layers, and TSV mirror are unaffected by
  containerization plans.
- §1 (Why a versioned schema) — the schema's existence already supports
  cross-machine portability; containerization extends that to the
  cluster pipelines.

### 16.6 Species portability (shipped, t14e+ continue)

A small but concrete step toward the §16 vision: the scrubber no longer
hardcodes a species. The JSON contract gains an **optional** top-level
`species` field; the scrubber reads it and surfaces it in:

| Surface                          | Behavior when `species` is present                    | Fallback when absent                |
|----------------------------------|-------------------------------------------------------|-------------------------------------|
| Header bar (`#headerMeta`)       | Shows `<i>{species}</i>` next to the chromosome name   | Field omitted                       |
| Manuscript prompt (`_promptTemplate`) | "in a *{species}* cohort"                          | "in the study cohort"               |
| Future: catalogue export front-matter | Auto-included in TSV header comments              | Not included                        |

Field shape:

```json
{
  "chrom": "C_gar_LG28",
  "species": "Clarias gariepinus",
  "n_samples": 226,
  ...
}
```

**Convention**: the value is the binomial scientific name, italicized
when displayed. Common name (e.g. "African catfish") could be added
later as a sibling `species_common` field but is NOT part of the
contract today.

**R-side**: the export script can populate `species` via a `--species`
CLI flag. Existing JSONs without this field continue to work unchanged
(field is optional; absence triggers the fallback in every consumer).

**Why this matters for §16**: portability of the toolkit means a Thai
research lab studying tilapia, a European group studying Atlantic
salmon, or a US group studying largemouth bass should be able to
generate JSONs from the same R-side scripts and have the scrubber
render them with their species name showing — not "Clarias gariepinus"
hardcoded everywhere. This is one of dozens of small species-agnostic
fixes that need to happen across the toolkit before §16's full
containerization vision is reachable. We close the easy ones now.

### 16.7 Cross-references

- §1 (Why a versioned schema) — `species` is an additive optional field;
  no schema bump required for v2 → v2 because the field is optional and
  legacy JSONs still work
- §13 / §14 — neither framework references species; both are
  species-agnostic by design

---

## 17. Atlas mode switching — Inversion Atlas ↔ Diversity Atlas (planned, schema 2.15, post-v4.0)

### 17.1 Vision

Per Quentin's t14e+ continue request: the scrubber today is the
*Inversion Atlas* — every page, every panel, every metric, every
catalogue column is oriented around chromosomal inversion candidates
(L1/L2 envelopes, K-means karyotype assignment, σ-profile verdicts,
breakpoint zones, marker panels, regime evidence).

The same data, viewed differently, is also a *Diversity Atlas* —
genome-wide patterns of nucleotide diversity, ROH, F_ROH, kinship,
ancestry-Q stratification, structural-variant load, family-LD
patterns. These are present-day facts about the cohort's genetic
makeup; they don't depend on inversions being real.

The user wants a single button at the top of the scrubber that
toggles between these two modes:

> "We can switch between Diversity Atlas and Inversion atlas. Here we
> are in the Inversion atlas. But when we click the button it switches
> to diversity atlas and all pages change. And so on. And the JSON is
> unloaded. I mean loaded but in stand by."

The JSON stays loaded in memory; only the *interpretation* layer
flips. No re-fetch, no re-parse — just a re-render of every page
through the alternative atlas's lens.

This is a **planned** feature. The current scrubber implements only
the Inversion Atlas. Schema §17 documents the contract that the
Diversity Atlas will follow when it ships, so the foundational
choices can be made coherently rather than retrofitted later.

### 17.2 Atlas as a top-level state slot

```js
state.atlas = 'inversion'   // current default — every existing page
                            // renders the inversion view
state.atlas = 'diversity'   // future — every page renders the
                            // diversity view of the SAME data
```

A single button (header bar, top-left, visible on every page) toggles
this. Persisted to localStorage so reloading the page preserves the
last choice.

```html
<button id="atlasModeToggle"
        title="Switch between Inversion Atlas (current — focus on chromosomal inversion candidates) and Diversity Atlas (future — focus on genome-wide diversity, ROH, ancestry, kinship). Same JSON, different interpretation layer.">
  📐 Inversion Atlas ▾
</button>
```

The toggle MUST NOT unload the data. Both atlases read the same
`state.data` object. The only thing that changes is which JSON layers
are *prominent* in the UI.

### 17.3 Page mapping — what each tab means in each atlas

| Tab # | Inversion Atlas (current)                  | Diversity Atlas (planned)                                    |
|-------|--------------------------------------------|--------------------------------------------------------------|
| 1     | Main scrubber (sim_mat, robust Z, lines)   | Main scrubber (θπ track, F_ROH track, ancestry Q strip)      |
| 2     | Candidate focus (per-candidate dashboard)  | Region focus (per-Mb dashboard: θπ, ROH density, Q at this Mb) |
| 3     | Boundaries (per-candidate boundary zones)  | ROH atlas (sample × position ROH heatmap)                    |
| 4     | Per-candidate sample table                 | Per-sample F_ROH + ancestry profile table                    |
| 5     | Reports (manuscript bundle)                | Reports (diversity manuscript bundle)                        |
| 6     | Help                                       | Help                                                         |
| 7     | Ancestry (Q windows, K assignment)         | Ancestry (same — primary surface in both atlases)            |
| 8     | Windows (per-window precomp inspector)     | Windows (per-window θπ + π/θ + Tajima's D inspector)         |
| 9     | Confirmed candidates carousel              | Saved regions carousel                                       |
| 10    | Marker panels                              | Diversity-marker panels (planned)                            |
| 11    | Boundary refinement                        | (Hidden in diversity mode)                                   |

Some tabs (5 reports, 6 help, 7 ancestry) are atlas-shared. Others
shift their meaning. A hidden tab in one atlas just doesn't render
its tab button.

### 17.4 The same JSON serves both atlases

Both atlases read the same `state.data` object. The JSON layers
already documented in §6 (cluster proposals), §11 (band diagnostics),
§3 (sample_froh), etc., are sufficient for both atlases — the
*Diversity Atlas* is mostly a re-foregrounding of layers the
Inversion Atlas treats as supportive.

| Layer (existing)            | Inversion Atlas role                 | Diversity Atlas role            |
|-----------------------------|--------------------------------------|---------------------------------|
| `windows[]`                 | Local-PCA grid (per-window |Z|, λs)  | Position grid for tracks         |
| `tracks.*`                  | Supporting tracks below sim_mat      | **Primary** — θπ, F_ROH, ancestry-Q stratification headline plots |
| `l1_envelopes`/`l2_envelopes` | **Primary** — inversion candidates | Background context (chromosomal block structure) |
| `candidates[]` registry     | **Primary** — confirmed inversions   | Background; "regions of interest" instead       |
| `theta_pi_panel` (planned)  | Auxiliary band-diagnostics input     | **Primary** — main diversity surface             |
| `roh_intervals` (planned)   | Auxiliary band-diagnostics input     | **Primary** — main IBD-load surface              |
| `sample_froh` (planned)     | Auxiliary band-diagnostics input     | **Primary** — per-sample F_ROH bars              |
| `ancestry_window`           | Per-window K assignment              | Per-window stratification map                    |
| `relatedness`               | NAToRA-pruning context               | **Primary** — pedigree / kinship surface         |

What changes is **emphasis**, not data availability.

### 17.5 What's NOT atlas-specific (shared infrastructure)

These pieces stay identical across both modes:

- The schema (the same JSON works in both modes).
- The candidate registry (saved candidates keep their IDs and confirmed
  flags; in Diversity Atlas they read as "regions of interest").
- Favorites, theme, layout customizations, lasso selections.
- Page 5 (reports) — both atlases produce manuscript bundles, just
  with different default templates.
- Help (page 6).
- The sidebar settings.

### 17.6 New JSON additions for the Diversity Atlas

The Diversity Atlas activates fully when these layers are present:

```json
{
  ...
  "theta_pi_panel": { "div_roll": [...], "samples": [...] },
  "sample_froh":    [...],
  "roh_intervals":  [...],
  "ancestry_window":{ "start_bp": [...], "q_means": [...] },
  "relatedness":    { "samples": [...], "hub_id_1st": [...] }
}
```

If only some are present, the Diversity Atlas still activates, but
some tabs render an empty-state hint pointing to the missing layer
("ROH atlas needs roh_intervals; not loaded").

If NO diversity-relevant layers are present, the atlas toggle either
disables the Diversity Atlas option, or shows it in a greyed state
with a tooltip explaining what's missing.

### 17.7 Catalogue behavior across atlases

The catalogue (page 4 in Inversion mode) becomes:

- **Inversion Atlas**: today's catalogue — one row per L2 envelope or
  L1-merged inversion, columns include K, σ-verdict, span, etc.
- **Diversity Atlas**: a region catalogue — one row per "interesting"
  Mb block as judged by the diversity-stratification engine (top θπ
  windows, top F_ROH windows, ancestry-shift breakpoints, etc.).

Both share the row-selection mechanism, the export format, the
favorites system. The export filename gets an atlas suffix:
`<chrom>_<species>_inversion_catalogue_<date>.tsv` vs
`<chrom>_<species>_diversity_catalogue_<date>.tsv`.

### 17.8 What "JSON in standby" means

Per Quentin: "the JSON is unloaded. I mean loaded but in stand by."
Translation: when the user switches atlases, the JSON object is NOT
freed from memory. `state.data` still holds it. The other-atlas's
panels render lazily — only the active atlas's pages re-render on
each interaction. The inactive atlas's caches (e.g.
`state._l3CacheFp`, `state.__linesCache`) stay populated so switching
back is instant.

The cost: roughly one extra atlas-active rendering cost on each
switch (≈ 200–500 ms for a 100 K-window chromosome). The benefit: no
JSON re-parse, no network refetch.

### 17.9 Implementation phasing

1. **Phase A (schema-only, t14e+ continue, NOW)**: this section. No
   code changes, no UI shipped. The schema documents the contract so
   future implementation has a target.
2. **Phase B (post-v4.0)**: ship the toggle button, the `state.atlas`
   slot, and the page-route dispatch. Both atlases initially show the
   same content — only the BUTTON works. This validates state
   transitions before content forks.
3. **Phase C (post-v4.0, multiple chats)**: per-page Diversity-mode
   renderers. One PR per tab. Each adds an `if (state.atlas ===
   'diversity') { ... }` branch in the page's render entry point.
4. **Phase D (post-v4.0)**: catalogue forking, manuscript-bundle
   templating, atlas-specific exports.

**Total code-side cost**: an estimate of ~3-5 weeks of dedicated work
once the foundation is in place. Schema-only documentation today
costs nothing.

### 17.10 What this is NOT

- It is NOT a new visualization tool. Both atlases share the same
  scrubber app, same panels, same React/Canvas rendering primitives.
- It is NOT a forking of the codebase. One scrubber, two views.
- It is NOT a different JSON contract. The same `state.data`
  satisfies both.
- It is NOT shipped. This section documents the design only.

### 17.11 Schema-version impact

This section adds NO new required JSON fields. Optional layers that
already exist (or are planned) cover both atlases. The `state.atlas`
slot is a UI-only concept; no JSON ever carries an atlas tag.

When the Diversity Atlas ships in code, the schema version may bump
to **2.15** with the addition of:
- `state.atlas` documented as a state slot (UI only, not JSON).
- Recommendation that R-side export scripts always emit the
  `theta_pi_panel`, `sample_froh`, and `roh_intervals` layers (which
  are already planned per §11) so that any precomp JSON can drive
  both atlases out of the box.

### 17.12 Cross-references

- §11 (Band diagnostics module) — supplies θπ, ROH, F_ROH layers
- §3 / §4 layers — ancestry, relatedness, sample-level metadata —
  read by both atlases
- §13 (Three-axis evidence framework) — the Inversion Atlas uses Q1–Q7
  to characterize candidates; the Diversity Atlas does NOT — it
  reports diversity facts directly without the convergence-rule
  framework
- §16 (Toolkit containerization) — the dual-atlas design doesn't
  affect containerization; both modes ship in the same container
- §15 (Per-sample line coloring modes) — line-coloring modes in the
  Inversion Atlas's per-sample panel will have analogues in the
  Diversity Atlas (e.g., color by F_ROH is more naturally a diversity
  mode); same picker UI, different default mode per atlas

---


## 18. Thai language support — i18n architecture (planned, schema 2.16)

### 18.1 Vision

Per Quentin's t14e+ continue request: the lab is in Thailand and many
collaborators read Thai more comfortably than English. The scrubber's
strings (button labels, tooltips, panel headers, help-page content,
status messages) should be available in Thai for this audience. The
user explicitly noted "my lab can read English so" — meaning Thai is
a **nice-to-have**, not blocking, and the timing is "later."

The user also flagged the technical reality: "Thai font is a
challenge but if it's easy. Add."

### 18.2 What makes Thai font a challenge

Thai script has unique typographic requirements that don't always
work with default font stacks:

1. **No spaces between words** — Thai uses spaces only between
   sentences/phrases. The renderer must NOT insert word-break
   opportunities the way English does. Browser line-breaking
   heuristics can be wrong; CSS `word-break: keep-all` may help.
2. **Tonal marks above and below characters** — Thai has up to four
   stacked diacritics (vowel sign, tone mark, etc.). Fonts that don't
   render the full Thai script either drop marks or stack them
   incorrectly.
3. **Variable line height** — because of the diacritic stacks, Thai
   lines need slightly more leading than Latin lines. CSS
   `line-height: 1.6` (vs 1.4 for English) is a common fix.
4. **Font availability** — system fonts on Windows, macOS, Linux,
   Android, iOS render Thai differently. The scrubber today uses
   `system-ui, sans-serif` which gives uneven Thai output.
5. **Mixed script** — when an English term (gene name, parameter
   flag) appears inline in Thai prose, the font transition must be
   smooth.

### 18.3 Architecture (planned)

```js
state.lang = 'en'   // 'en' | 'th'
```

UI-only state slot, persisted to localStorage. Toggle button in the
header (next to the species text) cycles `en → th → en`.

**Translation lookup** is a flat key/value map per locale:

```js
const I18N = {
  en: {
    'tab.diagnostic':      'diagnostic',
    'tab.candidate_focus': 'candidate focus',
    'btn.promote_candidate': '⬆ promote to candidate',
    'panel.no_data_loaded': 'Load a precomp JSON to begin',
    // ... ~300-400 strings
  },
  th: {
    'tab.diagnostic':      'การวินิจฉัย',
    'tab.candidate_focus': 'รายการที่สนใจ',
    'btn.promote_candidate': '⬆ ส่งเสริมเป็นรายการที่สนใจ',
    'panel.no_data_loaded': 'โหลดไฟล์ JSON เพื่อเริ่มต้น',
    // ...
  },
};

function t(key) {
  const lang = state.lang || 'en';
  return (I18N[lang] && I18N[lang][key]) || I18N.en[key] || key;
}
```

**HTML markup** uses `data-i18n="key"` attributes:

```html
<button data-i18n="btn.promote_candidate">⬆ promote to candidate</button>
```

A pass at init / on language-switch walks the DOM:

```js
function applyI18N() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    el.textContent = t(el.dataset.i18n);
  });
  document.querySelectorAll('[data-i18n-title]').forEach(el => {
    el.title = t(el.dataset.i18nTitle);
  });
}
```

Tooltips use `data-i18n-title="key"`. Dynamic strings (rendered by
JS, e.g. catalogue cell content) call `t('key')` directly.

### 18.4 Font handling

```css
:root {
  --font-base: system-ui, -apple-system, "Segoe UI", Roboto, "Noto Sans",
               "Noto Sans Thai", "IBM Plex Sans Thai", sans-serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, Consolas,
               "IBM Plex Mono", "Noto Sans Thai Looped", monospace;
}

html[lang="th"] body {
  line-height: 1.6;
  word-break: keep-all;
}
```

The font fallback chain ensures Latin text renders well regardless,
and Thai text picks up the appropriate font when the system has it
installed. For deployment portability:

- **Easy path**: rely on system fonts. Most modern Thai users have
  `Noto Sans Thai` or equivalents installed by default.
- **Bundled path**: embed `Noto Sans Thai` via Google Fonts CDN
  (~80 KB woff2). This guarantees consistent rendering across
  systems but adds a network dependency.
- **Self-hosted path**: vendor the woff2 files inline as base64 in
  the HTML. Bloats the file by ~80-100 KB but keeps everything
  offline.

The recommendation: easy path first (system fonts). Switch to bundled
path only if the Thai users report broken rendering.

### 18.5 Coverage tiers (what gets translated when)

The translation effort scales — translating 400 strings is real work.
Phase the rollout:

1. **Tier T1 — top-level navigation** (~30 strings): tab labels, page
   headers, primary action buttons. These appear on every page. Most
   visible payoff per string.
2. **Tier T2 — tooltips for top-level nav** (~30 strings): "title="
   text on the tab buttons + main toolbar buttons.
3. **Tier T3 — page-2 candidate focus content** (~50 strings):
   panel titles, section headers, inline labels on the most-used
   workflow page.
4. **Tier T4 — catalogue + windows** (~80 strings): column labels
   AND tooltips, filter labels, export-button labels.
5. **Tier T5 — help page** (~150 strings): the help-page roadmap is
   long-form prose; this is the bulk of the translation effort.
6. **Tier T6 — error / status / info messages** (~50 strings): alert
   strings, empty-state messages, sigma-verdict labels.

A reasonable MVP: ship T1 + T2 + the Thai font CSS. ~60 strings, big
visible impact, manageable scope. T3-T6 can follow in subsequent
batches as users request them.

### 18.6 What stays in English regardless

- Code identifiers, class names, JSON field names — these are
  contracts, not user-facing text.
- Scientific terminology with no widely-used Thai equivalent (e.g.
  "haplotype," "PCA," "F_ROH"). Domain experts in Thai labs read
  these as English loanwords.
- Citation strings, BibTeX keys, gene names, file paths.
- Numeric formatting — keep Arabic numerals (Thai numerals are
  understood but Arabic is universal in scientific contexts).

### 18.7 Schema-version impact

Schema bump: 2.15 → 2.16 (with the §19 14-axis classification — both
shipped together since they're additive, schema-neutral, planned-only).

`state.lang` is a UI-only state slot; no JSON ever carries a language
tag. Translation tables live in the scrubber's own constants, not
in precomp JSONs.

### 18.8 Cross-references

- §17 (Atlas mode switching) — both atlases use the same translation
  table; the atlas toggle button text (`📐 Inversion Atlas ▾`) is
  itself a translation key.
- §16 (Toolkit containerization) — for the multi-language goal,
  containerization implies the same scrubber HTML works for any
  language; i18n is part of the portability story.

### 18.9 What this is NOT

- It is NOT a full localization (l10n) — number formats, date
  formats, currency, plural rules. The scrubber doesn't display
  prices or dates beyond ISO 8601 timestamps. Plural rules in Thai
  are simple (no inflection); skipping a plural-rules library is
  fine.
- It is NOT a translation memory or CAT-tool integration. Strings
  live as flat key/value maps in the scrubber's constants.
- It is NOT shipped. This section documents the contract only.

---

## 19. 14-axis classification (planned, schema 2.16, t14e+ continue)

### 19.1 Why this section exists

The scrubber's Karyotype / Tier page (page 4) provides a **Tier sub-view**
that displays a 14-axis classification per candidate. The classification
is computed cluster-side by `characterize_candidate.R` +
`classify_inversions.R` (planned, recovered from past chat history).
This section documents the JSON contract those scripts must emit so
the scrubber can render the result.

This is NOT a redefinition of §13's three-axis evidence framework.
§13 describes the META structure (Confidence tier + Completion +
Characterization). §19 describes the practical OUTPUT of running
the characterization engine: a flat 14-axis tag per candidate with
explicit categorical values. Both coexist; §19's `confidence_tier`
axis is exactly §13's Axis 1.

### 19.2 The 14 axes

| # | Axis | Categories | Cluster-side source |
|---|------|------------|---------------------|
| 1 | `existence_layer_a`   | pass / fail / unknown                                                   | Layer A (local PCA)                |
| 2 | `existence_layer_b`   | pass / fail / unknown                                                   | Layer B (SV callers)               |
| 3 | `existence_layer_c`   | pass / fail / unknown                                                   | Layer C (GHSL haplotype)           |
| 4 | `existence_layer_d`   | pass / fail / unknown                                                   | Layer D (Fisher genotype-bp)       |
| 5 | `boundary_quality`    | sharp / fuzzy / unknown                                                 | Phase 3 (boundary refinement)      |
| 6 | `group_validation`    | NONE / UNCERTAIN / SUPPORTED / VALIDATED / SUSPECT                      | Phase 4c (group_validation)        |
| 7 | `internal_structure`  | clean / gradient / composite_undecomposed / unknown                     | Phase 4b.3 (decomposition)         |
| 8 | `recombinant_class`   | none / gene_conversion / double_crossover / mixed / unknown             | Phase 4b.2                         |
| 9 | `family_linkage`      | multi_family / few_family / single_family / pca_family_confounded / unknown | Phase 4c                       |
| 10 | `polymorphism_class` | cohort_wide / lineage_restricted / family_restricted / unclassified     | Phase 4c                           |
| 11 | `mechanism_class`    | NAHR / NHEJ / MMBIR / unknown                                           | Phase 4d cheat20                   |
| 12 | `age_class`          | young / intermediate / ancient / unknown                                | Phase 4d Q5                        |
| 13 | `burden_class`       | enriched / neutral / depleted / unknown                                 | Phase 4d Q6                        |
| 14 | `confidence_tier`    | T1 / T2 / T3 / T4 / SV_only / Layer_C_only / unknown                    | Phase 4e (computed from 1-13)      |

`confidence_tier` is derived from the other 13 axes by the rule:

- **T1**: all four existence layers `pass` AND `group_validation` =
  `VALIDATED`. The strongest possible call.
- **T2**: at least three existence layers `pass` AND
  `group_validation` ∈ {`VALIDATED`, `SUPPORTED`}.
- **T3**: at least two existence layers `pass` AND `group_validation`
  ∈ {`SUPPORTED`, `UNCERTAIN`}.
- **T4**: any other case where ≥1 existence layer passes.
- **SV_only**: only Layer B passes (SV callers without local-PCA support).
- **Layer_C_only**: only Layer C passes (GHSL without local-PCA / SV support).
- **unknown**: classification engine couldn't run (insufficient inputs).

The exact cutoffs may shift after calibration on the 226-sample LG28
cohort — this version reserves the contract surface only.

### 19.3 JSON layer shape

```json
{
  ...
  "final_classification": {
    "<candidate_id_1>": {
      "existence_layer_a":   "pass",
      "existence_layer_b":   "fail",
      "existence_layer_c":   "pass",
      "existence_layer_d":   "pass",
      "boundary_quality":    "sharp",
      "group_validation":    "VALIDATED",
      "internal_structure":  "clean",
      "recombinant_class":   "none",
      "family_linkage":      "multi_family",
      "polymorphism_class":  "cohort_wide",
      "mechanism_class":     "NAHR",
      "age_class":           "intermediate",
      "burden_class":        "neutral",
      "confidence_tier":     "T2"
    },
    "<candidate_id_2>": { ... },
    ...
  }
}
```

The top-level key is `candidate_id` exactly as it appears in the
candidate registry. Each entry is an object with all 14 axis keys.
Missing axes default to `"unknown"` in the renderer. Missing
candidates render the empty-state ("no entry for this candidate").

### 19.4 Sibling TSV

Cluster-side also emits a flat TSV (`final_catalog.tsv`) for non-JSON
consumers. Columns:

```
candidate_id  chrom  start_bp  end_bp  span_mb
existence_layer_a  existence_layer_b  existence_layer_c  existence_layer_d
boundary_quality  group_validation  internal_structure  recombinant_class
family_linkage  polymorphism_class  mechanism_class  age_class  burden_class
confidence_tier
```

This is the same data as the JSON layer, just flattened for spreadsheet
inspection. Schema-mirror per §1's TSV-mirror convention.

### 19.5 What the scrubber renders

The Tier sub-view on page 4 renders the 14 axes grouped into six
visual sections:

| Section | Axes |
|---------|------|
| EXISTENCE LAYERS    | layers A, B, C, D                            |
| BOUNDARIES          | boundary_quality                             |
| KARYOTYPE GROUPS    | group_validation, internal_structure, recombinant_class |
| POPULATION GENETICS | family_linkage, polymorphism_class           |
| BIOLOGY             | mechanism_class, age_class, burden_class     |
| OVERALL TIER        | confidence_tier                              |

Each axis renders as a card with a colored value pill. Colors follow
a "good/intermediate/bad" semantic: T1/VALIDATED/pass = green;
T2/SUPPORTED/sharp = teal; T3/UNCERTAIN/fuzzy = amber; T4/SUSPECT/fail
= red; unknown = grey.

When `state.data.final_classification` is absent, the Tier view
renders an empty state showing the axis schema (categories per axis)
without values. This serves as documentation in the UI itself.

### 19.6 Read-only contract

The scrubber NEVER writes to `final_classification`. The user cannot
edit axis values from the UI. The R-side cluster pipeline is the
single source of truth. This is an explicit design choice: the
classification is a downstream characterization, not a user judgment.
If a user wants to flag a candidate as suspect / promising / unique,
they use the existing favorites + confirmed flags + manuscript-bundle
notes.

### 19.7 Coexistence with §13 three-axis framework

§13 Axis 1 (Confidence tier, T1-T4) is the same as §19 axis 14
(`confidence_tier`). They MUST agree. If the cluster-side emit
populates both `state.data.final_classification[id].confidence_tier`
AND `state.data.candidates_registry[id].tier`, the values match.

§13 Axis 2 (Completion, ~320-370 keys) is ORTHOGONAL to the 14 axes
here. The 14 axes are categorical labels; completion is "what
fraction of the registry is filled." A candidate can be 100%
completed but classified `unknown` on every axis (engine ran but
all evidence layers failed); it can also be 30% completed but have
a tentative T2 tier (engine ran on partial data).

§13 Axis 3 (Characterization, 7 questions Q1-Q7) is the WORKFLOW
that produces the 14 axes. The Q1-Q7 questions map to §19 axis
groups roughly as:

| §13 Question | §19 axes |
|--------------|----------|
| Q1 What is it           | layers A-D, group_validation |
| Q2 What's happening inside | internal_structure, recombinant_class |
| Q3 What are the boundaries doing | boundary_quality |
| Q4 How did it form      | mechanism_class |
| Q5 How old              | age_class |
| Q6 How common           | family_linkage, polymorphism_class |
| Q7 Is it real           | confidence_tier (synthesis) |

So §13 is the **process**, §19 is the **output catalog**. Both are
needed; one doesn't replace the other.

### 19.8 Schema-version impact

Schema bump: 2.15 → 2.16 (alongside §18 Thai i18n).

The `final_classification` JSON layer is **optional**. Legacy JSONs
without it render the Tier-view empty state but the rest of the
scrubber works unchanged. Adding the layer doesn't change any
existing scrubber behavior — only the Tier sub-view begins
displaying values.

### 19.9 Cross-references

- §13 (Three-axis evidence framework) — process / orchestration
- §14 (Multi-evidence regime framework) — the per-band convergence
  rule informs `group_validation` and `internal_structure`
- §11 (Band diagnostics) — the per-band metrics feed `internal_structure`
  and `recombinant_class`
- §12 (Boundary refinement) — feeds `boundary_quality`
- §6 (Cluster proposals registry) — this section's `final_classification`
  is the post-classification synthesis of the cluster-side pipeline

### 19.10 What's shipped today vs planned

**SHIPPED (v3.99 t14e+ continue)**:
- Page 4 renamed to "Karyotype / Tier"
- Sub-view toggle UI (Karyotype | Tier ▾) inside page 4
- `karyoState.subview` state slot, persisted to localStorage
- `renderCandidateTier()` rendering function
- 14-axis schema constant `_TIER_AXES`
- Color palette for axis values (`_tierAxisValueColor`)
- Empty-state rendering when `final_classification` layer absent
- Layer detection in `detectSchemaAndLayers`

**PLANNED (cluster-side R, post-v4.0)**:
- `characterize_candidate.R` migration to phase 4e
- `classify_inversions.R` migration to phase 4e
- Population of `final_classification` JSON layer
- Sibling TSV `final_catalog.tsv`

When the R-side ships, the scrubber's Tier view automatically
populates with values — no scrubber-side changes needed.

---

## 20. Registry interop — loading cluster registry artifacts directly (planned, schema 2.17, partial scaffold shipped)

### 20.1 The honest answer to "can we just load the registry?"

Per Quentin's t14e+ continue ask (registries/schemas image + cheatsheet
paste): the cluster-side registry is JSON. The scrubber loads JSON.
**Can the scrubber load the registry directly, skipping the precomp
export step?**

The honest answer is: **partially**. The cluster-side registry has four
tables (`sample_registry`, `interval_registry`, `evidence_registry`,
`results_registry` per the chat-16 design). Three of them are TSV
mirrors of JSON schemas; one is per-candidate JSON blocks. Mapping
each onto the scrubber's `state.data` layers:

| Registry artifact                      | Scrubber `state.data` layer            | Loads cleanly? |
|----------------------------------------|----------------------------------------|----------------|
| `sample_registry/sample_groups.tsv`    | `state.data.sample_groups`             | **Yes**        |
| `interval_registry/candidate_intervals.tsv` | `state.data.candidate_intervals`  | **Yes**        |
| `results_registry/manifest.tsv`        | `state.data.results_manifest`          | **Yes**        |
| `evidence_registry/per_candidate/<cid>/structured/*.json` | `state.data.evidence_blocks[<cid>][<block_type>]` | **Yes** |
| `evidence_registry/per_candidate/<cid>/keys.tsv` | (derived from blocks; not loaded) | N/A — extracted |
| `results_registry/pairwise/...tsv.gz`  | (per-candidate enrichment, on demand)  | Out of scope†   |
| `results_registry/candidate/<cid>/Q_K<NN>.tsv.gz` | `state.data.ancestry_window` (eventually) | Future |
| `interval_registry/windows.tsv`        | `state.data.windows[]` (with PCA scalars) | **NO** ‡    |

† Pairwise FST tracks live in `results_registry/pairwise/` as gzipped
TSVs. Loading them per-candidate is possible but requires gunzip in
the browser (not yet wired) and is more naturally a Diversity Atlas
concern (§17).

‡ The scrubber's per-window data — sim_mat, robust |Z|, λ₁/λ₂,
dosage chunks, simba sets — does NOT live in the registry. It lives
in precomp RDS files and is exported to a precomp JSON by
`export_precomp_to_json_v3.R`. The registry is the FACTORY (computes
per-candidate facts after candidates exist); the precomp is the
SHIPMENT (window-level snapshot for visualization).

So registry-load is **additive enrichment** on top of a precomp JSON,
not a replacement for it. The precomp JSON brings the per-window
local-PCA data; the registry brings everything else.

### 20.2 Why not replace the precomp entirely?

The precomp JSON has ~100,000 windows × ~10 scalar fields each, plus
optional sample × window matrices (Q, GHSL, dosage chunks). At 9×
coverage on a 226-sample cohort, the precomp for one chromosome is
~5–50 MB compressed. The registry is normalized to per-candidate
records (a few hundred candidates × ~14 axes + structured blocks per
question), so ~100 KB total per cohort.

Loading the registry doesn't tell you what the local PCA looks like
at any specific window. That's the precomp's job. The registry tells
you what the cluster-side pipeline CONCLUDED about the candidates
that the local PCA discovered.

**Conceptual mapping:**

```
Precomp JSON  ←──  cluster-side LANDSCAPE pipeline (per-window)
                   - windows[] with z, lam1, lam2, n_snps, ...
                   - tracks (theta_pi, ancestry, ROH, ...)
                   - sample × window matrices (Q, GHSL, dosage chunks)

Registry  ←──  cluster-side PER-CANDIDATE pipeline (post-discovery)
               - sample_registry: WHO (groups, families, sub-clusters)
               - interval_registry: WHERE (candidates, segments, parent_id)
               - evidence_registry: WHAT-SCALAR (Tier-2 JSON blocks + keys)
               - results_registry: WHAT-NUMERICAL (Q/F matrices, FST tracks)
```

Both feed the scrubber. The precomp populates the diagnostic page (1)
and the windows page (8) and the catalogue (4). The registry
populates the per-candidate enrichment views: candidate focus (2),
karyotype/tier (5), confirmed candidates (9), and (in the planned
Diversity Atlas, §17) the ROH atlas + sample F_ROH table.

### 20.3 What's shipped (v3.99 t14e+ continue)

**📦 load registry button** in the candidate-list pane (page 4),
between `📋 export registry` and `+ load enrichment`. Opens a
multi-file picker; the user selects any subset of registry artifacts
in one shot. The scrubber:

1. Parses each file as TSV (for `.tsv` files) or JSON (for `.json` files).
2. Identifies the artifact type by filename + content shape:
   - `sample_groups.tsv` → sample groups table
   - `candidate_intervals.tsv` → candidate intervals table
   - `manifest.tsv` → results manifest table
   - `structured/<block>.json` → per-candidate structured block
3. Light schema-validates against the four registry schemas
   (registries/schemas/{sample_group,candidate_interval,result_row,evidence_key}.schema.json):
   required columns/fields present, types match.
4. Merges into `state.data` as the corresponding optional layer.
5. Reports a summary alert: how many of each kind loaded, how many
   skipped, what errors.

**Special handling for `final_classification`/`classification` blocks**:
when a structured block of type `final_classification` (or
`classification`) is loaded, the scrubber extracts the 14 axis values
and writes them into `state.data.final_classification[<cid>]` so the
Tier sub-view (page 4) populates immediately. This means: drop the
registry's per-candidate classification JSON blocks → see the 14-axis
grid populated in the UI within seconds.

**Light validation, not full JSON Schema validation**: the scrubber
checks required columns and basic field types. Full schema validation
(with `jsonschema` library) is a cluster-side concern; the scrubber
trusts the registry. If validation fails, the file is rejected with a
specific error message; the rest of the load continues.

**Gzip not supported in browser**: registry files served as
`.tsv.gz` or `.json.gz` need to be extracted before drag-drop. The
scrubber flags these with a hint to extract first. Adding browser-
side gunzip (`pako` library, ~50 KB minified) is on the backlog but
not a blocker — the user can run `gunzip *.tsv.gz` once before
loading.

### 20.4 Schema mapping per artifact type

#### sample_groups.tsv → state.data.sample_groups

```js
state.data.sample_groups = {
  headers: ['group_id', 'chrom', 'inv_id', 'subgroup', 'dimension',
            'members_file', 'n', 'description', 'created'],
  rows: [
    { group_id: 'all_226', chrom: '.', inv_id: '.',
      subgroup: '.', dimension: 'cohort',
      members_file: 'groups/all_226.txt', n: '226',
      description: 'Full cohort', created: '2026-04-15 12:00:00' },
    { group_id: 'unrelated_81', dimension: 'unrelated', n: '81', ... },
    { group_id: 'inv_LG12_17_HOM_INV', chrom: 'C_gar_LG12',
      inv_id: 'LG12_17', dimension: 'karyotype', n: '32', ... },
    { group_id: 'inv_LG12_17_HOM_INV__sub1', dimension: 'karyotype_subcluster', n: '12', ... },
    ...
  ]
};
```

The `dimension` field (chat-16 addition) is metadata: classification
scripts can filter `list_groups()[dimension == 'karyotype_subcluster']`
to find sub-cluster groups. The scrubber today doesn't dispatch on
`dimension` but the field is preserved verbatim for future use (e.g.
the Diversity Atlas's family-stratified panels).

The `members_file` path is informational only — actual sample IDs
live in `groups/<group_id>.txt`, which the scrubber doesn't load
unless the user separately drops those files. For the
`get_groups_for_candidate(cid)` style queries the scrubber surfaces,
membership is denormalized into the candidate registry's existing
karyotype assignments.

#### candidate_intervals.tsv → state.data.candidate_intervals

```js
state.data.candidate_intervals = {
  headers: ['candidate_id', 'chrom', 'start_bp', 'end_bp',
            'size_kb', 'scale', 'parent_id'],
  rows: [
    { candidate_id: 'LG12_17', chrom: 'C_gar_LG12',
      start_bp: '12500000', end_bp: '20030000',
      size_kb: '7530', scale: '100', parent_id: '.' },
    { candidate_id: 'LG12_17_seg_DCO1', chrom: 'C_gar_LG12',
      start_bp: '14480000', end_bp: '14530000',
      scale: 'seg_dco', parent_id: 'LG12_17' },
    ...
  ]
};
```

The `parent_id` column gives the nested-candidate hierarchy. A
follow-up scrubber feature can build a tree view from this (chat-17+
backlog). For now: loaded verbatim, stored as a denormalized table.

The scrubber does NOT auto-merge these into `state.candidateList`
(the user-promoted candidate list) because the registry's intervals
are cluster-pipeline output, not user judgment. If the user wants
to promote a registry candidate into their working set, that's a
manual step (page 4 catalogue → 👁 view as candidate). This keeps
the user-promoted list separate from the cluster-emit catalogue —
they may diverge.

#### manifest.tsv → state.data.results_manifest

```js
state.data.results_manifest = {
  headers: ['row_id', 'kind', 'where.chrom', 'where.start_bp',
            'where.end_bp', 'where.candidate_id',
            'who_1.group_id', 'who_1.group_version',
            'who_2.group_id', 'who_2.group_version',
            'what.stat', 'what.K', 'file', 'shape.n_rows',
            'shape.n_cols', 'shape.sha256',
            'provenance.engine', 'provenance.engine_version',
            'provenance.source_script', 'provenance.run_id',
            'provenance.config_hash', 'timestamp'],
  rows: [...]
};
```

The manifest is a flat TSV mirror of `result_row.schema.json`'s nested
JSON shape. Dot-notation column names ("where.chrom",
"who_1.group_id") match the cluster-side convention. The scrubber
loads it verbatim and uses it for two things:

1. **Status badges**: when a candidate has a `final_classification`
   loaded, the scrubber can show "FST: ✓ K=8 (computed 2026-04-15)"
   on the candidate focus page by querying the manifest for rows
   matching `where.candidate_id == cid && what.stat == 'fst'`.
2. **Diversity Atlas integration** (planned, §17): the manifest's
   per-interval ancestry summaries become primary surfaces in
   diversity mode.

#### structured/*.json → state.data.evidence_blocks[cid][block_type]

The Tier-2 JSON blocks are the heart of the registry. Each block
captures one structured measurement with full context (groups used,
parameters, evidence assessment, version). A typical block:

```json
{
  "candidate_id": "LG12_17",
  "block_type": "final_classification",
  "engine": "characterize_candidate.R",
  "engine_version": "v10_phase4e_chat17",
  "groups_used": {
    "HOM_REF": { "n": 89, "version": "2026-04-15 12:00:00" },
    "HET":     { "n": 98, "version": "2026-04-15 12:00:00" },
    "HOM_INV": { "n": 32, "version": "2026-04-15 12:00:00" }
  },
  "existence_layer_a": "pass",
  "existence_layer_b": "pass",
  "existence_layer_c": "pass",
  "existence_layer_d": "fail",
  "boundary_quality":  "sharp",
  "group_validation":  "VALIDATED",
  "internal_structure":"clean",
  "recombinant_class": "none",
  "family_linkage":    "multi_family",
  "polymorphism_class":"cohort_wide",
  "mechanism_class":   "NAHR",
  "age_class":         "intermediate",
  "burden_class":      "neutral",
  "confidence_tier":   "T2",
  "timestamp": "2026-04-20T09:14:00"
}
```

The scrubber stores this verbatim in
`state.data.evidence_blocks[cid][block_type]`. For the special case
of `final_classification` / `classification` block types, it ALSO
extracts the 14 flat axis values into
`state.data.final_classification[cid]` so the Tier sub-view
(SCHEMA §19) renders without further work.

Other block types planned by the cluster pipeline (per past chat
history of the 7-question framework):
- `q1_what_is_it` — existence layers + group validation
- `q2_internal_dynamics` — internal_structure + recombinant_class
- `q3_boundaries` — boundary_quality + breakpoint zones
- `q4_mechanism` — mechanism_class
- `q5_age` — age_class + Tajima D + θπ asymmetry
- `q6_recurrence` — family_linkage + polymorphism_class
- `q7_validation` — confidence_tier (synthesis)

These follow the same shape: `{ candidate_id, block_type,
engine, engine_version, groups_used, ...question-specific fields,
timestamp }`. The scrubber stores all of them in
`evidence_blocks[cid][block_type]`. Future renderers can read any
specific block with a one-liner: `state.data.evidence_blocks?.[cid]?.q5_age`.

### 20.5 What this UNLOCKS — concrete scenarios

1. **Tier view populates from registry**: drop a folder of
   `evidence_registry/per_candidate/<cid>/structured/final_classification.json`
   files; the Karyotype/Tier page (5) shows 14-axis values for every
   candidate in the bundle.

2. **Per-candidate evidence inspection**: any candidate's structured
   blocks become inspectable. A future "Evidence Browser" panel
   (chat-18+ backlog) renders the JSON blocks as expandable cards on
   the candidate focus page (2).

3. **Cross-candidate consistency checks**: with the manifest loaded,
   the scrubber can flag candidates that are missing standard
   computations ("LG12_17 has Q + classification but no FST tracks").

4. **Registry-to-precomp consistency check**: comparing `windows[]`
   in the precomp JSON against `candidate_intervals.tsv` from the
   registry surfaces drift between the two pipelines (e.g. a
   candidate registered in the registry but not in the precomp's
   `l1_envelopes`). Helpful for QC.

### 20.6 What's NOT YET WIRED (limitations of the scaffold)

- **Per-candidate Q matrices** (`results_registry/candidate/<cid>/Q_K<NN>.<group>.tsv.gz`):
  registered in the manifest, but the scrubber doesn't load the data
  files themselves yet. Loading would feed an enriched ancestry view
  on the candidate focus page. Backlog.
- **FST scan tracks** (`results_registry/pairwise/fst/<chrom>/<g1>__vs__<g2>.tsv.gz`):
  registered in the manifest, data not loaded. Loading would feed
  per-candidate FST tracks on the boundaries page. Backlog.
- **Sample × candidate karyotype matrix**: derivable by intersecting
  `sample_groups.tsv` rows like `inv_<cid>_HOM_INV` with
  `groups/inv_<cid>_HOM_INV.txt` files, but the scrubber doesn't
  load the `groups/*.txt` files yet (only the master TSV). Backlog.
- **Browser-side gunzip**: gzipped registry files need pre-extraction.
  Adding `pako` dependency (~50 KB) would solve this. Backlog —
  weighed against keeping the scrubber dependency-free.
- **Schema validation depth**: the scrubber does light validation
  (required columns, basic types). Full JSON Schema validation
  (with `Ajv` library, ~80 KB) is overkill for the trust boundary
  here — the registry is authoritative; if it's malformed, the
  cluster-side loader is the proper place to catch it.

### 20.7 Schema-version impact

Schema bump: 2.16 → 2.17.

New optional layers (all top-level, all read-only from scrubber's
perspective):

```js
state.data.sample_groups          // { headers, rows } — TSV-shaped
state.data.candidate_intervals    // { headers, rows } — TSV-shaped
state.data.results_manifest       // { headers, rows } — TSV-shaped
state.data.evidence_blocks        // { [cid]: { [block_type]: <object> } }
```

Plus the `final_classification` layer (already documented in §19) is
populated as a side-effect when a `final_classification` block is
loaded.

All four are additive. Legacy precomp JSONs without these layers
continue to work unchanged.

### 20.8 What stays in the precomp JSON

Per §20.1's table, these layers are PRECOMP, not registry:

- `windows[]` (with `z`, `lam1`, `lam2`, `n_snps`, ...)
- `tracks` (theta_pi, ancestry summaries, ROH density, ...)
- `l1_envelopes`, `l2_envelopes`
- `sim_mat` (when present, the chromosome-level sim matrix)
- `dosage_chunks` (per-region dosage matrices for the heatmap)
- `candidate_sample_coherence`, `candidate_marker_polarity`
- `bam_evidence` (planned, §11)
- `theta_pi_panel`, `roh_intervals`, `sample_froh` (planned, §11)
- `per_sample_theta_pi` (planned, §15)
- `boundary_evidence` (per §12)
- `marker_*` (planned, §10)

This split is by computational lifecycle:
- **Precomp** = computed once per chromosome at discovery time,
  cached as RDS, exported to JSON for the scrubber.
- **Registry** = computed per-candidate AFTER candidates exist;
  results live in the registry indefinitely (with provenance).

The scrubber needs both. Loading the precomp JSON is the entry
point; loading registry artifacts is enrichment.

### 20.9 Cross-references

- §6 (Cluster proposals registry) — the legacy candidate registry
  contract; the new registry interop (§20) extends rather than
  replaces it
- §13 (Three-axis evidence framework) — the registry's evidence
  blocks are the data source for §13's Completion + Characterization
  axes
- §17 (Atlas mode switching) — Diversity Atlas reads heavily from
  registry artifacts (per-interval ancestry summaries, per-candidate
  Q matrices)
- §19 (14-axis classification) — populated as a side-effect of
  loading `final_classification` structured blocks
- chat-16 `DATABASE_DESIGN.md` (cluster-side) — single source of
  truth for the registry's tables, FKs, and query plane; this section
  documents only the read-side scrubber-facing contract

### 20.10 Future work — chat-17+ backlog

- Browser-side gunzip via `pako` so `*.tsv.gz` and `*.json.gz` files
  drop-load directly
- Per-candidate Q + FST-track loaders (results_registry data files,
  not just manifest rows)
- Folder-drop support (HTML5 directory picker, `webkitdirectory`
  attribute) so Quentin can drag a whole `registries/data/` dir at
  once instead of selecting files
- Manifest-driven "compute-if-missing" UI: the scrubber notices
  results that aren't in the manifest and offers to flag them as
  TODO for the next cluster run
- Registry write-back: when the user confirms a candidate or edits
  its boundaries, write the change as a new structured block in
  `evidence_registry/per_candidate/<cid>/structured/`. This is a
  larger architectural shift (the scrubber becomes a registry
  contributor, not just a reader) — needs design before any code

---

## 21. Structured result blocks — 18 block types (planned schema 2.18, partial scaffold shipped)

### 21.1 Why this section

Per Quentin's t14e+ continue paste: the cluster-side pipeline emits
**18 distinct structured block types**, one per major analysis. Each
block is a JSON file in `evidence_registry/per_candidate/<cid>/structured/`
with a common header and block-specific fields. §20 documented the
generic registry-loading pipeline; §21 documents the 18 specific
block types so the scrubber can extract value from each.

The 18 blocks are the cluster-side's **per-candidate Tier 2 storage**
(per the chat-15 three-tier framing: Tier 1 raw files → Tier 2
structured blocks → Tier 3 flat keys.tsv). Each block keeps its
measurements together with their context, group provenance, and
evidence assessment — so a downstream consumer (the scrubber or any
classification engine) reads ONE file to understand ONE question
about ONE candidate.

### 21.2 Common header

Every block has the same header fields:

```json
{
  "block_type":     "<one of 18>",
  "candidate_id":   "LG12_inv17",
  "chrom":          "C_gar_LG12",
  "region":         [8204500, 12510000],
  "source_script":  "STEP_D03_statistical_tests_and_seeds.py",
  "source_version": "v2",
  "computed_at":    "2026-04-16T14:32:00",
  "groups_used": {
    "source":           "C01i_v2",
    "version":          "2026-04-15",
    "validation_level": "VALIDATED",
    "counts": { "HOM_STD": 89, "HET": 98, "HOM_INV": 32, "REC": 7 }
  },
  "keys_produced": ["q7_layer_d_fisher_or", "q7_layer_d_fisher_p", "..."],
  "raw_files":     ["STEP03_contingency_table.tsv"],
  ...block-specific fields...
}
```

The header is sufficient for the scrubber to:
1. Confirm the block applies to the right candidate / chromosome
2. Know which groups were used (so a group_version mismatch can flag stale results)
3. Know which raw files to surface as "the underlying data"
4. Know which Tier 3 keys this block produced (so the manifest is consistent)

### 21.3 The 18 blocks at a glance

| #  | Block                  | Source                  | Question  | Groups needed | Maps to 14-axis           |
|----|------------------------|-------------------------|-----------|---------------|---------------------------|
| 1  | `existence_layer_a`    | C01a/b/d                | Q1, Q7    | NONE          | `existence_layer_a`       |
| 2  | `existence_layer_b`    | C00, MODULE_4D/4E/4G    | Q7        | NONE          | `existence_layer_b`       |
| 3  | `existence_layer_c`    | C04 GHSL                | Q7        | NONE†         | `existence_layer_c`       |
| 4  | `existence_layer_d`    | STEP03                  | Q7        | IS validation | `existence_layer_d`       |
| 5  | `boundary_left`        | C01g                    | Q3        | NONE          | (½ of `boundary_quality`) |
| 5b | `boundary_right`       | C01g                    | Q3        | NONE          | (½ of `boundary_quality`) |
| 6  | `carrier_reconciliation` | audit + regenotype     | Q3,Q6,Q7  | N/A           | `group_validation`        |
| 7  | `internal_dynamics`    | C01i + decomp_stats     | Q2        | UNCERTAIN     | `internal_structure`, `recombinant_class` |
| 8  | `mechanism`            | cheats 14, 27, 29, 21   | Q4        | NONE          | `mechanism_class`         |
| 9  | `age_evidence`         | cheat30 + popstats      | Q5        | SUPPORTED‡    | `age_class`               |
| 10 | `frequency`            | C01i + C01f             | Q6        | SUPPORTED     | `family_linkage`, `polymorphism_class` |
| 11 | `hypothesis_verdict`   | C01f                    | Q7        | varies        | `confidence_tier`         |
| 12 | `morphology`           | C01a                    | Q1        | NONE          | (no axis; supportive)     |
| 13 | `band_composition`     | C01i + instant_q        | Q1        | UNCERTAIN     | (no axis; supportive)     |
| 14 | `burden`               | burden_regr             | Q6        | VALIDATED     | `burden_class`            |
| 15 | `block_detect`         | PHASE_01C               | Q1, Q3    | NONE          | (no axis; supportive)     |
| 16 | `triangle_insulation`  | C01c                    | Q1, Q3    | NONE          | (no axis; supportive)     |
| 17 | `peel_diagnostic`      | C01f / C01n             | Q7        | NONE          | (no axis; supportive)     |
| 18 | `synteny_dollo`        | mashmap + dollo         | Q5        | NONE          | (no axis; supportive)     |

† GHSL produces its own partition independently of the karyotype groups.
‡ The GDS sub-block of `age_evidence` needs NONE; the FST/dXY sub-block needs SUPPORTED.

### 21.4 Block-by-block field summary

Full JSON shape for each is in the t14e+ continue paste. The
high-value fields the scrubber will surface:

#### existence_layer_a (Q1, Q7)
- `detected: bool` — pass/fail flag
- `inv_likeness_mean` / `inv_likeness_max` / `inv_likeness_sd` — 0..1 score
- `family_likeness_mean` — confounder check
- `beta_pval` / `beta_qval` — significance
- `core_family` — '1L', '2R', etc.
- `pa_pattern` — presence/absence pattern (e.g. 'SML')
- `n_windows` — windows in the region
- `shape_class` — 'strong_square', 'weak_diffuse', etc.
- `dimensions: {D1..D12}` — 12-dim component scores
- `composite_score` / `dim_positive` (count of D's > threshold)

#### existence_layer_b (Q7)
- `detected: bool`
- `delly_inv: bool` / `manta_inv: bool` / `bnd_triangulated: bool`
- `delly_id` / `manta_id` — caller record IDs
- `bp1_pos` / `bp2_pos` / `bp1_cipos` / `bp2_ciend` — breakpoint positions + confidence intervals
- `pe_support` / `sr_support` — paired-end + split-read counts
- `n_carriers_sv` — total carriers from SV
- `sv_audit: {...}` — full DELLY + Manta dropout / rescue diagnostics (15+ subfields)

#### existence_layer_c (Q7)
- `detected: bool`
- `ghsl_version` (currently 'v6')
- `ghsl_contrast_mean` / `ghsl_n_pass` / `ghsl_n_total_windows` / `ghsl_pct_pass` / `ghsl_quality`
- `partition_stable: bool` / `partition_entropy` / `partition_groups`
- `pca_ghsl_concordance` — 0..1 agreement with PCA partition

#### existence_layer_d (Q7)
- `tested: bool`
- `contingency_table: [[a,b],[c,d]]` + `table_labels`
- `fisher_or` / `fisher_ci: [lo, hi]` / `fisher_p`
- `armitage_z` / `armitage_p` — trend test
- `concordance` (e.g. 0.89 = 89% agreement)
- `inv_support_frac` / `het_support_frac` / `ref_support_frac`
- `samples_inv_with_support: [...]` / `samples_inv_no_support: [...]`
- `seed_qualified: bool` / `seed_reason: "..."`

#### boundary_left / boundary_right (Q3)
- `position_bp` — final consensus position
- `position_sources: { pca_boundary, sv_breakpoint, staircase_vote, delta12_changepoint, fst_step }` — multiple estimates
- `concordance_kb` — spread among estimates
- `hardness` (0..1) / `sharpness`
- `type` ('STRUCTURAL_SHARP', 'PCA_FUZZY', 'FOSSIL', etc.)
- `verdict` ('confirmed_structural', 'fuzzy', 'rejected_fossil', etc.)
- `cheats_supporting: { cheat4_fst_step, cheat10_depth_ratio, cheat11_clip_count, cheat17_fossil, cheat21_te_density }` — per-cheat results
- `n_cheats_supporting` — count
- `fst_profile: { distances_kb, values, step_magnitude }` — FST scan around breakpoint
- `hobs_profile` — heterozygosity scan
- `repeat_context: { density_10kb, dominant_class, gc_content, enrichment_vs_genome }`
- `mask_offset: { pca_to_sv_distance_bp, bp_in_repeat, repeat_class_at_bp }`

#### carrier_reconciliation (Q3, Q6, Q7)
- Three carrier sets: `pca_carriers`, `sv_carriers`, `ghsl_carriers` (each with `n` + `source` + `sample_ids`)
- `reconciliation: { all_three_agree, pca_sv_agree, pca_ghsl_agree, pca_only, pca_carrier_sv_dropout, sv_carrier_pca_miss, concordance_pca_sv, concordance_pca_ghsl, dropout_rate }`
- `group_validation: { level: NONE|UNCERTAIN|SUPPORTED|VALIDATED|SUSPECT, reason: "..." }` — **the source of truth for the `group_validation` 14-axis value**

#### internal_dynamics (Q2)
- `n_recombinant` / `n_gene_conversion` / `n_double_crossover`
- `recombinant_detail: [...]` — per-recombinant samples with crossover_bp + class transitions
- `position_distribution: { left_20pct, center_60pct, right_20pct }`
- `switching_rates: { HOM_STD, HET, HOM_INV, REC, kruskal_wallis_p }`
- `class_stability_pct` / `class_entropy_mean`
- `diversity_gradient: { r2, shape: 'shallow_U' | 'monotonic' | 'flat' }`
- `phase_blocks: { n50_inside, n50_flank, ratio, switch_rate_inside, switch_rate_flank }`
- `indel_concordance: { n_classes, concordance, ashman_D }`
- `founder_haplotypes: { chao1_std, chao1_inv, saturated_std, saturated_inv, n_founders_std, n_founders_inv }`

#### mechanism (Q4)
- `sd_evidence: { has_inverted_sd, left/right coords, identity_pct, orientation, biser2_concordance, ... }`
- `junction_evidence: { left/right: { type, mh_length, mh_sequence, flanking_50bp, te_name, te_family } }`
- `te_evidence: { enrichment, enrichment_fold, same_family, same_orientation, tr_enrichment }`
- `gene_content: { n_genes_inside, n_genes_spanning_bp, gene_names_at_bp, gene_density_inside, ... }`
- `classification: { mechanism: NAHR|NHEJ|MMBIR|unknown, support, confidence, decision_tree_path }`

#### age_evidence (Q5)
Five sub-blocks, all conditional on group availability:
- `gds_based: { gds_gap, gds_gap_percentile, gds_within_std, gds_within_inv, gds_between, gds_het_pattern, origin_dip_p, origin_class, requires_groups: false }`
- `fst_based: { fst_b1b3, requires_groups: true, groups_validation }`
- `divergence_based: { dxy_inside, dxy_flanking, dxy_ratio, da_net, theta_pi_*, tajima_D_*, segregating_sites_*, fixed_differences, shared_polymorphisms, requires_groups: true }`
- `diversity_profile: { shape, r2, requires_groups: false }`
- `cross_species: { dollo_node, dollo_mya, n_species_sharing }`
- `cross_validation: { gds_fst_spearman_rho, gds_fst_spearman_p, age_proxies_agree }`
- `conclusion: { age_class: young|intermediate|ancient|old, evidence_for: [...], evidence_against: [...], confidence: ANSWERED|PARTIAL|MEASURED|CONTRADICTED|EMPTY }`

Note the `'old'` / `'ancient'` synonym: the scrubber normalizes `'old'` → `'ancient'` for the §19 axis enum.

#### frequency (Q6)
- `freq_inv` (overall) / `genotype_counts: { HOM_STD, HET, HOM_INV, REC, UNCLASS, total }`
- `hwe_assessment: { expected_het, observed_expected_ratio, deviation, chisq_p }`
- `per_qgroup_freq: { Q1..Q8 }` — frequency per ancestry-Q group
- `freq_cv_across_qgroups` — coefficient of variation
- `family_linkage`: 'multi_family' | 'few_family' | 'single_family' | 'pca_family_confounded'
- `jackknife: { max_delta, sensitive_qgroup, status }`
- `selection_signal: { tajima_D_inside, tajima_D_flanking, pattern, caveat }`

The `caveat` field (e.g. "hatchery Ne~20, cannot distinguish selection from drift") must be surfaced in any UI rendering — the scrubber MUST NOT display selection results without the caveat.

#### hypothesis_verdict (Q7)
- `verdict: 'confirmed_real_inversion' | 'likely_real_inversion' | 'rejected' | ...`
- `verdict_confidence: 'high' | 'medium' | 'low'`
- `fdr_qval`
- `layers_tested: int` / `layers_passed: int`
- `independence_class: 'confirmed' | 'sv_only' | 'layer_c_only' | ...`
- `supporting_tests: { t8_clair3_concordance, t9_jackknife_status, t9_max_delta, t10_theta_concordance }`
- `hypothesis_history: [{version, date, verdict, change_reason}, ...]` — append-only audit trail

#### burden (Q6 selection_pattern)
- `burden_mean_ref` / `burden_mean_het` / `burden_mean_inv`
- `burden_fold_inv_ref`
- `kw_p` / `kw_qval` — Kruskal-Wallis test
- `wt_inv_vs_ref_p` — pairwise Wilcoxon
- `inside_outside_fold`
- `verdict: 'INV_ELEVATED' | 'INV_DEPLETED' | 'NEUTRAL'`

#### morphology (Q1, supportive)
- `flat_inv_score` / `spiky_inv_score` / `fragmentation_score`
- `s_het_mean` / `s_pve_mean` / `s_dip_mean` — component scores feeding inv_likeness
- `inv_likeness_mean` / `inv_likeness_max` / `inv_likeness_sd`
- `dosage_het_cv_mean` / `pve1_excess_mean` / `dip_pval_median`

#### band_composition (Q1, supportive)
- `band_qgroup_fracs: { HOM_STD: {Q1..Q8}, HET: {Q1..Q8}, HOM_INV: {Q1..Q8} }`
- `dominant_qgroup_std` / `dominant_qgroup_inv` (e.g. 'Q1', 'Q3')
- `q_group_overlap` — 0..1, how similar the std and inv ancestry distributions are

#### block_detect (Q1, Q3, supportive)
- `boundaries: [...]` — boundary classifications from ±80 sim_mat analysis
- `blue_cross_verdicts: [...]`
- `block_concordance_matrix`

#### triangle_insulation (Q1, Q3, supportive)
- Interval classifications, squareness, insulation depths, sub-regime assignments, off-diagonal bridges

#### peel_diagnostic (Q7, supportive)
- `L1b_effect` / `L2_effect` / `peel_delta`
- `samples_removed: [...]` / `samples_gained: [...]`

#### synteny_dollo (Q5, supportive)
- `mashmap_breaks: [...]`
- `dollo_node` / `dollo_mya` / `species_sharing` / `min_age_mya`

### 21.5 Multiple blocks compose into the 14-axis classification

This is the key insight: **the 14-axis classification (§19) is the
synthesis of the question blocks**. Loading a `final_classification`
block gives the scrubber all 14 axes at once (cluster-side did the
synthesis). Loading a SUBSET of question blocks lets the scrubber
derive whatever axes it can, leaving the rest as 'not yet computed'.

Concrete example: drop `existence_layer_a.json`, `existence_layer_b.json`,
`existence_layer_c.json`, `existence_layer_d.json` for a candidate
(no other blocks). The scrubber:
1. Stores all 4 blocks in `state.data.evidence_blocks[cid]`
2. Derives `existence_layer_a` axis from block 1's `detected` field
3. Derives `existence_layer_b` axis from block 2's `detected` field
4. Derives `existence_layer_c` axis from block 3's `detected` field
5. Derives `existence_layer_d` axis from block 4's `fisher_p < 0.05`
6. Writes all 4 axes to `state.data.final_classification[cid]`
7. The Tier sub-view (page 4) shows 4/14 axes populated, 10/14 as
   "not yet computed"

Drop more blocks (mechanism, age_evidence, frequency, etc.) → more
axes populate. Drop the final synthesis block → all 14 axes
populate at once and the per-question derivations are overwritten
(synthesis is authoritative when present).

### 21.6 Axis derivation rules (per-block)

The scrubber's `_deriveAxesFromBlock(blockType, obj)` function applies
these rules. Encoded conservatively — when a block is ambiguous, the
function returns nothing for that axis (rather than a bad value).

| Block                    | Derives axis           | Rule                                                       |
|--------------------------|------------------------|------------------------------------------------------------|
| `existence_layer_a`      | `existence_layer_a`    | `obj.detected === true` → 'pass'; `=== false` → 'fail'     |
| `existence_layer_b`      | `existence_layer_b`    | same as above                                              |
| `existence_layer_c`      | `existence_layer_c`    | same as above                                              |
| `existence_layer_d`      | `existence_layer_d`    | `obj.tested === false` → leave unknown; else `fisher_p < 0.05` → 'pass' / 'fail' |
| `boundary_left/right`    | `boundary_quality`     | reconciled at end-of-load: BOTH sides verdict ~ structural AND hardness ≥ 0.7 → 'sharp'; else 'fuzzy' |
| `carrier_reconciliation` | `group_validation`     | `obj.group_validation.level` → uppercase enum             |
| `internal_dynamics`      | `internal_structure`   | `n_recombinant === 0` && `r2 < 0.3` → 'clean'; `n_rec ∈ [1, 9]` → 'gradient'; `n_rec ≥ 10` → 'composite_undecomposed' |
| `internal_dynamics`      | `recombinant_class`    | `gc + dco === 0` → 'none'; `gc>0 && dco===0` → 'gene_conversion'; `gc===0 && dco>0` → 'double_crossover'; both > 0 → 'mixed' |
| `mechanism`              | `mechanism_class`      | `obj.classification.mechanism` → enum {NAHR, NHEJ, MMBIR, unknown} |
| `age_evidence`           | `age_class`            | `obj.conclusion.age_class` → enum {young, intermediate, ancient}; 'old' normalized to 'ancient' |
| `frequency`              | `family_linkage`       | `obj.family_linkage` → enum                                |
| `frequency`              | `polymorphism_class`   | `freq_cv_across_qgroups < 0.20` && mean > 5% → 'cohort_wide'; ≥0.40 → 'family_restricted'; ≥0.20 → 'lineage_restricted' |
| `hypothesis_verdict`     | `confidence_tier`      | `layers_passed >= 4` && verdict ~ confirmed → T1; `>=3` → T2; `>=2` → T3; `>=1` → T4; `independence_class === 'sv_only'` → 'SV_only'; `'layer_c_only'` → 'Layer_C_only' |
| `burden`                 | `burden_class`         | `obj.verdict` ~ INV_ELEVATED → 'enriched'; INV_DEPLETED → 'depleted'; NEUTRAL → 'neutral' |
| `morphology`             | (none)                 | supportive only                                            |
| `band_composition`       | (none)                 | supportive only                                            |
| `block_detect`           | (none)                 | supportive only                                            |
| `triangle_insulation`    | (none)                 | supportive only                                            |
| `peel_diagnostic`        | (none)                 | supportive only                                            |
| `synteny_dollo`          | (none)                 | supportive only                                            |
| `final_classification`   | ALL 14                 | copy verbatim from synthesis block (authoritative)         |
| `classification`         | ALL 14                 | alias of `final_classification`                            |

These rules are defaults — when the cluster-side synthesis runs, its
`final_classification` block overrides the per-block derivations
(synthesis is more sophisticated). The per-block derivations exist
so the scrubber works even when only a subset of blocks is loaded.

### 21.7 Group provenance + staleness check

Every block's `groups_used` field declares which sample groups were
used. With `sample_groups.tsv` also loaded, the scrubber can detect
when a block is stale: if the block's `groups_used.version` doesn't
match the current `created` timestamp in `sample_groups.tsv`, the
block was computed against an outdated group definition.

Stale-detection scope (planned, chat-17+): show a warning chip on
the candidate focus page like "⚠ existence_layer_d uses HOM_INV from
2026-04-10; current HOM_INV is 2026-04-15" — so the user knows to
re-run that step. Not yet wired; the data needed (current group
versions from `sample_groups.tsv`) is loaded by the registry import,
just no UI yet.

### 21.8 What's shipped (v3.99 t14e+ continue)

- `_KNOWN_BLOCK_TYPES` constant — the 21 entries (18 question blocks
  + 2 `final_classification`/`classification` aliases + reserves)
- `_deriveAxesFromBlock(blockType, obj)` — the per-block axis
  derivation table from §21.6 above
- `_reconcileBoundaryQuality(cid)` — end-of-load boundary_left +
  boundary_right reconciliation into `boundary_quality` axis
- Registry loader's structured-block branch now recognizes all 18
  known types, derives axes, composes into
  `state.data.final_classification[cid]`
- Summary alert breaks down loaded blocks by type, separates known
  vs unknown, reports axis derivations
- **Block-presence indicator chips on candidate focus page (page 2)**:
  20 chips (18 numbered question blocks + `boundary_right` sibling +
  `final_classification` synthesis),
  rendered as a horizontal row at the top of the candidate focus
  view by `candidateBlockChipsHtml(c)`. Each chip is lit when its
  block is loaded for the active candidate, dim when missing. Color
  encodes status: green for axis-contributing blocks (per §21.6),
  blue for supportive-only blocks, gold for the synthesis block.
  Click ordering follows §21.3 groups with small left-margin
  spacers between groups for visual sectioning. Tooltip explains
  loading mechanism for missing blocks.
- **Inline JSON inspector on click**: clicking a lit chip
  (`_toggleBlockInspector`) appends a collapsible inspector below
  the chip row showing the block's raw JSON content (header fields
  like `source_script`, `source_version`, `computed_at`,
  `groups_used.validation_level` surfaced separately, then a
  scrollable `<pre>` with the full JSON). Multiple inspectors can
  be open simultaneously. Blocks > 200 KB stringified are
  truncated with a `[truncated]` badge.
- Registry-load finalizer also re-renders the candidate focus page
  so chips light up immediately after files are dropped.

### 21.9 What's NOT YET WIRED (chat-17+ backlog)

- **Per-block renderer panels**: each block could have a dedicated
  panel on the candidate focus page (page 2). For example,
  `internal_dynamics.json` could render the recombinant detail table
  + switching rate chart + diversity gradient line. Today the chips
  + JSON inspector show raw structure; rich domain-specific renderers
  will be added per-block as the §21 fields become familiar. The
  inspector already gives a complete, if utilitarian, view of any
  block.
- **Stale group warnings**: per §21.7 — chip turns amber when block's
  `groups_used.version` differs from current `sample_groups.tsv`
  `created` timestamp. Data needed (sample_groups loaded via §20) is
  already available; just no UI yet.
- **Manuscript bundle integration**: when loaded, the structured
  blocks should feed the manuscript bundle's Methods + Results prose
  generation. E.g. if `mechanism.json` says NAHR with 97.3% identity
  on a 14.2 kb SD, the bundle's Methods can write that sentence
  automatically.

### 21.10 Cross-references

- §19 (14-axis classification) — what the blocks compose INTO
- §20 (Registry interop) — generic loading mechanism that §21
  specializes
- §13 (Three-axis evidence framework) — the 7-question framework the
  blocks are organized around
- §11 (Band diagnostics) — `internal_dynamics` and `band_composition`
  blocks overlap with the band-diagnostics module's metrics

### 21.11 Schema-version impact

Schema bump: 2.17 → 2.18. The scrubber-side scaffold for §21 ships
in v3.99 t14e+ continue; the schema version reflects the formal
documentation of the 18 block contracts. NO new required JSON
fields are added; all 18 blocks are optional and additive.

---

## 22. θπ scrubber — chromosome-wide diversity scanner mirroring page 1 (planned, schema 2.19, structural scaffold shipped)

### 22.1 What changed vs the prior §22 design

An earlier draft of §22 documented θπ-MDS concordance as a per-candidate
sub-view on page 2 (six panels comparing genotype-based local PCA to
θπ-profile MDS, with the figure-mockup A-F structure). On rereading the
mockups Quentin then said:

> "Honestly it needs to be on its own page because I have super high
> hope in this orthogonal validation using theta pi concordance. Make
> it page (2). I thought it should be mirroring page (1) actually.
> Since it totally have same type of signal in theory ... page (1)
> copy but instead of local PCA of dosage its local PCA of theta pi"

That reframes the feature substantially. The per-candidate view is
still useful but secondary; the **primary** surface is a chromosome-wide
scanner that runs the whole page-1 pipeline (per-window analysis →
window×window similarity → MDS → cluster → candidate intervals)
**on θπ data instead of dosage data**. This is genuinely Quentin's
discovery — there's no standard pipeline for diversity-based local-PCA
candidate scanning; he's inventing one.

§22 (this rewrite) documents the page-level mirror. The per-candidate
concordance view (the original §22 figure mockup) becomes §22.7 —
secondary, not the primary surface.

### 22.2 The conceptual mirror

| Page 1 (dosage / genotype scrubber) | Page 2 NEW (θπ / diversity scrubber) |
|---|---|
| Per-window dosage matrix (samples × SNPs) | Per-window θπ vector (samples × 1, or samples × bp positions inside window) |
| Local PCA → PC1, PC2 per sample, per window | Local PCA on θπ → diversity-axis-1, diversity-axis-2 per sample, per window |
| Per-window eigenvalues λ₁, λ₂ → robust \|Z\| | Per-window θπ eigenvalues → robust diversity-\|Z\| |
| sim_mat: window×window similarity from PCA shapes | θπ_sim_mat: window×window similarity from θπ-PCA shapes |
| MDS-embed similarity → cluster windows → L1 envelopes | MDS-embed θπ_sim_mat → cluster windows → diversity L1 envelopes |
| L2 sub-envelopes by re-running on each L1 | L2 sub-envelopes by re-running on each diversity L1 |
| Candidate intervals from L2 envelopes | Diversity-candidate intervals from diversity L2 envelopes |
| K-means on PC1/PC2 → karyotype groups | K-means on θπ-axes → diversity groups (Hom1 / Het_upper / Het_lower / Hom2 expected) |

The two scrubbers produce **the same shape of output** (per-window
embedding + per-window robust score + window×window similarity + MDS +
clustering + envelopes + candidates). They differ ONLY in the input
signal. This is what makes orthogonal validation possible: drop both
candidate lists side-by-side and look at the agreement matrix.

### 22.3 Why this is genuinely orthogonal validation

Local PCA detects regions where samples cluster by **linkage / haplotype
identity at SNPs**. It's blind to selection sweeps that don't disturb
linkage, blind to gene-conversion gradients within heterozygotes, blind
to assembly artifacts that look identical at the SNP level.

θπ-PCA detects regions where samples cluster by **how much diversity
their windowed sequences carry** — this is sensitive to:

- Hard sweeps (drop in diversity at the swept window relative to flanking)
- Balancing selection (elevated diversity)
- Inversions with allele-frequency-asymmetric haplotype spread (the Het
  class splits into subgroups by diversity even when their genotype
  pattern is identical)
- Regions of differential introgression between subpopulations
- Mis-assemblies where the reference collapses paralogs (samples have
  diversity drops or jumps at the boundaries)

A region that hits BOTH scrubbers' candidate lists is ~certainly real
biology. A region that hits ONLY local PCA is genotype-only structure
(typical inversion). A region that hits ONLY θπ-PCA is something the
genotype scrubber can't see — and that's where the new biology is.

### 22.4 Required JSON layers (chromosome-scale, NOT per-candidate)

The page needs three new optional layers, structurally mirroring page 1's
existing layers. Two shapes are acceptable for `theta_pi_per_window`
(see §22.13 for why):

```json
{
  // SHAPE A (existing — already shipped in production JSONs that passed
  // --theta to export_precomp_to_json.R; per-window embedding):
  "windows": [
    { "idx": 0, "start_bp": ..., "end_bp": ..., "z": ..., "pc1": [...],
      "theta": [n_samples θπ values, sign-aligned by precomp window order] },
    ...
  ],

  // SHAPE B (planned — top-level layer; symmetric with how page 1's
  // top-level arrays live; produced by a future R-side wrapper around Q05):
  "theta_pi_per_window": {
    "samples": ["CGA009", ...],
    "windows": [{ "start_bp": ..., "end_bp": ..., "n_sites": ... }, ...],
    "values": Float32Array,             // [n_windows × n_samples], per-sample θπ in window
    "window_size_bp": 50000,
    "step_size_bp": 10000               // matches Q05 default scale
  },

  // The remaining two layers are NEW (no existing equivalent):
  "theta_pi_local_pca": {               // NEW — R-side STEP_R40, planned
    "n_windows": <int>,                 // matches theta_pi_per_window.windows.length
    "n_samples": <int>,
    "samples": ["CGA009", ...],
    "z": Float32Array,                  // [n_windows] robust diversity-|Z|
    "lam1": Float32Array,               // [n_windows] first θπ-PCA eigenvalue
    "lam2": Float32Array,               // [n_windows] second θπ-PCA eigenvalue
    "ratio": Float32Array,              // [n_windows] λ₁/λ₂
    "n_sites_qc": Float32Array,         // [n_windows] sites that passed QC
    "pc1": Float32Array,                // [n_windows × n_samples] θπ-PC1 per sample per window
    "pc2": Float32Array,                // [n_windows × n_samples] θπ-PC2 per sample per window
    "sim_mat": Float32Array,            // [n_windows × n_windows] window-window similarity
    "mds_coords": Float32Array,         // [n_windows × 2] MDS embedding of windows
    "method_version": "v1"
  },
  "theta_pi_envelopes": {               // NEW — R-side STEP_R41, planned
    "l1": [{ "win_start": ..., "win_end": ..., "id": "th_L1_1", ... }, ...],
    "l2": [{ "win_start": ..., "win_end": ..., "parent_l1": ..., "id": "th_L2_1", ... }, ...],
    "candidate_intervals": [{ "id": "th_cand_1", "chrom": ..., "start_bp": ..., "end_bp": ..., "support_class": ... }, ...]
  }
}
```

**Field-by-field correspondence with existing page-1 layers**:

| θπ scrubber field | Page 1 (dosage) equivalent |
|---|---|
| `theta_pi_per_window.values` | (input layer; not stored on page 1, computed live from precomp dosage) |
| `theta_pi_local_pca.z` | top-level `z[]` array |
| `theta_pi_local_pca.lam1`, `lam2`, `ratio` | top-level `lam1[]`, `lam2[]`, `ratio[]` |
| `theta_pi_local_pca.sim_mat` | top-level `sim_mat[]` |
| `theta_pi_local_pca.mds_coords` | top-level `mds_coords[]` |
| `theta_pi_envelopes.l1`, `l2` | top-level `l1[]`, `l2[]` |
| `theta_pi_envelopes.candidate_intervals` | top-level `candidate_intervals[]` (after merge) |

Two design choices vs the prior §22 draft:

1. **Layers live at top level, namespaced under `theta_pi_*`** — not
   nested inside a per-candidate object. Symmetric with how page 1 lays
   out `z`, `sim_mat`, `mds_coords`, `l1`, `l2` at the top level.
2. **Computation lives R-side, NOT JS** — same rationale as the prior
   §22 draft, scaled up. Computing per-window local PCA on θπ for a
   whole chromosome × 226 samples is not something to do in the
   browser. Three new R scripts: `STEP_R39_emit_theta_pi_per_window.R`,
   `STEP_R40_emit_theta_pi_local_pca.R`, `STEP_R41_emit_theta_pi_envelopes.R`.

### 22.4.1 Scale — locked to `win50000.step10000`

ANGSD `thetaStat` (in MODULE_3) emits θπ at four scales and stores the
outputs in `02_heterozygosity/03_theta/`:

| Scale (`win.step`)         | Origin     | Resolution      | Use for                                                       |
|---------------------------|------------|------------------|---------------------------------------------------------------|
| `win5000.step1000`        | multiscale | 5 kb / 1 kb step  | per-candidate breakpoint inspection (post-v4.0 boundary panel) |
| `win10000.step2000`       | multiscale | 10 kb / 2 kb step | per-candidate interior structure (post-v4.0 boundary panel)    |
| `win50000.step10000`      | multiscale | 50 kb / 10 kb step | **chromosome-wide θπ scrubber (page 12 default)**             |
| `win500000.step500000`    | main       | 500 kb / 500 kb   | broad ideogram tracks (popstats page)                         |

The chromosome-wide θπ scrubber **locks to
`win50000.step10000`**. No SCALE selector is exposed on page 12. The
finer scales are reserved for a separate per-candidate breakpoint
inspection view (planned, post-v4.0). Three reasons for the lock:

#### 1. Browser memory — `sim_mat` is `n_windows²`

For a 33 Mb chromosome (LG28 size):

| Scale                  | n_windows | sim_mat cells | float32 size | Verdict                |
|------------------------|-----------|----------------|---------------|------------------------|
| `win5000.step1000`     | ~33 000   | 1.09 billion   | **~4.4 GB**   | infeasible in browser  |
| `win10000.step2000`    | ~16 500   | ~272 million   | **~1.1 GB**   | infeasible in browser  |
| `win50000.step10000`   | ~3 300    | ~10.9 million  | **~44 MB**    | tractable (default)    |
| `win500000.step500000` | ~66       | 4 356          | trivial       | too coarse             |

Page 1's existing dosage scrubber already handles ~5 000 windows ≈
100 M cells ≈ ~400 MB of sim_mat and that's already the upper limit
of what most browsers render smoothly. Doubling to 16 500 windows
(`win10000`) crashes most environments; the 5 kb scale is a complete
non-starter at chromosome scale.

#### 2. Per-window θπ stability

At 9× coverage with ~10–40 callable sites/kb in the LG28 cohort, the
per-sample θπ noise floor is set by site count. Below ~30 kb windows,
the variance of θπ swamps biological signal:

| Scale                | Sites / window  | Per-sample θπ stability             |
|---------------------|-----------------|--------------------------------------|
| `win5000`           | ~50–200         | high variance, mostly noise          |
| `win10000`          | ~100–400        | marginal                             |
| `win50000`          | ~500–2 000      | stable enough to local-PCA            |
| `win500000`         | ~5 000–20 000   | very stable (but no spatial detail)   |

Local-PCA on noisy per-sample features mostly captures noise rather
than biology. This is why MODULE_3's main physical-window default is
500 kb / 500 kb (chosen for stability of per-sample heterozygosity)
and even the multiscale "fine" scale stops at 5 kb / 1 kb step rather
than going smaller.

#### 3. Finer step doesn't buy you breakpoint resolution

Page 1's breakpoints are sharp because the local-PCA clustering signal
is **binary**: a sample is either in the inversion's haplotype cluster
or not, and that flips at SNP-level boundaries. The θπ analog is
**gradient-shaped**: nucleotide diversity drops smoothly across an
inversion's flanks, not in a step. Even at 1 kb step, the θπ-PCA
breakpoint is diffuse over 20–50 kb of genomic space — the underlying
biological gradient sets the floor regardless of scale.

The finer scales (`win5000.step1000`, `win10000.step2000`) ARE useful
for **per-candidate breakpoint inspection** — once a candidate has been
identified, loading the finer-scale data for just that region's
windows gives a cleaner picture of where the diversity drop happens.
That is a per-candidate feature on the boundaries page (current
user-visible page 4), NOT the chromosome scrubber.

#### Layered design summary

| Use case                                | Scale                       | Page                         |
|-----------------------------------------|-----------------------------|------------------------------|
| Chromosome-wide θπ scrubber             | `win50000.step10000`        | page 12 (this page)          |
| Per-candidate breakpoint detail         | `win10000.step2000` zoom → `win5000.step1000` | boundaries page (post-v4.0 θπ track) |
| Genome-wide ideogram tracks             | `win500000.step500000`      | popstats page                |

#### What this means for the schema

`theta_pi_per_window.window_size_bp` is fixed at `50000` and
`step_size_bp` at `10000` for the page-12 scrubber's input layer. The
scrubber's reader rejects layers with other scales (or warns and
disables the page 12 panels). The per-candidate boundary view, when it
ships, will use a separate top-level layer (`theta_pi_per_window_fine`
or per-candidate slices loaded on demand) so the two scales never share
a JSON key.

### 22.5 Page architecture — mirror of page 1

The new page has DOM id `page12` (next available numeric ID; user-visible
position 2 in the tab bar). Tab order shifts: existing pages 2-11 each
move one slot right in the tab bar. **The DOM ids stay the same** —
only the user-visible tab numbering changes. This means all existing
code that looks up `getElementById('page2')` for the candidate-focus
page continues to work; only the tab bar's visible labels change.

Page structure mirrors page 1 panel-for-panel:

```
#page12 (θπ diagnostic)
├── #thCtrlBar           — scrubber slider (mirrors #ctrlBar)
│   ├── play button
│   ├── range input → window index
│   ├── view-mode bar (genome / L1 / L2 zoom)
│   └── window label
├── #thSimPanel          — θπ_sim_mat heatmap (mirrors #simPanel)
├── #thZPanel            — diversity-|Z| waveform (mirrors #zPanel)
├── #thLinesPanel        — per-sample θπ-PC1 lines (mirrors #linesPanel)
├── #thPcaPanel          — θπ-PC1 vs θπ-PC2 K-means scatter (mirrors #pcaPanel)
└── #thL3Panel           — diversity L3 contingency (mirrors #l3Panel)
```

**Each panel reads from the corresponding `theta_pi_*` layer** instead
of the page-1 dosage layers. Renderers can largely reuse page-1's draw
functions (parameterized by which layer to read).

**Empty state** when the three required JSON layers aren't loaded: a
single placeholder panel explaining what the page is, what data it
needs, and what each panel will become once data lands. This is what
ships in v3.99 t14e+ continue. Real renderers light up panel-by-panel
as the R-side emit scripts ship.

### 22.6 What's shipped now (v3.99 t14e+ continue)

Structural scaffold only:

- New DOM page `#page12` with class `page` (matches existing pages)
- Tab-bar button at user-visible position 2 (data-page="page12"), with
  the old position-2 button (candidate focus) and all subsequent
  buttons shifted one slot right; visible numbering updated 2→3, 3→4,
  ..., 11→12
- Empty-state placeholder explaining the page's purpose, the three
  required JSON layers, and the panel-mirror architecture
- Layer detection extended (`detectSchemaAndLayers`) to recognize
  `theta_pi_per_window`, `theta_pi_local_pca`, `theta_pi_envelopes` as
  optional layers
- Help-page roadmap entry under PLANNED · post-v4.0 explaining
  the page-level mirror approach and what happens when each R-side
  layer ships

NOT yet shipped:

- Actual panel renderers (each one is its own follow-up turn)
- The three R-side scripts
- Cross-method candidate-list comparison view (the §22.7 secondary
  surface, see below)

### 22.7 Per-candidate concordance view — the original figure mockups (deferred)

The original §22 design (six panels A-F comparing local PCA to θπ-MDS
for ONE candidate, the figure mockups Quentin sent earlier) becomes
the secondary view. It still has value as a per-candidate deep-dive
once a candidate has been selected from EITHER scrubber. It would live
as a sub-view on the candidate-focus page (page2 → user-visible
position 3 after the tab shift), enabled when both `theta_pi_local_pca`
AND the existing per-candidate karyotype layers are loaded.

This is documented in §22.10 as a backlog item; the page-level mirror
takes priority because it's where candidates get DISCOVERED, not just
inspected.

### 22.8 Cross-method candidate concordance (also deferred)

When BOTH `candidate_intervals` (from page-1 dosage scrubber) AND
`theta_pi_envelopes.candidate_intervals` (from page-2 θπ scrubber) are
loaded, the catalogue gains a "method" column showing each candidate's
provenance:

- `dosage_only` — found by page 1 only
- `theta_pi_only` — found by page 2 only
- `both` — found by both methods (orthogonal validation)
- `both_overlap_partial` — overlapping intervals from both methods but
  with differing boundaries (both methods see something but disagree
  on extent)

This is the payoff Quentin called out — the orthogonal validation
matrix. Implementation deferred to a follow-up turn after both
scrubbers have real candidate lists to compare.

### 22.9 R-side scripts (planned)

Three new R-side emit scripts:

```r
# STEP_R39_emit_theta_pi_per_window.R
# Compute per-sample θπ in sliding 50 kb windows (step 25 kb).
# Inputs: per-sample BAM or VCF; reference FASTA for window coords.
# For each sample × window: count segregating sites, compute θπ.
# Emit theta_pi_per_window layer.

# STEP_R40_emit_theta_pi_local_pca.R
# For each window:
#   1. Pull per-sample θπ vector across windows in a local neighbourhood
#      (matching page 1's window-PCA neighbourhood — usually ~5 windows)
#   2. Run local PCA on the (samples × neighbourhood-windows) matrix
#   3. Compute λ₁, λ₂, robust |Z|, PC1/PC2 per sample
# Compute window×window sim_mat (cor between PC-loadings or similar)
# Compute MDS of sim_mat to 2D
# Emit theta_pi_local_pca layer.

# STEP_R41_emit_theta_pi_envelopes.R
# Threshold theta_pi_local_pca.z → L1 envelopes
# Re-run local-PCA-style decomposition inside each L1 → L2 sub-envelopes
# Promote L2s passing thresholds → candidate_intervals
# Emit theta_pi_envelopes layer.
```

These scripts mirror the existing R-side dosage scrubber pipeline
(`STEP_R10_emit_window_pca.R`, etc., from the cluster-side STEP_R20-R23
work). Naming uses R39/R40/R41 since R36-R38 were reserved for §15
(per-sample θπ) and prior §22 (per-candidate MDS / concordance).

### 22.10 What's NOT YET WIRED (post-v4.0 backlog)

- **Panel renderers**: each of the 6 panels in §22.5 needs a renderer
  that reads from `theta_pi_*` layers instead of dosage layers. Start
  with `#thZPanel` (the |Z| waveform — simplest panel, single 1-D
  array) and grow.
- **Candidate-list cross-method merge**: §22.8 catalogue extension
  showing dosage-only / θπ-only / both candidates side-by-side
- **Per-candidate concordance sub-view** (the original figure mockups):
  six panels A-F as a sub-view on the candidate-focus page, surfacing
  per-candidate the contingency-table-style cross-method comparison
  (§22.7)
- **The three R-side scripts** (STEP_R39, R40, R41) — these block all
  the above
- **Tab-bar number renumbering** is shipped; if Quentin wants the
  user-visible "θπ diagnostic" label to read just "diagnostic" or
  similar, that's a one-line edit in the tab markup

### 22.11 Coexistence with §17 Atlas mode switching

In Inversion Atlas mode (current default), this page sits at
user-visible position 2 ("θπ diagnostic") and is one of TWO scrubbers
(genotype + diversity).

In Diversity Atlas mode (planned, §17), this page is the PRIMARY
surface — the genotype scrubber moves to a secondary slot. Same JSON
layers, different tab-bar emphasis.

### 22.12 Cross-references

- §15 (per-sample line coloring modes) — `theta_pi` mode for the lines
  panel reads `theta_pi_per_window` (now the same layer the new page
  needs)
- §11 (band diagnostics) — `theta_pi_panel` is a per-band aggregate of
  the same θπ data; page 12 is per-window
- §17 (Atlas mode switching) — Diversity Atlas elevates page 12 to
  primary
- §19 (14-axis classification) — `internal_structure` axis correlates
  with θπ-PCA's Het-subdivision detection
- §21 (18 structured blocks) — per-candidate `internal_dynamics` block
  carries metrics that depend on per-sample θπ profiles, the same data
  underlying page 12

### 22.13 Data source pipeline — what already exists vs what's still needed

After Quentin's t14e+ continue follow-up paste of three existing scripts
(`STEP_Q05_aggregate_theta.sh`, `region_popstats.c` / `STEP_Q07_popstats.sh`,
`export_precomp_to_json.R`), here's the honest state of what already
exists and what still needs to be written:

#### ALREADY EXISTS — `STEP_Q05_aggregate_theta.sh` produces `theta_pi_per_window`

`STEP_Q05_aggregate_theta.sh` (in `phase_5_qc_triage/`) aggregates ANGSD
`thetaStat` `.pestPG` files into a long-format TSV:

```
${QC_TRACKS}/theta.<CHR>.<SCALE>.tsv.gz
  columns: sample chrom win_center_bp tP nSites theta_pi_persite
```

This IS the per-sample per-window θπ data the §22.4 `theta_pi_per_window`
layer needs. Production scale is `win50000.step10000` (50 kb sliding
windows, 10 kb step) — same scale page 1's local PCA already uses. No
new R-side script is needed for this layer; the existing Q05 already
produces the right data at the right resolution.

#### ALREADY EXISTS — `export_precomp_to_json.R` already wires Q05 output

The existing R-side exporter `export_precomp_to_json.R` in
`phase_5_qc_triage/` already accepts a `--theta` argument pointing at
Q05's TSV and embeds the per-sample θπ inside each window object as
`w.theta` (an array of n_samples values, sign-aligned by precomp window
index). Code path: lines around `theta_by_sample <- matrix(...)` and the
later `if (!is.null(theta_by_sample)) { w$theta <- ... }` inside the
windows-array-build loop.

This means **JSON files exported with `--theta` already carry the data
the page-12 θπ scrubber needs** — just under a different shape than
§22.4 originally proposed. Two viable embeddings:

- **Per-window embedding (existing pattern)**: each `w.theta` is an
  array of n_samples θπ values. Compact, aligned with how page 1's
  per-window data lives. Reading from `data.windows[i].theta[j]`.
- **Top-level layer (my §22.4 original proposal)**: `theta_pi_per_window`
  as a top-level object with `samples`, `windows`, `values` (typed
  array). Symmetric with how page 1's PC1/PC2/sim_mat live at top level.

**Decision (subject to revision)**: the scrubber's page-12 reader will
**accept BOTH shapes** transparently. A small adapter `_thetaPiResolve()`
checks which shape is present and presents a uniform interface to the
panel renderers. That way:

1. JSONs already exported with the existing `export_precomp_to_json.R`
   path (window-keyed `w.theta`) work without re-export.
2. New cluster-side emits using the planned top-level layer also work.

#### DOES NOT EXIST — `theta_pi_local_pca` (the actual θπ-PCA)

The piece that's NEW is running local PCA **on θπ profiles** instead of
on dosage. The existing pipeline does NOT do this — Q05 produces the
input, but no R-side step computes per-window PCA on the per-sample θπ
matrix. This is genuinely Quentin's discovery; `STEP_R40_emit_theta_pi_local_pca.R`
needs to be written.

The script's job: for each window, take the (samples × neighbourhood-windows)
θπ matrix, run local PCA, emit `z`, `lam1`, `lam2`, `ratio`, `pc1`, `pc2`,
`sim_mat`, `mds_coords` — same shapes as page 1's existing top-level
arrays. ~150 lines of R, mostly mirroring the existing dosage local-PCA
script's structure with the input matrix swapped.

#### NOT SUITABLE — `region_popstats.c` / Q07 produces a DIFFERENT layer

`region_popstats.c` (Engine F, in `unified_ancestry/`) and its wrapper
`STEP_Q07_popstats.sh` produce **per-window per-GROUP** population
stats: Hudson Fst, dXY, dA, theta_pi (pooled within group), theta_W,
Tajima's D, MI, MI_norm. This is per-group aggregation, NOT per-sample.

Q07 is excellent for the per-candidate cross-method concordance figure
(the deferred §22.7 view — its outputs would feed the contingency-table
side of the cross-method comparison once a candidate has karyotype
groups assigned). It is **NOT** what the page-12 chromosome-wide
scrubber needs — that needs per-sample θπ profiles to run local PCA on.

So the question "is it Q05 or Q07?" has a clear answer:
- **Q05** for the page-12 scrubber's `theta_pi_per_window` input
- **Q07** for the deferred per-candidate concordance view (§22.7)
- Both are different cuts of related data; both eventually useful

#### Updated dependency map

| Layer | Source | Status |
|---|---|---|
| `theta_pi_per_window` | `STEP_Q05_aggregate_theta.sh` → `theta.<CHR>.<SCALE>.tsv.gz` | **EXISTS**, already wired through `export_precomp_to_json.R --theta` |
| `theta_pi_local_pca` | `STEP_R40` (planned, NEW) — runs local PCA on per-window per-sample θπ | NOT YET WRITTEN |
| `theta_pi_envelopes` | `STEP_R41` (planned, NEW) — thresholds θπ-`z` into L1/L2 envelopes | NOT YET WRITTEN |
| Per-candidate cross-method concordance (§22.7) | `STEP_Q07_popstats.sh` (already exists) + a small R post-processor for contingency / ARI / NMI | partial — Q07 ships pooled per-group stats, just needs aggregation |

The picture changed: **two of the three layers go from "all new" to
"one already exists, one needs writing"**, and the per-candidate
concordance view (§22.7) is closer to ready than originally documented
because Q07 is already producing per-group aggregates.

### 22.14 internal_ancestry_composition.py — planned per-candidate panel

Quentin's t14e+ continue paste of `internal_ancestry_composition.py`
(formerly `nested_composition.py`) raises a separate question: should
this composition classifier feed the scrubber? And where?

The script takes a parent interval + per-window per-sample ancestry
labels (from Engine B's `local_Q_samples.tsv.gz`) and classifies each
sample's internal structure within that interval as one of:

| Class | Meaning |
|---|---|
| `homogeneous` | One ancestry label across the whole interval |
| `dominant_plus_secondary` | Dominant label ≥80% + small minority |
| `two_block_composite` | Two-label, 30–70% split, low switching |
| `continuous_gradient` | Smooth monotonic transition between two halves |
| `multi_block_fragmented` | High switching rate (≥40% of positions) |
| `diffuse_mixed` | Many labels, high entropy |

Per-sample fragmentation score, internal entropy, block analysis, and
a per-parent dominant_structure_type with breakdown across samples.

#### Where this fits in the scrubber

Two reasonable placements, neither shipped this turn:

**Option A (page 1 + page 12, activate-on-zoom)**: when the user zooms
into an L2 or L3 envelope, run the composition classifier on that
envelope's samples and surface the result as a small panel below the
K-means scatter. Quentin's framing in his message: "Maybe it can be
for page 1 and page 2 like activate nested composition detection ??
When in L2 or L3 or ?" — yes, this is the natural fit. The panel reads
from `data.ancestry_sample` (the per-window per-sample maxQ matrix
already loaded in §11 ancestry context) and runs the same algorithm
the Python file implements, in JS.

**Option B (page 3 candidate focus, always-on)**: when a candidate is
viewed, show the composition classification as one of the per-candidate
analysis panels. This matches the chip-row + JSON-inspector pattern
already established for §21 structured blocks.

**Recommendation**: BOTH, scoped differently. Option A on pages 1/12
when zoomed to L2/L3 (chromosome-scale exploratory tool). Option B on
page 3 (per-candidate persistent panel). Same algorithm, two render
paths.

#### What needs to ship

1. **JS port of `classify_structure()` + `analyze_parent_composition()`**
   — pure-function port of the Python algorithm; ~100 lines, no external
   dependencies. Reads from `data.ancestry_sample` (already loaded per
   §11 / §13 context) and produces the per-sample composition classes
   + per-parent breakdown.
2. **Page 1/12 zoom-trigger**: when `state.viewMode === 'l2'` or `'l3'`
   AND `ancestry_sample` layer is loaded, render a composition panel
   below the K-means scatter. Lazy — only runs when the user actually
   zooms.
3. **Page 3 always-on panel**: a new candidate-focus panel
   `candidateCompositionHtml(c)` that runs the classifier on the
   candidate's interval and shows per-sample structure type + per-parent
   dominant class + small fragmentation distribution.
4. **Optional R-side emit (`STEP_C01i_c_nested_composition.py` already
   exists)**: when the cluster-side wrapper has run, the result is in
   the `internal_dynamics` block (§21 block 7) under fields like
   `internal_structure` (already documented in §19) — so the scrubber
   can EITHER compute composition live in JS OR read the precomputed
   result from `evidence_blocks[cid].internal_dynamics`. When the block
   is loaded (via §20 registry interop), prefer the precomputed result;
   when not loaded, compute live in JS.

#### Naming clarification

The script's docstring carefully distinguishes "internal ancestry
composition" (data-structure: Q windows nested inside parent intervals)
from "nested inversion" (inversion-inside-inversion, a stronger
biological claim). The scrubber must respect this distinction:

- A `two_block_composite` verdict is a **diagnostic finding**, not a
  classification of "this candidate is a nested inversion."
- The interpretation step (mapping composite verdict → "this looks
  like a nested inversion, run cross-checks") is a downstream
  inference layer, NOT shipped in the composition panel itself. The
  panel just shows the composition; the interpretation belongs in
  §21's `internal_dynamics` block + §19's `internal_structure` axis.

#### Status

NOT shipped this turn. Documented in §22.14 as a planned panel + §22's
post-v4.0 backlog. The same `ancestry_sample` data the panel needs is
already loaded by `export_precomp_to_json.R --ancestry_samples` (the
existing `maxq_by_sample` matrix). Algorithm port, panel renderer, and
zoom-trigger wiring all wait for a follow-up turn.

### 22.15 Schema-version impact

Schema bump confirmed: 2.18 → **2.19**. Three new optional top-level
JSON layers (`theta_pi_per_window`, `theta_pi_local_pca`,
`theta_pi_envelopes`). Of those: **`theta_pi_per_window` already exists
in production** (per §22.13: emitted by `STEP_Q05_aggregate_theta.sh` →
embedded into JSON as `w.theta` per-window via `export_precomp_to_json.R --theta`)
— so the scrubber's reader accepts both the existing per-window
embedding AND the planned top-level layer. The remaining two
(`theta_pi_local_pca`, `theta_pi_envelopes`) need new R-side scripts.
Scrubber-side structural scaffold (DOM page, tab button "local PCA
thetapi" mirroring page 1's "local PCA |z|", empty state, layer
detection) ships in v3.99 t14e+ continue. Panel renderers ship as
follow-up turns when the local-PCA-on-θπ output lands. NO new required
fields; legacy precomp JSONs continue to work.

§22.14 (internal_ancestry_composition.py panel) and §22.13 (data source
pipeline clarification) are documentation additions; no contract change.

---
