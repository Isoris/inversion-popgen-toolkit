#!/usr/bin/env node
// =============================================================================
// v4.1 continue full-scope: u/v mode-expansion runtime tests
// =============================================================================
// Tests four new u/v-based clustering modes shipped in this release:
//   - uv-denoise   (DBSCAN as pre-filter, K-means3 on survivors)
//   - uv-dbscan    (K-means3 first, DBSCAN within each stripe)
//   - uv-dist-rank (closest tercile of Hom1/Hom2 to Het centroid → Het label)
//   - uv-dist-fuzzy (soft inverse-distance argmax with tie-break threshold)
//
// Plus the supporting primitives:
//   - _getOrComputeUVRotation(l2idx) — shared rotation cache
//   - _dbscan(pointsObj, eps, minPts) — pure-JS DBSCAN
//   - _kDistAutoEps(pointsObj, k)    — auto-eps from median k-NN distance
//
// All tests run on synthetic data mimicking real inversion stripe patterns.
// =============================================================================

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

const sandbox = {
  console,
  Math, Number, isFinite, parseFloat, parseInt, Array, ArrayBuffer,
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, DataView, Map, Set, Symbol, Promise,
  document: {
    getElementById: () => null, querySelectorAll: () => [],
    addEventListener: () => {}, body: { addEventListener: () => {} },
    createElement: () => ({ style: {}, addEventListener: () => {},
                            appendChild: () => {}, querySelector: () => null }),
  },
  window: { addEventListener: () => {}, removeEventListener: () => {},
            matchMedia: () => ({ matches: false, addEventListener: () => {} }) },
  localStorage: { _store: {}, getItem(k) { return this._store[k] || null; },
                  setItem(k, v) { this._store[k] = String(v); } },
  setTimeout: () => 0, clearTimeout: () => 0, requestAnimationFrame: () => 0,
  performance: { now: () => 0 },
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; console.log('  PASS', msg); }
  else { fail++; console.log('  FAIL', msg); }
}
function approx(a, b, tol, msg) {
  const ok_ = Math.abs(a - b) < tol;
  if (ok_) { pass++; console.log('  PASS', msg, `(${a.toFixed(4)} ≈ ${b.toFixed(4)})`); }
  else { fail++; console.log('  FAIL', msg, `(${a.toFixed(4)} vs ${b.toFixed(4)})`); }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) {}

  console.log('\n--- v4.1 continue full-scope: u/v modes runtime tests ---');

  // ============================================================================
  // Function existence
  // ============================================================================
  console.log('\n  --- function existence ---');
  ok(typeof sandbox._getOrComputeUVRotation === 'function',
     '_getOrComputeUVRotation defined');
  ok(typeof sandbox._dbscan === 'function',
     '_dbscan defined');
  ok(typeof sandbox._kDistAutoEps === 'function',
     '_kDistAutoEps defined');
  ok(typeof sandbox.clusterL2_UVRotated === 'function',
     'clusterL2_UVRotated defined (cache-aware version of distance-uv)');
  ok(typeof sandbox.clusterL2_UVDenoise === 'function',
     'clusterL2_UVDenoise defined');
  ok(typeof sandbox.clusterL2_UVDBSCAN === 'function',
     'clusterL2_UVDBSCAN defined');
  ok(typeof sandbox.clusterL2_UVDistRank === 'function',
     'clusterL2_UVDistRank defined');
  ok(typeof sandbox.clusterL2_UVDistFuzzy === 'function',
     'clusterL2_UVDistFuzzy defined');

  // ============================================================================
  // _dbscan primitive — synthetic data with known ground truth
  // ============================================================================
  console.log('\n  --- _dbscan primitive ---');
  // Three well-separated 1D clusters: { -5..-4 } (10 pts), { -0.5..0.5 } (10 pts), { 4..5 } (10 pts)
  // Plus 2 outliers at -10 and +10
  const dbsc1d = new Float64Array([
    -5, -4.5, -4.8, -4.3, -4.7, -4.2, -4.9, -4.4, -4.6, -4.1,
    -0.4, -0.2, 0, 0.2, 0.4, -0.1, 0.1, -0.3, 0.3, 0.05,
     4, 4.5, 4.8, 4.3, 4.7, 4.2, 4.9, 4.4, 4.6, 4.1,
    -10, 10
  ]);
  // eps=0.6, minPts=3. Should find 3 clusters + 2 noise points
  const labels1d = sandbox._dbscan(dbsc1d, 0.6, 3);
  const noise1d = Array.from(labels1d).filter(l => l === 0).length;
  const nClust1d = Math.max(...Array.from(labels1d));
  ok(nClust1d === 3,
     `_dbscan finds 3 clusters in well-separated 1D data (got ${nClust1d})`);
  ok(noise1d === 2,
     `_dbscan flags 2 outliers as noise (got ${noise1d})`);

  // 2D test: same three clusters at different (x, y) positions, with noise
  const dbsc2d_data = new Float64Array(60);
  // Cluster 1 around (-3, -3)
  for (let i = 0; i < 10; i++) {
    dbsc2d_data[i*2] = -3 + (Math.random() - 0.5) * 0.4;
    dbsc2d_data[i*2+1] = -3 + (Math.random() - 0.5) * 0.4;
  }
  // Cluster 2 around (0, 0)
  for (let i = 10; i < 20; i++) {
    dbsc2d_data[i*2] = 0 + (Math.random() - 0.5) * 0.4;
    dbsc2d_data[i*2+1] = 0 + (Math.random() - 0.5) * 0.4;
  }
  // Cluster 3 around (3, 3)
  for (let i = 20; i < 30; i++) {
    dbsc2d_data[i*2] = 3 + (Math.random() - 0.5) * 0.4;
    dbsc2d_data[i*2+1] = 3 + (Math.random() - 0.5) * 0.4;
  }
  const labels2d = sandbox._dbscan({ dim: 2, data: dbsc2d_data, n: 30 }, 0.8, 3);
  const nClust2d = Math.max(...Array.from(labels2d));
  ok(nClust2d === 3,
     `_dbscan finds 3 clusters in well-separated 2D data (got ${nClust2d})`);

  // Edge: all points in a tight blob → 1 cluster, no noise
  const dbsc_tight = new Float64Array([0, 0.1, 0.05, -0.05, 0.02, -0.02, 0.08, -0.08, 0.03, -0.03]);
  const lab_tight = sandbox._dbscan(dbsc_tight, 0.5, 3);
  const nClust_tight = Math.max(...Array.from(lab_tight));
  const noise_tight = Array.from(lab_tight).filter(l => l === 0).length;
  ok(nClust_tight === 1 && noise_tight === 0,
     `_dbscan groups tight blob as single cluster, no noise (clusters=${nClust_tight}, noise=${noise_tight})`);

  // Edge: all points isolated (eps too small) → all noise
  const dbsc_sparse = new Float64Array([0, 10, 20, 30, 40]);
  const lab_sparse = sandbox._dbscan(dbsc_sparse, 0.5, 3);
  const all_noise = Array.from(lab_sparse).every(l => l === 0);
  ok(all_noise, '_dbscan flags all points as noise when eps is too small');

  // ============================================================================
  // _kDistAutoEps — verify eps = median(k-NN) * 0.8
  // ============================================================================
  console.log('\n  --- _kDistAutoEps ---');
  // Uniform spacing: each point's 1-NN distance = 1
  const uniform = new Float64Array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
  const eps_uniform = sandbox._kDistAutoEps(uniform, 1);
  approx(eps_uniform, 0.8, 1e-9, 'eps = 1.0 × 0.8 = 0.8 for uniform unit spacing (k=1)');

  // For k=3, the 3-NN distance for interior points is 3 (gap of 1 each direction
  // gives 1-NN=1, 2-NN=2, 3-NN=3); endpoints have larger 3-NN. Median ~3.
  // BUT: my _kDistAutoEps uses k_actual = min(k, n-1), so if we pass k=3 with n=10,
  // it uses k=3 (which is min(3, 9)=3). Median of 3-NN distances...
  const eps_k3 = sandbox._kDistAutoEps(uniform, 3);
  ok(eps_k3 > 1.5 && eps_k3 < 4,
     `_kDistAutoEps for k=3 uniform spacing returns reasonable value (got ${eps_k3.toFixed(2)})`);

  // 2D version
  const u2d = new Float64Array([0, 0, 1, 0, 2, 0, 3, 0, 4, 0]);   // row of 5 unit-spaced
  const eps_2d = sandbox._kDistAutoEps({ dim: 2, data: u2d, n: 5 }, 1);
  approx(eps_2d, 0.8, 1e-9, '2D _kDistAutoEps: eps = 0.8 for unit-spaced 2D row (k=1)');

  // Edge: degenerate (n < 2) → NaN
  const eps_one = sandbox._kDistAutoEps(new Float64Array([5]), 1);
  ok(!isFinite(eps_one), '_kDistAutoEps returns NaN for n < 2');

  // ============================================================================
  // Markup tests — picker dropdown contains the new options
  // ============================================================================
  console.log('\n  --- picker UI markup ---');
  ok(/<option value="uv-denoise"[^>]*>uv-denoise<\/option>/.test(html),
     'uv-denoise option in picker, enabled (no disabled attr)');
  ok(/<option value="uv-dbscan"[^>]*>uv-dbscan<\/option>/.test(html),
     'uv-dbscan option in picker, enabled');
  ok(/<option value="uv-dist-rank"[^>]*>uv-dist-rank<\/option>/.test(html),
     'uv-dist-rank option in picker, enabled');
  ok(/<option value="uv-dist-fuzzy"[^>]*>uv-dist-fuzzy<\/option>/.test(html),
     'uv-dist-fuzzy option in picker, enabled');
  // Tooltips reference the algorithm details
  ok(/uv-denoise[\s\S]{0,500}DBSCAN as pre-filter/.test(html),
     'uv-denoise tooltip explains DBSCAN-as-prefilter');
  ok(/uv-dbscan[\s\S]{0,500}STEP22/.test(html),
     'uv-dbscan tooltip references STEP22');
  ok(/uv-dist-rank[\s\S]{0,500}closest tercile/.test(html),
     'uv-dist-rank tooltip mentions closest tercile relabel');
  ok(/uv-dist-fuzzy[\s\S]{0,500}argmax/.test(html),
     'uv-dist-fuzzy tooltip mentions argmax + tie-break');

  // distance-uv kept for localStorage backwards-compat with uv-rotated label
  ok(/<option value="distance-uv"[^>]*>uv-rotated \(distance-uv\)<\/option>/.test(html),
     'distance-uv value preserved with uv-rotated display label (localStorage compat)');

  // Disabled modes
  ok(/<option value="dbscan-raw" disabled[^>]*>dbscan-raw \(planned\)<\/option>/.test(html),
     'dbscan-raw planned-disabled (renamed from "dbscan" to disambiguate from uv-dbscan)');

  // ============================================================================
  // Validity allow-list updated
  // ============================================================================
  console.log('\n  --- mode validity allow-list ---');
  ok(/validModes = \['kmeans-K3', 'kmeans-K6', 'distance-uv', 'uv-rotated',[\s\S]{0,200}'uv-denoise', 'uv-dbscan', 'uv-dist-rank', 'uv-dist-fuzzy'\]/.test(html),
     'validModes allow-list extended to all five u/v modes plus aliases');

  // ============================================================================
  // Dispatcher routes correctly
  // ============================================================================
  console.log('\n  --- getL2ClusterByMode dispatcher ---');
  ok(/case 'distance-uv':[\s\S]{0,200}case 'uv-rotated':[\s\S]{0,100}clusterL2_UVRotated/.test(html),
     "dispatcher routes 'distance-uv' AND 'uv-rotated' → clusterL2_UVRotated");
  ok(/case 'uv-denoise':[\s\S]{0,100}clusterL2_UVDenoise/.test(html),
     "dispatcher routes 'uv-denoise' → clusterL2_UVDenoise");
  ok(/case 'uv-dbscan':[\s\S]{0,100}clusterL2_UVDBSCAN/.test(html),
     "dispatcher routes 'uv-dbscan' → clusterL2_UVDBSCAN");
  ok(/case 'uv-dist-rank':[\s\S]{0,100}clusterL2_UVDistRank/.test(html),
     "dispatcher routes 'uv-dist-rank' → clusterL2_UVDistRank");
  ok(/case 'uv-dist-fuzzy':[\s\S]{0,100}clusterL2_UVDistFuzzy/.test(html),
     "dispatcher routes 'uv-dist-fuzzy' → clusterL2_UVDistFuzzy");

  // ============================================================================
  // §21 registry consumer fallback path present
  // ============================================================================
  console.log('\n  --- §21 registry consumer ---');
  ok(/state\.candidateUVModes/.test(html),
     'state.candidateUVModes referenced (consumer side wired)');
  ok(/state\.candidateUVModes\._byL2Mode/.test(html),
     '_byL2Mode lookup map referenced for fast L2-mode → precomp result lookup');
  ok(/STEP_R\?\?_emit_uv_modes_per_candidate/.test(html),
     'planned R-side script name referenced in dispatcher comments');

  // ============================================================================
  // Shared rotation cache present
  // ============================================================================
  console.log('\n  --- shared rotation cache ---');
  ok(/state\.l2UVRotationCache/.test(html),
     'state.l2UVRotationCache exists for shared rotation memoization');
  ok(/state\._l2UVRotationCacheDataKey/.test(html),
     'rotation cache invalidation key tracked');

  console.log(`\n--- v4.1 continue full-scope u/v modes runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
