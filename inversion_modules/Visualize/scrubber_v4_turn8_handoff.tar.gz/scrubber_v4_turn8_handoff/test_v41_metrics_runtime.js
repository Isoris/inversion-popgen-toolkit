#!/usr/bin/env node
// =============================================================================
// v4.1 runtime test suite — partition-comparison metrics + L3 UI scaffold
// =============================================================================
// Tests:
//   1. nmiFromTable / amiFromTable / ariFromTable on textbook examples
//   2. Edge cases: perfect agreement, perfect disagreement, single-cluster
//   3. Permutation invariance — relabeling clusters in either partition
//      should NOT change NMI / AMI / ARI (this is the property Cramér's V
//      lacks, and the reason these metrics were added in v4.1)
//   4. Numerical stability — bounded outputs, no NaN
//   5. L3 metric-cycle chip + L3 re-clustering picker UI scaffold present
//      with all 9 modes and correct disabled flags
// =============================================================================

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

// Minimal sandbox — these are pure-math functions, no DOM needed
const sandbox = {
  console,
  Math, Number, isFinite, parseFloat, parseInt,
  Float32Array, Float64Array, Int32Array, Uint8Array,
  ArrayBuffer, DataView, Map, Set, Symbol, Promise,
  document: {
    getElementById: () => null, querySelectorAll: () => [],
    addEventListener: () => {}, body: { addEventListener: () => {} },
    createElement: () => ({ style: {}, addEventListener: () => {},
                            appendChild: () => {}, querySelector: () => null }),
  },
  window: { addEventListener: () => {}, removeEventListener: () => {},
            matchMedia: () => ({ matches: false, addEventListener: () => {} }) },
  localStorage: { _store: {}, getItem(k) { return this._store[k] || null; },
                  setItem(k, v) { this._store[k] = String(v); } },
  setTimeout: () => 0, clearTimeout: () => 0, requestAnimationFrame: () => 0,
  performance: { now: () => 0 },
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { pass++; console.log('  PASS', msg); }
  else { fail++; console.log('  FAIL', msg); }
}
function approx(a, b, tol, msg) {
  const ok_ = Math.abs(a - b) < tol;
  if (ok_) { pass++; console.log('  PASS', msg, `(${a.toFixed(4)} ≈ ${b.toFixed(4)})`); }
  else { fail++; console.log('  FAIL', msg, `(${a.toFixed(4)} vs expected ${b.toFixed(4)}, |diff|=${Math.abs(a-b).toFixed(4)})`); }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated — DOM-dependent code paths fail silently */ }

  console.log('\n--- v4.1: partition-comparison metric runtime tests ---');

  // Verify the functions are exposed
  ok(typeof sandbox.nmiFromTable === 'function', 'nmiFromTable defined');
  ok(typeof sandbox.amiFromTable === 'function', 'amiFromTable defined');
  ok(typeof sandbox.ariFromTable === 'function', 'ariFromTable defined');
  ok(typeof sandbox._miFromTable === 'function', '_miFromTable defined');
  ok(typeof sandbox._entropyMarginal === 'function', '_entropyMarginal defined');

  // ============================================================================
  // PERFECT AGREEMENT (diagonal contingency)
  // ============================================================================
  console.log('\n  --- perfect agreement (diagonal) ---');
  // 3-cluster perfect: 50 in each diagonal cell
  const T_perfect = [[50, 0, 0], [0, 50, 0], [0, 0, 50]];
  approx(sandbox.nmiFromTable(T_perfect, 3), 1.0, 1e-9, 'NMI = 1 on perfect agreement');
  approx(sandbox.amiFromTable(T_perfect, 3), 1.0, 1e-3, 'AMI ≈ 1 on perfect agreement');
  approx(sandbox.ariFromTable(T_perfect, 3), 1.0, 1e-9, 'ARI = 1 on perfect agreement');

  // ============================================================================
  // PERFECT AGREEMENT BUT WITH PERMUTED LABELS — the case Cramér's V handles
  // but is fundamentally distinguishable; NMI/AMI/ARI should still report 1
  // because they're permutation-invariant.
  // ============================================================================
  console.log('\n  --- permutation invariance ---');
  // Off-diagonal "perfect" (row 0 → col 1, row 1 → col 2, row 2 → col 0)
  const T_perm = [[0, 50, 0], [0, 0, 50], [50, 0, 0]];
  approx(sandbox.nmiFromTable(T_perm, 3), 1.0, 1e-9, 'NMI = 1 on permuted-but-perfect agreement');
  approx(sandbox.amiFromTable(T_perm, 3), 1.0, 1e-3, 'AMI ≈ 1 on permuted-but-perfect agreement');
  approx(sandbox.ariFromTable(T_perm, 3), 1.0, 1e-9, 'ARI = 1 on permuted-but-perfect agreement');

  // ============================================================================
  // RANDOM (independent) — table from product of marginals
  // ============================================================================
  console.log('\n  --- independent (random) partitions ---');
  // Uniform table — each cell exactly equal
  // For perfectly uniform K=3 with N=90 and equal marginals:
  // Each cell = 10. Marginals all = 30. MI = sum (10/90) * log(90*10 / 900) = 0.
  const T_indep = [[10, 10, 10], [10, 10, 10], [10, 10, 10]];
  approx(sandbox.nmiFromTable(T_indep, 3), 0.0, 1e-9, 'NMI = 0 on independent uniform partitions');
  // AMI is chance-corrected; on finite N with deterministic uniform table,
  // observed MI is exactly 0 but E[MI] under hypergeometric null is positive,
  // so AMI = (0 - E[MI])/(max(H) - E[MI]) is mildly negative. This is correct
  // math — AMI ≈ 0 only in expectation across random partitions, not for any
  // specific deterministic table. We just check magnitude is small.
  const ami_indep = sandbox.amiFromTable(T_indep, 3);
  ok(Math.abs(ami_indep) < 0.5, `AMI within ±0.5 on independent uniform table (got ${ami_indep.toFixed(4)})`);
  // Same caveat for ARI on finite N — the uniform deterministic table has
  // ARI close to 0 but not exactly 0 (the chance-correction's expected value
  // doesn't perfectly match the observed agreeing-pair count for any specific
  // table; only in expectation across random partitions). Allow ±0.1.
  const ari_indep = sandbox.ariFromTable(T_indep, 3);
  ok(Math.abs(ari_indep) < 0.1, `ARI within ±0.1 on independent uniform table (got ${ari_indep.toFixed(4)})`);

  // ============================================================================
  // PARTIAL AGREEMENT — known textbook example
  // ============================================================================
  console.log('\n  --- partial agreement ---');
  // 80% agreement on diagonal, 20% off
  const T_partial = [[40, 5, 5], [5, 40, 5], [5, 5, 40]];
  const nmi_partial = sandbox.nmiFromTable(T_partial, 3);
  const ami_partial = sandbox.amiFromTable(T_partial, 3);
  const ari_partial = sandbox.ariFromTable(T_partial, 3);
  ok(nmi_partial > 0 && nmi_partial < 1, `NMI strictly in (0,1) on partial agreement (got ${nmi_partial.toFixed(4)})`);
  ok(ami_partial > 0 && ami_partial < 1, `AMI strictly in (0,1) on partial agreement (got ${ami_partial.toFixed(4)})`);
  ok(ari_partial > 0 && ari_partial < 1, `ARI strictly in (0,1) on partial agreement (got ${ari_partial.toFixed(4)})`);
  ok(ami_partial < nmi_partial,
     `AMI < NMI on partial agreement (chance-correction reduces value: AMI=${ami_partial.toFixed(4)}, NMI=${nmi_partial.toFixed(4)})`);

  // ============================================================================
  // IMBALANCED PARTITIONS — the catfish hatchery use case (180/30/16)
  // ============================================================================
  console.log('\n  --- imbalanced partition (hatchery-like 180/30/16) ---');
  // Partitions agree perfectly but with very imbalanced sizes
  const T_imbal_perfect = [[180, 0, 0], [0, 30, 0], [0, 0, 16]];
  approx(sandbox.nmiFromTable(T_imbal_perfect, 3), 1.0, 1e-9, 'NMI = 1 on perfect agreement even when imbalanced');
  approx(sandbox.ariFromTable(T_imbal_perfect, 3), 1.0, 1e-9, 'ARI = 1 on perfect agreement even when imbalanced');
  // Partial agreement on imbalanced
  const T_imbal_partial = [[170, 5, 5], [5, 25, 0], [5, 0, 11]];
  const nmi_ip = sandbox.nmiFromTable(T_imbal_partial, 3);
  const ari_ip = sandbox.ariFromTable(T_imbal_partial, 3);
  const ami_ip = sandbox.amiFromTable(T_imbal_partial, 3);
  ok(nmi_ip > 0 && nmi_ip < 1, `NMI on imbalanced partial: ${nmi_ip.toFixed(4)}`);
  ok(ari_ip > 0 && ari_ip < 1, `ARI on imbalanced partial: ${ari_ip.toFixed(4)}`);
  ok(ami_ip > 0 && ami_ip < 1, `AMI on imbalanced partial: ${ami_ip.toFixed(4)}`);

  // ============================================================================
  // EDGE CASES
  // ============================================================================
  console.log('\n  --- edge cases ---');
  // Empty table → 0
  const T_empty = [[0, 0, 0], [0, 0, 0], [0, 0, 0]];
  approx(sandbox.nmiFromTable(T_empty, 3), 0, 1e-9, 'NMI = 0 on empty table');
  approx(sandbox.amiFromTable(T_empty, 3), 0, 1e-9, 'AMI = 0 on empty table');
  approx(sandbox.ariFromTable(T_empty, 3), 0, 1e-9, 'ARI = 0 on empty table');

  // All in one cell → both partitions degenerate (one-cluster); NMI = 0 (no info)
  const T_single = [[100, 0, 0], [0, 0, 0], [0, 0, 0]];
  approx(sandbox.nmiFromTable(T_single, 3), 0, 1e-9, 'NMI = 0 when both partitions are single-cluster');
  approx(sandbox.ariFromTable(T_single, 3), 1, 1e-9, 'ARI = 1 by convention when both partitions are single-cluster (no disagreement possible)');

  // K=2 case (binary partitioning — minimal valid case)
  console.log('\n  --- K=2 case ---');
  const T_k2_perfect = [[40, 0], [0, 60]];
  approx(sandbox.nmiFromTable(T_k2_perfect, 2), 1.0, 1e-9, 'K=2 NMI = 1 on perfect agreement');
  approx(sandbox.ariFromTable(T_k2_perfect, 2), 1.0, 1e-9, 'K=2 ARI = 1 on perfect agreement');

  // K=2 partial: 80% agreement
  const T_k2_partial = [[40, 10], [10, 40]];
  const nmi_k2 = sandbox.nmiFromTable(T_k2_partial, 2);
  const ari_k2 = sandbox.ariFromTable(T_k2_partial, 2);
  ok(nmi_k2 > 0 && nmi_k2 < 1, `K=2 NMI on partial: ${nmi_k2.toFixed(4)}`);
  ok(ari_k2 > 0 && ari_k2 < 1, `K=2 ARI on partial: ${ari_k2.toFixed(4)}`);

  // ============================================================================
  // BOUNDS — outputs must be in their stated ranges
  // ============================================================================
  console.log('\n  --- output bounds ---');
  // Adversarial: very small but valid table
  const T_small = [[1, 2, 0], [0, 3, 0], [1, 0, 1]];
  const n_s = sandbox.nmiFromTable(T_small, 3);
  const a_s = sandbox.amiFromTable(T_small, 3);
  const r_s = sandbox.ariFromTable(T_small, 3);
  ok(n_s >= 0 && n_s <= 1, `NMI in [0,1] on small table (${n_s.toFixed(4)})`);
  ok(a_s >= -1 && a_s <= 1, `AMI in [-1,1] on small table (${a_s.toFixed(4)})`);
  ok(r_s >= -1 && r_s <= 1, `ARI in [-1,1] on small table (${r_s.toFixed(4)})`);

  // ============================================================================
  // SCALING INVARIANCE — multiplying all counts by k should not change metrics
  // (they're all functions of proportions, not absolute counts)
  // ============================================================================
  console.log('\n  --- scaling invariance ---');
  const T_base = [[20, 5, 5], [5, 20, 5], [5, 5, 20]];
  const T_x10 = [[200, 50, 50], [50, 200, 50], [50, 50, 200]];
  const nmi_base = sandbox.nmiFromTable(T_base, 3);
  const nmi_x10 = sandbox.nmiFromTable(T_x10, 3);
  approx(nmi_base, nmi_x10, 1e-9, 'NMI invariant under uniform scaling');
  const ari_base = sandbox.ariFromTable(T_base, 3);
  const ari_x10 = sandbox.ariFromTable(T_x10, 3);
  // ARI is asymptotically scale-invariant — exact only as N → ∞ because of
  // the (n-1) terms in C(n,2) = n(n-1)/2. For T_base (N=90) vs T_x10 (N=900)
  // the difference is small but nonzero. A 0.05 tolerance covers it.
  approx(ari_base, ari_x10, 0.05, 'ARI approximately invariant under uniform scaling (asymptotic)');

  // ============================================================================
  // MUTUAL INFORMATION sanity — MI ≤ min(H(X), H(Y))
  // ============================================================================
  console.log('\n  --- MI ≤ min entropy ---');
  // For T_partial above
  const mi = sandbox._miFromTable(T_partial, 3);
  let row3 = [0, 0, 0], col3 = [0, 0, 0], n_total = 0;
  for (let r = 0; r < 3; r++) for (let c = 0; c < 3; c++) {
    row3[r] += T_partial[r][c]; col3[c] += T_partial[r][c]; n_total += T_partial[r][c];
  }
  const hX = sandbox._entropyMarginal(row3, n_total);
  const hY = sandbox._entropyMarginal(col3, n_total);
  ok(mi <= hX + 1e-9 && mi <= hY + 1e-9,
     `MI (${mi.toFixed(4)}) ≤ min(H(X)=${hX.toFixed(4)}, H(Y)=${hY.toFixed(4)})`);
  ok(mi >= 0, `MI ≥ 0 (got ${mi.toFixed(4)})`);

  // ============================================================================
  // UI SCAFFOLD — markup tests
  // ============================================================================
  console.log('\n  --- UI scaffold ---');
  ok(/class="ct-row l3-metric-chip"/.test(html),
     'L3 metric chip has class l3-metric-chip');
  ok(/data-metric-active="\$\{activeKey\}"/.test(html),
     'metric chip has data-metric-active attr');
  ok(/data-cramer="\$\{cramerV\.toFixed\(4\)\}"/.test(html),
     'metric chip stashes cramerV value');
  ok(/data-nmi="\$\{nmiVal\.toFixed\(4\)\}"/.test(html),
     'metric chip stashes nmiVal');
  ok(/data-ami="\$\{amiVal\.toFixed\(4\)\}"/.test(html),
     'metric chip stashes amiVal');
  ok(/data-ari="\$\{ariVal\.toFixed\(4\)\}"/.test(html),
     'metric chip stashes ariVal');
  ok(/l3-metric-chip[\s\S]{0,2000}cursor: pointer; user-select: none/.test(html),
     'metric chip has cursor:pointer + user-select:none in style attr');
  ok(/Click to cycle: Cramér's V → NMI → AMI → ARI → Cramér's V/.test(html),
     'metric chip tooltip explains the cycle order');

  // L3 re-clustering mode picker scaffold
  ok(/id="l3ReclusterMode"/.test(html),
     'L3 re-clustering mode picker container present');
  ok(/id="l3ReclusterSel"/.test(html),
     'L3 re-clustering select element present');
  // 9 modes total, 3 enabled, 6 disabled
  ok(/<option value="kmeans-K3"[^>]*>kmeans-K3<\/option>/.test(html),
     'kmeans-K3 option (default, current behavior)');
  ok(/<option value="kmeans-K6"[^>]*>kmeans-K6<\/option>/.test(html),
     'kmeans-K6 option enabled');
  // distance-uv keeps value="distance-uv" for localStorage backwards-compat;
  // display label updated to "uv-rotated (distance-uv)" to convey that this
  // is the rotated-K-means3 canonical mode.
  ok(/<option value="distance-uv"[^>]*>uv-rotated \(distance-uv\)<\/option>/.test(html),
     'distance-uv option enabled (label: uv-rotated (distance-uv))');
  // v4.1 continue full-scope: four new u/v modes shipped enabled
  ok(/<option value="uv-denoise"[^>]*>uv-denoise<\/option>/.test(html),
     'uv-denoise option enabled (DBSCAN as pre-filter)');
  ok(/<option value="uv-dbscan"[^>]*>uv-dbscan<\/option>/.test(html),
     'uv-dbscan option enabled (mirrors STEP22 within-stripe DBSCAN)');
  ok(/<option value="uv-dist-rank"[^>]*>uv-dist-rank<\/option>/.test(html),
     'uv-dist-rank option enabled (closest tercile to Het relabeled)');
  ok(/<option value="uv-dist-fuzzy"[^>]*>uv-dist-fuzzy<\/option>/.test(html),
     'uv-dist-fuzzy option enabled (soft argmax with tie-break)');
  ok(/<option value="gmm-3" disabled[^>]*>gmm-3 \(planned\)<\/option>/.test(html),
     'gmm-3 option disabled with (planned) suffix');
  ok(/<option value="gmm-4" disabled[^>]*>gmm-4 \(planned\)<\/option>/.test(html),
     'gmm-4 option disabled');
  ok(/<option value="gmm-5" disabled[^>]*>gmm-5 \(planned\)<\/option>/.test(html),
     'gmm-5 option disabled');
  ok(/<option value="gmm-6" disabled[^>]*>gmm-6 \(planned\)<\/option>/.test(html),
     'gmm-6 option disabled');
  // standalone "dbscan" planned option renamed to "dbscan-raw" to disambiguate
  // from uv-dbscan which is now shipping
  ok(/<option value="dbscan-raw" disabled[^>]*>dbscan-raw \(planned\)<\/option>/.test(html),
     'dbscan-raw option disabled (renamed from "dbscan" — uv-dbscan ships separately)');
  ok(/<option value="dosage" disabled[^>]*>dosage \(planned\)<\/option>/.test(html),
     'dosage option disabled (needs dosage_chunks layer)');

  // State slots present
  ok(/l3SecondaryMetric: 'cramer'/.test(html),
     'state.l3SecondaryMetric defaults to cramer (preserves pre-v4.1 behavior)');
  ok(/l3ReclusterMode: 'kmeans-K3'/.test(html),
     'state.l3ReclusterMode defaults to kmeans-K3 (current behavior)');

  // Click handler installed (via _v41HandlerInstalled flag)
  ok(/window\._v41HandlerInstalled = true/.test(html),
     'metric-cycle click handler installed flag set');
  ok(/localStorage\.setItem\('pca_scrubber_v3\.l3SecondaryMetric'/.test(html),
     'metric-cycle persists choice to localStorage');
  ok(/localStorage\.setItem\('pca_scrubber_v3\.l3ReclusterMode'/.test(html),
     're-clustering mode persists choice to localStorage');

  // SCRUBBER_VERSION bumped to v4
  ok(/const SCRUBBER_VERSION = 'v4'/.test(html),
     'SCRUBBER_VERSION = v4 (renamed from v4.1)');

  console.log(`\n--- v4.1 metric runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
