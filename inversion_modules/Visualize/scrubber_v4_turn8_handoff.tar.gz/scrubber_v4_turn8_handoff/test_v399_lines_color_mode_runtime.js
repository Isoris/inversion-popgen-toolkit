#!/usr/bin/env node
// Runtime behavioral test for v3.99 t14e+ lines color mode picker scaffold.
// Unlike test_v399.js (regex-against-source), this test extracts the script,
// runs it in a sandboxed VM, and exercises the actual functions to confirm
// they behave per SCHEMA §15.6 contract.

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const scriptMatch = html.match(/<script>([\s\S]+?)<\/script>/);
if (!scriptMatch) { console.error('no <script>'); process.exit(1); }
const code = scriptMatch[1];

// Build a minimal browser-like sandbox. We don't need a real DOM —
// the functions we test here either don't touch DOM (validator, stub
// renderers) or guard their DOM access defensively.
const sandbox = {
  console: console,
  document: {
    getElementById: (id) => null,
    querySelectorAll: () => [],
    querySelector: () => null,
    addEventListener: () => {},
    body: { dataset: {}, classList: { add: () => {}, remove: () => {}, toggle: () => {} } },
    documentElement: { dataset: {} },
  },
  window: {},
  setTimeout: () => 0,
  clearTimeout: () => {},
  requestAnimationFrame: (cb) => 0,
  localStorage: {
    _store: {},
    getItem: function (k) { return this._store[k] || null; },
    setItem: function (k, v) { this._store[k] = String(v); },
    removeItem: function (k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  TextEncoder: typeof TextEncoder !== 'undefined' ? TextEncoder : undefined,
  TextDecoder: typeof TextDecoder !== 'undefined' ? TextDecoder : undefined,
  URL: typeof URL !== 'undefined' ? URL : undefined,
  Blob: typeof Blob !== 'undefined' ? Blob : function () {},
};
sandbox.globalThis = sandbox;
sandbox.self = sandbox;
sandbox.global = sandbox;
sandbox.window.document = sandbox.document;
sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  // Wrap in try/catch — most code paths are guarded but some run at script
  // top-level and may touch DOM that doesn't exist. We tolerate top-level
  // throws and check whether the functions we care about made it into the
  // sandbox.
  try { vm.runInContext(code, sandbox); }
  catch (e) {
    // Many init paths fail in the headless sandbox (canvas APIs etc).
    // That's fine — we only care whether the picker scaffold landed.
  }

  console.log('\n--- t14e+ continue: lines color mode runtime tests ---');

  // Note: const-declared identifiers (state, _LINES_COLOR_MODES,
  // _LINES_COLOR_MODE_KEY) don't surface in the vm sandbox's global scope —
  // only function declarations do. We verify the const declarations exist
  // via the regex tests in test_v399.js (TEST 62). This file tests the
  // BEHAVIOR of the public functions.

  // 1. _isLinesColorModeAvailable behavior (function declarations DO surface)
  if (typeof sandbox._isLinesColorModeAvailable === 'function') {
    ok(sandbox._isLinesColorModeAvailable('kmeans') === true,
       'kmeans always available (no source layer required)');
    ok(sandbox._isLinesColorModeAvailable('family') === true,
       'family always available (no source layer required)');
    ok(sandbox._isLinesColorModeAvailable('dosage') === false,
       'dosage NOT available when dosage_chunks layer absent');
    ok(sandbox._isLinesColorModeAvailable('theta_pi') === false,
       'theta_pi NOT available when per_sample_theta_pi layer absent');
    ok(sandbox._isLinesColorModeAvailable('nonexistent_mode') === false,
       'unknown mode id returns false (not crash)');

    // We can't add to sandbox.state.layersPresent (state is const, not on
    // sandbox global), but we CAN test the function with a synthetic state
    // by setting sandbox.state. Let's create one and re-call the functions
    // that use the global state binding by re-executing their bodies in
    // context — actually, safer to test via a small fragment.
    //
    // Instead: confirm that _isLinesColorModeAvailable USES state.layersPresent
    // (we already did this via regex). Skip the dynamic add/remove test.
  } else {
    ok(false, '_isLinesColorModeAvailable not defined');
  }

  // 2. Stub renderers return null sentinel
  if (typeof sandbox._resolveSampleColorByMode === 'function') {
    ok(sandbox._resolveSampleColorByMode(0, 0, 'kmeans') === null,
       '_resolveSampleColorByMode returns null sentinel (kmeans, today)');
    ok(sandbox._resolveSampleColorByMode(0, 0, 'dosage') === null,
       '_resolveSampleColorByMode returns null sentinel (dosage, stub)');
    ok(sandbox._resolveSampleColorByMode(0, null, 'family') === null,
       '_resolveSampleColorByMode handles null gi gracefully');
  } else {
    ok(false, '_resolveSampleColorByMode not defined');
  }
  if (typeof sandbox._resolveSampleScopeColor === 'function') {
    ok(sandbox._resolveSampleScopeColor(0, 'kmeans') === null,
       '_resolveSampleScopeColor returns null sentinel (kmeans, stub)');
    ok(sandbox._resolveSampleScopeColor(0, 'froh') === null,
       '_resolveSampleScopeColor returns null sentinel (froh, stub)');
  } else {
    ok(false, '_resolveSampleScopeColor not defined');
  }

  // 3. refreshLinesColorMode is callable without exception (it touches the
  // const state but should handle the no-DOM case via guards)
  if (typeof sandbox.refreshLinesColorMode === 'function') {
    let threw = false;
    try { sandbox.refreshLinesColorMode(); }
    catch (e) { threw = true; console.error('  refresh threw:', e.message); }
    ok(!threw,
       'refreshLinesColorMode runs without throwing in headless context');
  } else {
    ok(false, 'refreshLinesColorMode not defined');
  }

  // 4. _wireLinesColorModePicker is callable without exception
  if (typeof sandbox._wireLinesColorModePicker === 'function') {
    let threw = false;
    try { sandbox._wireLinesColorModePicker(); }
    catch (e) { threw = true; console.error('  wire threw:', e.message); }
    ok(!threw,
       '_wireLinesColorModePicker runs without throwing in headless context');
  } else {
    ok(false, '_wireLinesColorModePicker not defined');
  }

  console.log(`\n--- v3.99 t14e+ continue runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
