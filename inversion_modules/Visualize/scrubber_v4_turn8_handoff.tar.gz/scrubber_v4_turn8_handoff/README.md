# Scrubber v4 turn 8 handoff bundle

Self-contained bundle for resuming the inversion scrubber + 226-sample
C. gariepinus inversion-detection work in a fresh chat.

## Bundle contents

### Top level (the live working set)

- `pca_scrubber_v3.html` — **1,517,307 bytes**, v4 turn 7 staged build.
  This is the file to edit. All UI work + tests pass against this version.

- `population_atlas_v1.html` — sibling scaffold (Population Atlas v1).
  Independent file; ship-along for context if atlas work resumes.

### Active test suites (16 files, 1,445 / 1,445 passing)

```
test_v399.js                              754/754
test_v4_diversity_atlas_runtime.js         51/51
test_population_atlas_v1_runtime.js        75/75
test_v41_metrics_runtime.js                68/68
test_v41_recluster_rebuild_runtime.js      38/38
test_v41_uv_modes_runtime.js               38/38
test_v399_theta_pi_scrubber_runtime.js     32/32
test_v4_pca_lasso_runtime.js               20/20
test_v399_winsum_color_runtime.js          33/33
test_v399_blocks_runtime.js                62/62
test_v399_candidate_bar_runtime.js         25/25
test_v399_lines_color_mode_runtime.js      12/12
test_v399_chips_inspector_runtime.js       34/34
test_v399_karyotype_tier_runtime.js       140/140
test_v399_catalogue_export_runtime.js      32/32
test_v399_registry_interop_runtime.js      31/31
                                       --------
                                       1,445 / 1,445 ✅
```

Run them all from this directory with:

```bash
for f in test_*.js; do echo "=== $f ==="; node "$f" 2>&1 | tail -1; done
```

### Design docs (read FIRST in next chat)

- **`HANDOFF_v4_turn8_resume.md`** — master handoff. Read this first.
  Contains: current staged file state, what shipped this session, what's
  queued from prior turns (ancestry-confound test, chrom axis ticks, drag
  handle JS, free-mode polish), what's NEW (deliverables A/B/C/D), the
  recommended next-chat plan, cohort-isolation rules, working-style
  reminders.

- **`SPEC_v4_window_row_overlapping_regimes.md`** — implementation spec
  for the four new deliverables:
  - **A**: per-window row in candidate strip (~250 lines, 1 turn)
  - **B**: overlapping candidates lane-stacking (~400 lines, 1 turn)
  - **C**: regime registry CRUD (~700 lines, 2 turns)
  - **D**: scale-stability test reusing 3-pane carousel + multi-unit scale
        picker (windows / SNPs / kb / L2 / L1 / candidate) + Sankey
        fuse/split diagrams (~600 lines, 2 turns)

  Recommended order: **A → D → B → C**. If only one ships: A. If two: A + D.

- **`SCHEMA_v2_25_DRAFT.md`** — schema additions §24 (window-row + L3 cuts),
  §25 (overlapping candidates + many-to-many regime mapping), §26
  (architecture-call vocabulary, user-chosen), §27 (scale-stability verdict
  vocabulary + Sankey signatures + unit dropdown vocabulary).

- **`SCHEMA_V2.md`** — full schema reference through v2.24 (354 KB). Keep
  for cross-reference; new §24-§27 build on top of it.

### `context/` — prior turn handoffs

Useful but not required:
- `HANDOFF_v4_turn4.md`, `HANDOFF_v4_turn7.md` — prior turn handoffs from
  this session; provide UX-polish-arc context
- `HANDOFF_v4_population_atlas_v1.md` — sibling atlas scaffold context
- `HANDOFF_v4_0.md` — broader v4 milestone context

### `r_scripts/` — referenced R-side modules

- `STEP_M04_emit_dosage_chunks.R` — referenced by the dosage layer
- `STEP_M06_emit_boundary_evidence.R` — referenced by boundary diagnostics
- `STEP_R45a_broodline_check.R` — early sketch of the broodline confounding
  test (superseded by the ancestry-Q test design in turn 7's response).
  Kept for the algorithmic reference, but the recommended path is the
  ancestry-Q test described in the master handoff section "What's queued
  from prior turns" → item 1.

## How to resume in next chat

1. Extract the tarball.
2. Open `HANDOFF_v4_turn8_resume.md` and read the entire document.
3. Copy `pca_scrubber_v3.html` to `/tmp/w2/`.
4. Run the test loop above to confirm baseline 1,445 / 1,445 against the
   staged file before making any edits.
5. Pick the next deliverable per the recommended next-chat plan in the
   master handoff. Recommended turn 1: apply the queued ancestry-confound
   patch (~30 min, design already written in turn 7's response and
   summarized in the master handoff).

## Critical reminders (from the master handoff, repeated for safety)

- **226-sample pure C. gariepinus hatchery cohort** ("MS_Inversions_North_
  african_catfish") on LANTA, account lt200308. NEVER conflate with:
  - F1 hybrid (genome assembly paper)
  - Pure C. macrocephalus wild cohort (future paper)

- **Multi-session parallel chats**: ALWAYS reconcile script versions before
  assuming state. This session reconciled twice with parallel work
  (Save/Load JSON, ★ promote button additions). Check `/tmp/w2/` byte
  count vs the bundle before assuming they match.

- **Architecture-call labels in §26 are user-chosen, NEVER auto-assigned
  by the scrubber.** The scrubber suggests; the user confirms. Validation
  thresholds live in the planned R-side `STEP_R45_arrangement_tree.R`,
  not in JS.

- **L3 cuts are per-candidate UI subdivisions, NOT a third hierarchical
  level.** No `state.data.l3_envelopes`, no R-side L3 emit competing with
  L2.

## Bundle metadata

- Created: end of v4 turn 8 chat session
- Total uncompressed size: ~2.4 MB
- File count: ~30 files
- Tested: spot-checked test_v399.js, test_v4_pca_lasso_runtime.js,
  test_v399_karyotype_tier_runtime.js against bundled scrubber → all green
