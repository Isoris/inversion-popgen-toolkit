#!/usr/bin/env node
// Runtime tests for v3.99 t14e+ Karyotype/Tier sub-view scaffold (TEST 70
// runtime counterpart). Verifies the 14-axis constant has correct shape,
// the color helper returns expected hues, and the empty-state grid renders
// 14 cards across 6 sections.

const fs = require('fs');
const vm = require('vm');

const html = fs.readFileSync('/tmp/w2/pca_scrubber_v3.html', 'utf8');
const code = html.match(/<script>([\s\S]+?)<\/script>/)[1];

const sandbox = {
  console,
  document: {
    elements: {},
    getElementById(id) {
      if (!this.elements[id]) {
        this.elements[id] = {
          id, listeners: {}, dataset: {}, style: { display: 'none' },
          classList: { add() {}, remove() {} },
          addEventListener: function (ev, fn) { (this.listeners[ev] = this.listeners[ev] || []).push(fn); },
          appendChild() {}, removeChild() {}, click() {},
          options: [], textContent: '', innerHTML: '', value: '',
        };
      }
      return this.elements[id];
    },
    createElement: () => ({ dataset: {}, style: {}, classList: { add() {}, remove() {} }, addEventListener() {}, appendChild() {} }),
    body: { appendChild() {}, removeChild() {} },
    documentElement: { dataset: {} },
    querySelectorAll: () => [], querySelector: () => null,
    addEventListener() {},
  },
  window: {
    addEventListener() {}, removeEventListener() {},
    matchMedia: () => ({ matches: false, addEventListener() {}, removeEventListener() {} }),
  },
  setTimeout: () => 0, clearTimeout() {}, requestAnimationFrame: () => 0,
  localStorage: {
    _store: {}, getItem(k) { return this._store[k] || null; }, setItem(k, v) { this._store[k] = String(v); },
    removeItem(k) { delete this._store[k]; },
  },
  performance: { now: () => 0 },
  fetch: () => Promise.resolve({ json: () => Promise.resolve({}) }),
  Float32Array, Float64Array, Int8Array, Int16Array, Int32Array,
  Uint8Array, Uint16Array, Uint32Array, ArrayBuffer, DataView,
  Map, Set, Promise, Symbol, WeakMap, WeakSet,
  URL: { createObjectURL: () => 'blob:fake', revokeObjectURL: () => {} },
  Blob: function () {},
  alert: () => {},
};
sandbox.globalThis = sandbox; sandbox.self = sandbox; sandbox.global = sandbox;
sandbox.window.document = sandbox.document; sandbox.window.localStorage = sandbox.localStorage;

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('  PASS', msg); pass++; }
  else      { console.log('  FAIL', msg); fail++; }
}

try {
  vm.createContext(sandbox);
  try { vm.runInContext(code, sandbox); } catch (_) { /* tolerated */ }

  console.log('\n--- t14e+ continue: Karyotype/Tier scaffold runtime tests ---');

  // _TIER_AXES is `const` so doesn't show up on sandbox; access via eval
  // (function declarations DO show up automatically, which is why
  // _tierAxisValueColor and _renderTierAxesGrid are reachable via sandbox.*)
  const _TIER_AXES = vm.runInContext('typeof _TIER_AXES !== "undefined" ? _TIER_AXES : null', sandbox);

  // _TIER_AXES constant
  ok(Array.isArray(_TIER_AXES), '_TIER_AXES is an array');
  ok(_TIER_AXES && _TIER_AXES.length === 14, '_TIER_AXES has exactly 14 entries');

  // Each axis has the expected shape
  const expectedIds = [
    'existence_layer_a', 'existence_layer_b', 'existence_layer_c', 'existence_layer_d',
    'boundary_quality', 'group_validation', 'internal_structure', 'recombinant_class',
    'family_linkage', 'polymorphism_class', 'mechanism_class', 'age_class',
    'burden_class', 'confidence_tier',
  ];
  const actualIds = _TIER_AXES.map(a => a.id);
  for (const exp of expectedIds) {
    ok(actualIds.includes(exp), `axis "${exp}" present in _TIER_AXES`);
  }

  // Each axis has id, label, group, desc, cats fields
  for (const ax of _TIER_AXES) {
    ok(typeof ax.id === 'string' && ax.id.length > 0,
       `axis "${ax.id}" has id`);
    ok(typeof ax.label === 'string' && ax.label.length > 0,
       `axis "${ax.id}" has label "${ax.label}"`);
    ok(['existence', 'boundary', 'groups', 'population', 'biology', 'tier'].includes(ax.group),
       `axis "${ax.id}" group = "${ax.group}" (valid)`);
    ok(typeof ax.desc === 'string' && ax.desc.length > 5,
       `axis "${ax.id}" has descriptive desc`);
    ok(Array.isArray(ax.cats) && ax.cats.length >= 2,
       `axis "${ax.id}" has cats array with ≥2 categories`);
  }

  // Group counts: existence(4) + boundary(1) + groups(3) + population(2) + biology(3) + tier(1) = 14
  const groupCounts = {};
  for (const ax of _TIER_AXES) {
    groupCounts[ax.group] = (groupCounts[ax.group] || 0) + 1;
  }
  ok(groupCounts.existence === 4, 'existence group has 4 axes (Layers A-D)');
  ok(groupCounts.boundary === 1, 'boundary group has 1 axis (boundary_quality)');
  ok(groupCounts.groups === 3, 'groups group has 3 axes (validation+structure+recombinant)');
  ok(groupCounts.population === 2, 'population group has 2 axes (linkage+polymorphism)');
  ok(groupCounts.biology === 3, 'biology group has 3 axes (mechanism+age+burden)');
  ok(groupCounts.tier === 1, 'tier group has 1 axis (confidence_tier)');

  // _tierAxisValueColor — categorical color mapping
  if (typeof sandbox._tierAxisValueColor === 'function') {
    // Existence layers
    const passColor = sandbox._tierAxisValueColor('existence_layer_a', 'pass');
    ok(passColor.includes('34,160,80'), 'pass → green (rgba(34,160,80,...))');
    const failColor = sandbox._tierAxisValueColor('existence_layer_b', 'fail');
    ok(failColor.includes('224,85,92'), 'fail → red (rgba(224,85,92,...))');

    // Boundary quality
    ok(sandbox._tierAxisValueColor('boundary_quality', 'sharp').includes('34,160,80'),
       'sharp boundary → green');
    ok(sandbox._tierAxisValueColor('boundary_quality', 'fuzzy').includes('245,200,60'),
       'fuzzy boundary → amber');

    // Group validation tiers
    ok(sandbox._tierAxisValueColor('group_validation', 'VALIDATED').includes('34,160,80'),
       'VALIDATED → green');
    ok(sandbox._tierAxisValueColor('group_validation', 'SUPPORTED').includes('60,192,138'),
       'SUPPORTED → teal');
    ok(sandbox._tierAxisValueColor('group_validation', 'UNCERTAIN').includes('245,200,60'),
       'UNCERTAIN → yellow');
    ok(sandbox._tierAxisValueColor('group_validation', 'SUSPECT').includes('245,165,36'),
       'SUSPECT → amber');
    ok(sandbox._tierAxisValueColor('group_validation', 'NONE').includes('224,85,92'),
       'NONE → red');

    // Confidence tier
    ok(sandbox._tierAxisValueColor('confidence_tier', 'T1').includes('34,160,80'),
       'T1 tier → green');
    ok(sandbox._tierAxisValueColor('confidence_tier', 'T2').includes('60,192,138'),
       'T2 tier → teal');
    ok(sandbox._tierAxisValueColor('confidence_tier', 'T3').includes('245,200,60'),
       'T3 tier → yellow');
    ok(sandbox._tierAxisValueColor('confidence_tier', 'T4').includes('245,165,36'),
       'T4 tier → amber');
    ok(sandbox._tierAxisValueColor('confidence_tier', 'SV_only').includes('180,120,200'),
       'SV_only → purple (rare-but-known case)');
    ok(sandbox._tierAxisValueColor('confidence_tier', 'Layer_C_only').includes('180,120,200'),
       'Layer_C_only → purple');

    // Family linkage edge case (pca_family_confounded is a warning state)
    ok(sandbox._tierAxisValueColor('family_linkage', 'pca_family_confounded').includes('224,85,92'),
       'pca_family_confounded → red (warning — known confounder)');

    // Unknown / null
    ok(sandbox._tierAxisValueColor('any_axis', 'unknown').includes('120,130,145'),
       'unknown → grey');
    ok(sandbox._tierAxisValueColor('any_axis', null).includes('120,130,145'),
       'null value → grey');
    ok(sandbox._tierAxisValueColor('any_axis', '').includes('120,130,145'),
       'empty string → grey');
  } else {
    ok(false, '_tierAxisValueColor in sandbox');
  }

  // _renderTierAxesGrid — empty state
  if (typeof sandbox._renderTierAxesGrid === 'function') {
    const emptyHtml = sandbox._renderTierAxesGrid(null);
    ok(typeof emptyHtml === 'string' && emptyHtml.length > 0,
       'empty grid renders non-empty HTML string');
    // Should contain all 6 section labels
    ok(emptyHtml.includes('EXISTENCE LAYERS'), 'empty grid has EXISTENCE LAYERS section');
    ok(emptyHtml.includes('BOUNDARIES'), 'empty grid has BOUNDARIES section');
    ok(emptyHtml.includes('KARYOTYPE GROUPS'), 'empty grid has KARYOTYPE GROUPS section');
    ok(emptyHtml.includes('POPULATION GENETICS'), 'empty grid has POPULATION GENETICS section');
    ok(emptyHtml.includes('BIOLOGY'), 'empty grid has BIOLOGY section');
    ok(emptyHtml.includes('OVERALL TIER'), 'empty grid has OVERALL TIER section');
    // Should have "not yet computed" placeholders
    ok(emptyHtml.includes('not yet computed'), 'empty grid shows "not yet computed" pills');
    // Should mention all 14 axes
    for (const exp of expectedIds) {
      const ax = _TIER_AXES.find(a => a.id === exp);
      ok(emptyHtml.includes(ax.label), `empty grid renders axis "${exp}" label "${ax.label}"`);
    }

    // Filled state
    const filledValues = {
      existence_layer_a:  'pass',
      existence_layer_b:  'pass',
      existence_layer_c:  'fail',
      existence_layer_d:  'pass',
      boundary_quality:   'sharp',
      group_validation:   'VALIDATED',
      internal_structure: 'clean',
      recombinant_class:  'none',
      family_linkage:     'multi_family',
      polymorphism_class: 'cohort_wide',
      mechanism_class:    'NAHR',
      age_class:          'intermediate',
      burden_class:       'neutral',
      confidence_tier:    'T2',
    };
    const filledHtml = sandbox._renderTierAxesGrid(filledValues);
    ok(typeof filledHtml === 'string' && filledHtml.length > emptyHtml.length / 2,
       'filled grid renders substantive HTML');
    ok(filledHtml.includes('VALIDATED'), 'filled grid shows "VALIDATED" pill text');
    ok(filledHtml.includes('T2'), 'filled grid shows "T2" tier pill');
    ok(filledHtml.includes('NAHR'), 'filled grid shows "NAHR" mechanism pill');
    ok(!filledHtml.includes('not yet computed'),
       'filled grid does NOT show "not yet computed" placeholders (all axes filled)');
  } else {
    ok(false, '_renderTierAxesGrid in sandbox');
  }

  // karyoState.subview persistence — initial value (karyoState is const,
  // accessed via runInContext)
  const karyoState = vm.runInContext('typeof karyoState !== "undefined" ? karyoState : null', sandbox);
  ok(karyoState && (karyoState.subview === 'karyotype' || karyoState.subview === 'tier'),
     'karyoState.subview initialized to valid value');

  // _CAND_SUBVIEW_KEY constant
  const candSubviewKey = vm.runInContext('typeof _CAND_SUBVIEW_KEY !== "undefined" ? _CAND_SUBVIEW_KEY : null', sandbox);
  ok(candSubviewKey === 'pca_scrubber_v3.candSubview',
     '_CAND_SUBVIEW_KEY = "pca_scrubber_v3.candSubview"');

  console.log(`\n--- v3.99 t14e+ continue Karyotype/Tier runtime tests: ${pass}/${pass + fail} ---`);
  if (fail > 0) process.exit(1);
} catch (e) {
  console.error('FATAL:', e.message);
  console.error(e.stack);
  process.exit(2);
}
