# SCHEMA v2.25 (DRAFT) — additions

Three new sections proposed for `SCHEMA_V2.md`. All are scoped tightly so the
existing v2.24 schema and persisted user data continue to work unchanged.
Migration rules are explicit; no breaking changes.

---

## §24. Window-resolution candidate strip + L3 cuts

### Motivation

L2 envelopes in the 226-sample C. gariepinus cohort average ~90 windows each
(~10 Mb at the cohort's window size). When the user wants to call a candidate
inversion that spans only PART of an L2 — say, a 3-Mb peak inside a 10-Mb L2 —
the existing candidate-mode drafting at L2 resolution is too coarse. The user
either over-calls (whole-L2 candidate that includes irrelevant flanks) or
mis-calls (drafts the wrong L2 because the inversion crosses an L2 boundary).

### Concept

Add a third zone-bar row to the candidate strip — the "**W row**" — visible
ONLY when `state.candidateMode === true`. The W row shows:

- A faint baseline strip across the visible range
- Vertical tick marks at every window boundary inside the focal L2 (and
  optionally adjacent L2s when in `±2` carousel layout)
- The current draft's exact window span as a highlighted block on this row,
  with drag handles at left/right edges

Click on a tick → set the draft's nearest edge to that window. Drag a handle
→ extend/shrink the draft at window resolution.

### State changes

`state.l3Draft` is extended (additive — old shape continues to work):

```js
l3Draft: {
  // EXISTING fields (v3.x):
  focal_l2idx: int,        // anchor L2
  l2_left:     int,        // leftmost L2 in draft
  l2_right:    int,        // rightmost L2 in draft
  has_warning: bool,

  // NEW fields (v4 turn 8 — all optional, default to whole-L2 spans):
  resolution:  'L2' | 'W',  // default 'L2' for back-compat
  start_w:     int | null,  // window-level draft, only when resolution='W'
  end_w:       int | null,  // window-level draft, only when resolution='W'
  l3_cuts:     int[]  | [], // window indices where the user has placed L3 cuts
                            //   inside the draft; default empty
}
```

When `resolution === 'L2'`, the draft is interpreted as before — full L2
envelopes from `l2_left` to `l2_right`. When `resolution === 'W'`, the draft
is interpreted as windows `start_w..end_w` regardless of L2 boundaries.

### Persistence

L3 cuts persist with the candidate (see §25). They do NOT introduce a new
hierarchical level — there is no `state.data.l3_envelopes` array, no new
clustering step, no R-side L3 emit. L3 cuts are a UI-level subdivision tied
to a specific candidate.

This is deliberate. A persistent L3 layer competing with L2 would force every
analysis (catalogue, contingency tables, popstats, ancestry) to choose
between L2 and L3, doubling the maintenance surface. By tying L3 cuts to
candidates, they affect only the candidate they belong to.

### Migration rule

Old saved candidates have no `resolution` field. The reader defaults
`resolution = 'L2'`, `l3_cuts = []`, leaves `start_w/end_w` as currently
computed from `l2_indices`. No old candidates break.

### Schema entry summary

| Field            | Type         | Required | Default | Notes |
|------------------|--------------|----------|---------|-------|
| `l3Draft.resolution` | 'L2' \| 'W' | no | 'L2' | UI mode for the active draft |
| `l3Draft.start_w` | int \| null | no | null | window-level start; only when resolution='W' |
| `l3Draft.end_w`   | int \| null | no | null | window-level end |
| `l3Draft.l3_cuts` | int[]       | no | [] | user-placed cut window indices |

---

## §25. Overlapping candidates + per-candidate band-regime mapping

### Motivation

Two requirements that the current data model can't cleanly express:

1. **Overlapping candidates**: a region can host two distinct inversion-like
   systems whose breakpoints overlap in genomic space. The current registry
   doesn't forbid this technically, but the candidate-bar renderer
   z-stacks them poorly and the catalogue's "favorite this L2" logic
   silently picks one. We need explicit support.

2. **Many-to-many band → regime mapping**: the K=6 case where bands {1,2,3}
   belong to one regime/arrangement system and bands {4,5,6} to another.
   Today, a candidate has ONE band-set (its `K` and `locked_labels`). We
   need to express "this candidate's K=6 bands split across two regimes,
   bands g0+g1+g2 → regime A, bands g3+g4+g5 → regime B."

### Concept: regimes as separate registry objects

Introduce `state.regimeList[]` — separate registry, persisted alongside
`state.candidateList` per chromosome. Each regime has:

```js
{
  id:               string,          // 'regime_<hash>_<n>'
  name:             string,           // user-editable: 'INV_A', 'arrangement_X', ...
  chrom:            string,
  axis_topology:    'one_axis_3band' | 'two_axes_independent' |
                    'two_axes_linked' | 'multiallelic' | 'unknown',
  member_assignments: [
    {
      candidate_id: string,           // → state.candidateList[].id
      bands:        int[],            // band indices from that candidate's K-frame
                                      //   that belong to this regime
      role:         'primary' | 'secondary' | 'background',
                                      //   primary = the regime's main span
                                      //   secondary = also-spans-this-region
                                      //   background = shared-with-other-regime
    },
    ...
  ],
  notes:            string,
  created_at:       int,
}
```

Each candidate gains an OPTIONAL reverse-lookup convenience field:

```js
// In candidate object (additive to §19):
regime_assignments: [
  { regime_id: string, bands: int[], role: string },
  ...
]
```

This is denormalized but cheap to maintain — `addCandidateToRegime(cand_id,
regime_id, bands, role)` updates both sides atomically.

### What overlapping means

Two candidates overlap if their `[start_w, end_w]` window ranges intersect.
The candidate-bar renderer (drawCandidateBar) is extended to **stack
overlapping candidates vertically inside the bar** — the bar grows by N×4px
for N overlapping candidates at any given x. Each candidate is drawn as a
horizontal sub-strip; click selects one (cycle through if multiple overlap
the click point).

The catalogue grows a "regimes" column showing which regimes a row's L2
belongs to (via the candidates that include it). One L2 → many candidates
→ many regimes is now expressible.

### Migration rule

Old saved candidates have no `regime_assignments` field. The reader
defaults `regime_assignments = []`. No old candidates break.

`state.regimeList` defaults to `[]` for any chromosome that has no saved
regimes. Empty regime list = no regime assignments = catalogue/UI behaves
exactly as today.

### Persistence

Regimes are stored under a separate localStorage key per chromosome:

```
pca_scrubber_v3.regimes.<chrom>
```

Mirrors the candidate persistence pattern (`pca_scrubber_v3.candidates.<chrom>`).

### Schema entry summary

| Field                              | Type      | Required | Default | Notes |
|------------------------------------|-----------|----------|---------|-------|
| `regimeList[].id`                  | string    | yes      | —       | unique within chrom |
| `regimeList[].name`                | string    | yes      | id      | user-editable |
| `regimeList[].axis_topology`       | enum      | yes      | 'unknown' | see §26 |
| `regimeList[].member_assignments`  | object[]  | yes      | []      | many-to-many link to candidates |
| `candidate.regime_assignments`     | object[]  | no       | []      | reverse lookup |

---

## §26. Architecture-call vocabulary (informational, no data changes)

A controlled vocabulary for `regime.axis_topology`. Each value is a
distinct biological hypothesis about K-band structure. Per Quentin's
prior architectural-resolver discussion:

| Value | Description |
|-------|-------------|
| `one_axis_3band` | Single inversion with 3 bands: ref / het / inv. K=3 case. |
| `one_axis_nested` | K=6 but tree shows 3 deep tips, each a nested 2-band split. Selection or drift inside arrangements. |
| `two_axes_independent` | 9-cell het-cooccurrence near-uniform; two independent biallelic systems. |
| `two_axes_linked` | 9-cell pattern shows linkage; possibly epistasis or one-system. |
| `two_axes_independent_het_deficient` | The "never meet" case — two independent systems, one of which is fixed in this cohort. |
| `multiallelic` | Tree has > 2 deep lineages; doesn't reduce to a 2-axis model. |
| `unknown` | Default until the architecture-call analysis runs. |

These values are NOT auto-assigned by the scrubber. They are user-chosen
labels that document the user's interpretation, OR they will be populated
later by the planned R-side `STEP_R45_arrangement_tree.R` module
(architecture call). Until that ships, the field exists for documentation
and consistency. The scrubber UI lets the user pick from a dropdown.

This separation of concerns is deliberate:
- The scrubber is a viewer + recorder, not an architecture-call analyzer
- Architecture-call thresholds are NOT validated yet (no ground truth)
- Hard-coding thresholds in the scrubber would commit to defaults the
  user can't easily revise
- Reviewers will ask "where did the threshold come from" — the answer
  has to be the R module's methods section, not "the scrubber said so"

---

## §27. Scale-stability verdict vocabulary (informational)

Vocabulary for the scale-stability test (see SPEC Deliverable D). The test
reuses the existing 3-pane L3 carousel — when toggled ON, the same 3 panes
show 3 different scales (fine / medium / coarse) all centered on the focal,
each with an independent user-picked unit. Sankey diagrams between adjacent
panes show fuse/split structure visually. The verdict is derived from
fuse/split counts plus ARI:

| Value | Trigger | Sankey signature | Biological reading |
|-------|---------|------------------|--------------------|
| `STABLE_3BAND` | K=3 stable across all 3 scales (no fuses, no splits, ARI ≥ 0.85) | 3 thick parallel ribbons | classic single inversion |
| `STABLE_6BAND` | K=6 stable across all 3 scales (same conditions) | 6 thick parallel ribbons | stable multiband; needs band-tree to decide single vs compound |
| `NESTED_3IN6` | K=6 at fine collapses cleanly into K=3 at coarse (3 fuse events, 0 splits) | clean 6→3 fan-in | 3-band inversion with substructure visible only at fine scale |
| `OVERLAP_BREAKS_3` | K=3 stable at fine and coarse, K=6 emerges at medium with reshuffle | ribbons reshuffle in middle, restore at edges | possible two overlapping inversions — flank regions show one axis each |
| `UNSTABLE` | otherwise (crossing/braided ribbons, ARI < 0.5 anywhere) | crossing braided ribbons | do not force a biological call; treat as artifact-suspect |

### Scale unit vocabulary

The user picks each pane's scale from a fixed set:

| Unit | Definition |
|------|------------|
| `1w` / `5w` / `10w` / `25w` | N windows centered on focal |
| `Nw` (custom) | user-entered N windows |
| `100 SNPs` / `500 SNPs` / `1000 SNPs` | smallest contiguous range whose Σ `n_snps` ≥ N |
| `100 kb` / `500 kb` | smallest contiguous range whose Σ `span_bp` ≥ N |
| `L2` | the focal L2 envelope |
| `L1` | the focal L1 envelope |
| `candidate` | full active candidate's `start_w..end_w` (greyed if no active candidate) |

SNP-band and kb-band conversions provide constant-statistical-power and
constant-physical-distance scaling respectively, useful for cross-region
comparisons where window density varies.

### Relation to §26 axis_topology

The scale-stability verdict is automatic (computed by the scrubber from
data); the §26 `axis_topology` is user-chosen. They overlap but are not
identical:

| Scale-stability verdict | Suggested axis_topology |
|-------------------------|-------------------------|
| `STABLE_3BAND` | `one_axis_3band` |
| `STABLE_6BAND` | `one_axis_nested` OR `two_axes_independent` (band-tree decides) |
| `NESTED_3IN6` | `one_axis_nested` |
| `OVERLAP_BREAKS_3` | `two_axes_independent` (different spans) |
| `UNSTABLE` | leave as `unknown` |

The scale-stability test SUGGESTS an axis_topology when the user creates a
regime with `member_assignments` referencing the candidate. The user
confirms or overrides. The scrubber never auto-fills; it pre-fills with a
clearly-marked suggestion.

### Threshold caveat

The thresholds (ARI ≥ 0.85, fuse mapping rate ≥ 0.80, split mass ≥ 0.20)
are heuristic defaults. They were chosen by analogy to "high agreement"
thresholds in the cluster-comparison literature (Hubert & Arabie 1985
noted ARI > 0.8 as "very strong agreement"). They are NOT validated
against ground truth in the C. gariepinus cohort. The user can adjust
them via the scrubber's settings panel; the chosen values are persisted
per-cohort.

For publication, the thresholds used should be reported in the methods
section, with sensitivity analysis (how does the verdict distribution
change as ARI threshold goes from 0.7 to 0.9?). The scrubber records the
threshold values in each saved candidate's metadata so the analysis is
reproducible.
