# HANDOFF — Local PCA Scrubber v4.0 cut

**Date**: 2026-04-28
**Cut from**: v3.99 t14e+ continue (long arc closed)
**Schema state**: 2.19+++ (locked at v4.0 contract surface)
**Tests**: 753/753 main + 261/261 across 14 specialized runtime suites + all 6 e2e suites green

---

## Purpose of this document

This is the FRESH handoff for the next chat. It is NOT a dump of every t14e+ delta (that history lives in `HANDOFF_v3_99_turns_14a_to_14e.md` if you need it). This document is the clean overview a new chat needs to pick up where v4.0 left off.

If you're starting fresh: **read this document first**, then look at `SCHEMA_V2.md` for the full schema contract, then `pca_scrubber_v3.html` for the actual code.

---

## What v4.0 is (one paragraph)

The Local PCA Scrubber is Quentin Andres' interactive web tool for inversion discovery on the 226-sample pure *C. gariepinus* hatchery cohort, MS_Inversions_North_african_catfish manuscript. It runs in a single HTML file, reads precomputed JSON from the cluster-side R-pipeline, and exposes a chromosome-wide scrubber (page 1 — local PCA on dosage) plus 11 specialized analysis pages. v4.0 closes the t14e+ continue arc with significant new infrastructure: registry interop for cluster-emit consumption (§20), 18 structured evidence-block types (§21), a chips + JSON inspector UI for browsing per-candidate evidence, a brand-new θπ scrubber as page 12 mirroring page 1 but on diversity instead of dosage (§22, scaffold-complete), and finer-grained boundaries-page scan-radius controls (kb-tier added). Most new v4.0 features are **scaffold-complete** — the UI, schema, and tests are in place; the R-side data ingestion that lights up the panels ships in v4.x follow-up turns.

---

## What v4.0 ships (concrete inventory)

### Page-level features

| Feature | Page | Status | Schema |
|---|---|---|---|
| Local PCA scrubber on dosage | 1 (`local PCA \|z\|`) | shipped + production-tested | §1–§9 |
| Candidate focus deep-dive | 2 (`candidate focus`, DOM `page2`) | shipped, plus chips+inspector NEW | §11, §21 |
| **θπ scrubber (NEW page 12)** | 2 visible (`local PCA thetapi`) | **scaffold-complete, empty-state-only** | §22 |
| Boundary refinement | 3 visible (`boundaries`, DOM `page11`) | shipped, plus kb-tier buttons NEW | §12 |
| Catalogue (sortable/filterable) | 4 visible (DOM `page3`) | shipped, plus refined export | §3 |
| Karyotype / Tier sub-view | 5 visible (DOM `page4`) | scaffold + Tier sub-view ready for `final_classification` | §13, §19 |
| Popstats track stack | 6 visible (DOM `page6`) | shipped | §6 |
| Per-window ancestry | 7 visible (DOM `page7`) | shipped | §7 |
| Windows table (sortable) | 8 visible (DOM `page8`) | shipped | §8 |
| Confirmed walkthrough | 9 visible (DOM `page9`) | shipped | §9 |
| PCR markers | 10 visible (DOM `page10`, hidden) | scaffold | §10 |
| Help / vocabulary / hotkeys | 11 visible (DOM `page5`) | shipped + extended for all v4.0 features | — |

**Important**: User-visible tab numbering is decoupled from DOM ids. `data-page="page12"` is the NEW θπ scrubber at user-visible position 2; existing DOM ids `page2` / `page11` etc. remain unchanged so all code references continue to work.

### Cross-cutting v4.0 infrastructure

1. **Registry interop (§20)** — 📦 button + multi-file picker. Reads `sample_groups.tsv`, `candidate_intervals.tsv`, `manifest.tsv`, and `structured/*.json` evidence blocks from the cluster-side R-pipeline. Loads them into `state.data.{sample_groups, candidate_intervals, results_manifest, evidence_blocks}`.

2. **18 structured block types (§21)** — formal contract for per-candidate evidence blocks. `_KNOWN_BLOCK_TYPES` constant lists all 21 (18 numbered + `boundary_right` sibling + `final_classification` synthesis + extras). `_deriveAxesFromBlock(bt, obj)` applies §21.6 derivation rules to compute the 14-axis classification (Axis 1 confidence_tier, etc.) per candidate from loaded blocks. Multiple blocks compose; `final_classification` block overrides per-question derivations.

3. **Block-presence chips + JSON inspector (page 2)** — horizontal row of 20 chips at top of candidate-focus page. Color-coded: green = axis-contributing, blue = supportive-only, gold = synthesis. Click a lit chip → toggles inline JSON inspector. Multiple inspectors open simultaneously. State source of truth: `state.data.evidence_blocks[cid][block_type]`.

4. **θπ scrubber (§22, page 12) — scaffold-complete, structural mirror of page 1**.
   - Mirrors page 1's pipeline (per-window analysis → window×window similarity → MDS → cluster → candidate intervals) but on per-sample θπ instead of dosage.
   - Three required JSON layers (all optional, additive): `theta_pi_per_window`, `theta_pi_local_pca`, `theta_pi_envelopes`.
   - **Locked to scale `win50000.step10000`** (§22.4.1) — three-axis rationale documented: browser memory (sim_mat is n²), per-window θπ noise floor below ~30 kb, gradient-shaped breakpoints don't benefit from finer step.
   - Empty-state placeholder shows live ⚪/🟢 layer-status indicators per layer + scale comparison table + panel layout mirror.
   - **DOES NOT YET RENDER PANELS** — awaiting R-side STEP_R39/R40/R41.

5. **Boundaries page kb-tier (§12 extended)** — 5 new scan-radius buttons (1/5/10/25/100 kb) added alongside the existing Mb-tier (1/1.5/2/5 Mb), with visual separator. Existing JS wiring works unchanged. Each button has tooltip explaining its specific use case + which other module's scale it matches.

6. **HOBS role documented (§12)** — answer to "does Hobs work for our catfish?" Three-axis rationale: family structure inflates apparent HWE everywhere, inversion-heterozygote spikes are real but family-noise-floor-dependent, patched ANGSD `Isoris/angsd_fixed_HWE` non-negotiable. **Conclusion**: secondary confirmation only, NOT primary discovery. Already wired via §21 `boundary_left/right.hobs_profile`.

### Schema-only sections (NO code, NO UI yet)

- **§14 — Multi-evidence regime convergence** (Atlas mode switching across regime-defining evidence types)
- **§17 — Atlas mode switching** (Inversion Atlas vs Diversity Atlas vs others)
- **§18 — Thai i18n** (translation contract for the manuscript-language-aware UI)
- **§19 — 14-axis classification** (formal contract for `final_classification` JSON layer)
- **§22.7 — Per-candidate concordance sub-view** (the original figure mockups A-F, deferred to secondary surface)

These are all **explicitly post-v4.0** work.

---

## What v4.0 explicitly does NOT ship

This is a **scaffold-complete** cut. The following are deferred to v4.x:

1. **Panel renderers for page 12 θπ scrubber** — `#thSimPanel`, `#thZPanel`, `#thLinesPanel`, `#thPcaPanel`, `#thL3Panel` are empty placeholders. Will reuse page 1's draw functions parameterized by which layer to read.

2. **The three R-side scripts** — `STEP_R39_emit_theta_pi_per_window.R`, `STEP_R40_emit_theta_pi_local_pca.R`, `STEP_R41_emit_theta_pi_envelopes.R`. Without these the page 12 scaffold has no data to render. **STEP_R39 is partly redundant** — `STEP_Q05_aggregate_theta.sh` (in `phase_5_qc_triage/`) ALREADY produces per-sample per-window θπ at `win50000.step10000`, and `export_precomp_to_json.R --theta` already embeds it as `w.theta` (Shape A) inside production JSONs. Auto-detection logic in `detectSchemaAndLayers` already flags Shape A presence — so the first layer indicator can already light up green for legacy JSONs.

3. **Cross-method candidate-list merge** — when both `candidate_intervals` (page 1 dosage) AND `theta_pi_envelopes.candidate_intervals` (page 12 θπ) load, catalogue should gain a "method" column showing each candidate's provenance (`dosage_only` / `theta_pi_only` / `both` / `both_overlap_partial`). The orthogonal-validation payoff.

4. **Per-candidate concordance sub-view (§22.7)** — the original figure mockups A-F (contingency table + Sankey + θπ/π profile lines). Lives as a sub-view on the candidate-focus page; reads `region_popstats.c` per-group output (different layer from the chromosome-wide scrubber's per-sample input).

5. **MODULE_CONFIRMATION_HOBS_HWE → §21 hobs_profile wiring** — the cluster-side module exists; just needs output routed to per-candidate `boundary_left/right.hobs_profile` JSON fields so the boundaries page can render Hobs spikes alongside FST / depth tracks.

6. **Real-data validation on 226-sample LG28 cohort** — was originally the v4.0 gate; descoped to v4.x because the scaffold work expanded substantially during t14e+. The scrubber's behaviour against real data is the next major check.

7. **§14 multi-evidence regime convergence implementation** — schema-only currently. The mode switcher UI scaffold is in place (`linesColorMode` picker with 8 options, most disabled pending source layers). Wiring the renderers behind each mode is v4.x work.

---

## File inventory

### Code & schema

| File | Bytes | What it is |
|---|---|---|
| `pca_scrubber_v3.html` | ~1.37 MB | Single-file scrubber. Filename retains `v3` suffix (DOM/JS code already references it; rename would cascade through localStorage keys, persistence patterns, etc.). User-visible identity is v4.0 via `<title>`, `SCRUBBER_VERSION`, catalogue header, JSON tool ID, PNG watermark. |
| `SCHEMA_V2.md` | ~325 KB, 5429 lines | Full schema contract. Version table at top tracks every schema bump from 2.0 to 2.19+++. **The `v4.0 cut` row marks the boundary**: everything above is v4.0 contract surface; below would be v4.1+. |

### Tests (all green)

| Suite | Count | What it covers |
|---|---|---|
| `test_v399.js` | 753 | main static tests across all v3.94→v3.99 t14e+ continue features |
| `test_v399_theta_pi_scrubber_runtime.js` | 32 | runtime tests for `_refreshThetaPiLayerStatus` + θπ layer detection |
| `test_v399_chips_inspector_runtime.js` | 34 | runtime tests for block chips + JSON inspector |
| `test_v399_blocks_runtime.js` | 62 | runtime tests for `_deriveAxesFromBlock` over 18 block types |
| `test_v399_registry_interop_runtime.js` | 31 | runtime tests for `loadRegistryArtifacts()` |
| `test_v399_winsum_color_runtime.js` | 33 | runtime tests for Windows-page column-driven coloring |
| `test_v399_lines_color_mode_runtime.js` | 12 | runtime tests for lines-color-mode picker scaffold |
| `test_v399_catalogue_export_runtime.js` | 32 | runtime tests for catalogue TSV/MD/JSON export |
| `test_v399_candidate_bar_runtime.js` | 25 | runtime tests for candidate bar above L1/L2 |
| `test_v394.js` / `test_v394t2.js` | 10 + 9 | legacy v3.94 turn 1 & 2 tests |
| `test_v396.js` | 10 | legacy v3.96 tests |
| `test_v397.js` / `test_v397t2.js` / `test_v397t3.js` | 10 + 10 + 5 | legacy v3.97 turn 1/2/3 tests |
| `test_v398.js` | 39 | legacy v3.98 tests |
| `end_to_end_boundaries_check.js` | 22 | e2e boundaries page lifecycle |
| `end_to_end_boundaries_lifecycle.js` | 29 | e2e boundary annotation persistence |
| `end_to_end_tsv_roundtrip.js` | 26 | e2e candidate registry TSV round-trip |
| `end_to_end_check.js` | OK | e2e marker selection vs STEP_M04 chunk |
| `end_to_end_hover_check.js` | 15 | e2e hover tooltip rendering |
| `verify_null_concord_v398.js` | 6 | v3.98 NULL_CONCORD K=6 fallback verification |

### Documentation

| File | What it is |
|---|---|
| `HANDOFF_v4_0.md` | **THIS FILE** — clean v4.0 overview, the document a fresh chat should read first |
| `HANDOFF_v3_99_turns_14a_to_14e.md` | Long historical handoff with every t14e+ continue delta. Reference only — do not use as starting point. |
| `candidate_bar_preview.html` | Standalone preview of the candidate-bar UI element |

---

## Key architectural decisions (preserved across the cut)

These are the load-bearing design decisions that should not be revisited without strong reason:

1. **`state.candidateList` is the canonical promoted-candidates store**, not page-2 specific. The `confirmed` flag on each candidate is page-2 mutable.

2. **Schema enforces "boundary zone" as default semantic**. "Exact breakpoint" is reserved for junction-level evidence (split reads, assembly junctions) — never inferred from population statistics alone. `breakpoint_status` enum: `boundary_zone_only` | `SV_supported` | `junction_supported`.

3. **Cross-VM Float64Array duck-typing** via `.BYTES_PER_ELEMENT === 8` (not `instanceof Float64Array`) so JSON-loaded arrays from different realms work.

4. **L1/L2 palette unification**: rgba(48,116,200) blue (L1) + rgba(34,160,80) green (L2). Used everywhere the two envelope levels need to be visually distinct.

5. **Scale lock at `win50000.step10000` for chromosome-wide θπ scrubber** — finer scales (5/10 kb) reserved for per-candidate boundary inspection (§22.4.1, three-axis rationale).

6. **DOM mock pattern for runtime tests** with `_autoCreate` phase flag (true during script init, false during tests). Used by chips+inspector + θπ scrubber + others. New runtime tests should follow this pattern.

7. **Registry interop is identify-by-filename-then-content-shape** with light validation. Multiple blocks compose into `final_classification` axes via §21.6 rules.

8. **Tab-bar visible numbering decoupled from DOM ids**:
   - Visible: 1 local PCA |z| · 2 local PCA thetapi · 3 candidate focus · 4 boundaries · 5 catalogue · 6 karyotype/tier · 7 popstats · 8 ancestry · 9 windows · 10 confirmed · 11 markers (hidden) · 12 help
   - DOM ids: `page1`, `page12`, `page2`, `page11`, `page3`, `page4`, `page6`, `page7`, `page8`, `page9`, `page10`, `page5`

9. **`localStorage` keys still carry `pca_scrubber_v3` prefix** (not `v4`). These are persistence keys; flipping them would orphan all stored user state. v4.0 is a code/UI version, not a persistence migration.

---

## Probable starting points for v4.x continue

In rough priority order:

1. **STEP_R40 + STEP_R41 R-side scripts** — the blockers for page 12 panels lighting up. STEP_R40 runs local PCA on θπ profiles per window with the same neighbourhood as page 1's dosage local PCA; STEP_R41 thresholds diversity-|Z| into L1/L2 envelopes. STEP_R39 is partly redundant if leveraging existing Shape A `w.theta` embedding.

2. **Page 12 panel renderers** — once R-side data ships, light up panels one at a time. Start with `#thZPanel` (simplest, single 1-D array) → `#thSimPanel` → others. Largely reuses page 1's draw functions parameterized by which layer to read.

3. **MODULE_CONFIRMATION_HOBS_HWE → §21 hobs_profile wiring** — cluster-side module exists; just needs output routed to per-candidate `boundary_left/right.hobs_profile` JSON. Then page 11 boundaries page Hobs track renderer alongside existing FST/depth tracks. Quick win.

4. **Cross-method candidate-list merge in catalogue** — once both scrubbers have real candidate lists, add the `method` column (`dosage_only` / `theta_pi_only` / `both` / `both_overlap_partial`). The orthogonal-validation payoff.

5. **Real-data validation on 226-sample LG28 cohort** — load real precomputed JSON, run through both scrubbers, look at agreement matrix, sanity-check the chips + inspector against actual evidence blocks.

6. **Per-candidate concordance sub-view (§22.7)** — figure mockups A-F as a candidate-focus sub-view, reading `region_popstats.c` per-group output.

7. **§14 multi-evidence regime convergence implementation** — wire renderers behind each `linesColorMode` option (currently most are stub-disabled).

---

## Working style notes (preserved)

- "Continue" means "next agreed item". Quentin works across multiple parallel chats — always reconcile state at start of each chat with `stat -c '%y %s'` on key files + run `node test_v399.js` to confirm baseline.
- Quentin prefers compact non-fragmented pipelines, single central config file per module, original tested code used verbatim, targeted fixes over rewrites, deliverables as tarballs ready to extract.
- "If you don't know, you add to schemas" — defer uncertain implementation to schema documentation, ship code only when the design is settled.
- v4.0 cut explicitly closes the long t14e+ continue arc as **scaffold-complete**. Real-data validation is the next major check, not v4.x feature work alone.

---

## How to verify state at start of next chat

```bash
cd /tmp/w2  # or wherever the files live

# Confirm v4.0 markers in code
grep -n "SCRUBBER_VERSION = \|<title>\|local PCA scrubber v\|tool: 'pca_scrubber_v\|fillText('pca_scrubber v" pca_scrubber_v3.html

# Should show:
#   line 6:    <title>Local PCA Scrubber v4.0 ...
#   line ~20630: const SCRUBBER_VERSION = 'v4.0';
#   line ~26763: `Inversion catalogue export — local PCA scrubber v4.0`,
#   line ~26800:    tool: 'pca_scrubber_v4.0',
#   line ~27114: ctx.fillText('pca_scrubber v4.0', ...

# Confirm schema marker
grep "v4\.0 cut" SCHEMA_V2.md | head -1

# Run test sweep
node test_v399.js 2>&1 | tail -1   # → 753/753

# Full sweep (script all suites + e2e)
for t in test_v3*.js end_to_end_*.js verify_*.js; do
  echo "=== $t ==="
  node "$t" 2>&1 | tail -1
done
```

If anything is off, the previous turn's HANDOFF_v3_99 has the longer history.

---

**End of v4.0 handoff. Good luck on v4.x.**
