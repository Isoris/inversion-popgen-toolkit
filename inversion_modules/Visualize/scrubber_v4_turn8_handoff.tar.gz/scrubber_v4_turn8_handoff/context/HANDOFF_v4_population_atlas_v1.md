# Handoff — v4 + Population Atlas v1 → real-data testing

**Date**: 2026-04-29
**Project**: `inversion_codebase_v8.5` · 226-sample pure *C. gariepinus* hatchery cohort
**HPC**: LANTA (account `lt200308`)
**Project root**: `/scratch/lt200308-agbsci/Quentin_project_KEEP_2026-02-04/`
**conda env**: `assembly` (R: `/lustrefs/disk/project/lt200308-agbsci/13-programs/mambaforge/envs/assembly/bin/Rscript`)

> **Three-cohort reminder — must NEVER be conflated:**
> 1. F1 hybrid (*C. gariepinus* × *C. macrocephalus*) — genome assembly paper only
> 2. **226-sample pure *C. gariepinus* hatchery cohort** — current MS_Inversions_North_african_catfish, K clusters = hatchery broodline structure
> 3. Pure *C. macrocephalus* wild cohort — future paper

---

## What's shipped (all currently in `/mnt/user-data/outputs/`)

### Two sibling deliverables (the multi-atlas design)

| | File | Size | Status |
|---|---|---|---|
| 1/3 | `pca_scrubber_v3.html` | 1.39 MB | ✓ v4 production |
| 2/3 | `population_atlas_v1.html` | 54 KB | ✓ v1 scaffold |
| 3/3 | `variants_atlas_v1.html` | — | ⚪ planned (deleterious burden / catfish toxic mutations) |

### Schema doc

- `SCHEMA_V2.md` — 5435 lines, version markers up through 2.22 (Population Atlas v1 row)

### Test suites (all green from `/mnt/user-data/outputs/`)

```
test_v394.js                                 10/10
test_v394t2.js                                9/9
test_v396.js                                 10/10
test_v397.js                                 10/10
test_v397t2.js                               10/10
test_v397t3.js                                5/5
test_v398.js                                 39/39
test_v399.js                                753/753
test_v41_metrics_runtime.js                  68/68
test_v41_recluster_rebuild_runtime.js        38/38
test_v41_uv_modes_runtime.js                 38/38
test_v4_diversity_atlas_runtime.js           51/51
test_population_atlas_v1_runtime.js          75/75
─────────────────────────────────────────────────
                                          1124/1124 main + dedicated suites

Plus 8 t14e+ continue runtime suites (261/261 tests):
test_v399_lines_color_mode_runtime.js        12/12
test_v399_catalogue_export_runtime.js        32/32
test_v399_candidate_bar_runtime.js           25/25
test_v399_winsum_color_runtime.js            33/33
test_v399_registry_interop_runtime.js        31/31
test_v399_blocks_runtime.js                  62/62
test_v399_chips_inspector_runtime.js         34/34
test_v399_theta_pi_scrubber_runtime.js       32/32

Plus 6 e2e:
end_to_end_boundaries_check.js               22/22
end_to_end_boundaries_lifecycle.js           29/29
end_to_end_tsv_roundtrip.js                  26/26
end_to_end_check.js                          OK (real-data smoke test)
end_to_end_hover_check.js                    15/15
verify_null_concord_v398.js                   6/6
```

---

## v4 scrubber — what it does and what's new since v3.99

The Local PCA Scrubber is the production tool for chromosomal-inversion candidate calling on per-window dosage / θπ data. Loads precomputed JSON, exposes 13 tabs, supports candidate promotion + interval refinement + catalogue export. v4 closes the long t14e+ continue arc plus adds:

### v4 release contents (rolled up from v4.0 cut + v4.1 continue + full-scope work)

**Page-level features:**
- 13 tabs total: `local PCA |z|` / `local PCA θπ` (page12) / candidate focus / boundaries / catalogue / karyotype-tier / popstats / ancestry / windows / confirmed / markers / help / **diversity atlas (page13, NEW landing page)**
- θπ scrubber page12 scaffold — empty-state until R-side STEP_R39/R40/R41 ship `theta_pi_per_window` / `theta_pi_local_pca` / `theta_pi_envelopes` layers
- Diversity Atlas landing page (page13) — preview of the planned dual-mode design; the actual Population Atlas content lives in the separate `population_atlas_v1.html` file (architectural pivot — see schema row 2.22)

**L3 contingency improvements:**
- Four partition-comparison metrics on a click-to-cycle chip: Cramér's V (default) / NMI / AMI / ARI. Each has its own effect-size bands and tooltip. Click any value to advance through the cycle. State persists to `localStorage[pca_scrubber_v3.l3SecondaryMetric]`.
- L3 re-clustering picker — 7 enabled modes, 6 planned-disabled. State persists to `localStorage[pca_scrubber_v3.l3ReclusterMode]`. Mode change re-renders the contingency. The picker is recluster-mode only for the L3 panel — does NOT affect the catalogue, boundaries, or candidate-mode flows.

**Re-clustering modes shipped:**

| mode | algorithm | use case |
|---|---|---|
| `kmeans-K3` | default — current behavior | most cases |
| `kmeans-K6` | K=6 sub-band pass | nested haplotype substructure |
| `uv-rotated` (alias `distance-uv`) | rotated u/v coords + K-means3 | mirrors STEP20b `rotate_to_stripe_axis()` |
| `uv-denoise` | DBSCAN as pre-filter, K-means3 on survivors | filter family outliers before clustering |
| `uv-dbscan` | K-means3 → within-stripe DBSCAN on `v` | mirrors STEP22 |
| `uv-dist-rank` | closest tercile of Hom1/Hom2 to Het centroid → relabeled as Het | catches drift / recombinants |
| `uv-dist-fuzzy` | soft inverse-distance argmax with 0.45 tie-break threshold | catches ambiguous samples |

Six more planned-disabled (`gmm-3/4/5/6`, `dbscan-raw`, `dosage`) with tooltips explaining what each will do.

**Speed-first architecture:**
- Shared rotation cache `state.l2UVRotationCache` — expensive aggregation + K-means3 + rotation runs ONCE per L2; all five u/v modes use the cached coordinates
- Pure-JS DBSCAN `_dbscan(pointsObj, eps, minPts)` — naive O(N²); ~0.5ms at N=226, no kd-tree (overhead exceeds savings)
- Auto-eps via `_kDistAutoEps(pointsObj, k)` — `median(k-NN) × 0.8`, matches STEP22 exactly
- Per-mode result cache `state.l2GroupCacheByMode` — first call computes, subsequent calls hit cache

**§21 registry consumer (planned-fallback shipped now):**
- Dispatcher checks `state.candidateUVModes._byL2Mode.get(`${l2idx}_${mode}`)` BEFORE running on-the-fly clustering
- When the planned R-side `STEP_R??_emit_uv_modes_per_candidate.R` ships and emits `candidate_uv_modes.json` (one blob per promoted candidate, all 5 modes × all L2s within the candidate's span), loading that JSON populates `state.candidateUVModes` and the dispatcher prefers precomputed results
- On-the-fly stays as backup for L2s outside any candidate or for live exploratory scrolling

**Version markers:**
- `SCRUBBER_VERSION = 'v4'` (renamed from v4.1 — drops minor for canonical release name)
- `<title>Local PCA Scrubber v4 — L3 Contingency Debugger`
- Catalogue export header: `Inversion catalogue export — local PCA scrubber v4`
- JSON tool ID: `pca_scrubber_v4`
- PNG watermark: `pca_scrubber v4`

---

## Population Atlas v1 — sibling deliverable

Standalone HTML file (~54 KB) with same chrome as the scrubber. Different accent color (green `#3cc08a` instead of amber `#f5a524`) so the two atlases are visually distinguishable at a glance.

### 7 tabs, all layout/scaffold this turn

1. **Samples** — sortable-table-of-226-samples scaffold. Planned columns: `sample_id` / `family_id` / `broodline` / `mean_coverage` / `callable_fraction` / `genome_het` / `F_ROH` / `ancestry_Q_top` / `natora_status` / `qc_pass`. Includes ASCII mock-up of what the table will look like.
2. **Quality Control** — coverage histogram + missingness scatter panels. Documents thresholds (mean_coverage ≥5×, callable ≥90%, missingness ≤10%, FREEMIX ≤0.03, NAToRA π̂ <0.0884).
3. **Families & Genetic clusters** — six panel slots (NGSadmix Q-bar round 1 + round 2, kinship heatmap, NAToRA pruning, PCAngsd PCA, evalAdmix residuals). Two-round structure design explained (all-226 + 81-NAToRA-pruned).
4. **Heterozygosity** — four panels (cohort distribution, per-chromosome heatmap, H_obs vs F_ROH scatter, ranked bars). Folded-SFS caveat documented.
5. **Diversity** — chromosome θπ atlas (28 stacked tracks) + multiscale view + per-band θπ comparison. Documents 4 MODULE_3 scales (500kb, 50kb, 10kb, 5kb) with file paths.
6. **Inbreeding** — F_ROH ranked, ROH length distribution, ROH atlas (sample × position heatmap). Dual-bin ROH design explained (fixed + adaptive).
7. **About** — three-atlas manuscript design table, data sources by page, phasing roadmap, glossary (10 terms), cross-references to scrubber pages 7/8/12/13.

All seven pages are layout/scaffold — like the scrubber's page13 pattern. Planning grids, panel-slot mockups (`░░░ panel mockup ░░░`), no JSON loading, no rendering.

### Minimal JS (~50 lines)

- Tab switching (iterates `#tabBar button[data-page]`, toggles `.active` on tab + `.page` element)
- Theme toggle (cycles dark → light → academic)
- localStorage persistence for `population_atlas_v1.activeTab` and `population_atlas_v1.theme`
- Cross-link to scrubber: `<a href="pca_scrubber_v3.html">→ Inversions Atlas</a>` at the right end of the tab bar

### What v1 does NOT do

- No JSON loading
- No panel renderers
- No cross-atlas state sharing (each file has its own localStorage namespace)
- No reverse cross-link from scrubber → atlas yet (5-min addition for next turn)

---

## ⚠ The cross-atlas data-linking question (open architectural decision)

**Quentin's exact words at the end of the last turn**: *"Idk I thought the results for ROH and stuff can be linked across them. But its ok."*

This is a real architectural question that should be **answered before wiring any panel renderers in the Population Atlas**. Two viable options:

### Option A — shared JSON file
Both atlases load the **same precomputed JSON** that the scrubber already loads. The scrubber consumes the inversion-relevant layers (per-window PCA, candidates, ancestry, etc.); the Population Atlas consumes the population-relevant layers (per-sample F_ROH, kinship, family Q, ROH segments, multiscale θπ). The JSON is the single source of truth.

- **Pros**: One R-side emit pipeline. One file to maintain. Cross-references are automatic (same sample IDs, same chromosome coordinates). Updating the data updates both atlases simultaneously.
- **Cons**: JSON gets larger (population layers added on top of scrubber's existing payload). Both atlases need to handle "this layer is loaded / not loaded" gracefully; the scrubber already does this for inversion layers but the population atlas would need similar logic.

### Option B — per-atlas JSON files
Scrubber loads `precomp_<chrom>.json` (today). Population atlas loads `population_atlas.json` (cohort-level, not per-chromosome). Variants atlas loads `variants_atlas.json`. Each atlas has its own self-contained JSON.

- **Pros**: Each atlas is independent. Population atlas content is cohort-level not per-chromosome, so a single file makes sense. Smaller per-file payloads.
- **Cons**: Two R-side emit pipelines to maintain (per-chrom for scrubber + cohort-level for atlas). Cross-references rely on matching sample IDs and chromosome names manually. If a sample is renamed, both files need re-emission to stay consistent.

### My recommendation (for the next chat to consider)

**Hybrid**: cohort-level data (samples manifest, F_ROH per sample, kinship matrix, ancestry-Q at the cohort level) → `cohort.json` shared by both atlases. Per-chromosome data (per-window θπ, candidates, ancestry per window) → `precomp_<chrom>.json` already used by scrubber.

The Population Atlas pages 1-3 (Samples, QC, Families) all want cohort-level data — single load, fits in memory. Pages 4-6 (Het, Diversity, Inbreeding) want per-chromosome data — load on demand when user navigates to a chromosome view, similar to how the scrubber loads per-chromosome JSONs today.

This separation matches how **the data is actually emitted**: MODULE_2B (NGSadmix, NAToRA, ngsRelate) produces cohort-level outputs; MODULE_3 (multiscale θπ, ngsF-HMM) produces per-chromosome outputs.

**This decision should be made at the start of the next turn** before any panel-renderer work, to avoid having to rip apart the JSON loading later.

---

## Real-data testing focus areas

When testing on real LANTA data, here's what's worth verifying first (in priority order):

### 1. Scrubber loads the existing precomp JSON correctly

Should already work — no v4 changes affect JSON loading. But quick smoke check:
- Open `pca_scrubber_v3.html` in browser
- Load any `precomp_<chrom>.json` from `/scratch/lt200308-agbsci/Quentin_project_KEEP_2026-02-04/inversion_codebase_v8.5/MODULE_5A2_OUTPUT/`
- Verify the schema badge shows the loaded layers
- Click through tabs 1-12 to confirm nothing broke

### 2. New L3 contingency metrics on real data

This is the most concrete v4 addition that shows up immediately:
- Scrub into any L2 envelope where the K=3 → MERGE call feels questionable
- Click the metric chip on the L3 contingency display to cycle through Cramér's V → NMI → AMI → ARI
- **What to look for**: cases where Cramér's V says "MERGE-like" but ARI/AMI says "SEPARATE-like" (or vice-versa). When the metrics disagree, the disagreement is the signal. Imbalanced cohort splits (180/30/16-style) tend to inflate Cramér's V relative to AMI.

### 3. Re-clustering modes — does `uv-rotated` match cluster-side R?

Critical for reproducibility:
- Pick a candidate where `STEP21_candidate_state_assignment.R` already emitted `candidate_pca_rotated.tsv` for the corresponding L2 envelope
- In scrubber, set recluster mode to `uv-rotated` (or `distance-uv`)
- Compare scrubber's labels against the R-side `coarse_group_refined` column
- They should match (same algorithm, same input)
- **If they don't match**: that's a bug worth tracking down. The scrubber rotation math was sign-bug-fixed last turn (verified by the (1,1) → (√2, 0) anchor test) but real-data validation hasn't happened yet.

### 4. `uv-dbscan` vs STEP22 reproducibility

Same idea, harder to verify because STEP22 uses `(v + PC3)` and the scrubber currently uses `v` only:
- Pick a candidate with `candidate_subclusters.tsv` from STEP22
- Set scrubber recluster to `uv-dbscan`
- Verify the broad pattern matches even if exact cluster IDs differ
- **Known limitation**: scrubber doesn't have PC3 in its precomp data; STEP22 does. So `uv-dbscan` results won't be identical, just qualitatively similar.

### 5. Population Atlas opens cleanly

- Open `population_atlas_v1.html` in browser
- Click through all 7 tabs
- Verify dark/light/academic theme cycling works
- Click "→ Inversions Atlas" link, confirm it opens the scrubber
- This is purely structural — no real-data wiring this turn — but worth confirming the file works in your actual browser.

### 6. Edge cases worth probing

- What happens on a small chromosome with very few L2s? (Recluster modes might fall through to fallback.)
- What happens on a sample-pair with concord = 100% (perfectly aligned)? The metrics should all = 1.0; this is a sanity check.
- What happens when a recluster mode changes but the user immediately switches L2 (cache validity check)?
- Any chromosome where MODULE_3 multiscale θπ files exist but the scrubber JSON doesn't have `theta_pi_per_window` should leave page12 in empty-state.

---

## Known issues / things to watch

### Scrubber

- **`uv-dbscan` uses `v` only** — STEP22 uses `(v + PC3)`. Scrubber doesn't have PC3 in precomp. If results diverge significantly, this is the reason. Future work: emit per-window PC3 in the JSON layer.
- **`uv-dist-rank` and `uv-dist-fuzzy`** are intentionally lossy — they remap labels. If you see "wow concord went from 70% to 95% with `uv-dist-rank`", that's because samples got moved INTO the Het cell, not because the underlying clustering improved. The metric chip will show NMI/AMI/ARI values that reflect this — they should NOT increase as much as the relabeling-induced concord.
- **Distance-uv legacy function still exists** in addition to `clusterL2_UVRotated` — the older `clusterL2_DistanceUV` is left in place for reference. Both produce the same labels but `_UVRotated` uses the shared cache. Could be cleaned up but no functional issue.
- **The fingerprint cache** in `_renderL3Fingerprint` correctly includes `state.l3ReclusterMode` and `state.l3SecondaryMetric` — verified by tests. Tested by switching modes and confirming the contingency rebuilds.

### Population Atlas

- **No backlink from scrubber → atlas** — ~~currently you can go atlas → scrubber via the tab-bar link, but not the reverse~~. **Done this turn**: scrubber's tab bar now ends with `→ Population Atlas` link (mirrors the population atlas's `→ Inversions Atlas` link). Both directions work.
- **All pages are scaffold** — clicking a panel slot does nothing. By design for v1.
- **No JSON loading code at all** — when wiring real data, the loader pattern from the scrubber can be lifted directly. The scrubber's `loadPrecomp(file)` is the reference.

### Architectural

- **Cross-atlas state sharing is NOT wired**. Right now each file has its own localStorage namespace. If a user marks a sample as "of interest" in the population atlas, the scrubber doesn't know. This is fine for v1 but worth deciding if/when to bridge.
- **Variants Atlas not started** — `variants_atlas_v1.html` doesn't exist yet. Would follow the same pattern: copy `population_atlas_v1.html`, change accent color (purple? red?), change tabs (deleterious burden / conservation / BC tiers / catfish-specific risk variants), populate with planning content from MODULE_CONSERVATION outputs.

---

## File inventory — what's in `/mnt/user-data/outputs/`

### Production deliverables
- `pca_scrubber_v3.html` — v4 scrubber (1.39 MB)
- `population_atlas_v1.html` — Population Atlas (54 KB)

### Schema + handoffs
- `SCHEMA_V2.md` — 5435 lines, schemas 2.0 through 2.22
- This handoff: `HANDOFF_v4_population_atlas_v1.md`
- Older handoffs: `HANDOFF_v3_*.md`, `HANDOFF_v4_0.md`, etc.

### Test suites (13 dedicated, 8 t14e+ runtime, 6 e2e)
All listed in the test summary above. All green.

### R-side scripts (smoke tests + uploaded references)
- `smoke_test_M04_M05.R`, `smoke_test_M06.R` — existing R smoke tests

---

## Suggested next-turn agenda (in priority order)

1. **Decide cohort.json vs per-atlas-JSON** (5 min discussion, big architectural impact — see "cross-atlas data-linking question" above)
2. **Variants Atlas v1 scaffold** — copy population atlas pattern, ~3-4 pages (deleterious burden / conservation / BC tiers / catfish-specific). ~2 hours, gives the third deliverable to round out the manuscript design.
3. **Wire Population Atlas Samples page (page1) to real data** — needs the cohort.json schema decided first; then load JSON, render sortable table, filter pills (~3 hours).
4. **Real-data scrubber smoke test** — load any `precomp_<chrom>.json` and verify all 13 tabs work. If anything breaks: fix.
5. **uv-rotated reproducibility check** — scrubber labels vs `STEP21 candidate_pca_rotated.tsv` `coarse_group_refined` column. Probably matches. If not, investigate.

---

## Working-style notes (for the new chat)

Quentin works across multiple parallel chat sessions and reconciles script versions before assuming state. Always check timestamps + version markers before editing. v4 is the current canonical scrubber; population atlas v1 is the new sibling.

Quentin prefers:
- Compact non-fragmented pipelines
- Original tested code used verbatim, not reimplemented
- Single central config file per module
- Targeted fixes over full rewrites
- Deliverables as tarballs ready to extract (or just files in `/mnt/user-data/outputs/`)
- No mass step-file renaming
- All thresholds configurable not hardcoded
- "If you don't know, you add to schemas"
- Concise / abbreviated English; direct corrections welcomed
- Honest scope estimates; says "continue" when ready for the next agreed item

The three-cohort distinction is sacred — never conflate the F1 hybrid, the 226-sample pure *C. gariepinus* (current), and the planned pure *C. macrocephalus*.

The atlas-mode-switching design (in-scrubber, schema 2.21 / §17) was **superseded by the multi-file sibling-deliverable design** (schema 2.22) when Quentin said "make a different html then." The scrubber's page13 (Diversity Atlas landing page) stays as the in-scrubber preview / cross-reference; the actual Population Atlas content lives in `population_atlas_v1.html`.

---

End of handoff. Ready for real-data testing.
