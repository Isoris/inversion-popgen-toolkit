# Handoff — scrubber v3.97 turn 1 (2026-04-28)

## Where we are

**Current head:** `pca_scrubber_v3.html` v3.97 (1006 KB, 21,876 lines).
**SCHEMA:** `SCHEMA_V2.md` v2.8 (94 KB, 2017 lines).
**Tests:** 561/561 passing (39 + 522 carried forward).

This handoff covers v3.97 turn 1 — pure helpers + state extension for
the boundary zone refinement module. Page UI ships in turn 2; persistence
+ TSV export in turn 3. Prior:

- v3.96 (hover tooltips) in `HANDOFF_v3_96.md`
- v3.95 (R-side unblock) in `HANDOFF_v3_95.md`
- Schema 2.8 + spec in `SPEC_v3_97_boundaries.md` and
  `SCHEMA_2_8_BOUNDARIES_DRAFT.md` (now folded into SCHEMA_V2.md)

## Work shipped this chat (v3.97 turn 1)

### Pure helpers + state extension for boundary zones

11 functions, all unit-testable in node, implementing the schema §12
contract:

| Function | Purpose |
|---|---|
| `_ensureBoundariesState()` | Singleton state on `state.__boundaries` |
| `_bsearchWin(arr, target, mode)` | Binary search lo/hi in sorted bp array |
| `_boundaryScanRange(cand, scan_radius_bp, chromLen)` | Scan range with clamping + huge-candidate expansion |
| `_rollingMedian(arr, width)` | NA-aware width-3 default smoother |
| `_perTrackMad(arr)` | MAD with NA filtering |
| `_madNormalize(arr, mad)` | MAD-scaled normalization, NA → 0 |
| `_findSVAnchorsInZone(beRow, zoneStart, zoneEnd)` | Filter SV anchors by bp |
| `_supportClass(score, support)` | Schema-locked classification |
| `_buildBoundaryTrackScores(cand, scan)` | Collect per-track per-window arrays from available layers |
| `_computeBoundaryEdges(ts, scan, weights, opts)` | The 10-step algorithm |
| `_buildBoundaryRecord(edge, side, source, opts)` | Schema-§12-shaped JSON record |

Constants:
- `BOUNDARY_DEFAULTS` (scan radius, zone radius, smooth window, exclusion %, support-inclusion threshold, huge-candidate threshold)
- `BOUNDARY_TRACK_WEIGHTS` — locked per schema (sums to 1.0)
- `BOUNDARY_TRACK_POLARITY` — **new in implementation, added to schema 2.8** — per-track sign convention so falling-inside tracks (band_continuity, similarity, theta_pi) contribute coherently with rising-inside tracks (PCA, GHSL, het, FST)
- `BOUNDARY_TRACK_NAMES` — derived from `BOUNDARY_TRACK_WEIGHTS` keys
- `SUPPORT_CLASS_COLORS` — locked palette (green/amber/peach/grey at 0.20/0.18/0.16/0.10 opacity)

### Algorithm correction during implementation

While testing, found that the schema's "Step 2 (signed step) → Step 3
(rolling-median smooth)" order **erases clean single-window
transitions**: median of `[0, +0.6, 0]` = 0. The fix matches the user's
original spec wording ("smooth the score with a small rolling
median/mean") rather than the schema's slightly-ambiguous restatement:

- ❌ Before: `score → step → smooth → MAD-normalize`
- ✓ After:   `score → smooth → step → MAD-normalize`

Schema 2.8 section "Auto-propose algorithm (scrubber-side)" updated to
disambiguate. The corrected ordering preserves real edges while still
suppressing single-window noise.

### Per-track polarity convention (new in 2.8 schema, added during implementation)

Initial implementation only summed `step > 0` into `combined_left` and
`step < 0` into `combined_right`. But on synthetic data where
`band_continuity` *drops* inside the inversion, its rising step at the
right edge correctly contributed to `combined_right`, while its falling
step at the *left* edge incorrectly contributed to `combined_right`
again instead of `combined_left`.

Fix: per-track polarity (`+1` rises inside, `-1` falls inside). For
falling-inside tracks, the step is sign-flipped before the
left/right discrimination. After the fix, all 4 tracks in the e2e test
contribute to BOTH edges (was 3 before).

Schema 2.8 §12 "TRACK_NAMES enum" updated with polarity values:

```
pca_drop               +1
dosage_transition      +1
band_continuity_drop   -1
polarity_change        +1
similarity_edge        -1
ghsl_step              +1
het_transition         +1
fst_edge               +1
theta_pi_step          -1
discordant_pile        +1
sv_anchor              +1
```

### Tests (10 new in `test_v397.js`)

1. `SCRUBBER_VERSION` is `v3.97+`
2. `_bsearchWin` lo/hi modes + edge clamping (10 sub-cases)
3. `_boundaryScanRange` clamps + huge-candidate expansion (5 sub-cases)
4. `_rollingMedian` width=3 NA-aware (5 sub-cases incl. all-NA → NaN)
5. `_perTrackMad` + `_madNormalize` roundtrip (6 sub-cases)
6. `_findSVAnchorsInZone` filters by pos_bp (6 sub-cases incl. independent-copy assertion)
7. `_supportClass` covers all four classes (10 sub-cases, including
   the `n==2 AND s<0.40` priority-order edge case → `moderate`, NOT `weak`)
8. `_buildBoundaryTrackScores` returns only present-layer tracks
9. `_computeBoundaryEdges` on synthetic data — picks correct windows;
   support[] populated; multi-track agreement
10. `_buildBoundaryRecord` shape conforms to schema §12 + state shape

All 39 prior + 10 new tests pass: **49/49**. (Plus 522 from earlier
test files = 561 total.)

### End-to-end realistic synthetic test

`end_to_end_boundaries_check.js` builds a 30 Mb synthetic chromosome
with 1500 windows × 20 kb, embeds a candidate at 12-14 Mb with realistic-
shape signal transitions (5-6 windows of ramp, 3-4% noise), and runs
the full pipeline:

```
_boundaryScanRange → _buildBoundaryTrackScores → _computeBoundaryEdges
→ _buildBoundaryRecord (×2) → _supportClass
```

Result on synthetic input with 4 tracks (pca_drop, band_continuity_drop,
ghsl_step, het_transition):

- Detected left edge: window 593 (true 595, off by 2 windows = 40 kb)
- Detected right edge: window 710 (true 710, exact)
- Both zones bracket the true edges
- Both classified as `strong` (4-track support, score saturates at 1.0)

22/22 e2e checks pass. The algorithm is precise enough on clean
multi-track signal that the user can trust auto-propose as a starting
point — manual override (E/F keys, turn 2) is for refinement, not
correction of badly-wrong defaults.

## Notable design decisions

- **No UI in turn 1.** Page DOM, render, hotkeys, save/reset are all
  turn 2. Turn 1 is pure plumbing — the helpers can be developed and
  reasoned about in isolation, and turn 2 just calls them. This is
  the same pattern as v3.94's two-turn split.
- **`_buildBoundaryTrackScores` is partial in turn 1.** Tier-1 tracks
  (pca_drop, band_continuity_drop, ghsl_step, het_transition) emit
  when their source data is available. Tier-2 (polarity_change,
  dosage_transition) need richer derivations that turn 2 will exercise
  when the page UI runs them on real data — turn 1 emits these
  conservatively (only when the source is fully present and easily
  computable). Tier-3 (fst_edge, theta_pi_step, discordant_pile,
  sv_anchor) require the optional `boundary_evidence` layer (R-side,
  not yet shipped) — turn 1 emits these correctly when the layer is
  loaded but they don't exist in any current data.
- **`_computeBoundaryEdges` is fully implemented.** This is the
  algorithmic heart; once turn 2 builds richer track scores, the
  algorithm itself doesn't change.
- **Per-track polarity is a new contract item.** Initially I had it in
  the implementation only, but it's conceptually load-bearing — without
  it, falling-inside tracks contribute incorrectly. Added to schema
  2.8 §12 in the same chat.
- **Algorithm ordering corrected.** Schema 2.8 had the steps in the
  wrong order (smooth-then-step erases clean transitions). Fixed in
  schema and implementation in this chat.
- **Score saturates at 1.0.** When all available tracks step in the
  same direction at the same window, the MAD-normalized contributions
  sum to ≥1.0 and clip. This is fine — the support_class derivation
  uses BOTH `|support|` and `score`, so a saturated score with 4
  tracks is `strong`, while a saturated score with 1 track is `weak`.

## Outstanding items (turn 2 + turn 3)

### Turn 2 — page DOM + tracks + hotkeys + save/reset

Per `SPEC_v3_97_boundaries.md` §"Turn 2 — Page render, tracks,
hotkeys":

- Tab insertion: new `data-page="page11"` button at displayed-position
  3 between candidate-focus and catalogue
- Page DOM stub with toolbar, candidate selector, status dropdown,
  scan-radius buttons, action buttons, info slot, tracks slot, summary
- `renderBoundariesPage()` top-level driver
- `_bndSelectCandidate(candId)` — populates staging from existing
  candidate boundaries (if present) or empty
- `_bndAutoPropose()` — calls the turn-1 helpers, populates staging,
  marks dirty
- `_bndOverrideLeft()` / `_bndOverrideRight()` — manual override
  centered on `state.cur`
- `_bndReset()` — clears staging
- `_bndDrawTracks()` — stacked SVG/canvas tracks on shared bp axis;
  zone shading absolutely-positioned over track stack
- Page-scoped hotkeys (E/F/B/R + bonus A); `_bndAttachHotkeys()` /
  `_bndDetachHotkeys()` on page show/hide
- Reuses `drawDosageHeatmap` from v3.94 + hover tooltips from v3.96

Estimate: ~600 LOC + 8 tests.

### Turn 3 — persistence + TSV export

- `_bndSave()` persists staging → `state.candidates[i]`
- 14 new TSV columns added to `REGISTRY_TSV_COLUMNS` per schema §12
- Row builder helper `_boundaryColsFromCand(c)` returns the values

Estimate: ~150 LOC + 5 tests.

### Long-running parked

- `STEP_M06_emit_boundary_evidence.R` — R-side emit of the optional
  `boundary_evidence` layer (FST + theta-pi + discordant-pair + SV
  anchors). Out of scope for v3.97; comes after the page UI is real.

## Key v3.97 turn 1 functions (reference for next chat)

### Constants (top of HTML script)
- `BOUNDARY_DEFAULTS` — scan radius, zone radius, etc.
- `BOUNDARY_TRACK_WEIGHTS` — locked weights summing to 1.0
- `BOUNDARY_TRACK_POLARITY` — per-track ±1 sign convention
- `BOUNDARY_TRACK_NAMES`
- `SUPPORT_CLASS_COLORS`

### State + pure helpers
- `_ensureBoundariesState()`
- `_bsearchWin(arr, target, mode)`
- `_boundaryScanRange(cand, scan_radius_bp, chromLen)`
- `_rollingMedian(arr, width)`
- `_perTrackMad(arr)`
- `_madNormalize(arr, mad)`
- `_findSVAnchorsInZone(beRow, zoneStart, zoneEnd)`
- `_supportClass(score, support)`
- `_buildBoundaryTrackScores(cand, scanRange)`
- `_computeBoundaryEdges(trackScores, scanRange, weights, opts)`
- `_buildBoundaryRecord(edge, side, source, opts)`

## SCHEMA_V2.md status

**v2.8 already on disk** (was integrated last chat). Two refinements
this chat:

- §12 "Auto-propose algorithm" steps reordered (smooth before step) to
  match correct implementation
- §12 "TRACK_NAMES enum" extended with polarity values

Both refinements bring the schema back into precise alignment with the
working code. No new versioning bump (still 2.8) since the contract
shape is unchanged — these are clarifications, not contract changes.

## File staging at /mnt/user-data/outputs/

- **pca_scrubber_v3.html** — v3.97, 1006 KB, 21,876 lines
- **SCHEMA_V2.md** — v2.8 (refined), 94 KB, 2017 lines
- **test_v397.js** — 10 new tests, 432 lines
- **end_to_end_boundaries_check.js** — synthetic-input pipeline
  validation, 22 checks
- **HANDOFF_v3_97_turn1.md** — this file

## Suggested entry point for next chat

**v3.97 turn 2** — page DOM + tracks + hotkeys. The helpers are in
place, tested, and proven on synthetic data. Turn 2 is mostly DOM
plumbing: render the boundaries page section, wire the hotkeys
(page-scoped, only fire when no input has focus), render stacked
tracks with zone-shading overlays, hook into `setActivePage('page11')`.

If the user prefers to validate turn 1 on real data first, the right
move is to load the v3.95 R-side outputs (STEP_M04 / STEP_M05) for
LG28 and a phase-13 marker JSON, then run `_buildBoundaryTrackScores`
+ `_computeBoundaryEdges` directly via the browser console to see
what the algorithm picks for real candidates. The scrubber console
exposes the helpers via `window.__bnd = { ... }` (need to add this
binding in turn 2; for now, use `_buildBoundaryTrackScores` etc.
directly since they're top-level functions in the inline script).

## User working style notes

(Unchanged.)

"Continue" = proceed with next agreed item. This chat shipped v3.97
turn 1; turn 2 is the natural next step.

Three catfish cohorts that must NEVER be conflated:
1. F1 hybrid (*C. gariepinus* × *C. macrocephalus*) — genome assembly
   paper only
2. 226-sample pure *C. gariepinus* hatchery cohort — current inversion
   work, "MS_Inversions_North_african_catfish" — K clusters reflect
   broodline structure, NOT species admixture
3. Pure *C. macrocephalus* wild cohort — future paper

User's full name is Quentin Andres. Never invent a surname.
