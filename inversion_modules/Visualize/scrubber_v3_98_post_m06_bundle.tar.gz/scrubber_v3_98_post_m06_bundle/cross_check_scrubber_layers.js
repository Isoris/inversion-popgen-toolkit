#!/usr/bin/env node
// Cross-check that JSONs produced by STEP_M04 + STEP_M05 satisfy
// the scrubber's actual layer-detection rules (lifted from
// pca_scrubber_v3.html lines ~12781-12790).

const fs = require('fs');
const path = require('path');

// Re-implement the scrubber's detection cases verbatim
function detect(data) {
  const layers = [];
  // dosage_chunks: meta-layer index
  if (data && data.dosage_chunks && Array.isArray(data.dosage_chunks.chunks)) {
    layers.push('dosage_chunks');
  }
  // candidate_sample_coherence: array
  if (data && Array.isArray(data.candidate_sample_coherence)) {
    layers.push('candidate_sample_coherence');
  }
  // candidate_marker_polarity: array
  if (data && Array.isArray(data.candidate_marker_polarity)) {
    layers.push('candidate_marker_polarity');
  }
  return layers;
}

// And the scrubber's chunk-finding logic (lines 5414-5434)
function findCoveringChunk(idx, region) {
  if (!idx || !Array.isArray(idx.chunks)) return null;
  const c = idx.chunks.find(ch =>
    ch.start_bp <= region.start_bp && ch.end_bp >= region.end_bp);
  if (c) return { mode: 'cover', chunk: c };
  const overlap = idx.chunks.find(ch =>
    !(ch.end_bp < region.start_bp || ch.start_bp > region.end_bp));
  if (overlap) return { mode: 'overlap', chunk: overlap };
  return null;
}

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('ok:   ' + msg); pass++; }
  else      { console.log('FAIL: ' + msg); fail++; }
}

// Find smoke-test working dir
let work = process.env.SMOKE_WORK_DIR || '/home/claude/work/smoke_out';
if (!fs.existsSync(work)) {
  // Fall back to scanning /tmp
  const tmpRoot = '/tmp';
  const candidates = [];
  for (const d of fs.readdirSync(tmpRoot)) {
    const full = path.join(tmpRoot, d);
    try {
      if (fs.statSync(full).isDirectory()) {
        for (const e of fs.readdirSync(full)) {
          if (e.startsWith('m04m05_smoke_')) {
            candidates.push({ p: path.join(full, e), m: fs.statSync(path.join(full, e)).mtimeMs });
          }
        }
      }
    } catch (_) {}
  }
  candidates.sort((a, b) => b.m - a.m);
  if (candidates.length === 0) { console.error('no smoke-test work dir found'); process.exit(2); }
  work = candidates[0].p;
}
console.log('using work dir:', work);

const CHROM = 'TEST_LG01';
const baseDir = path.join(work, 'scrubber_data', CHROM);

// === M04 index ===
const idxPath = path.join(baseDir, `${CHROM}_dosage_chunks_index.json`);
const idx = JSON.parse(fs.readFileSync(idxPath, 'utf8'));
const idxLayers = detect(idx);
ok(idxLayers.includes('dosage_chunks'),
   `index registers dosage_chunks via scrubber detector  [layers=${idxLayers.join(',')}]`);
ok(idx.dosage_chunks.chunks.every(c => 'start_bp' in c && 'end_bp' in c && 'url' in c),
   'every chunk has start_bp/end_bp/url');

// === Chunk content match scrubber's _findCoveringChunk ===
// region 1..1000 should be covered (we built 8 windows spanning 1..1000)
const r1 = { start_bp: 200, end_bp: 350 };
const found1 = findCoveringChunk(idx.dosage_chunks, r1);
ok(found1 !== null, `region ${r1.start_bp}..${r1.end_bp} resolves to a chunk`);
if (found1) ok(['cover','overlap'].includes(found1.mode),
               `resolution mode = ${found1.mode}`);

// region spanning multiple chunks → overlap fallback
const r2 = { start_bp: 100, end_bp: 900 };
const found2 = findCoveringChunk(idx.dosage_chunks, r2);
ok(found2 !== null, `wide region ${r2.start_bp}..${r2.end_bp} resolves`);
ok(found2.mode === 'overlap', 'wide region uses overlap fallback');

// region beyond chrom end → null
const r3 = { start_bp: 2000, end_bp: 3000 };
const found3 = findCoveringChunk(idx.dosage_chunks, r3);
ok(found3 === null, 'out-of-range region returns null');

// === Chunk content shape (mirrors scrubber's selectTopMarkers expectations) ===
const ch1Path = path.join(work, 'scrubber_data', idx.dosage_chunks.chunks[0].url);
const ch1 = JSON.parse(fs.readFileSync(ch1Path, 'utf8'));
ok(Array.isArray(ch1.markers) && Array.isArray(ch1.dosage),
   'chunk has markers + dosage arrays');
ok(ch1.markers.every(m => Number.isFinite(m.pos_bp) && Number.isFinite(m.missingness)),
   'every marker has pos_bp + missingness');
ok(ch1.dosage.every(row => Array.isArray(row) && row.length === ch1.n_samples),
   'every dosage row has length == n_samples');
// NA encoded as -1
const flat = ch1.dosage.flat();
ok(flat.every(v => v === -1 || v === 0 || v === 1 || v === 2),
   `dosage values in {-1,0,1,2} (n=${flat.length})`);

// Run scrubber's selectTopMarkers locally on this chunk
function selectTopMarkers(chunk, region, capN) {
  const N = Math.max(1, Math.min(500, capN | 0));
  const inRegion = [];
  for (let mi = 0; mi < chunk.markers.length; mi++) {
    const m = chunk.markers[mi];
    if (m.pos_bp < region.start_bp || m.pos_bp > region.end_bp) continue;
    inRegion.push(mi);
  }
  const passing = inRegion.filter(mi => {
    const miss = chunk.markers[mi].missingness;
    return !(miss != null && miss > 0.20);
  });
  return { selected: passing.length, total: inRegion.length };
}
const sel = selectTopMarkers(ch1,
  { start_bp: ch1.region_start_bp, end_bp: ch1.region_end_bp }, 200);
ok(sel.total === ch1.n_markers,
   `selectTopMarkers sees all chunk markers (got ${sel.total}, n_markers=${ch1.n_markers})`);

// === M05 layers ===
const m05Path = path.join(baseDir, `${CHROM}_step29_layers.json`);
const m05 = JSON.parse(fs.readFileSync(m05Path, 'utf8'));
const m05Layers = detect(m05);
ok(m05Layers.includes('candidate_sample_coherence'),
   'M05 detected as candidate_sample_coherence');
ok(m05Layers.includes('candidate_marker_polarity'),
   'M05 detected as candidate_marker_polarity');

// === The scrubber's _buildPolarityLookup needs (candidate_id, pos) keying ===
const polRow = m05.candidate_marker_polarity[0];
ok(Number.isInteger(polRow.candidate_id) && Number.isInteger(polRow.pos),
   'polarity row has integer candidate_id + pos for keying');
ok(typeof polRow.final_flip_decision === 'boolean',
   `polarity final_flip_decision is boolean (got ${typeof polRow.final_flip_decision})`);

// === Coherence row schema ===
const cohRow = m05.candidate_sample_coherence[0];
const cohRequired = ['candidate_id','sample','coarse_group','agreement_fraction',
  'coherence_class','dist_to_centroid','centroid_z_score','stripe_quality',
  'tier_rule','n_informative_markers'];
ok(cohRequired.every(k => k in cohRow),
   'coherence row has all required keys');

console.log(`\n${pass} passed, ${fail} failed`);
process.exit(fail === 0 ? 0 : 1);
