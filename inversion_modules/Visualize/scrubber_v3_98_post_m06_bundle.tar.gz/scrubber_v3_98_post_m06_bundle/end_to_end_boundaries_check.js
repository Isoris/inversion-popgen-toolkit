#!/usr/bin/env node
// End-to-end realistic test for v3.97 boundary auto-propose.
// Uses the same shim pattern as test_v397.js so the inline script
// loads cleanly without DOM stubs failing.

const fs = require('fs');
const html = fs.readFileSync('/home/claude/v3/pca_scrubber_v3.html', 'utf8');
const m = html.match(/<script>([\s\S]+?)<\/script>/);
let js = m[1];

const shim = `
const _byId = new Map();
function _makeEl(tag) {
  const _ownC = new Set();
  const ctxStub = { setTransform:()=>{}, clearRect:()=>{}, fillRect:()=>{},
    strokeRect:()=>{}, beginPath:()=>{}, moveTo:()=>{}, lineTo:()=>{}, stroke:()=>{},
    fill:()=>{}, fillText:()=>{}, save:()=>{}, restore:()=>{},
    translate:()=>{}, rotate:()=>{}, setLineDash:()=>{},
    measureText:(s)=>({ width:0 }), createLinearGradient:()=>({addColorStop:()=>{}}),
    fillStyle:'',strokeStyle:'',lineWidth:1,font:'',textAlign:'',textBaseline:'' };
  const el = { tagName:(tag||'').toUpperCase(), id:'', textContent:'', _innerHTML:'',
    disabled:false, value:'', placeholder:'', title:'', checked:false,
    width:0, height:0, offsetWidth:100, offsetHeight:20, clientWidth:1000, clientHeight:400,
    style:{cssText:'',display:'',width:'',height:'',visibility:'',left:'',top:''},
    classList: { _c: _ownC, add(...a){a.forEach(x=>this._c.add(x));},
      remove(...a){a.forEach(x=>this._c.delete(x));}, toggle(){}, contains(x){return this._c.has(x);} },
    dataset:{}, _children:[],
    appendChild(c){ this._children.push(c); return c; },
    addEventListener(){}, removeEventListener(){},
    querySelector(){return null;}, querySelectorAll: () => [],
    setAttribute(){}, getAttribute(){return null;}, removeAttribute(){},
    getBoundingClientRect: () => ({left:0,top:0,width:1000,height:120,right:1000,bottom:120}),
    contains: () => false, parentNode: null, parentElement: null,
    getContext: () => ctxStub };
  Object.defineProperty(el,'innerHTML',{get(){return this._innerHTML;},set(v){this._innerHTML=String(v);}});
  Object.defineProperty(el,'className',{get(){return [...this.classList._c].join(' ');},
    set(v){this.classList._c.clear(); String(v||'').split(/\\s+/).filter(Boolean).forEach(x=>this.classList._c.add(x));}});
  return el;
}
const _bodyEl = _makeEl('body');
const document = {
  documentElement: _makeEl('html'),
  querySelectorAll: () => [], querySelector: () => null,
  getElementById(id) { if (!_byId.has(id)) { const el = _makeEl('div'); el.id = id; _byId.set(id, el); } return _byId.get(id); },
  createElement: _makeEl, body: _bodyEl,
  addEventListener: () => {}, removeEventListener: () => {},
};
const window = { devicePixelRatio: 1, addEventListener: () => {}, innerWidth: 1024, innerHeight: 768 };
const localStorage = { setItem(){}, getItem(){return null;}, removeItem(){}, clear(){} };
const getComputedStyle = () => ({ getPropertyValue: () => '' });
const FileReader = function() {};
const Blob = function() {};
const URL = { createObjectURL: () => '', revokeObjectURL: () => {} };
const requestAnimationFrame = (fn) => { try { fn(); } catch (e) {} return 1; };
const cancelAnimationFrame = () => {};
const setTimeout = (fn) => { try { fn(); } catch (e) {} return 1; };
const clearTimeout = () => {};
const alert = () => {};
const confirm = () => true;
`;
js = `${shim}\n${js}\nmodule.exports = {
  state, BOUNDARY_DEFAULTS, BOUNDARY_TRACK_WEIGHTS,
  _boundaryScanRange, _buildBoundaryTrackScores,
  _computeBoundaryEdges, _buildBoundaryRecord,
  _ensureBoundariesState,
};\n`;
fs.writeFileSync('/tmp/scrubber_e2e_v397.js', js);
delete require.cache[require.resolve('/tmp/scrubber_e2e_v397.js')];
const M = require('/tmp/scrubber_e2e_v397.js');

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('ok:   ' + msg); pass++; }
  else      { console.log('FAIL: ' + msg); fail++; }
}

// =============================================================================
// 30 Mb chromosome, 1500 windows of 20kb each. Candidate 12-14 Mb.
// True edges at windows 595 (11.9 Mb) and 710 (14.2 Mb).
// =============================================================================
const N_WIN = 1500;
const WIN_BP = 20000;
const windows = { start_bp: new Array(N_WIN), end_bp: new Array(N_WIN) };
for (let i = 0; i < N_WIN; i++) {
  windows.start_bp[i] = i * WIN_BP;
  windows.end_bp[i]   = (i + 1) * WIN_BP - 1;
}

const trueLeft  = 595;
const trueRight = 710;

let _seed = 42;
const rng = () => { _seed = (_seed * 16807) % 2147483647; return _seed / 2147483647; };

function buildSignal(insideValue, outsideValue, noiseStd, leftTransitionWidth, rightTransitionWidth) {
  const a = new Array(N_WIN);
  for (let i = 0; i < N_WIN; i++) {
    let baseline;
    if (i < trueLeft - leftTransitionWidth) baseline = outsideValue;
    else if (i < trueLeft) {
      const t = (i - (trueLeft - leftTransitionWidth)) / leftTransitionWidth;
      baseline = outsideValue + t * (insideValue - outsideValue);
    } else if (i <= trueRight) baseline = insideValue;
    else if (i <= trueRight + rightTransitionWidth) {
      const t = (i - trueRight) / rightTransitionWidth;
      baseline = insideValue + t * (outsideValue - insideValue);
    } else baseline = outsideValue;
    a[i] = baseline + (rng() - 0.5) * 2 * noiseStd;
  }
  return a;
}

windows.pve1 = buildSignal(0.55, 0.10, 0.03, 5, 6);
windows.band_continuity_score = buildSignal(0.40, 0.90, 0.04, 5, 6);
const ghsl_div_median = buildSignal(0.50, 0.10, 0.03, 5, 6);

M.state.data = {
  windows,
  ghsl_panel: { div_median: ghsl_div_median },
};
M.state.__boundaries = null;

// =============================================================================
// Run the pipeline
// =============================================================================
const cand = { id: 100, start_bp: 12000000, end_bp: 14000000 };
const scan = M._boundaryScanRange(cand, M.BOUNDARY_DEFAULTS.SCAN_RADIUS_BP, 30000000);
ok(scan !== null, 'scan range computed');
ok(scan.start_bp === 10500000 && scan.end_bp === 15500000,
   `scan span 10.5-15.5 Mb (got ${scan.start_bp}-${scan.end_bp})`);
ok(scan.win_lo === 525 && scan.win_hi === 774,
   `scan windows 525-774 (got ${scan.win_lo}-${scan.win_hi})`);

const ts = M._buildBoundaryTrackScores(cand, scan);
const presentTracks = Object.keys(ts.tracks);
console.log(`tracks present: ${presentTracks.join(', ')}`);
ok(presentTracks.includes('pca_drop'), 'pca_drop present');
ok(presentTracks.includes('band_continuity_drop'), 'band_continuity_drop present');
ok(presentTracks.includes('ghsl_step'), 'ghsl_step present');
ok(presentTracks.includes('het_transition'), 'het_transition present');

const edges = M._computeBoundaryEdges(ts, scan, M.BOUNDARY_TRACK_WEIGHTS, {});
ok(edges.left !== null, 'left edge detected');
ok(edges.right !== null, 'right edge detected');

const detL = edges.left.window_idx;
const detR = edges.right.window_idx;
console.log(`detected left:  ${detL} (true ${trueLeft}, off by ${detL - trueLeft})`);
console.log(`detected right: ${detR} (true ${trueRight}, off by ${detR - trueRight})`);
ok(Math.abs(detL - trueLeft)  <= 8, `left within +-8 of true`);
ok(Math.abs(detR - trueRight) <= 8, `right within +-8 of true`);

ok(edges.left.score  > 0, `left score > 0 (${edges.left.score.toFixed(4)})`);
ok(edges.right.score > 0, `right score > 0 (${edges.right.score.toFixed(4)})`);
ok(edges.left.support.length  >= 3, `left support >= 3 tracks (${edges.left.support.length}: ${edges.left.support.join(',')})`);
ok(edges.right.support.length >= 3, `right support >= 3 tracks (${edges.right.support.length}: ${edges.right.support.join(',')})`);

const recL = M._buildBoundaryRecord(edges.left,  'left',  'auto', { sv_anchors: [] });
const recR = M._buildBoundaryRecord(edges.right, 'right', 'auto', { sv_anchors: [] });
ok(recL && recR, 'records built');

const trueLeftBp  = windows.start_bp[trueLeft];
const trueRightBp = windows.start_bp[trueRight];
console.log(`left zone:  [${recL.zone_start_bp}..${recL.zone_end_bp}]  true edge ${trueLeftBp}`);
console.log(`right zone: [${recR.zone_start_bp}..${recR.zone_end_bp}]  true edge ${trueRightBp}`);
ok(recL.zone_start_bp <= trueLeftBp && recL.zone_end_bp >= trueLeftBp,
   'left zone brackets true left edge');
ok(recR.zone_start_bp <= trueRightBp && recR.zone_end_bp >= trueRightBp,
   'right zone brackets true right edge');

console.log(`left support_class:  ${recL.support_class}`);
console.log(`right support_class: ${recR.support_class}`);
ok(['strong', 'moderate'].includes(recL.support_class),
   `left support_class is strong or moderate (got ${recL.support_class})`);
ok(['strong', 'moderate'].includes(recR.support_class),
   `right support_class is strong or moderate (got ${recR.support_class})`);

ok(recL.source === 'auto' && recL.set_by === 'scrubber_auto', 'left record source=auto');
ok(recR.source === 'auto' && recR.set_by === 'scrubber_auto', 'right record source=auto');

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
