// v3.96 tests: hover tooltips on dosage heatmap cells
//
// What v3.96 adds:
//   - State extension: hover_static, hover_cursor on state.__dosageHm,
//     each shaped { last_cell: null, raf_handle: null }
//   - Pure helpers:
//       _heatmapHitTest(layout, mx, my, sample_order, selected_marker_indices)
//         → { marker_idx, sample_idx, col, row } | null
//       _heatmapTooltipText(hit, ctx) → string ('' on no hit)
//       _fmtBp(n) → "12,018,473"
//   - DOM-touching plumbing (not unit-tested, covered by manual validation):
//       _ensureHeatmapTooltipSlot(canvas) → div  (idempotent)
//       _positionDhTooltip(slot, canvas, mx, my)
//       _wireHeatmapHover(canvas, opts) (idempotent via __dh_hover_off)
//       _resetDhHoverState(hoverState, slot)
//   - Render-context stash on canvas: __dh_render_ctx after a successful
//     drawDosageHeatmap (set inside renderDosageHeatmap)
//   - Wire-in points: _redrawCandidateHeatmap + redrawCursorHeatmap call
//     _wireHeatmapHover after each successful render
//   - CSS: .dh-canvas-wrap { position: relative }, .dh-tooltip { ... }
//   - SCRUBBER_VERSION → 'v3.96'
//
// TESTS (10)
//   1. SCRUBBER_VERSION is v3.96+
//   2. _heatmapHitTest maps in-bounds px → cell indices correctly
//   3. _heatmapHitTest returns null outside matrix on all four sides
//   4. _heatmapHitTest returns null when col/row out of selection bounds
//   5. _heatmapTooltipText builds full string with all fields
//   6. _heatmapTooltipText omits each optional segment cleanly
//   7. _heatmapTooltipText formats NA dosage as 'dosage=NA'
//   8. _fmtBp formats with thousands separators
//   9. CSS: .dh-canvas-wrap position:relative + .dh-tooltip pointer-events:none
//  10. State extension: hover_static + hover_cursor with right shape
//      + render-context stash logic present in source

const fs = require('fs');
const html = fs.readFileSync('/home/claude/v3/pca_scrubber_v3.html', 'utf8');
const m = html.match(/<script>([\s\S]+?)<\/script>/);
let js = m[1];

const shim = `
const _byId = new Map();
function _makeEl(tag) {
  const _ownC = new Set();
  const ctxStub = {
    setTransform:()=>{}, clearRect:()=>{}, fillRect:()=>{},
    strokeRect:()=>{}, beginPath:()=>{}, moveTo:()=>{}, lineTo:()=>{}, stroke:()=>{},
    fill:()=>{}, fillText:()=>{}, save:()=>{}, restore:()=>{},
    translate:()=>{}, rotate:()=>{}, setLineDash:()=>{},
    measureText:(s)=>({ width: ((s && s.length) || 0) * 5 }),
    createLinearGradient: () => ({ addColorStop: () => {} }),
    fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', textBaseline: '',
  };
  const el = {
    tagName: (tag||'').toUpperCase(), id: '', textContent: '', _innerHTML: '',
    disabled: false, value: '', placeholder: '', title: '', checked: false,
    width: 0, height: 0, offsetWidth: 100, offsetHeight: 20, clientWidth: 1000, clientHeight: 400,
    style: { cssText: '', display: '', width: '', height: '', visibility: '', left: '', top: '' },
    classList: { _c: _ownC, add(...a){a.forEach(x=>this._c.add(x));},
      remove(...a){a.forEach(x=>this._c.delete(x));},
      toggle(){}, contains(x){return this._c.has(x);} },
    dataset: {}, _children: [],
    appendChild(c){ this._children.push(c); return c; },
    addEventListener(){}, removeEventListener(){},
    querySelector(){return null;}, querySelectorAll: () => [],
    setAttribute(){}, getAttribute(){return null;}, removeAttribute(){},
    getBoundingClientRect: () => ({ left:0, top:0, width:1000, height:120, right:1000, bottom:120 }),
    contains: () => false,
    parentNode: null,
    parentElement: null,
    getContext: () => ctxStub,
  };
  Object.defineProperty(el, 'innerHTML', { get(){return this._innerHTML;}, set(v){this._innerHTML=String(v);} });
  Object.defineProperty(el, 'className', {
    get() { return [...this.classList._c].join(' '); },
    set(v) { this.classList._c.clear();
             String(v||'').split(/\\s+/).filter(Boolean).forEach(x => this.classList._c.add(x)); }
  });
  return el;
}
const _bodyEl = _makeEl('body');
const document = {
  documentElement: _makeEl('html'),
  querySelectorAll: () => [],
  querySelector: () => null,
  getElementById(id) { if (!_byId.has(id)) { const el = _makeEl('div'); el.id = id; _byId.set(id, el); } return _byId.get(id); },
  createElement: _makeEl, body: _bodyEl,
  addEventListener: () => {}, removeEventListener: () => {},
};
const window = { devicePixelRatio: 1, addEventListener: () => {}, innerWidth: 1024, innerHeight: 768 };
const localStorage = { setItem(){}, getItem(){return null;}, removeItem(){}, clear(){} };
const getComputedStyle = () => ({ getPropertyValue: () => '' });
const FileReader = function() {};
const Blob = function() {};
const URL = { createObjectURL: () => '', revokeObjectURL: () => {} };
const requestAnimationFrame = (fn) => { try { fn(); } catch (e) {} return 1; };
const cancelAnimationFrame = () => {};
const setTimeout = (fn) => { try { fn(); } catch (e) {} return 1; };
const clearTimeout = () => {};
const alert = () => {};
const confirm = () => true;
`;
js = `${shim}\n${js}\nmodule.exports = {
  state, _ensureDosageHmState,
  _heatmapHitTest, _heatmapTooltipText, _fmtBp,
  _ensureHeatmapTooltipSlot, _positionDhTooltip,
  _wireHeatmapHover, _resetDhHoverState,
};\n`;
fs.writeFileSync('/tmp/scrubber_test_v396.js', js);
delete require.cache[require.resolve('/tmp/scrubber_test_v396.js')];
const M = require('/tmp/scrubber_test_v396.js');

let totalPass = 0, totalFail = 0;
function check(label, ok, detail) {
  if (ok) { totalPass++; console.log(' ', 'PASS'); }
  else    { totalFail++; console.log(' ', 'FAIL', detail || ''); }
}

// =============================================================================
// TEST 1: SCRUBBER_VERSION is v3.96+
// =============================================================================
console.log('--- TEST 1: SCRUBBER_VERSION v3.96+ ---');
const t1 = /const SCRUBBER_VERSION = 'v3\.(9[6-9]|\d{3,})';/.test(html);
console.log('  v3.96+:', t1);
check('test1', t1);

// =============================================================================
// TEST 2: _heatmapHitTest maps in-bounds px to cell indices
// =============================================================================
// Synthetic layout: matrix at (70, 12), 200×100, cells 10×5.
// Selection [10, 20, 30, 40, 50] (5 markers; col index 0..4).
// Sample order [3, 1, 4, 2, 0] (5 samples; row index 0..4 → samples
// 3, 1, 4, 2, 0 in display order).
console.log('\n--- TEST 2: _heatmapHitTest maps in-bounds px ---');
const layout = { matX: 70, matY: 12, matW: 200, matH: 100, cellW: 10, cellH: 5,
                 LEFT: 70, TOP: 12 };
const sel = [10, 20, 30, 40, 50];
const order = [3, 1, 4, 2, 0];

// Point (75, 17) → col 0 (75-70=5, /10=0), row 1 (17-12=5, /5=1)
//   → marker_idx = sel[0] = 10, sample_idx = order[1] = 1
const h2a = M._heatmapHitTest(layout, 75, 17, order, sel);
const t2a = h2a && h2a.col === 0 && h2a.row === 1
  && h2a.marker_idx === 10 && h2a.sample_idx === 1;
console.log('  (75,17) → col=0 row=1 marker=10 sample=1:', t2a, JSON.stringify(h2a));

// Point (88, 33) → col 1 (88-70=18, /10=1), row 4 (33-12=21, /5=4)
//   → marker_idx = sel[1] = 20, sample_idx = order[4] = 0
const h2b = M._heatmapHitTest(layout, 88, 33, order, sel);
const t2b = h2b && h2b.col === 1 && h2b.row === 4
  && h2b.marker_idx === 20 && h2b.sample_idx === 0;
console.log('  (88,33) → col=1 row=4 marker=20 sample=0:', t2b, JSON.stringify(h2b));

check('test2', t2a && t2b);

// =============================================================================
// TEST 3: _heatmapHitTest returns null outside matrix on all four sides
// =============================================================================
console.log('\n--- TEST 3: _heatmapHitTest out-of-matrix bounds ---');
// Matrix is [70..270, 12..112)
const t3a = M._heatmapHitTest(layout, 50, 50, order, sel) === null;   // left of matX
const t3b = M._heatmapHitTest(layout, 280, 50, order, sel) === null;  // right of matX+matW
const t3c = M._heatmapHitTest(layout, 100, 5, order, sel) === null;   // above matY
const t3d = M._heatmapHitTest(layout, 100, 120, order, sel) === null; // below matY+matH
// Also: null layout
const t3e = M._heatmapHitTest(null, 100, 50, order, sel) === null;
console.log('  left of matX → null:', t3a);
console.log('  right of matX+matW → null:', t3b);
console.log('  above matY → null:', t3c);
console.log('  below matY+matH → null:', t3d);
console.log('  null layout → null:', t3e);
check('test3', t3a && t3b && t3c && t3d && t3e);

// =============================================================================
// TEST 4: _heatmapHitTest returns null when col/row out of selection bounds
// =============================================================================
console.log('\n--- TEST 4: _heatmapHitTest selection-bounds guard ---');
// Selection has only 3 entries; layout cellW/H allow up to 20 cols & 20 rows.
const shortSel = [10, 20, 30];
const shortOrder = [0, 1, 2];
// Point (170, 50): col = (170-70)/10 = 10 → exceeds shortSel.length=3
const h4a = M._heatmapHitTest(layout, 170, 50, shortOrder, shortSel);
const t4a = h4a === null;
// Point (75, 50): col=0, row = (50-12)/5 = 7 → exceeds shortOrder.length=3
const h4b = M._heatmapHitTest(layout, 75, 50, shortOrder, shortSel);
const t4b = h4b === null;
// Bad inputs: non-array selection
const t4c = M._heatmapHitTest(layout, 75, 17, shortOrder, null) === null;
const t4d = M._heatmapHitTest(layout, 75, 17, null, shortSel) === null;
// Zero-size cells → guard
const t4e = M._heatmapHitTest({...layout, cellW: 0}, 75, 17, shortOrder, shortSel) === null;
console.log('  col >= sel.length → null:', t4a);
console.log('  row >= order.length → null:', t4b);
console.log('  null selection → null:', t4c);
console.log('  null order → null:', t4d);
console.log('  cellW=0 → null:', t4e);
check('test4', t4a && t4b && t4c && t4d && t4e);

// =============================================================================
// TEST 5: _heatmapTooltipText with full data
// =============================================================================
// Schema 2.7 example string:
//   CGA037 · M0124 (12,018,473 bp) · dosage=1 · HOMO_1 · core
console.log('\n--- TEST 5: _heatmapTooltipText full data ---');
const fakeChunk = {
  samples: ['CGA001', 'CGA037', 'CGA042'],
  markers: [
    { marker_id: 'M0001', pos_bp: 11000000, missingness: 0.05 },
    { marker_id: 'M0124', pos_bp: 12018473, missingness: 0.03 },
    { marker_id: 'M0200', pos_bp: 13500000, missingness: 0.04 },
  ],
  // Hit: marker_idx=1 (M0124), sample_idx=1 (CGA037) → dosage row 1, col 1
  dosage: [
    [0, 0, 1],
    [2, 1, 0],   // CGA037's value at M0124 is 1
    [0, 0, 0],
  ],
};
const fakeLk = {
  _groupOfSample: (si) => ['HOMO_1', 'HOMO_1', 'HET'][si],
  _qualityOfSample: (si) => ['core', 'core', 'peripheral'][si],
};
const fakePolarity = (col) => col === 1;   // marker_idx=1 (col 1 in selection) → flipped
const ctx5 = {
  chunk: fakeChunk,
  lk: fakeLk,
  polarity: fakePolarity,
  selected_marker_indices: [0, 1, 2],
};
const hit5 = { marker_idx: 1, sample_idx: 1, col: 1, row: 1 };
const text5 = M._heatmapTooltipText(hit5, ctx5);
console.log('  text:', JSON.stringify(text5));
const t5a = text5.includes('CGA037');
const t5b = text5.includes('M0124');
const t5c = text5.includes('12,018,473 bp');
const t5d = text5.includes('dosage=1');
const t5e = text5.includes('HOMO_1');
const t5f = text5.includes('core');
const t5g = text5.includes('flipped');
// Components separated by ' · '
const t5h = text5.split(' · ').length === 6;
console.log('  has CGA037:', t5a);
console.log('  has M0124:', t5b);
console.log('  has 12,018,473 bp:', t5c);
console.log('  has dosage=1:', t5d);
console.log('  has HOMO_1:', t5e);
console.log('  has core:', t5f);
console.log('  has flipped:', t5g);
console.log('  6 components separated by " · ":', t5h);
check('test5', t5a && t5b && t5c && t5d && t5e && t5f && t5g && t5h);

// =============================================================================
// TEST 6: _heatmapTooltipText omits each optional segment cleanly
// =============================================================================
console.log('\n--- TEST 6: _heatmapTooltipText optional-field omission ---');
// Group absent
const ctx6a = {
  chunk: fakeChunk,
  lk: { _groupOfSample: () => null,
        _qualityOfSample: () => 'unknown' },   // unknown also omitted
  polarity: () => false,                        // false also omitted
  selected_marker_indices: [0, 1, 2],
};
const text6a = M._heatmapTooltipText(hit5, ctx6a);
console.log('  group=null + quality=unknown + polarity=false:', JSON.stringify(text6a));
// Should have only 3 components: sample, marker(bp), dosage
const t6a = text6a.split(' · ').length === 3;
const t6b = !text6a.includes('null') && !text6a.includes('undefined');
const t6c = !text6a.includes('unknown');
const t6d = !text6a.includes('flipped');

// No lk at all
const ctx6e = { chunk: fakeChunk, lk: null, polarity: null,
                selected_marker_indices: [0, 1, 2] };
const text6e = M._heatmapTooltipText(hit5, ctx6e);
console.log('  no lk, no polarity:', JSON.stringify(text6e));
const t6e = text6e.split(' · ').length === 3;

// Empty hit → empty string
const t6f = M._heatmapTooltipText(null, ctx5) === '';
const t6g = M._heatmapTooltipText(hit5, null) === '';

// Marker without marker_id → fallback to pos<bp>
const fakeChunkNoIds = {
  samples: ['S0', 'S1', 'S2'],
  markers: [{ pos_bp: 1234567 }],
  dosage: [[0, 1, 2]],
};
const text6h = M._heatmapTooltipText(
  { marker_idx: 0, sample_idx: 1, col: 0, row: 0 },
  { chunk: fakeChunkNoIds, lk: null, polarity: null,
    selected_marker_indices: [0] });
console.log('  no marker_id → pos<bp> fallback:', JSON.stringify(text6h));
const t6h = text6h.includes('pos1234567') && text6h.includes('1,234,567 bp');

console.log('  3 components only:', t6a);
console.log('  no "null"/"undefined":', t6b);
console.log('  no "unknown":', t6c);
console.log('  no "flipped":', t6d);
console.log('  no lk → 3 components:', t6e);
console.log('  null hit → "":', t6f);
console.log('  null ctx → "":', t6g);
console.log('  no marker_id → pos<bp> fallback:', t6h);
check('test6', t6a && t6b && t6c && t6d && t6e && t6f && t6g && t6h);

// =============================================================================
// TEST 7: _heatmapTooltipText formats NA dosage as 'dosage=NA'
// =============================================================================
console.log('\n--- TEST 7: _heatmapTooltipText NA dosage ---');
const fakeChunkNa = {
  samples: ['S0', 'S1'],
  markers: [{ marker_id: 'M0', pos_bp: 100 }],
  dosage: [[0, -1]],   // S1 is NA at M0
};
const ctx7 = { chunk: fakeChunkNa, lk: null, polarity: null,
               selected_marker_indices: [0] };
const text7 = M._heatmapTooltipText(
  { marker_idx: 0, sample_idx: 1, col: 0, row: 0 }, ctx7);
console.log('  NA cell text:', JSON.stringify(text7));
const t7a = text7.includes('dosage=NA');
const t7b = !text7.includes('-1');   // sentinel hidden
check('test7', t7a && t7b);

// =============================================================================
// TEST 8: _fmtBp formats with thousands separators
// =============================================================================
console.log('\n--- TEST 8: _fmtBp formatting ---');
const t8a = M._fmtBp(12018473) === '12,018,473';
const t8b = M._fmtBp(0) === '0';
const t8c = M._fmtBp(999) === '999';
const t8d = M._fmtBp(null) === '?';
const t8e = M._fmtBp(undefined) === '?';
const t8f = M._fmtBp(NaN) === '?';
console.log('  12018473 → "12,018,473":', t8a, JSON.stringify(M._fmtBp(12018473)));
console.log('  0 → "0":', t8b);
console.log('  999 → "999":', t8c);
console.log('  null → "?":', t8d);
console.log('  undefined → "?":', t8e);
console.log('  NaN → "?":', t8f);
check('test8', t8a && t8b && t8c && t8d && t8e && t8f);

// =============================================================================
// TEST 9: CSS — .dh-canvas-wrap position:relative + .dh-tooltip pointer-events:none
// =============================================================================
console.log('\n--- TEST 9: CSS additions ---');
const t9a = /\.dh-canvas-wrap\s*\{[^}]*position:\s*relative/.test(html);
const t9b = /\.dh-tooltip\s*\{[^}]*pointer-events:\s*none/.test(html);
const t9c = /\.dh-tooltip\s*\{[^}]*display:\s*none/.test(html);
const t9d = /\.dh-tooltip\s*\{[^}]*z-index:\s*\d+/.test(html);
console.log('  .dh-canvas-wrap position:relative:', t9a);
console.log('  .dh-tooltip pointer-events:none:', t9b);
console.log('  .dh-tooltip display:none:', t9c);
console.log('  .dh-tooltip has z-index:', t9d);
check('test9', t9a && t9b && t9c && t9d);

// =============================================================================
// TEST 10: state extension + render-context wiring
// =============================================================================
console.log('\n--- TEST 10: state.__dosageHm hover_static + hover_cursor ---');
M.state.__dosageHm = null;   // reset
const hm = M._ensureDosageHmState();
const t10a = hm.hover_static && hm.hover_static.last_cell === null
  && hm.hover_static.raf_handle === null;
const t10b = hm.hover_cursor && hm.hover_cursor.last_cell === null
  && hm.hover_cursor.raf_handle === null;
// Idempotent — second call keeps the same instances (so state survives redraws)
const hm2 = M._ensureDosageHmState();
const t10c = hm.hover_static === hm2.hover_static
  && hm.hover_cursor === hm2.hover_cursor;
console.log('  hover_static shape:', t10a);
console.log('  hover_cursor shape:', t10b);
console.log('  state idempotent:', t10c);

// Source-grep: render-context stash + wire-in calls
const t10d = /canvas\.__dh_render_ctx\s*=\s*\{[\s\S]{0,400}layout/.test(html);
const t10e = /_wireHeatmapHover\s*\(\s*canvas\s*,/.test(html);
const t10f = /_resetDhHoverState\s*\(/.test(html);
const t10g = /_ensureHeatmapTooltipSlot\s*\(/.test(html);
console.log('  __dh_render_ctx stash present:', t10d);
console.log('  _wireHeatmapHover called from redraw paths:', t10e);
console.log('  _resetDhHoverState called pre-redraw:', t10f);
console.log('  _ensureHeatmapTooltipSlot called from wire-in:', t10g);
check('test10', t10a && t10b && t10c && t10d && t10e && t10f && t10g);

// =============================================================================
// SUMMARY
// =============================================================================
console.log(`\n--- v3.96 tests: ${totalPass}/${totalPass + totalFail} ---`);
if (totalFail > 0) process.exit(1);
