# Handoff — scrubber v3.97 turn 3 + v3.97 sequence close (2026-04-28)

## Where we are

**Current head:** `pca_scrubber_v3.html` v3.97 (1051 KB, 23,130 lines).
**SCHEMA:** `SCHEMA_V2.md` v2.8 (94 KB, 2,026 lines).
**Tests:** 576/576 passing (54 + 522 carried forward).
**End-to-end checks:** 77 across three scripts.

This handoff covers v3.97 turn 3 — TSV column emission for the 14 new
boundary fields. It also closes out the v3.97 sequence: turn 1 (helpers)
+ turn 2 (page UI) + turn 3 (TSV export) is the complete shipping unit
the user requested.

Prior:
- v3.97 turn 1 in `HANDOFF_v3_97_turn1.md`
- v3.97 turn 2 in `HANDOFF_v3_97_turn2.md`
- Schema 2.8 §12 in `SCHEMA_V2.md`

## Work shipped this chat (v3.97 turn 3)

### `REGISTRY_TSV_COLUMNS` extended to 45 columns

Pre-v3.97 width was 31 columns; v3.97 adds 14 (between `n_k6_pure` and
`qc_status`):

```
left_boundary_zone_start, left_boundary_zone_end,
left_boundary_score, left_boundary_support,
left_boundary_support_class, left_boundary_source,
right_boundary_zone_start, right_boundary_zone_end,
right_boundary_score, right_boundary_support,
right_boundary_support_class, right_boundary_source,
breakpoint_status, boundary_notes,
```

Total: **45 columns**. Schema 2.8 §12 had a stale "30 → 44" count;
corrected to "31 → 45" in this chat.

### `_boundaryColsFromCand(c)` helper

Returns an object with 14 string-typed fields, keyed by the column
names. Contract:

| Aspect | Behavior |
|---|---|
| Missing values | `''` (empty string), NOT `'NA'` — header-driven parsers don't break |
| `score` formatting | 4 decimal places (`0.78` → `'0.7800'`) |
| `support` formatting | Pipe-separated (`['pca_drop','ghsl_step']` → `'pca_drop|ghsl_step'`) |
| `support_class` | Lowercase string (`'strong'`, `'moderate'`, `'weak'`, `'ambiguous'`) or `''` |
| `source` | Lowercase string (`'auto'`, `'manual'`, `'auto_plus_manual'`) or `''` |
| `breakpoint_status` | `'boundary_zone_only'` / `'SV_supported'` / `'junction_supported'` / `''` (empty when never annotated) |
| `boundary_notes` | Tabs and newlines stripped (`\t` → space, `\n` → space) |

The contract: *if a candidate has never been visited in the boundaries
page, ALL 14 fields emit as `''`*. Specifically `breakpoint_status` is
`''`, NOT `'boundary_zone_only'` — emitting the latter would falsely
imply the candidate has been reviewed.

### Row-builder integration

The 14 fields spread into the row object via `..._boundaryColsFromCand(c)`,
placed between `n_k6_pure` and `qc_status` to match the column order.
Single-line change:

```js
const row = {
  // ... existing fields ...
  subband_nesting_status: subbandStatus,
  n_k6_groups: nK6Groups,
  n_k6_pure: nK6Pure,
  // v3.97: 14 boundary fields
  ..._boundaryColsFromCand(c),
  qc_status: c.qc_status || 'accepted',
  // ... existing fields ...
};
```

### Tests (5 new in `test_v397t3.js`)

1. `SCRUBBER_VERSION` v3.97+
2. `REGISTRY_TSV_COLUMNS` is 45 columns (was 31); 14 new columns present;
   ordering: between `n_k6_pure` and `qc_status`; 14-column block contiguous
3. `_boundaryColsFromCand` on populated candidate: 4dp score, pipe-
   separated support, breakpoint_status passes through (8 sub-cases)
4. `_boundaryColsFromCand` on unannotated candidate: all 14 fields `''`,
   no `'NA'` strings; half-populated case (only left set); tab/newline
   sanitization in notes (5 sub-cases)
5. End-to-end TSV row: populated cand emits all fields in correct
   columns at correct indices; unannotated cand emits 14 empty strings;
   TSV line has 45 tab-separated fields (9 sub-cases)

All 49 prior + 5 new tests pass: **54/54** in turn 1+2+3; total **576**
across all suites.

### End-to-end TSV roundtrip (`end_to_end_tsv_roundtrip.js`)

26 checks across 6 phases simulating the full export path that
downstream R will see:

1. Build TSV rows for two candidates (one with boundaries, one without)
2. Emit as TSV string + parse back; verify 45-field shape
3. Annotated candidate: 12 cells correctly populated (zone bp coords,
   score 4dp, support pipe-separated, support_class, source,
   breakpoint_status, boundary_notes)
4. Unannotated candidate: 14 cells all `''`
5. Existing fields (`candidate_id`, `chrom`, `K`, `qc_status`,
   `scrubber_version`, `span_mb`) unaffected by v3.97
6. Column ORDER positional check: `left_boundary_zone_start` immediately
   follows `n_k6_pure`; `qc_status` immediately follows `boundary_notes`;
   the 14-column block has exactly 13 internal gaps (i.e., contiguous)

All 26 checks pass.

## Notable design decisions

- **Spread-integration over hand-listed assignments.** Using
  `..._boundaryColsFromCand(c)` keeps the row builder readable and
  ensures the 14 fields stay synchronized with the helper's output. If
  the helper adds a field later, the row builder gets it for free
  (provided the column name is added to `REGISTRY_TSV_COLUMNS`).
- **Empty string `''` not `'NA'`.** The schema 2.8 §12 contract is
  explicit. Existing v3.93 fields use `'NA'`; v3.97 fields use `''`.
  This is a deliberate inconsistency — header-driven parsers (R's
  `readr::read_tsv` with `na = ''`) handle the new convention cleanly,
  while legacy `na = 'NA'` parsers still work for the older fields.
- **`breakpoint_status = ''` for unannotated candidates.** The schema
  default value is `'boundary_zone_only'` for the *staging* state in
  the page UI, but the *persisted* state on a candidate that's never
  been visited stays `''`. Emitting `'boundary_zone_only'` for
  un-reviewed candidates would mislead downstream R into thinking
  every promoted candidate has been reviewed.
- **`scrubber_version` reflects the version used for emission.** Since
  the field reads `SCRUBBER_VERSION` directly, every TSV exported by
  v3.97 will show `v3.97` as its scrubber_version — useful for tracking
  which scrubber version produced a given file in downstream analysis.

## v3.97 sequence summary

The complete v3.97 boundary-zone refinement module has shipped across
three turns:

| Turn | Scope | LOC delta | Tests | E2E checks |
|---|---|---|---|---|
| **Turn 1** | Pure helpers + state extension | +617 | 10 | 22 |
| **Turn 2** | Page DOM + tracks + hotkeys + actions | +1,175 | 10 | 29 |
| **Turn 3** | TSV column emission | +93 | 5 | 26 |
| **Total** | Full module | **+1,885** | **25** | **77** |

The module is feature-complete for v3.97. What ships:

- Schema 2.8 §12 contract (terminology, fields, algorithm, tracks enum,
  weights, polarity, color palette)
- 11 pure helpers (turn 1) for scoring + zone construction + record building
- 17 page-UI functions (turn 2) for selection + auto-propose + manual
  override + save + reset + status promotion
- 14 TSV columns (turn 3) for downstream consumption
- Page-scoped E/F/B/R/A hotkeys
- Per-track polarity convention (added during turn 1) for falling-inside tracks
- Algorithm correction (added during turn 1) — smooth-then-step, not step-then-smooth

What's deferred:

- **R-side `STEP_M06_emit_boundary_evidence.R`** — emits the optional
  `boundary_evidence` layer (FST + theta-pi + discordant-pair + SV
  anchors). Schema-defined; R-emission unwritten. Turn 1's
  `_buildBoundaryTrackScores` already detects the layer and consumes
  the four optional tracks when loaded; the R script just needs to ship.
- **Save-changes prompt on page leave** — staging.dirty is visible
  in the UI (Save button border), but no modal prompt yet.
- **Cursor line live update** — currently the cursor track marker only
  refreshes on tab revisit, not on `state.cur` change.
- **Per-edge zone radius slider** — fixed at ±5 windows.
- **Boundary history sibling array** — would let users see "what auto
  would have proposed if I hadn't manually overridden".
- **`exact_breakpoint_bp` field** — when junction-level evidence ships
  (split reads, assembly junctions), the schema upgrades the
  breakpoint_status to `junction_supported` and an additional bp field
  appears. Not relevant until that pipeline exists.

## File staging at /mnt/user-data/outputs/

- **pca_scrubber_v3.html** — v3.97, 1051 KB, 23,130 lines
- **SCHEMA_V2.md** — v2.8 (count corrected: 31→45), 94 KB, 2,026 lines
- **test_v397t3.js** — 5 new tests, ~390 lines
- **end_to_end_tsv_roundtrip.js** — TSV emit/parse roundtrip, 26 checks
- **HANDOFF_v3_97_turn3.md** — this file

## Suggested entry point for next chat

**Real-data validation on the 226-sample LG28 cohort.** v3.97 is
feature-complete; the next valuable step is exercising it on actual
data:

1. Drop the v3.95 R-side outputs (STEP_M04 dosage chunks +
   STEP_M05 coherence/polarity layers) into the scrubber
2. Open page 3 (boundaries) and try auto-propose on a real LG28
   candidate
3. Visual check: do the proposed zones land on biologically-sensible
   transitions? Do the support_class colors feel calibrated against
   real signal vs noise?
4. Tuning questions:
   - Are the default weights (0.20 PCA / 0.18 dosage / 0.14
     band_continuity / 0.12 GHSL / 0.10 polarity) producing the right
     balance?
   - Is the `support_class` threshold (n>=3 AND s>=0.60 → strong) too
     strict or too lenient for real cohort data?
   - Does the ±5 window zone radius feel right or should it be tunable?
5. Catalogue page (page 4) should now show populated boundary columns
   when LG28 candidates have been refined. Verify TSV export contains
   the 14 new columns in the right places.

These tuning questions only become legible on real data — synthetic
inputs always produce clean, saturating signals.

**Alternative entry points:**

- `STEP_M06_emit_boundary_evidence.R` — R-side emit of the optional
  layer. Adds FST + theta-pi + discordant-pair + SV anchor tracks;
  improves auto-propose precision when present. Schema is locked; the
  R emit is just transcription work.
- v3.98 unrelated work — band-confounder reviewer fix (parked from
  v3.93 review notes), or new K=6 popstats integration.

## Tally summary across the v3.97 sequence

```
TURN 1 (boundary helpers + state)       +617 LOC, 10 unit tests, 22 e2e checks
TURN 2 (page UI + tracks + hotkeys)     +1175 LOC, 10 unit tests, 29 e2e checks
TURN 3 (TSV column emission)            +93 LOC,   5 unit tests, 26 e2e checks
                                        ----------------------
                                        +1885 LOC, 25 tests,    77 e2e checks
```

All 25 v3.97 unit tests pass. All 77 e2e checks pass. All 522
carried-forward tests still pass. **576/576 total.**

## User working style notes

(Unchanged.)

"Continue" = proceed with next agreed item. This chat shipped v3.97
turn 3 and closed the v3.97 sequence. Real-data validation is the
natural next step.

Three catfish cohorts that must NEVER be conflated:
1. F1 hybrid (*C. gariepinus* × *C. macrocephalus*) — genome assembly
   paper only
2. 226-sample pure *C. gariepinus* hatchery cohort — current inversion
   work, "MS_Inversions_North_african_catfish" — K clusters reflect
   broodline structure, NOT species admixture
3. Pure *C. macrocephalus* wild cohort — future paper

User's full name is Quentin Andres. Never invent a surname.
