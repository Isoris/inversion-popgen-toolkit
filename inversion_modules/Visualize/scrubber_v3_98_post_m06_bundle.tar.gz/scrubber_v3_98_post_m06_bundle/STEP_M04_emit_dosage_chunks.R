#!/usr/bin/env Rscript

# =============================================================================
# STEP_M04_emit_dosage_chunks.R
#
# Phase M (Marker / dosage heatmap) emit script. Reads the per-chromosome
# dosage matrix and the L1 window registry, and writes:
#
#   1. ONE chunk-INDEX JSON per chromosome that the scrubber loads as an
#      enrichment layer to register all available chunk URLs:
#
#        <out_dir>/<chrom>/<chrom>_dosage_chunks_index.json
#
#      Index shape (matches the v3.94 scrubber's `dosage_chunks` layer
#      detection — { chrom, chunks: [{ start_bp, end_bp, url }, ...] }):
#
#        {
#          "schema_version": 2,
#          "_layers_present": ["dosage_chunks"],
#          "dosage_chunks": {
#            "chrom": "C_gar_LG28",
#            "n_chunks": 17,
#            "n_samples": 226,
#            "samples": ["CGA001", ...],          # cohort order
#            "chunks": [
#              { "start_bp": 0, "end_bp": 5000000,
#                "url": "C_gar_LG28/C_gar_LG28_dosage_chunk_0_5000000.json",
#                "n_markers": 412 },
#              ...
#            ]
#          },
#          "_generated_at": "...",
#          "_generator": "STEP_M04_emit_dosage_chunks.R"
#        }
#
#   2. ONE chunk-CONTENT JSON per region (typically tens per chromosome):
#
#        <out_dir>/<chrom>/<chrom>_dosage_chunk_<start_bp>_<end_bp>.json
#
#      Content shape (matches SCHEMA_V2 §10 "Dosage chunk file shape"):
#
#        {
#          "chrom": "C_gar_LG28",
#          "region_start_bp": 12000000,
#          "region_end_bp":   14000000,
#          "n_markers": 412,
#          "n_samples": 226,
#          "samples":  ["CGA001", ...],
#          "markers":  [
#            { "marker_id": "M0001", "pos_bp": 12018473,
#              "diagnostic_score": 0.92, "missingness": 0.04 },
#            ...
#          ],
#          "dosage":   [ [0, 1, 2, -1, ...], ... ]   # n_markers × n_samples
#        }
#
# CHUNK-BOUNDARY ALIGNMENT
# ------------------------
# Chunks are aligned to L1 window boundaries (the same windows that drive the
# scrubber's natural windowing — defined by the chr_meta TSV produced by
# STEP09b/STEP_A03). Each chunk covers an integer number of contiguous L1
# windows. This guarantees that:
#   - any cursor region (state.cur ± 5 windows) always falls within a single
#     chunk in the typical case, OR straddles at most two chunks (which the
#     scrubber's overlap-fallback in `_findCoveringChunk` already handles);
#   - chunk boundaries do not split a marker — pos_bp ranges are closed at
#     L1 window edges.
#
# Default target chunk size is 200 L1 windows ≈ 2-4 Mb at typical
# winsize=100 / step=20 settings, giving ~10-15 chunks for a 30 Mb LG and
# keeping each JSON in the 5-30 MB range for 226 samples × ~10k markers / Mb.
# Tunable via --windows_per_chunk.
#
# DIAGNOSTIC SCORE
# ----------------
# `marker_catalogue.tsv` is the canonical source of `diagnostic_score`
# (planned phase-13 marker module output, schema §10). When passed via
# --marker_catalogue, scores are joined per-marker and emitted directly.
# When absent, the scrubber falls back to per-marker dosage variance
# computed at render time (see selectTopMarkers in pca_scrubber_v3.html);
# we DO NOT pre-compute variance here to keep this emit faithful to the
# scrubber's contract — the "all-or-nothing diagnostic_score column" rule
# (selectTopMarkers line 4934) requires that if we emit ds, we emit it on
# every marker, which we can't guarantee from a partial catalogue.
#
# MISSINGNESS
# -----------
# Computed per marker as the fraction of NA dosage cells across the cohort,
# rounded to 4 decimals. The scrubber drops markers above MISSING_THRESHOLD
# (0.20 default) at render time.
#
# DOSAGE ENCODING
# ---------------
# Cells are integer 0/1/2 for HOMO_REF/HET/HOMO_ALT. NA encoded as -1
# (matches the scrubber's `chunk_get` and `selectTopMarkers` NA handling
# — line 4949 of pca_scrubber_v3.html).
#
# USAGE
# -----
#   Rscript STEP_M04_emit_dosage_chunks.R \
#     --dosage          /path/to/<chrom>.dos.tsv.gz \
#     --chr_meta        /path/to/<chrom>.chr_meta.tsv.gz \
#     --chrom           C_gar_LG28 \
#     --out_dir         /path/to/scrubber/data/ \
#     [--windows_per_chunk 200] \
#     [--marker_catalogue /path/to/<chrom>_candidate_marker_catalogue.tsv] \
#     [--samples           /path/to/sample_list.txt]   # cohort order, one per line
#     [--url_prefix        C_gar_LG28]                  # for chunk URLs
#     [--max_pos_per_chunk_bp NULL]                     # alt: bp-based chunking
#     [--keep_marker_id 1]
#
# OUTPUT LAYOUT
# -------------
#   <out_dir>/<chrom>/<chrom>_dosage_chunks_index.json
#   <out_dir>/<chrom>/<chrom>_dosage_chunk_<start_bp>_<end_bp>.json
#   <out_dir>/<chrom>/<chrom>_dosage_chunk_<start_bp>_<end_bp>.json
#   ...
# =============================================================================

suppressPackageStartupMessages({
  library(data.table)
  library(jsonlite)
})

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

# =============================================================================
# PARSE ARGS
# =============================================================================

usage <- function() {
  cat(paste(
    "Usage: Rscript STEP_M04_emit_dosage_chunks.R --dosage <dos.tsv.gz>",
    "                                              --chr_meta <chr_meta.tsv.gz>",
    "                                              --chrom <chr> --out_dir <dir>",
    "                                              [--windows_per_chunk 200]",
    "                                              [--marker_catalogue <tsv>]",
    "                                              [--samples <list.txt>]",
    "                                              [--url_prefix <chr>]",
    "                                              [--keep_marker_id 1]",
    "",
    "Required:",
    "  --dosage     Per-chromosome dosage TSV (one row per marker; first column",
    "               'marker' or 'pos', remaining columns are sample IDs).",
    "  --chr_meta   chr_meta.tsv.gz from STEP_A03 with start_bp/end_bp per L1",
    "               window. Used to align chunk boundaries.",
    "  --chrom      Chromosome name. Must match the chr_meta `chrom` column.",
    "  --out_dir    Output root. Writes <out_dir>/<chrom>/...",
    "",
    "Optional:",
    "  --windows_per_chunk N    Number of contiguous L1 windows per chunk.",
    "                           Default 200. Lower = more chunks, smaller files,",
    "                           more HTTP fetches; higher = fewer, larger.",
    "  --marker_catalogue F     If supplied, joins per-marker `diagnostic_score`",
    "                           by pos_bp (or marker_id if column present).",
    "                           Catalogue must cover ALL markers in the chrom",
    "                           or the column is dropped (all-or-nothing rule).",
    "  --samples F              Sample order file (one ID per line). Default:",
    "                           use the dosage file's column header order.",
    "  --url_prefix S           Path prefix prepended to chunk URLs in the",
    "                           index. Default: \"<chrom>/\". Set to \"\" if",
    "                           chunks are served from the same dir as index.",
    "  --keep_marker_id N       Emit `marker_id` field (1) or omit (0).",
    "                           Default 1. Set 0 to shrink JSON if catalogue",
    "                           join is by pos only.",
    sep = "\n"), "\n")
  quit(status = 1)
}

args <- commandArgs(trailingOnly = TRUE)

DOSAGE_F        <- NULL
CHR_META_F      <- NULL
CHROM           <- NULL
OUT_DIR         <- NULL
WIN_PER_CHUNK   <- 200L
CATALOGUE_F     <- NULL
SAMPLES_F       <- NULL
URL_PREFIX      <- NULL    # NULL = derive from chrom
KEEP_MARKER_ID  <- 1L

i <- 1L
while (i <= length(args)) {
  a <- args[i]
  if      (a == "--dosage"             && i < length(args)) { DOSAGE_F       <- args[i + 1]; i <- i + 2L }
  else if (a == "--chr_meta"           && i < length(args)) { CHR_META_F     <- args[i + 1]; i <- i + 2L }
  else if (a == "--chrom"              && i < length(args)) { CHROM          <- args[i + 1]; i <- i + 2L }
  else if (a == "--out_dir"            && i < length(args)) { OUT_DIR        <- args[i + 1]; i <- i + 2L }
  else if (a == "--windows_per_chunk"  && i < length(args)) { WIN_PER_CHUNK  <- as.integer(args[i + 1]); i <- i + 2L }
  else if (a == "--marker_catalogue"   && i < length(args)) { CATALOGUE_F    <- args[i + 1]; i <- i + 2L }
  else if (a == "--samples"            && i < length(args)) { SAMPLES_F      <- args[i + 1]; i <- i + 2L }
  else if (a == "--url_prefix"         && i < length(args)) { URL_PREFIX     <- args[i + 1]; i <- i + 2L }
  else if (a == "--keep_marker_id"     && i < length(args)) { KEEP_MARKER_ID <- as.integer(args[i + 1]); i <- i + 2L }
  else if (a == "-h" || a == "--help")                      { usage() }
  else { i <- i + 1L }
}

if (is.null(DOSAGE_F) || is.null(CHR_META_F) || is.null(CHROM) || is.null(OUT_DIR)) usage()
if (!file.exists(DOSAGE_F))   stop("Dosage file not found: ", DOSAGE_F)
if (!file.exists(CHR_META_F)) stop("chr_meta file not found: ", CHR_META_F)
if (WIN_PER_CHUNK < 1L)       stop("--windows_per_chunk must be >= 1")
if (is.null(URL_PREFIX))      URL_PREFIX <- paste0(CHROM, "/")

# =============================================================================
# LOAD CHR_META  (defines L1 boundaries we align chunks to)
# =============================================================================

cat("[M04_DOSAGE] Loading chr_meta: ", CHR_META_F, "\n", sep = "")
chr_meta <- fread(CHR_META_F)

required_meta <- c("chrom", "start_bp", "end_bp")
miss_meta <- setdiff(required_meta, names(chr_meta))
if (length(miss_meta) > 0) stop("chr_meta missing required cols: ", paste(miss_meta, collapse = ", "))

chr_meta <- chr_meta[chrom == CHROM]
if (nrow(chr_meta) == 0) {
  stop("chr_meta has zero rows for chrom='", CHROM,
       "'. Available chroms: ",
       paste(unique(fread(CHR_META_F)$chrom), collapse = ", "))
}

# Sort by start_bp; chr_meta SHOULD already be ordered but we don't assume
setorder(chr_meta, start_bp)

# A sanity-check: in the dense registry, consecutive windows overlap by
# (winsize - step) markers; their start_bp values are increasing but their
# bp ranges may overlap. We don't care about overlap for chunking — we
# carve chunk boundaries on consecutive non-overlapping unions of windows.
n_l1 <- nrow(chr_meta)
cat("[M04_DOSAGE]   L1 windows: ", n_l1, "\n", sep = "")
cat("[M04_DOSAGE]   chrom span: ", min(chr_meta$start_bp), " .. ",
    max(chr_meta$end_bp), " bp\n", sep = "")

# =============================================================================
# LOAD DOSAGE
# =============================================================================
# Expected columns: a 'marker' (or 'pos') column + one column per sample.
# Each row is one marker with 0/1/2/NA dosage values across samples.
# fread auto-detects gzip.

cat("[M04_DOSAGE] Loading dosage: ", DOSAGE_F, "\n", sep = "")
t_dos <- proc.time()[3]
dos <- fread(DOSAGE_F)
cat("[M04_DOSAGE]   loaded in ", round(proc.time()[3] - t_dos, 1),
    "s — ", nrow(dos), " markers × ", ncol(dos), " cols\n", sep = "")

# Detect the marker-id and pos columns
marker_col <- NULL
pos_col    <- NULL
for (c in c("marker_id", "marker", "id", "snp", "site")) {
  if (c %in% names(dos)) { marker_col <- c; break }
}
for (c in c("pos_bp", "pos", "position", "bp")) {
  if (c %in% names(dos)) { pos_col <- c; break }
}
if (is.null(marker_col) && is.null(pos_col)) {
  stop("Dosage file must have a marker-id column (marker_id/marker/id/snp/site) ",
       "OR a position column (pos_bp/pos/position/bp). Got: ",
       paste(names(dos)[1:min(10, ncol(dos))], collapse = ", "))
}

# If pos column is missing but marker column looks like "chrom_pos" or "chrom:pos",
# try to parse pos out
if (is.null(pos_col) && !is.null(marker_col)) {
  m_first <- as.character(dos[[marker_col]][1])
  parsed_pos <- suppressWarnings(as.integer(sub(".*[:_](\\d+).*$", "\\1", m_first)))
  if (!is.na(parsed_pos)) {
    cat("[M04_DOSAGE]   parsing pos from marker_id pattern (", m_first, " -> ", parsed_pos, ")\n", sep = "")
    dos[, pos_bp := suppressWarnings(as.integer(sub(".*[:_](\\d+).*$", "\\1", get(marker_col))))]
    pos_col <- "pos_bp"
  }
}

if (is.null(pos_col)) {
  stop("Could not determine bp position for markers — supply a pos column or use ",
       "marker_ids of form '<chrom>_<pos>' or '<chrom>:<pos>'.")
}

# Identify sample columns: every column except marker/pos meta
meta_cols <- c(marker_col, pos_col)
meta_cols <- meta_cols[!is.null(meta_cols)]
sample_cols <- setdiff(names(dos), meta_cols)

# If there's also a chrom column, drop it from sample_cols
sample_cols <- setdiff(sample_cols, c("chrom", "chr"))
n_samples_dos <- length(sample_cols)
cat("[M04_DOSAGE]   sample cols: ", n_samples_dos, "\n", sep = "")

if (n_samples_dos < 2) {
  stop("Could not detect sample columns. Found ", n_samples_dos,
       ". Check that dosage TSV has one column per sample.")
}

# Pos as integer
dos[, .__pos := as.integer(get(pos_col))]
if (any(is.na(dos$.__pos))) {
  n_bad <- sum(is.na(dos$.__pos))
  warning("Dropping ", n_bad, " markers with non-numeric pos")
  dos <- dos[!is.na(.__pos)]
}

# Sort markers by pos (must be sorted for boundary slicing to work)
setorder(dos, .__pos)

# =============================================================================
# RESOLVE SAMPLE ORDER
# =============================================================================
if (!is.null(SAMPLES_F)) {
  if (!file.exists(SAMPLES_F)) stop("samples file not found: ", SAMPLES_F)
  cohort_samples <- as.character(fread(SAMPLES_F, header = FALSE)[[1]])
  cohort_samples <- cohort_samples[nchar(cohort_samples) > 0]
  miss_in_dos <- setdiff(cohort_samples, sample_cols)
  if (length(miss_in_dos) > 0) {
    stop("Samples in --samples file not present in dosage columns: ",
         paste(head(miss_in_dos, 10), collapse = ", "),
         if (length(miss_in_dos) > 10) " (...)" else "")
  }
  cat("[M04_DOSAGE]   cohort sample order from --samples: ",
      length(cohort_samples), " ids\n", sep = "")
} else {
  cohort_samples <- sample_cols
  cat("[M04_DOSAGE]   cohort sample order from dosage header: ",
      length(cohort_samples), " ids\n", sep = "")
}
n_samples <- length(cohort_samples)

# Build the dosage matrix in cohort order (markers are rows, samples are cols)
# Keep this as integer to compress NA encoding cleanly.
dos_mat_dt <- dos[, ..cohort_samples]
# Coerce to integer matrix; ensure NA stays NA
dos_mat <- as.matrix(dos_mat_dt)
storage.mode(dos_mat) <- "integer"
# Sanity-check value range
val_range <- range(dos_mat, na.rm = TRUE)
if (val_range[1] < 0 || val_range[2] > 2) {
  warning(sprintf("[M04_DOSAGE] dosage values outside [0,2]: range=[%s,%s] — clamping NA outside-range cells",
                  val_range[1], val_range[2]))
  dos_mat[dos_mat < 0 | dos_mat > 2] <- NA_integer_
}

# Per-marker missingness — fraction of NA across cohort
missingness <- round(rowMeans(is.na(dos_mat)), 4)

n_markers_total <- nrow(dos_mat)
cat("[M04_DOSAGE]   total markers: ", n_markers_total,
    " — missingness median=", round(median(missingness), 4),
    "  max=", round(max(missingness), 4), "\n", sep = "")

# =============================================================================
# JOIN DIAGNOSTIC SCORE FROM CATALOGUE (optional, all-or-nothing)
# =============================================================================
# The scrubber's selectTopMarkers requires diagnostic_score on EVERY marker
# in a chunk OR none. So if the catalogue covers fewer than 100% of the
# chunk's markers, we drop the column for that chunk. Easiest safe behaviour:
# only emit ds if the catalogue covers >= 100% of all markers in the chrom.

diagnostic_score <- rep(NA_real_, n_markers_total)
joined_ds        <- FALSE

if (!is.null(CATALOGUE_F)) {
  if (!file.exists(CATALOGUE_F)) {
    warning("--marker_catalogue file not found, skipping ds join: ", CATALOGUE_F)
  } else {
    cat("[M04_DOSAGE] Loading marker_catalogue: ", CATALOGUE_F, "\n", sep = "")
    cat_dt <- fread(CATALOGUE_F)
    if (!"diagnostic_score" %in% names(cat_dt)) {
      warning("marker_catalogue has no diagnostic_score column; skipping ds join")
    } else {
      # Prefer marker_id join if available; else pos
      if (!is.null(marker_col) && marker_col %in% names(cat_dt)) {
        cat_lookup <- cat_dt[, .(.__key = get(marker_col),
                                  diagnostic_score = as.numeric(diagnostic_score))]
        marker_keys <- as.character(dos[[marker_col]])
        ds_vec <- cat_lookup$diagnostic_score[match(marker_keys, cat_lookup$.__key)]
        cat("[M04_DOSAGE]   joined ds by marker_id (", marker_col, ")\n", sep = "")
      } else if ("pos_bp" %in% names(cat_dt) || "pos" %in% names(cat_dt)) {
        cat_pos_col <- if ("pos_bp" %in% names(cat_dt)) "pos_bp" else "pos"
        cat_lookup <- cat_dt[, .(.__key = as.integer(get(cat_pos_col)),
                                  diagnostic_score = as.numeric(diagnostic_score))]
        ds_vec <- cat_lookup$diagnostic_score[match(dos$.__pos, cat_lookup$.__key)]
        cat("[M04_DOSAGE]   joined ds by pos (", cat_pos_col, ")\n", sep = "")
      } else {
        warning("marker_catalogue has neither marker_id nor pos column; skipping ds join")
        ds_vec <- NULL
      }
      if (!is.null(ds_vec)) {
        n_matched <- sum(!is.na(ds_vec))
        if (n_matched == n_markers_total) {
          diagnostic_score <- ds_vec
          joined_ds <- TRUE
          cat("[M04_DOSAGE]   ds covers all ", n_markers_total, " markers — emitting\n",
              sep = "")
        } else {
          cat("[M04_DOSAGE]   ds covers ", n_matched, "/", n_markers_total,
              " — INCOMPLETE — dropping ds (all-or-nothing rule)\n", sep = "")
        }
      }
    }
  }
}

# =============================================================================
# CARVE CHUNK BOUNDARIES (aligned to L1 windows)
# =============================================================================
# Strategy: walk through chr_meta windows in order, every WIN_PER_CHUNK
# windows starts a new chunk. The chunk's [start_bp, end_bp] is the union
# bp-span of those windows.

n_chunks <- ceiling(n_l1 / WIN_PER_CHUNK)
chunks_meta <- vector("list", n_chunks)
for (k in seq_len(n_chunks)) {
  i1 <- (k - 1L) * WIN_PER_CHUNK + 1L
  i2 <- min(k * WIN_PER_CHUNK, n_l1)
  chunks_meta[[k]] <- list(
    chunk_idx = k - 1L,
    win_lo    = i1,
    win_hi    = i2,
    start_bp  = chr_meta$start_bp[i1],
    end_bp    = chr_meta$end_bp[i2]
  )
}

cat("[M04_DOSAGE] Carving chunks: ", n_chunks, " chunks of up to ",
    WIN_PER_CHUNK, " L1 windows each\n", sep = "")

# =============================================================================
# WRITE OUTPUTS
# =============================================================================

chrom_dir <- file.path(OUT_DIR, CHROM)
dir.create(chrom_dir, recursive = TRUE, showWarnings = FALSE)

# Build the chunks-list for the index, while writing each content file
chunks_index <- vector("list", n_chunks)

# Marker positions as plain integer vector for fast slicing
pos_vec <- dos$.__pos
marker_id_vec <- if (!is.null(marker_col)) as.character(dos[[marker_col]]) else NULL

t_emit <- proc.time()[3]

for (k in seq_along(chunks_meta)) {
  m  <- chunks_meta[[k]]
  s  <- m$start_bp
  e  <- m$end_bp
  # Markers strictly within [s, e]; chunks may overlap on boundary L1 windows
  # but a marker at exactly the boundary belongs to the chunk whose start_bp
  # <= pos <= end_bp. To make chunks DISJOINT in coverage (so index lookup is
  # unambiguous), we use [s, e] inclusive on the LAST chunk and [s, e) on
  # earlier chunks. The next chunk's start_bp is >= the next L1 window's
  # start_bp, so this can only matter at exact equality.
  if (k < n_chunks) {
    in_chunk <- which(pos_vec >= s & pos_vec <  e)
  } else {
    in_chunk <- which(pos_vec >= s & pos_vec <= e)
  }

  n_m <- length(in_chunk)
  # Markers list (per-marker meta)
  markers_list <- vector("list", n_m)
  for (j in seq_len(n_m)) {
    mi <- in_chunk[j]
    rec <- list(
      pos_bp       = as.integer(pos_vec[mi]),
      missingness  = missingness[mi]
    )
    if (KEEP_MARKER_ID == 1L && !is.null(marker_id_vec)) {
      rec$marker_id <- marker_id_vec[mi]
    }
    if (joined_ds) {
      rec$diagnostic_score <- round(diagnostic_score[mi], 4)
    }
    markers_list[[j]] <- rec
  }

  # Dosage rows: one list element per marker, each a length-n_samples integer
  # vector with -1 for NA. We want JSON to emit these as flat integer arrays
  # (jsonlite serializes a plain vector as an array).
  dosage_rows <- vector("list", n_m)
  if (n_m > 0) {
    sub_mat <- dos_mat[in_chunk, , drop = FALSE]
    sub_mat[is.na(sub_mat)] <- -1L   # in-place NA encoding
    for (j in seq_len(n_m)) {
      dosage_rows[[j]] <- as.integer(sub_mat[j, ])
    }
  }

  # Filename
  base_name <- sprintf("%s_dosage_chunk_%d_%d.json", CHROM, s, e)
  full_path <- file.path(chrom_dir, base_name)
  rel_url   <- paste0(URL_PREFIX, base_name)

  chunk_obj <- list(
    chrom            = CHROM,
    region_start_bp  = as.integer(s),
    region_end_bp    = as.integer(e),
    n_markers        = as.integer(n_m),
    n_samples        = as.integer(n_samples),
    samples          = cohort_samples,
    markers          = markers_list,
    dosage           = dosage_rows,
    `_generated_at`  = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
    `_generator`     = "STEP_M04_emit_dosage_chunks.R"
  )

  json_str <- jsonlite::toJSON(chunk_obj, auto_unbox = TRUE, na = "null",
                                digits = NA, pretty = FALSE)
  writeLines(json_str, full_path)
  size_mb <- round(file.info(full_path)$size / 1e6, 2)

  cat(sprintf("[M04_DOSAGE]   chunk %3d/%3d  bp=%d..%d  markers=%d  size=%.2f MB  %s\n",
              k, n_chunks, s, e, n_m, size_mb, base_name))

  chunks_index[[k]] <- list(
    start_bp  = as.integer(s),
    end_bp    = as.integer(e),
    url       = rel_url,
    n_markers = as.integer(n_m)
  )
}

cat("[M04_DOSAGE] All chunk files written in ",
    round(proc.time()[3] - t_emit, 1), "s\n", sep = "")

# =============================================================================
# WRITE INDEX
# =============================================================================

index_obj <- list(
  schema_version    = 2L,
  `_layers_present` = list("dosage_chunks"),
  dosage_chunks     = list(
    chrom     = CHROM,
    n_chunks  = as.integer(n_chunks),
    n_samples = as.integer(n_samples),
    samples   = cohort_samples,
    chunks    = chunks_index
  ),
  `_generated_at`   = format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z"),
  `_generator`      = "STEP_M04_emit_dosage_chunks.R"
)

index_path <- file.path(chrom_dir, paste0(CHROM, "_dosage_chunks_index.json"))
index_json <- jsonlite::toJSON(index_obj, auto_unbox = TRUE, na = "null",
                                digits = NA, pretty = FALSE)
writeLines(index_json, index_path)

idx_kb <- round(file.info(index_path)$size / 1024, 1)

# =============================================================================
# DONE
# =============================================================================

cat("\n[M04_DOSAGE] === DONE ===\n")
cat("[M04_DOSAGE] Output dir:     ", chrom_dir, "\n", sep = "")
cat("[M04_DOSAGE] Index file:     ", basename(index_path), " (", idx_kb, " KB)\n", sep = "")
cat("[M04_DOSAGE] Chunks emitted: ", n_chunks, "\n", sep = "")
cat("[M04_DOSAGE] Markers total:  ", n_markers_total, "\n", sep = "")
cat("[M04_DOSAGE] Samples:        ", n_samples, "\n", sep = "")
cat("[M04_DOSAGE] ds_emitted:     ", joined_ds, "\n", sep = "")
cat("[M04_DOSAGE] schema_version: 2\n")
cat("[M04_DOSAGE] chrom:          ", CHROM, "\n", sep = "")
cat("\n")
cat("[M04_DOSAGE] Drop the index JSON into the scrubber as a per-chrom\n")
cat("[M04_DOSAGE] enrichment. The scrubber registers it as the\n")
cat("[M04_DOSAGE] 'dosage_chunks' layer; chunk content files are fetched\n")
cat("[M04_DOSAGE] on demand by URL when the heatmap region is set.\n")
cat("[M04_DOSAGE] Static heatmap (candidate page 2) and live heatmap (L3 ▦\n")
cat("[M04_DOSAGE] toggle) both light up automatically once the index loads.\n")
