#!/usr/bin/env Rscript

# =============================================================================
# STEP_M05_emit_step29_layers.R
#
# Phase M (Marker / dosage heatmap) emit shim. Wraps the existing STEP29
# coherence + polarity TSV outputs into a single per-chromosome JSON for the
# scrubber:
#
#   <out_dir>/<chrom>/<chrom>_step29_layers.json
#
# Two layers are emitted (both schema-v2 mirrors of the TSVs, no semantic
# transformation — this is a faithful column-by-column emit, by design):
#
#   - candidate_sample_coherence  (per-(candidate × sample) row)
#   - candidate_marker_polarity   (per-(candidate × marker) row)
#
# These light up the v3.94 dosage heatmap's Quality (left, track 3) and
# Polarity (top) annotation tracks. With the heatmap's
# `STEP_M04_emit_dosage_chunks.R` outputs already present, dropping this
# JSON into the scrubber fully populates the FIG_C08-style view — no
# button-computed stripe quality fallback needed.
#
# INPUT
# -----
# STEP29 produces two TSVs per chromosome (file names are conventional —
# pass paths directly):
#
#   --coherence_tsv  e.g. <chrom>_candidate_sample_coherence.tsv
#   --polarity_tsv   e.g. <chrom>_candidate_marker_polarity.tsv
#
# Required columns per SCHEMA_V2 §10:
#
#   coherence_tsv:
#     candidate_id, sample, coarse_group, agreement_fraction,
#     coherence_class, dist_to_centroid, centroid_z_score,
#     stripe_quality, tier_rule, n_informative_markers
#
#   polarity_tsv:
#     candidate_id, chrom, pos, marker_id,
#     raw_mean_HOMO_1, raw_mean_HOMO_2, raw_mean_HET,
#     delta_hom_mean, abs_delta_hom,
#     polarity_L1_sign, polarity_L1_confidence,
#     polarity_L1_ambiguous, polarity_L1_reversed,
#     block_id,
#     polarity_L2_sign, polarity_L2_confidence, polarity_L2_reversed,
#     final_flip_decision, flip_source, support_class
#
# Either or both may be supplied. If only one is present, the other layer
# simply isn't emitted (and the scrubber track silently disappears, which
# is the contracted failure mode).
#
# COLUMN HANDLING
# ---------------
# - Required columns absent → script aborts with a clear error.
# - Optional/extra columns → preserved as-is in the output (passed through).
# - Numeric types coerced to numeric; logicals coerced to JSON booleans.
# - Categorical columns left as strings.
# - NA values emitted as JSON null (jsonlite na="null").
#
# STRICT vs PERMISSIVE
# --------------------
# Default is permissive: warn and pass through unknown extra columns.
# Pass --strict_columns 1 to error out if extra columns appear (useful in
# CI / batch validation).
#
# USAGE
# -----
#   Rscript STEP_M05_emit_step29_layers.R \
#     --chrom          C_gar_LG28 \
#     --out_dir        /path/to/scrubber/data/ \
#     [--coherence_tsv /path/to/<chrom>_candidate_sample_coherence.tsv] \
#     [--polarity_tsv  /path/to/<chrom>_candidate_marker_polarity.tsv] \
#     [--strict_columns 0]
#
# OUTPUT LAYOUT
# -------------
#   <out_dir>/<chrom>/<chrom>_step29_layers.json
# =============================================================================

suppressPackageStartupMessages({
  library(data.table)
  library(jsonlite)
})

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

# =============================================================================
# PARSE ARGS
# =============================================================================

usage <- function() {
  cat(paste(
    "Usage: Rscript STEP_M05_emit_step29_layers.R --chrom <chr> --out_dir <dir>",
    "                                              [--coherence_tsv <tsv>]",
    "                                              [--polarity_tsv  <tsv>]",
    "                                              [--strict_columns 0]",
    "",
    "At least one of --coherence_tsv or --polarity_tsv is required.",
    sep = "\n"), "\n")
  quit(status = 1)
}

args <- commandArgs(trailingOnly = TRUE)

CHROM           <- NULL
OUT_DIR         <- NULL
COHERENCE_TSV   <- NULL
POLARITY_TSV    <- NULL
STRICT_COLS     <- 0L

i <- 1L
while (i <= length(args)) {
  a <- args[i]
  if      (a == "--chrom"           && i < length(args)) { CHROM         <- args[i + 1]; i <- i + 2L }
  else if (a == "--out_dir"         && i < length(args)) { OUT_DIR       <- args[i + 1]; i <- i + 2L }
  else if (a == "--coherence_tsv"   && i < length(args)) { COHERENCE_TSV <- args[i + 1]; i <- i + 2L }
  else if (a == "--polarity_tsv"    && i < length(args)) { POLARITY_TSV  <- args[i + 1]; i <- i + 2L }
  else if (a == "--strict_columns"  && i < length(args)) { STRICT_COLS   <- as.integer(args[i + 1]); i <- i + 2L }
  else if (a == "-h" || a == "--help")                   { usage() }
  else { i <- i + 1L }
}

if (is.null(CHROM) || is.null(OUT_DIR)) usage()
if (is.null(COHERENCE_TSV) && is.null(POLARITY_TSV)) {
  cat("[M05_STEP29] ERROR: at least one of --coherence_tsv or --polarity_tsv required\n")
  usage()
}
if (!is.null(COHERENCE_TSV) && !file.exists(COHERENCE_TSV)) {
  stop("Coherence TSV not found: ", COHERENCE_TSV)
}
if (!is.null(POLARITY_TSV) && !file.exists(POLARITY_TSV)) {
  stop("Polarity TSV not found: ", POLARITY_TSV)
}

# =============================================================================
# COLUMN CONTRACTS (from SCHEMA_V2 §10)
# =============================================================================

COHERENCE_REQUIRED <- c(
  "candidate_id", "sample", "coarse_group", "agreement_fraction",
  "coherence_class", "dist_to_centroid", "centroid_z_score",
  "stripe_quality", "tier_rule", "n_informative_markers"
)

POLARITY_REQUIRED <- c(
  "candidate_id", "chrom", "pos", "marker_id",
  "raw_mean_HOMO_1", "raw_mean_HOMO_2", "raw_mean_HET",
  "delta_hom_mean", "abs_delta_hom",
  "polarity_L1_sign", "polarity_L1_confidence",
  "polarity_L1_ambiguous", "polarity_L1_reversed",
  "block_id",
  "polarity_L2_sign", "polarity_L2_confidence", "polarity_L2_reversed",
  "final_flip_decision", "flip_source", "support_class"
)

# Type-coercion declarations: numeric, integer, logical. Anything not listed
# stays character.
COHERENCE_NUMERIC <- c("agreement_fraction", "dist_to_centroid", "centroid_z_score")
COHERENCE_INTEGER <- c("candidate_id", "n_informative_markers")

POLARITY_NUMERIC  <- c(
  "raw_mean_HOMO_1", "raw_mean_HOMO_2", "raw_mean_HET",
  "delta_hom_mean", "abs_delta_hom",
  "polarity_L1_confidence", "polarity_L2_confidence"
)
POLARITY_INTEGER  <- c(
  "candidate_id", "pos", "polarity_L1_sign", "polarity_L2_sign", "block_id"
)
POLARITY_LOGICAL  <- c(
  "polarity_L1_ambiguous", "polarity_L1_reversed",
  "polarity_L2_reversed", "final_flip_decision"
)

# Categorical / enum-valued columns we lightly validate (warn-only)
COHERENCE_ENUMS <- list(
  coarse_group     = c("HOMO_1", "HET", "HOMO_2"),
  coherence_class  = c("coherent", "intermediate", "discordant", "insufficient"),
  stripe_quality   = c("core", "peripheral", "junk", "unknown")
)
POLARITY_ENUMS <- list(
  flip_source   = c("L2_block", "L1_marker"),
  support_class = c("strong", "moderate", "weak", "ambiguous")
)

# =============================================================================
# HELPERS
# =============================================================================

coerce_logical <- function(v) {
  # Accept TRUE/FALSE, "TRUE"/"FALSE", "T"/"F", "true"/"false", "1"/"0"
  if (is.logical(v)) return(v)
  out <- rep(NA, length(v))
  s <- as.character(v)
  out[s %in% c("TRUE", "T", "true", "True", "1")] <- TRUE
  out[s %in% c("FALSE", "F", "false", "False", "0")] <- FALSE
  out
}

check_columns <- function(dt, required, label, strict) {
  miss <- setdiff(required, names(dt))
  if (length(miss) > 0) {
    stop(sprintf("[M05_STEP29] %s TSV missing required columns: %s",
                 label, paste(miss, collapse = ", ")))
  }
  extra <- setdiff(names(dt), required)
  if (length(extra) > 0) {
    msg <- sprintf("[M05_STEP29] %s TSV has %d extra columns: %s",
                   label, length(extra), paste(extra, collapse = ", "))
    if (strict == 1L) {
      stop(msg, " — aborting due to --strict_columns 1")
    } else {
      cat(msg, " — passing through (use --strict_columns 1 to abort)\n", sep = "")
    }
  }
  invisible(NULL)
}

check_enums <- function(dt, enums, label) {
  for (col in names(enums)) {
    if (!col %in% names(dt)) next
    vals <- unique(as.character(dt[[col]]))
    bad  <- setdiff(vals, enums[[col]])
    bad  <- bad[!is.na(bad)]
    if (length(bad) > 0) {
      cat(sprintf("[M05_STEP29] WARNING — %s.%s has %d unexpected values: %s (expected: %s)\n",
                  label, col, length(bad), paste(head(bad, 5), collapse = ", "),
                  paste(enums[[col]], collapse = ", ")), sep = "")
    }
  }
}

coerce_types <- function(dt, num_cols, int_cols, log_cols) {
  for (c in intersect(num_cols, names(dt))) {
    set(dt, NULL, c, suppressWarnings(as.numeric(dt[[c]])))
  }
  for (c in intersect(int_cols, names(dt))) {
    set(dt, NULL, c, suppressWarnings(as.integer(dt[[c]])))
  }
  for (c in intersect(log_cols, names(dt))) {
    set(dt, NULL, c, coerce_logical(dt[[c]]))
  }
  invisible(dt)
}

# Convert a data.table to a list of row-records (jsonlite emits as JSON array
# of objects). Faster than apply-based; handles per-row NA correctly.
dt_to_records <- function(dt) {
  cols <- names(dt)
  n    <- nrow(dt)
  out  <- vector("list", n)
  for (i in seq_len(n)) {
    rec <- vector("list", length(cols))
    names(rec) <- cols
    for (cj in seq_along(cols)) {
      v <- dt[[cols[cj]]][i]
      if (is.logical(v) && is.na(v)) v <- NA
      rec[[cj]] <- v
    }
    out[[i]] <- rec
  }
  out
}

# =============================================================================
# LOAD + PROCESS coherence_tsv
# =============================================================================

coherence_layer <- NULL
n_coh_rows <- 0L

if (!is.null(COHERENCE_TSV)) {
  cat("[M05_STEP29] Loading coherence TSV: ", COHERENCE_TSV, "\n", sep = "")
  coh_dt <- fread(COHERENCE_TSV)
  cat("[M05_STEP29]   rows: ", nrow(coh_dt), "  cols: ", ncol(coh_dt), "\n", sep = "")

  check_columns(coh_dt, COHERENCE_REQUIRED, "coherence", STRICT_COLS)

  coerce_types(coh_dt, COHERENCE_NUMERIC, COHERENCE_INTEGER, character(0))

  check_enums(coh_dt, COHERENCE_ENUMS, "coherence")

  # Quick sanity prints
  cat("[M05_STEP29]   coarse_group:    ",
      paste(sort(unique(as.character(coh_dt$coarse_group))), collapse = ", "), "\n", sep = "")
  cat("[M05_STEP29]   stripe_quality:  ",
      paste(sort(unique(as.character(coh_dt$stripe_quality))), collapse = ", "), "\n", sep = "")
  cat("[M05_STEP29]   coherence_class: ",
      paste(sort(unique(as.character(coh_dt$coherence_class))), collapse = ", "), "\n", sep = "")
  cat("[M05_STEP29]   distinct candidates: ",
      length(unique(coh_dt$candidate_id)), "\n", sep = "")
  cat("[M05_STEP29]   distinct samples:    ",
      length(unique(coh_dt$sample)), "\n", sep = "")

  coherence_layer <- dt_to_records(coh_dt)
  n_coh_rows <- length(coherence_layer)
}

# =============================================================================
# LOAD + PROCESS polarity_tsv
# =============================================================================

polarity_layer <- NULL
n_pol_rows <- 0L

if (!is.null(POLARITY_TSV)) {
  cat("[M05_STEP29] Loading polarity TSV: ", POLARITY_TSV, "\n", sep = "")
  pol_dt <- fread(POLARITY_TSV)
  cat("[M05_STEP29]   rows: ", nrow(pol_dt), "  cols: ", ncol(pol_dt), "\n", sep = "")

  check_columns(pol_dt, POLARITY_REQUIRED, "polarity", STRICT_COLS)

  # If the TSV has a chrom column with mixed values, warn but pass
  if ("chrom" %in% names(pol_dt)) {
    chr_vals <- unique(as.character(pol_dt$chrom))
    if (length(chr_vals) > 1L) {
      cat("[M05_STEP29] WARNING — polarity TSV has multiple chrom values: ",
          paste(chr_vals, collapse = ", "),
          " (passing through; scrubber filters by chrom at render).\n", sep = "")
    } else if (length(chr_vals) == 1L && chr_vals != CHROM) {
      cat("[M05_STEP29] WARNING — polarity TSV chrom='", chr_vals,
          "' differs from --chrom='", CHROM, "' — passing through unchanged.\n", sep = "")
    }
  }

  coerce_types(pol_dt, POLARITY_NUMERIC, POLARITY_INTEGER, POLARITY_LOGICAL)

  check_enums(pol_dt, POLARITY_ENUMS, "polarity")

  cat("[M05_STEP29]   distinct candidates: ",
      length(unique(pol_dt$candidate_id)), "\n", sep = "")
  cat("[M05_STEP29]   distinct markers:    ",
      length(unique(pol_dt$marker_id)), "\n", sep = "")
  cat("[M05_STEP29]   final_flip_decision: TRUE=",
      sum(isTRUE(pol_dt$final_flip_decision) | pol_dt$final_flip_decision %in% TRUE, na.rm = TRUE),
      "  FALSE=",
      sum(pol_dt$final_flip_decision %in% FALSE, na.rm = TRUE),
      "  NA=", sum(is.na(pol_dt$final_flip_decision)), "\n", sep = "")
  cat("[M05_STEP29]   flip_source:    ",
      paste(sort(unique(as.character(pol_dt$flip_source))), collapse = ", "), "\n", sep = "")
  cat("[M05_STEP29]   support_class:  ",
      paste(sort(unique(as.character(pol_dt$support_class))), collapse = ", "), "\n", sep = "")

  polarity_layer <- dt_to_records(pol_dt)
  n_pol_rows <- length(polarity_layer)
}

# =============================================================================
# ASSEMBLE JSON
# =============================================================================

layers_present <- c()
out <- list(
  schema_version = 2L,
  chrom          = CHROM
)

if (!is.null(coherence_layer)) {
  out$candidate_sample_coherence <- coherence_layer
  layers_present <- c(layers_present, "candidate_sample_coherence")
}
if (!is.null(polarity_layer)) {
  out$candidate_marker_polarity <- polarity_layer
  layers_present <- c(layers_present, "candidate_marker_polarity")
}

out$`_layers_present` <- as.list(layers_present)
out$`_generated_at`   <- format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
out$`_generator`      <- "STEP_M05_emit_step29_layers.R"

# =============================================================================
# WRITE
# =============================================================================

chrom_dir  <- file.path(OUT_DIR, CHROM)
dir.create(chrom_dir, recursive = TRUE, showWarnings = FALSE)
out_path   <- file.path(chrom_dir, paste0(CHROM, "_step29_layers.json"))

cat("[M05_STEP29] Serializing JSON...\n", sep = "")
t_ser <- proc.time()[3]
json_str <- jsonlite::toJSON(out, auto_unbox = TRUE, na = "null",
                              digits = NA, pretty = FALSE)
writeLines(json_str, out_path)
cat("[M05_STEP29]   serialized in ", round(proc.time()[3] - t_ser, 1), "s\n", sep = "")

f_size_kb <- round(file.info(out_path)$size / 1024, 1)
f_size_mb <- round(file.info(out_path)$size / 1e6, 2)

# =============================================================================
# DONE
# =============================================================================

cat("\n[M05_STEP29] === DONE ===\n")
cat("[M05_STEP29] Output: ", out_path, "\n", sep = "")
cat("[M05_STEP29] Size:   ", f_size_kb, " KB (", f_size_mb, " MB)\n", sep = "")
cat("[M05_STEP29] schema_version: 2\n")
cat("[M05_STEP29] chrom:          ", CHROM, "\n", sep = "")
cat("[M05_STEP29] Layers emitted: ", paste(layers_present, collapse = ", "), "\n", sep = "")
cat("[M05_STEP29] coherence rows: ", n_coh_rows, "\n", sep = "")
cat("[M05_STEP29] polarity rows:  ", n_pol_rows, "\n", sep = "")
cat("\n")
cat("[M05_STEP29] Drop this JSON into the scrubber alongside the dosage_chunks\n")
cat("[M05_STEP29] index from STEP_M04. The scrubber registers these as the\n")
cat("[M05_STEP29] 'candidate_sample_coherence' and 'candidate_marker_polarity'\n")
cat("[M05_STEP29] layers; the heatmap's Quality (left) and Polarity (top)\n")
cat("[M05_STEP29] tracks light up automatically. The 'Compute stripe quality'\n")
cat("[M05_STEP29] button is replaced by a 'stripe quality: from layer' status.\n")
