#!/usr/bin/env Rscript

# =============================================================================
# smoke_test_M04_M05.R
#
# End-to-end smoke test for STEP_M04 + STEP_M05. Generates tiny synthetic
# fixtures (chrom = TEST_LG01, 6 samples, 50 markers across 8 L1 windows)
# and exercises both scripts against them, then validates that:
#
#   - The chunk index has the expected URL pattern and shape.
#   - At least one chunk JSON loads, with markers/dosage shape matching
#     the SCHEMA_V2 §10 contract.
#   - The STEP29 shim emits both layers when given both TSVs and one layer
#     when given only one.
#   - All required columns from the schema appear in the JSON output.
#
# Designed to be self-contained — no real data needed. Run from anywhere:
#   Rscript smoke_test_M04_M05.R
# =============================================================================

suppressPackageStartupMessages({
  library(data.table)
  library(jsonlite)
})

stopifnot_msg <- function(cond, msg) {
  if (!isTRUE(cond)) {
    cat("FAIL: ", msg, "\n", sep = "")
    cat("smoke test FAILED\n")
    quit(status = 1)
  } else {
    cat("ok:   ", msg, "\n", sep = "")
  }
}

`%||%` <- function(a, b) if (is.null(a) || length(a) == 0) b else a

# Locate the two scripts in the same dir as this fixture script
script_dir <- tryCatch({
  if (sys.nframe() >= 1L) dirname(normalizePath(sys.frame(1)$ofile %||% "."))
  else getwd()
}, error = function(e) getwd())
M04 <- file.path(script_dir, "STEP_M04_emit_dosage_chunks.R")
M05 <- file.path(script_dir, "STEP_M05_emit_step29_layers.R")
if (!file.exists(M04)) M04 <- "STEP_M04_emit_dosage_chunks.R"
if (!file.exists(M05)) M05 <- "STEP_M05_emit_step29_layers.R"
stopifnot_msg(file.exists(M04), paste0("script exists: ", M04))
stopifnot_msg(file.exists(M05), paste0("script exists: ", M05))

# =============================================================================
# Build fixtures
# =============================================================================

work_root <- Sys.getenv("SMOKE_WORK_DIR", unset = "")
work <- if (nzchar(work_root)) work_root else tempfile("m04m05_smoke_")
dir.create(work, showWarnings = FALSE, recursive = TRUE)
cat("\n[smoke] working dir: ", work, "\n", sep = "")

CHROM <- "TEST_LG01"
N_SAMP <- 6L
N_MARK <- 50L
N_WIN  <- 8L

samples <- sprintf("S%03d", seq_len(N_SAMP))

set.seed(1L)
# Markers spread across 1..1000 bp uniformly
positions <- sort(sample.int(1000L, N_MARK))
marker_id <- sprintf("%s_%d", CHROM, positions)
dosage <- matrix(sample(c(0L, 1L, 2L, NA_integer_), N_MARK * N_SAMP,
                         replace = TRUE, prob = c(0.4, 0.4, 0.18, 0.02)),
                  nrow = N_MARK, ncol = N_SAMP)

dos_dt <- data.table(marker = marker_id, pos_bp = positions)
for (s in seq_len(N_SAMP)) dos_dt[[samples[s]]] <- dosage[, s]

dosage_path <- file.path(work, paste0(CHROM, ".dos.tsv.gz"))
fwrite(dos_dt, dosage_path, sep = "\t", compress = "gzip")
cat("[smoke] wrote dosage: ", dosage_path,
    " (", N_MARK, " markers × ", N_SAMP, " samples)\n", sep = "")

# chr_meta with 8 L1 windows partitioning bp 1..1000
win_starts <- c(1L, 130L, 260L, 390L, 520L, 650L, 780L, 910L)
win_ends   <- c(  129L, 259L, 389L, 519L, 649L, 779L, 909L, 1000L)
stopifnot(length(win_starts) == N_WIN, length(win_ends) == N_WIN)
chr_meta <- data.table(
  chrom = CHROM,
  start_bp = win_starts, end_bp = win_ends,
  window_index_chr = seq_len(N_WIN) - 1L,
  n_snps = 100L
)
chr_meta_path <- file.path(work, paste0(CHROM, ".chr_meta.tsv.gz"))
fwrite(chr_meta, chr_meta_path, sep = "\t", compress = "gzip")
cat("[smoke] wrote chr_meta: ", chr_meta_path, " (", N_WIN, " windows)\n", sep = "")

# =============================================================================
# Run STEP_M04 with windows_per_chunk = 3 → 3 chunks
# =============================================================================
cat("\n[smoke] === Running STEP_M04 ===\n")

m04_out_dir <- file.path(work, "scrubber_data")
m04_args <- c(
  "--dosage", dosage_path,
  "--chr_meta", chr_meta_path,
  "--chrom", CHROM,
  "--out_dir", m04_out_dir,
  "--windows_per_chunk", "3"
)

rc <- system2("Rscript", c(M04, m04_args), stdout = TRUE, stderr = TRUE)
cat(paste(rc, collapse = "\n"), "\n")

# Validate index file
idx_path <- file.path(m04_out_dir, CHROM, paste0(CHROM, "_dosage_chunks_index.json"))
stopifnot_msg(file.exists(idx_path), "M04 index file written")

idx <- fromJSON(idx_path, simplifyVector = FALSE)
stopifnot_msg(idx$schema_version == 2L, "M04 schema_version=2")
stopifnot_msg(identical(idx$`_layers_present`[[1]], "dosage_chunks"),
              "M04 _layers_present registers dosage_chunks")
stopifnot_msg(idx$dosage_chunks$chrom == CHROM, "M04 chrom matches")
stopifnot_msg(idx$dosage_chunks$n_samples == N_SAMP, "M04 n_samples matches")
stopifnot_msg(length(idx$dosage_chunks$samples) == N_SAMP,
              "M04 samples array length matches")
stopifnot_msg(length(idx$dosage_chunks$chunks) == ceiling(N_WIN / 3),
              sprintf("M04 chunks count = %d (8/3 ceiling)", ceiling(N_WIN / 3)))

# Validate chunk URL shape and that each chunk file exists
for (k in seq_along(idx$dosage_chunks$chunks)) {
  ch <- idx$dosage_chunks$chunks[[k]]
  stopifnot_msg(!is.null(ch$start_bp) && !is.null(ch$end_bp),
                sprintf("M04 chunk %d has start_bp/end_bp", k))
  stopifnot_msg(grepl("_dosage_chunk_\\d+_\\d+\\.json$", ch$url),
                sprintf("M04 chunk %d URL pattern", k))
  cf <- file.path(m04_out_dir, ch$url)
  stopifnot_msg(file.exists(cf),
                sprintf("M04 chunk %d content file exists: %s", k, basename(cf)))
}

# Validate first chunk's content shape
chunk_path <- file.path(m04_out_dir, idx$dosage_chunks$chunks[[1]]$url)
chunk1 <- fromJSON(chunk_path, simplifyVector = FALSE)

stopifnot_msg(chunk1$chrom == CHROM, "M04 chunk content chrom")
stopifnot_msg(chunk1$n_samples == N_SAMP, "M04 chunk n_samples matches")
stopifnot_msg(length(chunk1$samples) == N_SAMP, "M04 chunk samples length")
stopifnot_msg(chunk1$n_markers == length(chunk1$markers),
              "M04 chunk n_markers matches markers list length")
stopifnot_msg(chunk1$n_markers == length(chunk1$dosage),
              "M04 chunk dosage rows == n_markers")

# Validate marker record shape (pos_bp + missingness required)
m1 <- chunk1$markers[[1]]
stopifnot_msg(!is.null(m1$pos_bp), "M04 marker has pos_bp")
stopifnot_msg(!is.null(m1$missingness), "M04 marker has missingness")

# Validate dosage row shape (length-N_SAMP integer with -1 for NA)
d1 <- unlist(chunk1$dosage[[1]])
stopifnot_msg(length(d1) == N_SAMP, "M04 dosage row length == n_samples")
stopifnot_msg(all(d1 %in% c(-1L, 0L, 1L, 2L)), "M04 dosage values in {-1,0,1,2}")

# Markers are pos-ordered within chunk
positions_in_chunk <- vapply(chunk1$markers, function(m) m$pos_bp, integer(1))
stopifnot_msg(!is.unsorted(positions_in_chunk), "M04 markers pos-ordered")

# All chunks together cover all markers exactly once
total_markers <- 0L
all_positions <- c()
for (k in seq_along(idx$dosage_chunks$chunks)) {
  ch_path <- file.path(m04_out_dir, idx$dosage_chunks$chunks[[k]]$url)
  ch <- fromJSON(ch_path, simplifyVector = FALSE)
  total_markers <- total_markers + ch$n_markers
  all_positions <- c(all_positions,
                     vapply(ch$markers, function(m) m$pos_bp, integer(1)))
}
stopifnot_msg(total_markers == N_MARK,
              sprintf("M04 total markers across chunks = %d (expected %d)",
                      total_markers, N_MARK))
stopifnot_msg(length(unique(all_positions)) == N_MARK,
              "M04 chunks cover each marker exactly once")

# =============================================================================
# Build STEP29-style fixtures and run STEP_M05
# =============================================================================
cat("\n[smoke] === Building STEP29 fixtures + running STEP_M05 ===\n")

# coherence: 3 candidates × 6 samples = 18 rows
coh <- data.table(
  candidate_id          = rep(1:3, each = N_SAMP),
  sample                = rep(samples, times = 3),
  coarse_group          = rep(c("HOMO_1", "HET", "HOMO_2"), times = 6),
  agreement_fraction    = round(runif(18, 0.4, 0.95), 3),
  coherence_class       = sample(c("coherent", "intermediate", "discordant", "insufficient"),
                                  18, replace = TRUE),
  dist_to_centroid      = round(runif(18, 0, 2), 3),
  centroid_z_score      = round(rnorm(18), 3),
  stripe_quality        = sample(c("core", "peripheral", "junk", "unknown"),
                                  18, replace = TRUE,
                                  prob = c(0.5, 0.3, 0.15, 0.05)),
  tier_rule             = "test_rule",
  n_informative_markers = sample(20:60, 18, replace = TRUE)
)
coh_path <- file.path(work, paste0(CHROM, "_candidate_sample_coherence.tsv"))
fwrite(coh, coh_path, sep = "\t")

# polarity: 3 candidates × 8 markers each = 24 rows
n_pol_rows <- 24L
pol <- data.table(
  candidate_id           = rep(1:3, each = 8),
  chrom                  = CHROM,
  pos                    = sample(positions, n_pol_rows, replace = TRUE),
  marker_id              = sample(marker_id, n_pol_rows, replace = TRUE),
  raw_mean_HOMO_1        = round(runif(n_pol_rows, 0, 0.4), 3),
  raw_mean_HOMO_2        = round(runif(n_pol_rows, 1.6, 2.0), 3),
  raw_mean_HET           = round(runif(n_pol_rows, 0.8, 1.2), 3),
  delta_hom_mean         = round(runif(n_pol_rows, 1.4, 1.8), 3),
  abs_delta_hom          = round(runif(n_pol_rows, 1.4, 1.8), 3),
  polarity_L1_sign       = sample(c(-1L, 1L), n_pol_rows, replace = TRUE),
  polarity_L1_confidence = round(runif(n_pol_rows, 0.5, 1.0), 3),
  polarity_L1_ambiguous  = sample(c(TRUE, FALSE), n_pol_rows, replace = TRUE, prob = c(0.1, 0.9)),
  polarity_L1_reversed   = sample(c(TRUE, FALSE), n_pol_rows, replace = TRUE, prob = c(0.2, 0.8)),
  block_id               = sample(1:5, n_pol_rows, replace = TRUE),
  polarity_L2_sign       = sample(c(-1L, 1L), n_pol_rows, replace = TRUE),
  polarity_L2_confidence = round(runif(n_pol_rows, 0.7, 1.0), 3),
  polarity_L2_reversed   = sample(c(TRUE, FALSE), n_pol_rows, replace = TRUE, prob = c(0.15, 0.85)),
  final_flip_decision    = sample(c(TRUE, FALSE), n_pol_rows, replace = TRUE, prob = c(0.3, 0.7)),
  flip_source            = sample(c("L2_block", "L1_marker"), n_pol_rows, replace = TRUE),
  support_class          = sample(c("strong", "moderate", "weak", "ambiguous"),
                                   n_pol_rows, replace = TRUE)
)
pol_path <- file.path(work, paste0(CHROM, "_candidate_marker_polarity.tsv"))
fwrite(pol, pol_path, sep = "\t")

# Run M05 with both TSVs
m05_out_dir <- m04_out_dir   # share dir
m05_args <- c(
  "--chrom", CHROM,
  "--out_dir", m05_out_dir,
  "--coherence_tsv", coh_path,
  "--polarity_tsv",  pol_path
)
rc <- system2("Rscript", c(M05, m05_args), stdout = TRUE, stderr = TRUE)
cat(paste(rc, collapse = "\n"), "\n")

m05_path <- file.path(m05_out_dir, CHROM, paste0(CHROM, "_step29_layers.json"))
stopifnot_msg(file.exists(m05_path), "M05 layers file written")

m05 <- fromJSON(m05_path, simplifyVector = FALSE)
stopifnot_msg(m05$schema_version == 2L, "M05 schema_version=2")
stopifnot_msg(m05$chrom == CHROM, "M05 chrom matches")
lp <- vapply(m05$`_layers_present`, identity, character(1))
stopifnot_msg(setequal(lp, c("candidate_sample_coherence", "candidate_marker_polarity")),
              "M05 both layers in _layers_present when both TSVs supplied")
stopifnot_msg(length(m05$candidate_sample_coherence) == 18L,
              "M05 coherence row count matches input")
stopifnot_msg(length(m05$candidate_marker_polarity) == n_pol_rows,
              "M05 polarity row count matches input")

# Schema column-presence check on first row of each
coh_keys <- names(m05$candidate_sample_coherence[[1]])
stopifnot_msg(all(c("candidate_id", "sample", "coarse_group",
                     "agreement_fraction", "coherence_class",
                     "dist_to_centroid", "centroid_z_score",
                     "stripe_quality", "tier_rule",
                     "n_informative_markers") %in% coh_keys),
              "M05 coherence first row has all required schema columns")

pol_keys <- names(m05$candidate_marker_polarity[[1]])
required_pol <- c("candidate_id", "chrom", "pos", "marker_id",
                  "raw_mean_HOMO_1", "raw_mean_HOMO_2", "raw_mean_HET",
                  "delta_hom_mean", "abs_delta_hom",
                  "polarity_L1_sign", "polarity_L1_confidence",
                  "polarity_L1_ambiguous", "polarity_L1_reversed",
                  "block_id",
                  "polarity_L2_sign", "polarity_L2_confidence",
                  "polarity_L2_reversed",
                  "final_flip_decision", "flip_source", "support_class")
stopifnot_msg(all(required_pol %in% pol_keys),
              "M05 polarity first row has all required schema columns")

# Booleans round-trip as JSON true/false
fr1 <- m05$candidate_marker_polarity[[1]]$final_flip_decision
stopifnot_msg(is.logical(fr1) || fr1 %in% c(TRUE, FALSE),
              "M05 final_flip_decision is boolean")

# =============================================================================
# Run STEP_M05 with only coherence TSV → polarity layer absent
# =============================================================================
cat("\n[smoke] === STEP_M05 single-layer mode (coherence only) ===\n")

solo_dir <- file.path(work, "solo")
solo_args <- c("--chrom", CHROM, "--out_dir", solo_dir,
               "--coherence_tsv", coh_path)
system2("Rscript", c(M05, solo_args), stdout = FALSE, stderr = FALSE)

solo_path <- file.path(solo_dir, CHROM, paste0(CHROM, "_step29_layers.json"))
solo <- fromJSON(solo_path, simplifyVector = FALSE)
solo_lp <- vapply(solo$`_layers_present`, identity, character(1))
stopifnot_msg(identical(solo_lp, "candidate_sample_coherence"),
              "M05 single-layer mode emits only coherence")
stopifnot_msg(is.null(solo$candidate_marker_polarity),
              "M05 single-layer mode omits polarity key")

# =============================================================================
# Run STEP_M04 with --windows_per_chunk = 999 → ALL markers in one chunk
# =============================================================================
cat("\n[smoke] === STEP_M04 single-chunk mode ===\n")

big_dir <- file.path(work, "big")
big_args <- c(
  "--dosage", dosage_path, "--chr_meta", chr_meta_path,
  "--chrom", CHROM, "--out_dir", big_dir,
  "--windows_per_chunk", "999"
)
system2("Rscript", c(M04, big_args), stdout = FALSE, stderr = FALSE)
big_idx <- fromJSON(file.path(big_dir, CHROM,
                               paste0(CHROM, "_dosage_chunks_index.json")),
                     simplifyVector = FALSE)
stopifnot_msg(length(big_idx$dosage_chunks$chunks) == 1L,
              "M04 single-chunk mode produces exactly 1 chunk")

# =============================================================================
cat("\n[smoke] ALL CHECKS PASSED\n")
cat("[smoke] working dir kept at: ", work, "\n", sep = "")
