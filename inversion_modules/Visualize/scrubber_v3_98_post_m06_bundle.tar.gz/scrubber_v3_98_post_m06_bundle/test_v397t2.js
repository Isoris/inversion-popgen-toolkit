// v3.97 turn 2 tests: boundaries page UI + hotkeys + action handlers
//
// What v3.97 turn 2 adds:
//   - Tab button data-page="page11" (displayed as tab "3 boundaries")
//   - Page DOM: #page11 with toolbar + info + tracks + summary slots
//   - Functions:
//       renderBoundariesPage()
//       _bndPopulateCandidateSelect()
//       _bndSelectCandidate(candId)
//       _bndAutoPropose()
//       _bndOverrideLeft() / _bndOverrideRight()
//       _bndReset()
//       _bndSave()
//       _bndDrawTracks()
//       _bndRefreshSummary() / _bndRefreshUI()
//       _bndUpdateRadiusButtons() / _bndUpdateSaveButton() / _bndUpdateStatusSelect()
//       _bndKeyHandler() / _bndAttachHotkeys() / _bndDetachHotkeys()
//       _bndCloneRecord(rec) / _bndStageFromCandidate(cand) / _bndFindCandidate(id)
//       _bndManualOverride(side)
//   - CSS: #page11 .bnd-toolbar / .bnd-radius-btn / .bnd-zone / .bnd-summary
//   - Hook in tab-switch handler: target === 'page11' triggers
//     renderBoundariesPage() + _bndAttachHotkeys(); else detaches
//
// TESTS (10)
//   1. SCRUBBER_VERSION still v3.97+
//   2. Tab button HTML present + page11 DOM section present
//   3. CSS rules present (.bnd-toolbar, .bnd-radius-btn.active, .bnd-zone,
//      .bnd-summary table, .bnd-cls-strong/moderate/weak/ambiguous)
//   4. _bndCloneRecord deep-copies and isolates from source
//   5. _bndFindCandidate looks up by id OR candidate_id
//   6. _bndStageFromCandidate populates staging from existing boundary fields
//   7. _bndAutoPropose populates staging.boundary_left/right when layers present
//   8. _bndReset clears staging; _bndSave persists to candidate
//   9. Hotkey wiring: setActivePage('page11') hook + grep for attach/detach
//  10. _bndKeyHandler routes E/F/B/R/A; suppressed when input focused or
//      when page11 not active

const fs = require('fs');
const html = fs.readFileSync('/home/claude/v3/pca_scrubber_v3.html', 'utf8');
const m = html.match(/<script>([\s\S]+?)<\/script>/);
let js = m[1];

const shim = `
const _byId = new Map();
const _addedListeners = [];
function _makeEl(tag) {
  const _ownC = new Set();
  const ctxStub = { setTransform:()=>{}, clearRect:()=>{}, fillRect:()=>{},
    strokeRect:()=>{}, beginPath:()=>{}, moveTo:()=>{}, lineTo:()=>{}, stroke:()=>{},
    fill:()=>{}, fillText:()=>{}, save:()=>{}, restore:()=>{},
    translate:()=>{}, rotate:()=>{}, setLineDash:()=>{},
    measureText:(s)=>({ width:0 }), createLinearGradient:()=>({addColorStop:()=>{}}),
    fillStyle:'',strokeStyle:'',lineWidth:1,font:'',textAlign:'',textBaseline:'' };
  const el = { tagName:(tag||'').toUpperCase(), id:'', textContent:'', _innerHTML:'',
    disabled:false, value:'', placeholder:'', title:'', checked:false,
    width:0, height:0, offsetWidth:100, offsetHeight:20, clientWidth:1000, clientHeight:400,
    style:{cssText:'',display:'',width:'',height:'',visibility:'',left:'',top:''},
    classList: { _c: _ownC, add(...a){a.forEach(x=>this._c.add(x));},
      remove(...a){a.forEach(x=>this._c.delete(x));}, toggle(){}, contains(x){return this._c.has(x);} },
    dataset:{}, _children:[],
    appendChild(c){ this._children.push(c); return c; },
    addEventListener(){}, removeEventListener(){},
    insertAdjacentHTML(){},
    querySelector(){return null;}, querySelectorAll: () => [],
    setAttribute(){}, getAttribute(){return null;}, removeAttribute(){},
    getBoundingClientRect: () => ({left:0,top:0,width:1000,height:120,right:1000,bottom:120}),
    contains: () => false, parentNode: null, parentElement: null,
    getContext: () => ctxStub };
  Object.defineProperty(el,'innerHTML',{get(){return this._innerHTML;},set(v){this._innerHTML=String(v);}});
  Object.defineProperty(el,'className',{get(){return [...this.classList._c].join(' ');},
    set(v){this.classList._c.clear(); String(v||'').split(/\\s+/).filter(Boolean).forEach(x=>this.classList._c.add(x));}});
  return el;
}
const _bodyEl = _makeEl('body');
const document = {
  documentElement: _makeEl('html'),
  querySelectorAll: () => [], querySelector: () => null,
  getElementById(id) { if (!_byId.has(id)) { const el = _makeEl('div'); el.id = id; _byId.set(id, el); } return _byId.get(id); },
  createElement: _makeEl, body: _bodyEl,
  addEventListener: (kind, fn) => { _addedListeners.push({kind, fn}); },
  removeEventListener: (kind, fn) => {
    const i = _addedListeners.findIndex(L => L.kind === kind && L.fn === fn);
    if (i >= 0) _addedListeners.splice(i, 1);
  },
  activeElement: { tagName: 'DIV' },   // not an input
};
const window = { devicePixelRatio: 1, addEventListener: () => {}, innerWidth: 1024, innerHeight: 768 };
const localStorage = { setItem(){}, getItem(){return null;}, removeItem(){}, clear(){} };
const getComputedStyle = () => ({ getPropertyValue: () => '' });
const FileReader = function() {};
const Blob = function() {};
const URL = { createObjectURL: () => '', revokeObjectURL: () => {} };
const requestAnimationFrame = (fn) => { try { fn(); } catch (e) {} return 1; };
const cancelAnimationFrame = () => {};
const setTimeout = (fn) => { try { fn(); } catch (e) {} return 1; };
const clearTimeout = () => {};
const alert = () => {};
const confirm = () => true;
`;
js = `${shim}\n${js}\nmodule.exports = {
  state, BOUNDARY_DEFAULTS, BOUNDARY_TRACK_WEIGHTS, SUPPORT_CLASS_COLORS,
  _ensureBoundariesState, _bndFindCandidate, _bndCloneRecord,
  _bndStageFromCandidate, _bndPopulateCandidateSelect,
  _bndSelectCandidate, _bndAutoPropose, _bndManualOverride,
  _bndOverrideLeft, _bndOverrideRight, _bndReset, _bndSave,
  _bndKeyHandler, _bndAttachHotkeys, _bndDetachHotkeys,
  renderBoundariesPage,
  _addedListeners, _byId,
};\n`;
fs.writeFileSync('/tmp/scrubber_test_v397t2.js', js);
delete require.cache[require.resolve('/tmp/scrubber_test_v397t2.js')];
const M = require('/tmp/scrubber_test_v397t2.js');

let totalPass = 0, totalFail = 0;
function check(label, ok, detail) {
  if (ok) { totalPass++; console.log(' ', 'PASS'); }
  else    { totalFail++; console.log(' ', 'FAIL', detail || ''); }
}

// =============================================================================
// TEST 1: SCRUBBER_VERSION still v3.97+
// =============================================================================
console.log('--- TEST 1: SCRUBBER_VERSION v3.97+ ---');
const t1 = /const SCRUBBER_VERSION = 'v3\.(9[7-9]|\d{3,})';/.test(html);
check('test1', t1);

// =============================================================================
// TEST 2: Tab button + page DOM section
// =============================================================================
console.log('\n--- TEST 2: tab + page DOM ---');
const t2a = /<button[^>]*data-page="page11"[^>]*>[^<]*<span class="num">3<\/span>\s*boundaries/i.test(html);
const t2b = /<div id="page11"\s+class="page">/.test(html);
const t2c = /<div id="page11Content"/.test(html);
const t2d = /id="page11Header"/.test(html);
// Renumbered tabs: markers should now be "10", help should be "11"
const t2e = /<button[^>]*data-page="page10"[^>]*>[^<]*<span class="num">10<\/span>\s*markers/i.test(html);
const t2f = /<button[^>]*data-page="page5"[^>]*>[^<]*<span class="num">11<\/span>\s*help/i.test(html);
console.log('  page11 tab button (displayed "3 boundaries"):', t2a);
console.log('  #page11 section present:', t2b);
console.log('  #page11Content slot:', t2c);
console.log('  #page11Header:', t2d);
console.log('  markers tab renumbered to 10:', t2e);
console.log('  help tab renumbered to 11:', t2f);
check('test2', t2a && t2b && t2c && t2d && t2e && t2f);

// =============================================================================
// TEST 3: CSS rules present
// =============================================================================
console.log('\n--- TEST 3: CSS rules ---');
const t3a = /#page11\s+\.bnd-toolbar/.test(html);
const t3b = /\.bnd-radius-btn\.active/.test(html);
const t3c = /#page11\s+\.bnd-zone\b/.test(html);
const t3d = /#page11\s+\.bnd-summary\s+table/.test(html);
const t3e = /\.bnd-cls-strong/.test(html);
const t3f = /\.bnd-cls-moderate/.test(html);
const t3g = /\.bnd-cls-weak/.test(html);
const t3h = /\.bnd-cls-ambiguous/.test(html);
const t3i = /\.bnd-anchor/.test(html);
const t3j = /\.bnd-cur\b/.test(html);
console.log('  .bnd-toolbar:', t3a);
console.log('  .bnd-radius-btn.active:', t3b);
console.log('  .bnd-zone:', t3c);
console.log('  .bnd-summary table:', t3d);
console.log('  .bnd-cls-strong:', t3e, '/moderate:', t3f, '/weak:', t3g, '/ambiguous:', t3h);
console.log('  .bnd-anchor + .bnd-cur:', t3i, t3j);
check('test3', t3a && t3b && t3c && t3d && t3e && t3f && t3g && t3h && t3i && t3j);

// =============================================================================
// TEST 4: _bndCloneRecord deep-copies and isolates
// =============================================================================
console.log('\n--- TEST 4: _bndCloneRecord ---');
const original = {
  zone_start_bp: 100, zone_end_bp: 200,
  score: 0.75, support: ['pca_drop', 'ghsl_step'],
  support_class: 'strong', source: 'auto',
  sv_anchors_in_zone: [{ kind: 'DELLY_INV', pos_bp: 150 }],
  notes: 'test', set_at: '2026-04-28T00:00:00Z', set_by: 'scrubber_auto',
};
const cloned = M._bndCloneRecord(original);
const t4a = cloned.zone_start_bp === 100 && cloned.score === 0.75;
// Mutate original and confirm cloned is unchanged
original.support.push('mutation');
original.sv_anchors_in_zone[0].kind = 'MUTATED';
const t4b = cloned.support.length === 2;
const t4c = cloned.sv_anchors_in_zone[0].kind === 'DELLY_INV';
// null → null
const t4d = M._bndCloneRecord(null) === null;
console.log('  basic clone:', t4a);
console.log('  support[] is independent copy:', t4b);
console.log('  sv_anchors are independent copies:', t4c);
console.log('  null → null:', t4d);
check('test4', t4a && t4b && t4c && t4d);

// =============================================================================
// TEST 5: _bndFindCandidate by id or candidate_id
// =============================================================================
console.log('\n--- TEST 5: _bndFindCandidate ---');
M.state.candidateList = [
  { id: 1, candidate_id: 1, chrom: 'X', start_bp: 100, end_bp: 200 },
  { candidate_id: 5, chrom: 'X', start_bp: 300, end_bp: 400 },   // no `id`
  { id: 10, chrom: 'X', start_bp: 500, end_bp: 600 },             // no `candidate_id`
];
const t5a = M._bndFindCandidate(1) === M.state.candidateList[0];
const t5b = M._bndFindCandidate(5) === M.state.candidateList[1];
const t5c = M._bndFindCandidate(10) === M.state.candidateList[2];
const t5d = M._bndFindCandidate(99) === null;
const t5e = M._bndFindCandidate(null) === null;
console.log('  by id (1):', t5a);
console.log('  by candidate_id (5, no id):', t5b);
console.log('  by id (10, no candidate_id):', t5c);
console.log('  not found → null:', t5d);
console.log('  null arg → null:', t5e);
check('test5', t5a && t5b && t5c && t5d && t5e);

// =============================================================================
// TEST 6: _bndStageFromCandidate populates staging
// =============================================================================
console.log('\n--- TEST 6: _bndStageFromCandidate ---');
M.state.__boundaries = null;
const candWithBoundaries = {
  id: 42, chrom: 'X', start_bp: 1000, end_bp: 2000,
  boundary_left: {
    zone_start_bp: 950, zone_end_bp: 990,
    score: 0.7, support: ['pca_drop'],
    support_class: 'weak', source: 'auto',
    sv_anchors_in_zone: [], notes: '', set_at: 't', set_by: 'scrubber_auto',
  },
  boundary_right: null,
  breakpoint_status: 'SV_supported',
  boundary_notes: 'reviewed',
};
M._bndStageFromCandidate(candWithBoundaries);
const bs = M._ensureBoundariesState();
const t6a = bs.staging.cand_id === 42;
const t6b = bs.staging.boundary_left && bs.staging.boundary_left.zone_start_bp === 950;
const t6c = bs.staging.boundary_right === null;
const t6d = bs.staging.breakpoint_status === 'SV_supported';
const t6e = bs.staging.boundary_notes === 'reviewed';
const t6f = bs.staging.dirty === false;
// Empty cand → reset to defaults
M._bndStageFromCandidate(null);
const t6g = bs.staging.cand_id === null && bs.staging.boundary_left === null
  && bs.staging.breakpoint_status === 'boundary_zone_only';
console.log('  cand_id:', t6a);
console.log('  boundary_left preserved:', t6b);
console.log('  null right preserved:', t6c);
console.log('  breakpoint_status:', t6d);
console.log('  notes:', t6e);
console.log('  dirty=false after stage:', t6f);
console.log('  null cand → defaults:', t6g);
check('test6', t6a && t6b && t6c && t6d && t6e && t6f && t6g);

// =============================================================================
// TEST 7: _bndAutoPropose populates staging when layers present
// =============================================================================
console.log('\n--- TEST 7: _bndAutoPropose end-to-end ---');
// Build state.data with windows + pve1 + ghsl_panel (same as turn-1 e2e shape)
const N_WIN = 200;
const WIN_BP = 20000;
const windows = { start_bp: new Array(N_WIN), end_bp: new Array(N_WIN) };
for (let i = 0; i < N_WIN; i++) {
  windows.start_bp[i] = i * WIN_BP;
  windows.end_bp[i]   = (i + 1) * WIN_BP - 1;
}
// Inversion at windows 80-130 (1.6-2.6 Mb)
const trueLeft = 80, trueRight = 130;
const buildSig = (inside, outside, noise) => {
  const a = new Array(N_WIN);
  for (let i = 0; i < N_WIN; i++) {
    let base;
    if (i < trueLeft - 4) base = outside;
    else if (i < trueLeft) { const t = (i - (trueLeft - 4)) / 4; base = outside + t * (inside - outside); }
    else if (i <= trueRight) base = inside;
    else if (i <= trueRight + 4) { const t = (i - trueRight) / 4; base = inside + t * (outside - inside); }
    else base = outside;
    a[i] = base + (Math.random() - 0.5) * 2 * noise;
  }
  return a;
};
windows.pve1 = buildSig(0.55, 0.10, 0.02);
windows.band_continuity_score = buildSig(0.40, 0.90, 0.03);
M.state.data = {
  windows,
  ghsl_panel: { div_median: buildSig(0.50, 0.10, 0.02) },
  n_bp: N_WIN * WIN_BP,
};
M.state.candidateList = [{ id: 7, chrom: 'X', start_bp: 1600000, end_bp: 2600000 }];
M.state.__boundaries = null;
M._bndSelectCandidate(7);
M._bndAutoPropose();
const bs7 = M._ensureBoundariesState();
const t7a = bs7.staging.boundary_left !== null;
const t7b = bs7.staging.boundary_right !== null;
const t7c = bs7.staging.dirty === true;
const t7d = bs7.staging.boundary_left.source === 'auto'
         && bs7.staging.boundary_right.source === 'auto';
const t7e = bs7.staging.boundary_left.support.length >= 2
         && bs7.staging.boundary_right.support.length >= 2;
console.log('  left set:', t7a);
console.log('  right set:', t7b);
console.log('  dirty=true:', t7c);
console.log('  source=auto:', t7d);
console.log('  multi-track support:', t7e,
            'L=' + JSON.stringify(bs7.staging.boundary_left.support),
            'R=' + JSON.stringify(bs7.staging.boundary_right.support));
check('test7', t7a && t7b && t7c && t7d && t7e);

// =============================================================================
// TEST 8: _bndReset clears, _bndSave persists
// =============================================================================
console.log('\n--- TEST 8: reset + save ---');
// Continue from test 7's state (cand 7 with auto boundaries staged)
M._bndSave();   // persist
const cand7 = M._bndFindCandidate(7);
const t8a = cand7.boundary_left && cand7.boundary_left.score > 0;
const t8b = cand7.boundary_right && cand7.boundary_right.score > 0;
const t8c = cand7.breakpoint_status === 'boundary_zone_only';
const t8d = bs7.staging.dirty === false;   // saved → no longer dirty
// Reset clears staging, marks dirty
M._bndReset();
const t8e = bs7.staging.boundary_left === null && bs7.staging.boundary_right === null;
const t8f = bs7.staging.dirty === true;
// But the persisted candidate is still set (reset only touches staging)
const t8g = cand7.boundary_left !== null;
console.log('  saved boundary_left:', t8a);
console.log('  saved boundary_right:', t8b);
console.log('  saved status:', t8c);
console.log('  dirty=false after save:', t8d);
console.log('  reset clears staging:', t8e);
console.log('  dirty=true after reset:', t8f);
console.log('  reset does NOT touch persisted cand:', t8g);
check('test8', t8a && t8b && t8c && t8d && t8e && t8f && t8g);

// =============================================================================
// TEST 9: tab-switch hook + attach/detach grep
// =============================================================================
console.log('\n--- TEST 9: tab-switch hook ---');
const t9a = /target === 'page11'/.test(html);
const t9b = /renderBoundariesPage\s*\(\s*\)/.test(html);
const t9c = /_bndAttachHotkeys\s*\(\s*\)/.test(html);
const t9d = /_bndDetachHotkeys\s*\(\s*\)/.test(html);
console.log('  tab handler tests target === page11:', t9a);
console.log('  renderBoundariesPage called:', t9b);
console.log('  _bndAttachHotkeys called:', t9c);
console.log('  _bndDetachHotkeys called:', t9d);
check('test9', t9a && t9b && t9c && t9d);

// =============================================================================
// TEST 10: hotkey routing + suppression rules
// =============================================================================
console.log('\n--- TEST 10: _bndKeyHandler ---');
// We verify the handler's logic via grep against the source — replacing
// the closured action handlers in tests is brittle since they're captured
// at script-eval time. Source-grep is sufficient for the routing contract.
// Match the whole _bndKeyHandler function body via lazy regex.
const fnBody = (html.match(/function _bndKeyHandler[\s\S]*?\n\}/) || [''])[0];
const t10a = /_bndOverrideLeft\(\)/.test(fnBody);
const t10b = /_bndOverrideRight\(\)/.test(fnBody);
const t10c = /_bndAutoPropose\(\)/.test(fnBody);
const t10d = /_bndSave\(\)/.test(fnBody);
const t10e = /_bndReset\(\)/.test(fnBody);
// Suppression rules (matched against fnBody, not whole html, so they're scoped)
const t10f = /INPUT\|TEXTAREA\|SELECT/.test(fnBody);
const t10g = /e\.ctrlKey\s*\|\|\s*e\.metaKey\s*\|\|\s*e\.altKey/.test(fnBody);
console.log('  E → _bndOverrideLeft:', t10a);
console.log('  F → _bndOverrideRight:', t10b);
console.log('  A → _bndAutoPropose:', t10c);
console.log('  B → _bndSave:', t10d);
console.log('  R → _bndReset:', t10e);
console.log('  suppress when input focused:', t10f);
console.log('  suppress on Ctrl/Meta/Alt:', t10g);
// Attach idempotency: count keydown listeners specifically (other modules
// may have added click etc. listeners during script-load).
const initialKeydown = M._addedListeners.filter(L => L.kind === 'keydown').length;
M._bndDetachHotkeys();   // ensure clean start
const cleanKeydown = M._addedListeners.filter(L => L.kind === 'keydown').length;
M._bndAttachHotkeys();
const after1 = M._addedListeners.filter(L => L.kind === 'keydown').length;
M._bndAttachHotkeys();   // should be no-op
const after2 = M._addedListeners.filter(L => L.kind === 'keydown').length;
const t10h = (after1 === cleanKeydown + 1) && (after2 === after1);
M._bndDetachHotkeys();
const after3 = M._addedListeners.filter(L => L.kind === 'keydown').length;
const t10i = (after3 === cleanKeydown);
console.log('  initial keydown listeners:', initialKeydown, '→ clean:', cleanKeydown);
console.log('  attach idempotent (added 1, second is no-op):', t10h, '(after1=' + after1 + ', after2=' + after2 + ')');
console.log('  detach removes the listener:', t10i, '(after3=' + after3 + ')');
check('test10', t10a && t10b && t10c && t10d && t10e && t10f && t10g && t10h && t10i);

// =============================================================================
// SUMMARY
// =============================================================================
console.log(`\n--- v3.97 turn 2 tests: ${totalPass}/${totalPass + totalFail} ---`);
if (totalFail > 0) process.exit(1);
