# Handoff — scrubber v3.97 turn 2 (2026-04-28)

## Where we are

**Current head:** `pca_scrubber_v3.html` v3.97 (1067 KB, 23,037 lines).
**SCHEMA:** `SCHEMA_V2.md` v2.8 (94 KB, 2,026 lines, unchanged this turn).
**Tests:** 571/571 passing (49 + 522 carried forward).
**End-to-end checks:** 51 across two scripts.

This handoff covers v3.97 turn 2 — page DOM + tracks + hotkeys + action
handlers. Builds on turn 1's pure helpers. Turn 3 (TSV column emission,
final polish) remains. Prior:

- v3.97 turn 1 (helpers) in `HANDOFF_v3_97_turn1.md`
- v3.96 (hover tooltips) in `HANDOFF_v3_96.md`
- Schema 2.8 §12 in `SCHEMA_V2.md`

## Work shipped this chat (v3.97 turn 2)

### Page 11 ("3 boundaries") — full UI

A new dedicated page wedged between candidate-focus (page 2) and
catalogue, displayed as tab "3 boundaries". The whole tab numbering
shifts: catalogue is now "4", karyotype "5", popstats "6", ancestry
"7", windows "8", confirmed "9", markers "10", help "11". Internal
`data-page` IDs unchanged — only display labels.

Page DOM:

- **Toolbar** — candidate `<select>` with ✓ glyph for candidates that
  already have boundaries; scan-radius button group (1 / 1.5 / 2 / 5 Mb,
  active state styled with `--accent`); 5 action buttons (auto-propose,
  override left, override right, reset, save) and a status `<select>`
  (boundary_zone_only / SV_supported / junction_supported).
- **Info banner** — current candidate id, chrom, interval, span Mb, and
  a dirty marker `(unsaved)` when staging has uncommitted changes; also
  shows current support_class colors when boundaries are set.
- **Tracks container** — stacked SVG sparklines for each present track,
  plus a combined-score track at the bottom (green for left signal, red
  for right). Boundary zones drawn as shaded vertical bands across the
  whole track stack, color-coded by `support_class`. Anchor lines (faint
  dotted) mark the candidate's pre-existing `[start_bp, end_bp]` interval
  — the *anchor* the boundary zones refine *from*. A solid accent
  vertical at `state.cur` shows the current cursor.
- **Summary table** — left/right edge details side-by-side: zone bp range,
  score, support tracks, support_class (color-coded), source (auto/
  manual/auto_plus_manual), SV anchors in zone.

### 17 new functions

Page-builder + UI-refresh:

- `renderBoundariesPage()` — top-level driver; idempotent (re-runs cleanly)
- `_bndPopulateCandidateSelect()` — fills `<select>` with promoted candidates,
  ✓ glyph for those with boundaries
- `_bndUpdateRadiusButtons()` — reflects `bs.scan_radius_bp` on the button group
- `_bndUpdateSaveButton()` — disables when no candidate selected; `dirty` class
  when staging has uncommitted changes
- `_bndUpdateStatusSelect()` — syncs the status `<select>` with staging
- `_bndRefreshSummary()` — renders info banner + summary table from staging
- `_bndDrawTracks()` — stacked SVG track stack + zone overlays + anchors + cursor
- `_bndRefreshUI()` — top-level refresh (summary + tracks + buttons)

Action handlers:

- `_bndSelectCandidate(candId)` — load existing boundaries from candidate or empty
- `_bndAutoPropose()` — runs the turn-1 algorithm; populates staging; cache result
- `_bndOverrideLeft()` / `_bndOverrideRight()` / `_bndManualOverride(side)` —
  manual edge at `state.cur`; computes per-track contributions at the chosen
  window; sets `source: manual` (or `auto_plus_manual` if other side was auto)
- `_bndReset()` — clear both edges; status reverts; dirty=true
- `_bndSave()` — persist staging onto `state.candidateList[i].boundary_left/right`
  (independent deep copies; staging mutations don't bleed back); dirty=false

Hotkey infrastructure:

- `_bndKeyHandler(e)` — page-scoped routing for E/F/B/R/A
- `_bndAttachHotkeys()` / `_bndDetachHotkeys()` — idempotent attach/detach
  on `document` for `keydown`; flag-guarded against double-attach

Helpers:

- `_bndFindCandidate(candId)` — looks up by `id` OR `candidate_id`
- `_bndFmtBp(n)` — re-uses v3.96 `_fmtBp` with " bp" suffix
- `_bndCloneRecord(rec)` — deep-copies a boundary record (so staging
  mutations don't bleed into the persisted candidate)
- `_bndStageFromCandidate(cand)` — populate staging from candidate or empty;
  always sets dirty=false

### Hotkeys (page-scoped)

| Key | Action | Suppressed when... |
|---|---|---|
| **E** | Override LEFT boundary at cursor | input has focus, OR Ctrl/Meta/Alt held |
| **F** | Override RIGHT boundary at cursor | input has focus, OR Ctrl/Meta/Alt held |
| **A** | Auto-propose | input has focus, OR Ctrl/Meta/Alt held |
| **B** | Save (persist staging → candidate) | input has focus, OR Ctrl/Meta/Alt held |
| **R** | Reset (clear staging) | input has focus, OR Ctrl/Meta/Alt held |

Hotkeys fire only when page 11 is active (checked via `classList.contains('active')`).
Attached via the tab-switch handler when target === 'page11'; detached
on any other tab. Suppressed inside text-entry controls and on
modifier-key combos (so the browser's own shortcuts work).

### CSS

13 new CSS rule blocks under `#page11`:

- `.bnd-toolbar`, `.bnd-toolbar select`, `.bnd-toolbar button` (regular,
  primary, dirty states)
- `.bnd-radius-group`, `.bnd-radius-btn`, `.bnd-radius-btn.active`
- `.bnd-status-wrap`
- `.bnd-info` (with color-coded support-class spans)
- `.bnd-tracks`, `.bnd-track`, `.bnd-track-label`, `.bnd-track svg`
- `.bnd-zone` (absolute-positioned vertical band, color from inline style)
- `.bnd-zone-label` (floating text label inside zone)
- `.bnd-anchor` (faint dotted vertical at candidate's start/end_bp)
- `.bnd-cur` (solid accent vertical at state.cur)
- `.bnd-summary table`, `th`, `td`, `td.bnd-cls` (with .bnd-cls-strong/
  /moderate/weak/ambiguous color modifiers, matching schema palette)
- `.bnd-empty`, `.bnd-empty-h` (placeholder when no candidate or no layers)

### Tests (10 new in `test_v397t2.js`)

1. `SCRUBBER_VERSION` v3.97+
2. Tab button HTML present + `#page11` DOM section + renumbered tabs
   (markers → "10", help → "11")
3. CSS rules present (.bnd-toolbar, .bnd-radius-btn.active, .bnd-zone,
   .bnd-summary table, all 4 .bnd-cls-* color modifiers, .bnd-anchor,
   .bnd-cur)
4. `_bndCloneRecord` deep-copies; mutating original does not bleed into
   clone (4 sub-cases including null → null)
5. `_bndFindCandidate` looks up by `id` OR `candidate_id` (5 sub-cases)
6. `_bndStageFromCandidate` populates staging from existing boundary
   fields; null cand → defaults (7 sub-cases)
7. `_bndAutoPropose` end-to-end on synthetic candidate with 4 evidence
   layers — sets staging; dirty=true; multi-track support
8. `_bndReset` clears staging; `_bndSave` persists; reset does NOT
   touch persisted candidate (7 sub-cases)
9. Tab-switch hook present (grep): tests target === 'page11', calls
   renderBoundariesPage + attach/detach
10. `_bndKeyHandler` routes E/F/A/B/R; suppression rules in place;
    `_bndAttachHotkeys` is idempotent; `_bndDetachHotkeys` removes (9 sub-cases)

All 49 prior + 10 new tests pass: **49/49** in turn 1+2; total **571/571**
across all suites.

### End-to-end lifecycle test (`end_to_end_boundaries_lifecycle.js`)

29 checks across 8 phases simulating a complete user workflow:

1. Select candidate → auto-propose → both edges set, source=auto, dirty=true
2. Save (B) → persisted left/right; staging.dirty=false; persisted record
   is independent of staging (verified by mutating staging post-save)
3. Manual override left at cursor (E) → source becomes `auto_plus_manual`
   (because right was previously auto-set), set_by=scrubber_manual, zone
   centered on `state.cur ± 5` windows
4. Save then reset (R) → reset clears staging; dirty=true; status reverts;
   persisted record survives reset until save; after save, persisted is cleared
5. Re-run auto (A) → repopulates staging fresh
6. Status promotion to SV_supported → persisted on save
7. Candidate selector ✓ glyph runs without error
8. scan_radius_bp change invalidates cache; auto-propose repopulates

29/29 pass. The whole user workflow is exercised.

## Notable design decisions

- **Independent persisted records.** `_bndSave` deep-copies staging via
  `_bndCloneRecord` before assigning to `cand.boundary_left/right`.
  Confirmed by lifecycle test phase 2: mutating `bs.staging.boundary_left`
  AFTER save does NOT change the persisted candidate. This is the contract
  that lets users press Save then continue editing without fear of
  retroactive mutation.
- **Manual override sets `source` based on prior state.** If the OTHER
  side is unset or has source=manual, the new override is `manual`. If
  the other side has source=auto, the new override is `auto_plus_manual`
  — flagging that the candidate has mixed provenance. This matches the
  schema's three-value source enum.
- **Reset does NOT touch persisted candidate.** Reset clears staging
  only; the persisted record on the candidate stays until the user saves
  the cleared staging. This protects against accidental data loss.
- **scan_radius_bp change invalidates cache.** Different radii produce
  different scan ranges, which produce different track scores. The cache
  is keyed on `cand_id` only (not `(cand_id, radius)`), so the radius-
  button click handler explicitly invalidates the cache for the active
  candidate. Confirmed by lifecycle test phase 8.
- **`_bndDrawTracks` reads from cache, falls back to recompute.** The
  cache is populated by auto-propose (turn 1's `_buildBoundaryTrackScores`
  + `_computeBoundaryEdges`). `_bndDrawTracks` checks cache freshness
  (start/end_bp must match), recomputes if stale. This means switching
  candidates is fast on revisit (cache hit), and the redraw doesn't have
  to know whether the user just ran auto or just changed candidate.
- **No prompt on tab leave with dirty staging.** v3.97 turn 2 ships
  without a "save changes?" prompt when leaving page 11 with
  `staging.dirty=true`. Reasoning: the spec mentions this as future work,
  and forcing it now would interrupt the multi-session pragmatic working
  style. The dirty flag is visible (banner + Save button border), so
  users have feedback. Add the prompt in turn 3 if Quentin requests it.
- **Tab-switch handler hooks page show AND every other tab.** Detach
  fires on any tab that isn't page11. Idempotent — no harm if fired when
  already detached.
- **Empty states are descriptive.** When no candidate is selected:
  "Pick a promoted candidate from the toolbar to refine its boundary
  zones." When no layers loaded: "Auto-propose needs at least one of:
  precomp PVE1, band-continuity, GHSL panel, dosage_chunks,
  candidate_marker_polarity, or boundary_evidence. Use manual override
  (E / F at cursor) to annotate from PCA alone." This is informative for
  Quentin AND for any future user opening the scrubber on incomplete data.

## Outstanding items (turn 3 + beyond)

### Turn 3 — TSV column emission

- Add 14 new columns to `REGISTRY_TSV_COLUMNS` per schema §12 in the
  documented order (between `subband_nesting_status` block and `qc_status`)
- Helper `_boundaryColsFromCand(c)` returning 14 string values with `''`
  for missing
- Update `_registryRowsForCandidates` to call the helper
- 4-5 unit tests covering: column count delta, populated row, missing-
  values row, pipe-separated `support` formatting

Estimate: ~150 LOC + ~80 LOC tests. Half-turn increment.

### Optional polish (not on critical path)

- Save-changes prompt when leaving page 11 with dirty staging
- Re-render tracks on `setCur` (currently the cursor line doesn't move
  until next page revisit; could update via debounced redraw on cursor
  change)
- Window-radius UI: per-edge zone radius slider (currently fixed at ±5)
- Per-track polarity override (e.g. when a track's signal direction is
  inverted relative to default)
- Boundary-history sibling array for QC ("show what auto would have
  proposed if I hadn't manually overridden")

### Long-running parked

- `STEP_M06_emit_boundary_evidence.R` — R-side emit of the optional
  boundary_evidence layer (FST + theta-pi + discordant-pair + SV anchors)
- v3.92 R-side parked items unchanged

## Key v3.97 turn 2 functions (reference for next chat)

### Page DOM + render
- `renderBoundariesPage()` — top-level page builder
- `_bndPopulateCandidateSelect()` — populate `<select>` with promoted candidates
- `_bndDrawTracks()` — stacked SVG tracks + overlays
- `_bndRefreshSummary()` — info banner + summary table
- `_bndRefreshUI()` — full refresh

### Action handlers
- `_bndSelectCandidate(candId)` — load existing boundaries
- `_bndAutoPropose()` — run algorithm
- `_bndOverrideLeft()` / `_bndOverrideRight()` — manual override at cursor
- `_bndReset()` — clear staging
- `_bndSave()` — persist to candidate

### Hotkeys
- `_bndKeyHandler(e)` — keydown router
- `_bndAttachHotkeys()` / `_bndDetachHotkeys()` — idempotent

### Helpers
- `_bndFindCandidate(candId)`
- `_bndCloneRecord(rec)`
- `_bndStageFromCandidate(cand)`
- `_bndManualOverride(side)`

## SCHEMA_V2.md status

**Unchanged this turn** — still v2.8. Turn 2 implements the schema 2.8
contract; no schema changes needed.

## File staging at /mnt/user-data/outputs/

- **pca_scrubber_v3.html** — v3.97, 1067 KB, 23,037 lines
- **SCHEMA_V2.md** — v2.8 (unchanged from turn 1), 94 KB, 2,026 lines
- **test_v397.js** — turn 1 (10 tests), unchanged
- **test_v397t2.js** — turn 2, 10 tests, ~290 lines
- **end_to_end_boundaries_check.js** — turn 1 e2e (22 checks), unchanged
- **end_to_end_boundaries_lifecycle.js** — turn 2 e2e (29 checks), new
- **HANDOFF_v3_97_turn2.md** — this file

## Suggested entry point for next chat

**v3.97 turn 3** — TSV column emission. The smallest of the three turns
(~150 LOC). Once shipped, candidates with boundary annotations export
correctly to the catalogue TSV and downstream R scripts can read the
14 new columns.

If the user prefers real-data validation first: load v3.95's R-side
outputs (STEP_M04 / STEP_M05 LG28 chunks + step29 layers), open the
scrubber, navigate to page 3 (boundaries), pick a real LG28 candidate,
and try auto-propose + manual override. The page will exercise:
- Real chr_meta windows (not synthetic)
- Real precomp PVE1 + band continuity from STEP_C01a output
- Real GHSL panel
- Real polarity layer (from STEP29 if loaded)

Visual check: do the proposed zones land on biologically-sensible
transitions? Does the support_class color-coding feel calibrated?
Are the default weights (0.20 / 0.18 / 0.14 / 0.12 / ...) producing
the right balance? These are tuning questions that only become legible
on real cohort data.

## User working style notes

(Unchanged.)

"Continue" = proceed with next agreed item. This chat shipped v3.97
turn 2; turn 3 (TSV columns) is the natural next step. Real-data
validation is also valuable here — turn 2 is the first real visible UI
of v3.97, and seeing it on the 226-sample LG28 cohort will inform
whether the default weights need tuning.

Three catfish cohorts that must NEVER be conflated:
1. F1 hybrid (*C. gariepinus* × *C. macrocephalus*) — genome assembly
   paper only
2. 226-sample pure *C. gariepinus* hatchery cohort — current inversion
   work, "MS_Inversions_North_african_catfish" — K clusters reflect
   broodline structure, NOT species admixture
3. Pure *C. macrocephalus* wild cohort — future paper

User's full name is Quentin Andres. Never invent a surname.
