#!/usr/bin/env node
// End-to-end test for v3.97 turn 2: full lifecycle of boundary annotation
// on a candidate. Auto-propose → save → manual override → save → reset → save.

const M = require('/tmp/scrubber_test_v397t2.js');

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('ok:   ' + msg); pass++; }
  else      { console.log('FAIL: ' + msg); fail++; }
}

// =============================================================================
// Build a synthetic 30 Mb chromosome with a clear inversion at 12-14 Mb
// =============================================================================
const N_WIN = 1500;
const WIN_BP = 20000;
const windows = { start_bp: new Array(N_WIN), end_bp: new Array(N_WIN) };
for (let i = 0; i < N_WIN; i++) {
  windows.start_bp[i] = i * WIN_BP;
  windows.end_bp[i]   = (i + 1) * WIN_BP - 1;
}
const trueLeft = 595, trueRight = 710;

let _seed = 7;
const rng = () => { _seed = (_seed * 16807) % 2147483647; return _seed / 2147483647; };

function buildSig(inside, outside, noise, leftW, rightW) {
  const a = new Array(N_WIN);
  for (let i = 0; i < N_WIN; i++) {
    let base;
    if (i < trueLeft - leftW) base = outside;
    else if (i < trueLeft) { const t = (i - (trueLeft - leftW)) / leftW; base = outside + t * (inside - outside); }
    else if (i <= trueRight) base = inside;
    else if (i <= trueRight + rightW) { const t = (i - trueRight) / rightW; base = inside + t * (outside - inside); }
    else base = outside;
    a[i] = base + (rng() - 0.5) * 2 * noise;
  }
  return a;
}

windows.pve1 = buildSig(0.55, 0.10, 0.03, 5, 6);
windows.band_continuity_score = buildSig(0.40, 0.90, 0.04, 5, 6);
const ghsl_div_median = buildSig(0.50, 0.10, 0.03, 5, 6);

M.state.data = { windows, ghsl_panel: { div_median: ghsl_div_median }, n_bp: 30000000 };
M.state.candidateList = [
  { id: 100, chrom: 'C_gar_LG28', start_bp: 12000000, end_bp: 14000000 },
];
M.state.cur = trueLeft + 12;   // simulating cursor near (but not at) the left edge
M.state.__boundaries = null;

// =============================================================================
// Lifecycle: select → auto-propose → save → manual override → save
//            → reset → save → auto again
// =============================================================================

console.log('--- Phase 1: select + auto-propose ---');
M._bndSelectCandidate(100);
const bs = M._ensureBoundariesState();
ok(bs.active_cand_id === 100, 'active_cand_id set');
ok(bs.staging.boundary_left === null, 'staging starts empty (no prior boundaries)');

M._bndAutoPropose();
ok(bs.staging.boundary_left !== null,  'auto-propose set left');
ok(bs.staging.boundary_right !== null, 'auto-propose set right');
ok(bs.staging.dirty === true,          'dirty after auto');
ok(bs.staging.boundary_left.source === 'auto', 'left source=auto');

const autoLeftZone  = bs.staging.boundary_left.zone_start_bp;
const autoRightZone = bs.staging.boundary_right.zone_start_bp;
console.log(`auto-detected left  zone start: ${autoLeftZone}`);
console.log(`auto-detected right zone start: ${autoRightZone}`);

console.log('\n--- Phase 2: save (B) ---');
M._bndSave();
const cand = M._bndFindCandidate(100);
ok(cand.boundary_left  !== null, 'persisted left');
ok(cand.boundary_right !== null, 'persisted right');
ok(cand.boundary_left.zone_start_bp === autoLeftZone, 'persisted left zone matches auto');
ok(bs.staging.dirty === false,   'dirty cleared after save');

// Ensure the persisted record is independent of staging (so future
// mutations to staging don't bleed back into the candidate)
const persistedLeftZone = cand.boundary_left.zone_start_bp;
bs.staging.boundary_left.zone_start_bp = -999;   // mutate staging
ok(cand.boundary_left.zone_start_bp === persistedLeftZone,
   'persisted record is independent of staging mutations');

console.log('\n--- Phase 3: manual override left (E) ---');
// Move cursor to a different window and manually override left
M.state.cur = 590;   // 5 windows left of trueLeft
M._bndOverrideLeft();
ok(bs.staging.boundary_left.source === 'manual'
  || bs.staging.boundary_left.source === 'auto_plus_manual',
   `manual override sets source (got ${bs.staging.boundary_left.source})`);
ok(bs.staging.boundary_left.set_by === 'scrubber_manual', 'set_by=scrubber_manual');
ok(bs.staging.dirty === true, 'dirty after manual override');
// The new zone should be centered on state.cur=590, ±5 windows
const expectedLo = windows.start_bp[Math.max(0, 590 - 5)];
const expectedHi = windows.end_bp[Math.min(N_WIN - 1, 590 + 5)];
ok(bs.staging.boundary_left.zone_start_bp === expectedLo
  && bs.staging.boundary_left.zone_end_bp === expectedHi,
   `manual override zone centered on state.cur ([${expectedLo}, ${expectedHi}])`);

console.log('\n--- Phase 4: save then reset (R) ---');
M._bndSave();
ok(cand.boundary_left.set_by === 'scrubber_manual', 'persisted manual-override status');
M._bndReset();
ok(bs.staging.boundary_left === null && bs.staging.boundary_right === null,
   'reset clears both edges');
ok(bs.staging.dirty === true, 'dirty after reset');
ok(bs.staging.breakpoint_status === 'boundary_zone_only',
   'status reverts to default after reset');
// Persisted candidate is NOT touched until save
ok(cand.boundary_left !== null, 'persisted record survives reset (until save)');
M._bndSave();
ok(cand.boundary_left === null && cand.boundary_right === null,
   'after save, persisted record is cleared');

console.log('\n--- Phase 5: re-run auto (A) ---');
M._bndAutoPropose();
ok(bs.staging.boundary_left  !== null, 're-auto sets left again');
ok(bs.staging.boundary_right !== null, 're-auto sets right again');
ok(bs.staging.boundary_left.source === 'auto', 're-auto: source=auto');

console.log('\n--- Phase 6: status promotion (boundary_zone_only → SV_supported) ---');
bs.staging.breakpoint_status = 'SV_supported';
bs.staging.dirty = true;
M._bndSave();
ok(cand.breakpoint_status === 'SV_supported', 'promoted status persisted');

console.log('\n--- Phase 7: candidate selector reflects ✓ ---');
// _bndPopulateCandidateSelect should mark candidate 100 with ✓ now.
// We can't easily inspect the select element in node, but we can call
// the function and confirm it doesn't throw.
M._bndPopulateCandidateSelect();
ok(true, 'populate select runs without error');

// =============================================================================
// Phase 8: scan_radius_bp change invalidates cache
// =============================================================================
console.log('\n--- Phase 8: scan_radius_bp change ---');
M.state.cur = trueLeft + 12;
const cacheBefore = bs.cache.has(100);
ok(cacheBefore, 'cache populated by auto-propose');
bs.scan_radius_bp = 2000000;   // change radius
bs.cache.delete(100);          // (simulated by toolbar handler — verified
                                //  in test_v397t2.js test 9 via the wiring)
ok(!bs.cache.has(100), 'cache invalidated when radius changes');
M._bndAutoPropose();
ok(bs.cache.has(100), 'cache repopulated by re-running auto');

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
