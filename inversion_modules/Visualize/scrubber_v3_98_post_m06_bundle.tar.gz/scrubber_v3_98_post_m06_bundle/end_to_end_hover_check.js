#!/usr/bin/env node
// End-to-end: pull the REAL hover helpers from the v3.96 HTML and run
// them on a chunk produced by STEP_M04. Verifies that the schema-spec'd
// tooltip pipeline functions correctly with R-side outputs.

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const html = fs.readFileSync('/home/claude/work/pca_scrubber_v3.html', 'utf8');

function extractFn(src, name) {
  const fnRe = new RegExp(`function ${name}\\s*\\(`);
  const m = src.match(fnRe);
  if (!m) throw new Error(`function ${name} not found`);
  let i = m.index;
  const open = src.indexOf('{', i);
  let depth = 0, j = open;
  for (; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) { j++; break; } }
  }
  return src.slice(i, j);
}
function extractConst(src, name) {
  const re = new RegExp(`const ${name}\\s*=\\s*\\{`);
  const m = src.match(re);
  if (!m) throw new Error(`const ${name} not found`);
  let i = m.index, open = src.indexOf('{', i);
  let depth = 0, j = open;
  for (; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) { j++; break; } }
  }
  if (src[j] === ';') j++;
  return src.slice(i, j);
}

const ctx = {};
vm.createContext(ctx);
vm.runInContext(extractConst(html, 'DOSAGE_HEATMAP_DEFAULTS'), ctx);
vm.runInContext(extractFn(html, 'selectTopMarkers'), ctx);
vm.runInContext(extractFn(html, 'orderSamplesByGroupAndPC1'), ctx);
vm.runInContext(extractFn(html, 'chunk_get'), ctx);
vm.runInContext(extractFn(html, '_fmtBp'), ctx);
vm.runInContext(extractFn(html, '_heatmapHitTest'), ctx);
vm.runInContext(extractFn(html, '_heatmapTooltipText'), ctx);

// Load a chunk produced by STEP_M04 (smoke-test output)
const chunkFile = '/home/claude/work/smoke_out/scrubber_data/TEST_LG01/TEST_LG01_dosage_chunk_390_779.json';
const chunk = JSON.parse(fs.readFileSync(chunkFile, 'utf8'));

console.log(`chunk: ${chunk.n_markers} markers × ${chunk.n_samples} samples`);
console.log(`region: bp ${chunk.region_start_bp}..${chunk.region_end_bp}`);

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('ok:   ' + msg); pass++; }
  else      { console.log('FAIL: ' + msg); fail++; }
}

// Build region for the full chunk
const region = { start_bp: chunk.region_start_bp, end_bp: chunk.region_end_bp };

// Use selectTopMarkers to get a real selection
const sel = ctx.selectTopMarkers(chunk, region, 200);
console.log(`selection: ${sel.selected_indices.length} markers (used_diagnostic_score=${sel.used_diagnostic_score})`);

// Build a realistic sample order — group=null, just use index order
const order = ctx.orderSamplesByGroupAndPC1(
  chunk.samples.length,
  () => null,
  (i) => i,
  ['HOMO_1', 'HET', 'HOMO_2']
);
ok(order.length === chunk.n_samples, `sample order length = ${chunk.n_samples}`);

// Synthetic layout matching what drawDosageHeatmap would produce on a
// 600×400 canvas with these dimensions.
const layout = {
  matX: 70, matY: 12,
  matW: 200, matH: 100,
  cellW: 200 / sel.selected_indices.length,
  cellH: 100 / order.length,
  LEFT: 70, TOP: 12,
};

// Hit-test the center of the first cell — should hit selection[0], order[0]
const cx = layout.matX + layout.cellW / 2;
const cy = layout.matY + layout.cellH / 2;
const hit0 = ctx._heatmapHitTest(layout, cx, cy, order, sel.selected_indices);
ok(hit0 !== null, `hit-test center of first cell returns non-null`);
ok(hit0.col === 0 && hit0.row === 0, `first cell → col=0 row=0`);
ok(hit0.marker_idx === sel.selected_indices[0],
   `marker_idx = ${sel.selected_indices[0]} (got ${hit0.marker_idx})`);
ok(hit0.sample_idx === order[0],
   `sample_idx = ${order[0]} (got ${hit0.sample_idx})`);

// Build tooltip text on this real hit
const fakeLk = {
  _groupOfSample: () => null,        // no group (bare-genome cursor mode)
  _qualityOfSample: () => null,      // no coherence layer loaded
};
const text0 = ctx._heatmapTooltipText(hit0, {
  chunk,
  lk: fakeLk,
  polarity: null,
  selected_marker_indices: sel.selected_indices,
});
console.log(`\ntooltip(real chunk, real hit): ${JSON.stringify(text0)}`);
ok(text0.length > 0, 'tooltip is non-empty');
ok(text0.includes(chunk.samples[hit0.sample_idx]),
   `tooltip contains sample id "${chunk.samples[hit0.sample_idx]}"`);
ok(text0.includes(chunk.markers[hit0.marker_idx].marker_id),
   `tooltip contains marker id "${chunk.markers[hit0.marker_idx].marker_id}"`);
ok(text0.includes(' bp'), 'tooltip contains " bp" suffix');
ok(/dosage=(\d|NA)/.test(text0), 'tooltip contains dosage=N or dosage=NA');
// 3 components: sample · marker(bp) · dosage  (no group, no quality, no flipped)
const components = text0.split(' · ');
ok(components.length === 3, `3 components when group/quality/polarity absent (got ${components.length})`);

// Hit a NA cell explicitly: find one
let naHit = null;
for (let mi_idx = 0; mi_idx < sel.selected_indices.length && !naHit; mi_idx++) {
  const mi = sel.selected_indices[mi_idx];
  for (let si = 0; si < chunk.samples.length; si++) {
    if (chunk.dosage[mi][si] === -1) {
      naHit = {
        marker_idx: mi, sample_idx: si,
        col: mi_idx, row: order.indexOf(si),
      };
      break;
    }
  }
}
if (naHit) {
  const naText = ctx._heatmapTooltipText(naHit, {
    chunk, lk: fakeLk, polarity: null,
    selected_marker_indices: sel.selected_indices,
  });
  console.log(`tooltip(NA cell):  ${JSON.stringify(naText)}`);
  ok(naText.includes('dosage=NA'), 'NA cell shows dosage=NA');
  ok(!naText.includes('-1'), 'NA sentinel -1 not exposed');
} else {
  console.log('(no NA cells in this selection — skipping NA test)');
}

// Out-of-matrix → null
ok(ctx._heatmapHitTest(layout, 5, 5, order, sel.selected_indices) === null,
   'out-of-matrix → null');

// Boundary case: cell exactly at matX+matW edge → null (right-exclusive)
ok(ctx._heatmapHitTest(layout, layout.matX + layout.matW, cy, order, sel.selected_indices) === null,
   'right edge (matX+matW) → null (exclusive)');

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
