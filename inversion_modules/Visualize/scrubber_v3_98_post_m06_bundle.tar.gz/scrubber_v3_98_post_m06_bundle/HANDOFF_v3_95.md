# Handoff — R-side dosage-heatmap unblock (post-v3.94, 2026-04-28)

## Where we are

**Scrubber head:** `pca_scrubber_v3.html` v3.94 (970 KB, 21,269 lines) — unchanged this chat.
**Schema:** `SCHEMA_V2.md` v2.6 — unchanged this chat.
**Tests:** 523/523 still passing (no scrubber-side changes).

This chat shipped two R-side emit scripts that unblock v3.94's dosage
heatmap module for real-data validation on the 226-sample LG28 cohort.
Once both scripts are run on the real data and the resulting JSONs are
loaded into the scrubber, v3.94's empty-placeholder behaviours light up
automatically — no scrubber changes needed.

The previous chat scoped itself to scrubber-only. This chat was
explicitly scoped to the opposite — R-side only — at user request.

## Work shipped this chat

### 1. STEP_M04_emit_dosage_chunks.R (new)

Per-chromosome emit of the dosage heatmap's data layer. Two output files
per chromosome:

- **Index JSON** (`<chrom>_dosage_chunks_index.json`) — small, registers
  with the scrubber as the `dosage_chunks` layer. Index shape matches
  the scrubber's detector at `pca_scrubber_v3.html:12787` exactly:
  `{ chrom, chunks: [{ start_bp, end_bp, url, n_markers }, ...] }`.
- **Per-chunk content JSONs** (`<chrom>_dosage_chunk_<start>_<end>.json`)
  — fetched on demand by the scrubber via the URL field. Content shape
  matches SCHEMA_V2 §10 "Dosage chunk file shape" verbatim.

**Key design decisions:**

- **Chunk boundaries align to L1 windows** (the same windows that drive
  the scrubber's `state.cur ± 5` cursor mode). Default 200 L1 windows
  per chunk, configurable via `--windows_per_chunk`. This guarantees
  the scrubber's overlap-fallback in `_findCoveringChunk` only triggers
  on candidate-bound regions that legitimately straddle chunks; cursor
  mode (~11 windows) almost always hits a single chunk.
- **NA encoded as -1** in the integer dosage rows — matches
  `selectTopMarkers` line 4949's NA handling exactly.
- **Diagnostic score is all-or-nothing per chrom.** If a marker
  catalogue is supplied via `--marker_catalogue` AND covers 100% of
  markers in the chrom, `diagnostic_score` is emitted on every marker.
  Anything less → column dropped, scrubber falls back to per-chunk
  variance ranking automatically. This matches `selectTopMarkers` line
  4934's "all-or-nothing" detection.
- **Marker `pos_bp` is parseable from `<chrom>_<pos>` or `<chrom>:<pos>`
  marker IDs** when no explicit position column is present, so the
  script accepts the dosage TSV format produced by both the inversion
  pipeline's STEP_C01a path and the marker-module pipeline.
- **Chunks are disjoint in coverage.** Within-chunk ranges are
  half-open `[s, e)` for all chunks except the last (which is `[s, e]`)
  to guarantee each marker lives in exactly one chunk. Verified by
  smoke test: 50 unique markers across 3 chunks, no double-counting.

**Required inputs:**

- `--dosage <chrom>.dos.tsv.gz` — one row per marker; first column
  `marker`/`marker_id` and/or `pos_bp`/`pos`; remaining columns one per
  sample with integer 0/1/2 or NA dosage.
- `--chr_meta <chrom>.chr_meta.tsv.gz` — output of STEP_A03 (or
  STEP09b-S1 in the inversion codebase v8.5). Must have `chrom`,
  `start_bp`, `end_bp` columns. Defines L1 boundaries.
- `--chrom <chrom>` — chromosome name; must match `chrom` in chr_meta.
- `--out_dir <dir>` — writes `<out_dir>/<chrom>/...`.

**Optional:**

- `--windows_per_chunk N` (default 200) — tunes chunk count vs size.
  Smaller = more chunks, smaller files, more HTTP fetches.
- `--marker_catalogue <tsv>` — joined for `diagnostic_score` (see
  above).
- `--samples <list.txt>` — explicit cohort sample order. Default uses
  the dosage TSV column header order.
- `--url_prefix <s>` — prepended to chunk URLs in the index. Default
  `<chrom>/`. Set to `""` if chunks are served from same dir.
- `--keep_marker_id 0` — drops the `marker_id` field from chunk
  marker records (saves a few % JSON size when joining only by pos).

**Sizing on the 226-sample LG28 cohort (estimate):**

- LG28 ≈ 30 Mb → with default winsize=100/step=20 dense registry:
  ~1500 L1 windows
- @ 200 windows/chunk: ~8 chunks
- Per chunk: ~10k markers (with hatchery cohort marker density) ×
  226 samples = ~2.3M integer cells → JSON ~10-25 MB per chunk
- Total: ~80-200 MB per chrom, comfortable for the scrubber's
  LRU cache (default cap 50 chunks).

### 2. STEP_M05_emit_step29_layers.R (new)

JSON emit shim around STEP29's existing two TSV outputs. Single output
per chromosome:

- `<chrom>_step29_layers.json` — emits `candidate_sample_coherence`
  and/or `candidate_marker_polarity` layers, faithful column-by-column
  mirror of the input TSVs.

**Key design decisions:**

- **Column contract enforced from SCHEMA_V2 §10.** Required columns
  validated up-front; missing → script aborts with explicit message;
  extra → passed through with a warning (or aborted under
  `--strict_columns 1`).
- **Type coercion is explicit.** Numeric / integer / logical columns
  declared by name; logicals accept TRUE/FALSE/T/F/0/1 strings;
  everything else stays string.
- **Enum validation is warn-only.** `coarse_group`,
  `coherence_class`, `stripe_quality`, `flip_source`, `support_class`
  validated against the schema-listed values; unexpected values warn
  and pass through (so the user sees a flag, not an abort).
- **Either layer is optional.** Pass only the coherence TSV → only
  that layer emitted → scrubber's Polarity top-track stays empty
  (graceful per `_buildPolarityLookup`). Same vice versa.
- **`final_flip_decision` round-trips as JSON boolean.** Validated by
  smoke test — `_buildPolarityLookup` reads it as truthy/falsy directly.

**Required:**

- `--chrom <chrom>` and `--out_dir <dir>`.
- At least one of `--coherence_tsv` or `--polarity_tsv`.

## Cross-validation against the real scrubber

Both scripts have been smoke-tested end-to-end on synthetic data,
**including running the actual `selectTopMarkers` function lifted from
`pca_scrubber_v3.html` against chunks produced by STEP_M04**:

- `smoke_test_M04_M05.R` — 28 R-level checks covering shape, schema
  conformance, single-layer mode, single-chunk mode, sample alignment,
  marker disjointness across chunks. ALL PASS.
- `cross_check_scrubber_layers.js` — 17 Node-level checks against the
  scrubber's actual `detectSchemaAndLayers` and `_findCoveringChunk`
  logic (lifted verbatim from the HTML). ALL PASS.
- `end_to_end_check.js` — Loads `selectTopMarkers` directly from the
  HTML via VM context, runs it on a real M04-produced chunk: cap-100
  returns all 15 markers, cap-5 picks top 5 by variance and
  pos-orders them, out-of-range returns empty. ALL OK.

This means: **when these scripts run on the 226-sample LG28 dosage
matrix and STEP29 outputs, the resulting JSONs will plug into v3.94
without further scrubber changes.**

## Suggested production run

```bash
# Per-chromosome dosage chunks (do for LG28 first, then iterate over chroms)
Rscript STEP_M04_emit_dosage_chunks.R \
  --dosage   /scratch/lt200308-agbsci/.../C_gar_LG28.dos.tsv.gz \
  --chr_meta /scratch/lt200308-agbsci/.../C_gar_LG28.chr_meta.tsv.gz \
  --chrom    C_gar_LG28 \
  --out_dir  /path/to/scrubber/data/ \
  --windows_per_chunk 200

# STEP29 layers shim — coherence + polarity together
Rscript STEP_M05_emit_step29_layers.R \
  --chrom         C_gar_LG28 \
  --out_dir       /path/to/scrubber/data/ \
  --coherence_tsv /path/to/C_gar_LG28_candidate_sample_coherence.tsv \
  --polarity_tsv  /path/to/C_gar_LG28_candidate_marker_polarity.tsv
```

After running both, the layout in `/path/to/scrubber/data/C_gar_LG28/`
will be:

```
C_gar_LG28_dosage_chunks_index.json   ← drop into scrubber as enrichment
C_gar_LG28_dosage_chunk_<bp>_<bp>.json ← fetched on demand by the scrubber
C_gar_LG28_dosage_chunk_<bp>_<bp>.json
... (≈ 8-15 chunk files)
C_gar_LG28_step29_layers.json         ← drop into scrubber as enrichment
```

Drop the **index** and the **step29_layers** JSONs into the scrubber's
enrichment loader. Open candidate page 2 → the FIG_C08-style heatmap
section will populate with the static view including Quality (left
track 3, "from layer") and Polarity (top track) annotations. Toggle the
`▦ live dosage` button in the L3 toolbar → the cursor-bound docked
strip below L3 shows the live ±5 windows view, redrawing on arrow-key
navigation (150 ms debounced).

## What this unblocks (downstream)

1. **Real-data validation of v3.94 heatmap** — the only thing that
   needed it. All five left-side tracks render; top polarity track
   renders; dosage cells colored by `#2166AC / #F7F7F7 / #B2182B`.
2. **Stripe-quality button** — replaced by status text "stripe quality:
   from layer" because the layer is loaded.
3. **Marker selection cascade** — variance fallback exercised against
   real cohort dosage; `diagnostic_score` ranking exercised once the
   marker catalogue ships (TBD by phase 13 work).

## Outstanding R-side from prior handoffs (still parked)

These don't block heatmap validation; listed here for completeness:

- `STEP_T06_emit_theta_pi_panel.R` — unlocks θπ pillar (v3.92)
- `STEP_R12_emit_roh_intervals.R` — unlocks ROH pillar (v3.92)
- `STEP_R13_emit_sample_froh.R` — unlocks FROH pillar (v3.92)

## Outstanding scrubber-side (from v3.94 handoff)

The user's message offered three scrubber-only fallbacks if R-side was
parked. R-side is now done, so these stay open as natural next-session
candidates:

- Hover tooltips on heatmap cells (schema-noted: must be overlay
  updates, not redraws — uses cached canvas image data + hit-test on
  the layout returned by `drawDosageHeatmap`)
- Per-candidate filtered TSV export buttons on page 10 (last v3.90
  deferred item)
- v3.80 UI text rewrite

## File staging at /mnt/user-data/outputs/

- **STEP_M04_emit_dosage_chunks.R** — new, ~430 lines
- **STEP_M05_emit_step29_layers.R** — new, ~340 lines
- **smoke_test_M04_M05.R** — new, ~280 lines, exits non-zero on any
  failure (suitable for CI)
- **cross_check_scrubber_layers.js** — new, ~110 lines, validates
  outputs against scrubber's actual layer-detection code
- **end_to_end_check.js** — new, ~60 lines, runs the scrubber's real
  `selectTopMarkers` on M04 output
- **HANDOFF_v3_95.md** — this file (R-side unblock; scrubber unchanged)

Scrubber and schema files unchanged this chat:

- pca_scrubber_v3.html — v3.94 (carried forward)
- SCHEMA_V2.md — v2.6 (carried forward)

## Notes for future-me / next chat

- **The 226-sample cohort is pure *C. gariepinus* hatchery broodstock.**
  K clusters reflect broodline structure, not species admixture. This
  matters for interpretation of stripe_quality and coarse_group when
  Quentin starts inspecting the heatmap.
- **Don't conflate cohorts.** F1 hybrid (assembly paper),
  pure-gariepinus 226 (current heatmap), pure-macrocephalus wild
  (future paper).
- **Run order matters in production.** STEP29 must complete before
  STEP_M05 (it writes the input TSVs). STEP_A03 must complete before
  STEP_M04 (it writes chr_meta). STEP_M04 and STEP_M05 are independent
  of each other and can run in parallel.
- **If marker_catalogue has partial coverage**, STEP_M04 silently drops
  the `diagnostic_score` column (the all-or-nothing rule). The
  scrubber automatically falls back to variance ranking — no error.
  This is intentional, because the marker module (phase 13) hasn't
  shipped yet for all chroms.
- **The R `assembly` env at `/lustrefs/disk/project/lt200308-agbsci/13-programs/mambaforge/envs/assembly/bin/Rscript`
  has `data.table`, `jsonlite`, and `R.utils`** — verified during prior
  pipeline work. No new package installs needed.
