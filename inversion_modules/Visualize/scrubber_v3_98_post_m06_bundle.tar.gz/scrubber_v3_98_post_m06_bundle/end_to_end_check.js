#!/usr/bin/env node
// End-to-end: pull the REAL selectTopMarkers from the HTML and run it
// on a chunk emitted by STEP_M04.

const fs = require('fs');
const path = require('path');
const vm = require('vm');

const html = fs.readFileSync('/mnt/user-data/uploads/pca_scrubber_v3.html', 'utf8');

// Extract DOSAGE_HEATMAP_DEFAULTS + selectTopMarkers
function extractFn(src, name) {
  const fnRe = new RegExp(`function ${name}\\s*\\(`);
  const m = src.match(fnRe);
  if (!m) throw new Error(`function ${name} not found`);
  let i = m.index;
  // brace-balance to capture full body
  const open = src.indexOf('{', i);
  let depth = 0, j = open;
  for (; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) { j++; break; } }
  }
  return src.slice(i, j);
}

function extractConst(src, name) {
  const re = new RegExp(`const ${name}\\s*=\\s*\\{`);
  const m = src.match(re);
  if (!m) throw new Error(`const ${name} not found`);
  let i = m.index, open = src.indexOf('{', i);
  let depth = 0, j = open;
  for (; j < src.length; j++) {
    if (src[j] === '{') depth++;
    else if (src[j] === '}') { depth--; if (depth === 0) { j++; break; } }
  }
  // include trailing semicolon
  if (src[j] === ';') j++;
  return src.slice(i, j);
}

const ctx = {};
vm.createContext(ctx);
vm.runInContext(extractConst(html, 'DOSAGE_HEATMAP_DEFAULTS'), ctx);
vm.runInContext(extractFn(html, 'selectTopMarkers'), ctx);

// Load a chunk produced by STEP_M04
const chunkDir = '/home/claude/work/smoke_out/scrubber_data/TEST_LG01';
const chunkFile = path.join(chunkDir, 'TEST_LG01_dosage_chunk_1_389.json');
const chunk = JSON.parse(fs.readFileSync(chunkFile, 'utf8'));

console.log(`chunk has ${chunk.n_markers} markers, ${chunk.n_samples} samples`);
console.log(`region: ${chunk.region_start_bp}..${chunk.region_end_bp}`);

// Region covering the whole chunk, cap=100 (well above marker count)
const r1 = ctx.selectTopMarkers(chunk,
  { start_bp: chunk.region_start_bp, end_bp: chunk.region_end_bp }, 100);
console.log('cap=100 (over-cap):', JSON.stringify(r1, null, 2));

// Region with cap=5 → tests variance fallback ranking
const r2 = ctx.selectTopMarkers(chunk,
  { start_bp: chunk.region_start_bp, end_bp: chunk.region_end_bp }, 5);
console.log('\ncap=5:', JSON.stringify(r2, null, 2));

// Verify pos-ordering of selected
const positions = r2.selected_indices.map(i => chunk.markers[i].pos_bp);
const sorted = [...positions].sort((a, b) => a - b);
const orderingOk = positions.every((p, i) => p === sorted[i]);
console.log('\nselected markers are pos-ordered:', orderingOk);

// Out-of-range region → empty
const r3 = ctx.selectTopMarkers(chunk, { start_bp: 100000, end_bp: 200000 }, 5);
console.log('out-of-range region selection:', r3);

console.log('\nEND-TO-END: REAL scrubber selectTopMarkers + STEP_M04 chunk = OK');
