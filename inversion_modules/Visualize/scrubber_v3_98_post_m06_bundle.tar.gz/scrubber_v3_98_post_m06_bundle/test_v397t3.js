// v3.97 turn 3 tests: TSV column emission for boundary fields
//
// What v3.97 turn 3 adds:
//   - 14 new columns in REGISTRY_TSV_COLUMNS (between n_k6_pure and qc_status)
//   - Helper _boundaryColsFromCand(c) returning the 14 string values
//   - Spread integration in _registryRowsForCandidates
//
// TESTS (5)
//   1. SCRUBBER_VERSION still v3.97+
//   2. REGISTRY_TSV_COLUMNS length increased by 14; new columns present
//      in the documented order
//   3. _boundaryColsFromCand on candidate WITH boundaries: populated
//      values, pipe-separated support, lowercase support_class, score
//      formatted to 4dp
//   4. _boundaryColsFromCand on candidate WITHOUT boundaries: all 14
//      fields are '' (empty string), NOT 'NA'
//   5. End-to-end TSV row: a populated candidate emits the 14 fields
//      in correct columns, in correct order; an unannotated candidate
//      emits '' in those columns

const fs = require('fs');
const html = fs.readFileSync('/home/claude/v3/pca_scrubber_v3.html', 'utf8');
const m = html.match(/<script>([\s\S]+?)<\/script>/);
let js = m[1];

const shim = `
const _byId = new Map();
function _makeEl(tag) {
  const _ownC = new Set();
  const ctxStub = { setTransform:()=>{}, clearRect:()=>{}, fillRect:()=>{},
    strokeRect:()=>{}, beginPath:()=>{}, moveTo:()=>{}, lineTo:()=>{}, stroke:()=>{},
    fill:()=>{}, fillText:()=>{}, save:()=>{}, restore:()=>{},
    translate:()=>{}, rotate:()=>{}, setLineDash:()=>{},
    measureText:(s)=>({ width:0 }), createLinearGradient:()=>({addColorStop:()=>{}}),
    fillStyle:'',strokeStyle:'',lineWidth:1,font:'',textAlign:'',textBaseline:'' };
  const el = { tagName:(tag||'').toUpperCase(), id:'', textContent:'', _innerHTML:'',
    disabled:false, value:'', placeholder:'', title:'', checked:false,
    width:0, height:0, offsetWidth:100, offsetHeight:20, clientWidth:1000, clientHeight:400,
    style:{cssText:'',display:'',width:'',height:'',visibility:'',left:'',top:''},
    classList: { _c: _ownC, add(...a){a.forEach(x=>this._c.add(x));},
      remove(...a){a.forEach(x=>this._c.delete(x));}, toggle(){}, contains(x){return this._c.has(x);} },
    dataset:{}, _children:[],
    appendChild(c){ this._children.push(c); return c; },
    addEventListener(){}, removeEventListener(){},
    insertAdjacentHTML(){},
    querySelector(){return null;}, querySelectorAll: () => [],
    setAttribute(){}, getAttribute(){return null;}, removeAttribute(){},
    getBoundingClientRect: () => ({left:0,top:0,width:1000,height:120,right:1000,bottom:120}),
    contains: () => false, parentNode: null, parentElement: null,
    getContext: () => ctxStub };
  Object.defineProperty(el,'innerHTML',{get(){return this._innerHTML;},set(v){this._innerHTML=String(v);}});
  Object.defineProperty(el,'className',{get(){return [...this.classList._c].join(' ');},
    set(v){this.classList._c.clear(); String(v||'').split(/\\s+/).filter(Boolean).forEach(x=>this.classList._c.add(x));}});
  return el;
}
const _bodyEl = _makeEl('body');
const document = {
  documentElement: _makeEl('html'),
  querySelectorAll: () => [], querySelector: () => null,
  getElementById(id) { if (!_byId.has(id)) { const el = _makeEl('div'); el.id = id; _byId.set(id, el); } return _byId.get(id); },
  createElement: _makeEl, body: _bodyEl,
  addEventListener: () => {}, removeEventListener: () => {},
  activeElement: { tagName: 'DIV' },
};
const window = { devicePixelRatio: 1, addEventListener: () => {}, innerWidth: 1024, innerHeight: 768 };
const localStorage = { setItem(){}, getItem(){return null;}, removeItem(){}, clear(){} };
const getComputedStyle = () => ({ getPropertyValue: () => '' });
const FileReader = function() {};
const Blob = function() {};
const URL = { createObjectURL: () => '', revokeObjectURL: () => {} };
const requestAnimationFrame = (fn) => { try { fn(); } catch (e) {} return 1; };
const cancelAnimationFrame = () => {};
const setTimeout = (fn) => { try { fn(); } catch (e) {} return 1; };
const clearTimeout = () => {};
const alert = () => {};
const confirm = () => true;
`;
js = `${shim}\n${js}\nmodule.exports = {
  state, REGISTRY_TSV_COLUMNS,
  _boundaryColsFromCand, _registryRowsForCandidates,
};\n`;
fs.writeFileSync('/tmp/scrubber_test_v397t3.js', js);
delete require.cache[require.resolve('/tmp/scrubber_test_v397t3.js')];
const M = require('/tmp/scrubber_test_v397t3.js');

let totalPass = 0, totalFail = 0;
function check(label, ok, detail) {
  if (ok) { totalPass++; console.log(' ', 'PASS'); }
  else    { totalFail++; console.log(' ', 'FAIL', detail || ''); }
}

// =============================================================================
// TEST 1: SCRUBBER_VERSION still v3.97+
// =============================================================================
console.log('--- TEST 1: SCRUBBER_VERSION v3.97+ ---');
const t1 = /const SCRUBBER_VERSION = 'v3\.(9[7-9]|\d{3,})';/.test(html);
check('test1', t1);

// =============================================================================
// TEST 2: REGISTRY_TSV_COLUMNS shape
// =============================================================================
console.log('\n--- TEST 2: REGISTRY_TSV_COLUMNS ---');
const cols = M.REGISTRY_TSV_COLUMNS;
// Pre-v3.97 width was 31; should now be 45 (31 + 14)
const t2a = cols.length === 45;
console.log('  total column count = 45:', t2a, `(got ${cols.length})`);
const expectedNew = [
  'left_boundary_zone_start', 'left_boundary_zone_end',
  'left_boundary_score', 'left_boundary_support',
  'left_boundary_support_class', 'left_boundary_source',
  'right_boundary_zone_start', 'right_boundary_zone_end',
  'right_boundary_score', 'right_boundary_support',
  'right_boundary_support_class', 'right_boundary_source',
  'breakpoint_status', 'boundary_notes',
];
const t2b = expectedNew.every(name => cols.indexOf(name) >= 0);
console.log('  all 14 new columns present:', t2b);
// Order: should fall between n_k6_pure and qc_status
const idxNk6Pure = cols.indexOf('n_k6_pure');
const idxQcStatus = cols.indexOf('qc_status');
const idxLeftStart = cols.indexOf('left_boundary_zone_start');
const idxBoundaryNotes = cols.indexOf('boundary_notes');
const t2c = idxNk6Pure < idxLeftStart
         && idxLeftStart < idxBoundaryNotes
         && idxBoundaryNotes < idxQcStatus;
console.log('  ordering nk6_pure < left_zone_start < boundary_notes < qc_status:', t2c,
  `(${idxNk6Pure} < ${idxLeftStart} < ${idxBoundaryNotes} < ${idxQcStatus})`);
// Documented order between left and right blocks
let lastIdx = idxLeftStart - 1;
let orderingOk = true;
for (const name of expectedNew) {
  const idx = cols.indexOf(name);
  if (idx <= lastIdx) { orderingOk = false; break; }
  lastIdx = idx;
}
const t2d = orderingOk;
console.log('  14 columns in documented order (left block then right block):', t2d);
check('test2', t2a && t2b && t2c && t2d);

// =============================================================================
// TEST 3: _boundaryColsFromCand on populated candidate
// =============================================================================
console.log('\n--- TEST 3: _boundaryColsFromCand (populated) ---');
const candA = {
  id: 1, chrom: 'X', start_bp: 1000000, end_bp: 2000000,
  boundary_left: {
    zone_start_bp: 950000, zone_end_bp: 990000,
    score: 0.78,
    support: ['pca_drop', 'ghsl_step', 'band_continuity_drop', 'het_transition'],
    support_class: 'strong',
    source: 'auto',
    sv_anchors_in_zone: [],
    notes: '',
    set_at: '2026-04-28T07:00:00Z',
    set_by: 'scrubber_auto',
  },
  boundary_right: {
    zone_start_bp: 2010000, zone_end_bp: 2050000,
    score: 0.6,
    support: ['pca_drop'],
    support_class: 'weak',
    source: 'manual',
    sv_anchors_in_zone: [],
    notes: '',
    set_at: '2026-04-28T07:01:00Z',
    set_by: 'scrubber_manual',
  },
  breakpoint_status: 'SV_supported',
  boundary_notes: 'reviewed against DELLY anchors',
};
const colsA = M._boundaryColsFromCand(candA);
const t3a = colsA.left_boundary_zone_start === '950000'
         && colsA.left_boundary_zone_end   === '990000';
console.log('  left zone bp coords:', t3a, JSON.stringify({
  start: colsA.left_boundary_zone_start, end: colsA.left_boundary_zone_end,
}));
const t3b = colsA.left_boundary_score === '0.7800';
console.log('  score formatted to 4dp (0.78 → "0.7800"):', t3b, colsA.left_boundary_score);
const t3c = colsA.left_boundary_support
  === 'pca_drop|ghsl_step|band_continuity_drop|het_transition';
console.log('  support[] pipe-separated:', t3c);
console.log('    got:', colsA.left_boundary_support);
const t3d = colsA.left_boundary_support_class === 'strong';
const t3e = colsA.left_boundary_source === 'auto';
console.log('  support_class + source:', t3d, t3e);
const t3f = colsA.right_boundary_score === '0.6000'
         && colsA.right_boundary_support === 'pca_drop'
         && colsA.right_boundary_support_class === 'weak'
         && colsA.right_boundary_source === 'manual';
console.log('  right block:', t3f);
const t3g = colsA.breakpoint_status === 'SV_supported';
console.log('  breakpoint_status:', t3g);
const t3h = colsA.boundary_notes === 'reviewed against DELLY anchors';
console.log('  boundary_notes:', t3h);
check('test3', t3a && t3b && t3c && t3d && t3e && t3f && t3g && t3h);

// =============================================================================
// TEST 4: _boundaryColsFromCand on unannotated candidate
// =============================================================================
console.log('\n--- TEST 4: _boundaryColsFromCand (unannotated) ---');
const candB = { id: 2, chrom: 'X', start_bp: 0, end_bp: 1000 };
const colsB = M._boundaryColsFromCand(candB);
const expectedKeys = [
  'left_boundary_zone_start', 'left_boundary_zone_end',
  'left_boundary_score', 'left_boundary_support',
  'left_boundary_support_class', 'left_boundary_source',
  'right_boundary_zone_start', 'right_boundary_zone_end',
  'right_boundary_score', 'right_boundary_support',
  'right_boundary_support_class', 'right_boundary_source',
  'breakpoint_status', 'boundary_notes',
];
let allEmpty = true;
for (const k of expectedKeys) {
  if (colsB[k] !== '') { allEmpty = false; break; }
}
const t4a = allEmpty;
console.log('  all 14 fields are "" (empty string):', t4a);
// No 'NA' strings
let anyNA = false;
for (const k of expectedKeys) if (colsB[k] === 'NA') { anyNA = true; break; }
const t4b = !anyNA;
console.log('  no "NA" strings (schema says "" for v3.97 fields):', t4b);
// Half-populated candidate: only left set
const candC = {
  id: 3, chrom: 'X', start_bp: 0, end_bp: 1000,
  boundary_left: {
    zone_start_bp: 100, zone_end_bp: 200,
    score: 0.55, support: ['pca_drop'],
    support_class: 'weak', source: 'auto',
    sv_anchors_in_zone: [], notes: '',
    set_at: 't', set_by: 'scrubber_auto',
  },
  boundary_right: null,
  breakpoint_status: 'boundary_zone_only',
  boundary_notes: '',
};
const colsC = M._boundaryColsFromCand(candC);
const t4c = colsC.left_boundary_zone_start === '100'
         && colsC.right_boundary_zone_start === ''
         && colsC.right_boundary_score === ''
         && colsC.right_boundary_support === '';
console.log('  half-populated: left set, right empty:', t4c);
const t4d = colsC.breakpoint_status === 'boundary_zone_only';
console.log('  breakpoint_status preserved when set:', t4d);
// Tab/newline sanitization in notes
const candD = {
  id: 4, chrom: 'X', start_bp: 0, end_bp: 1000,
  boundary_notes: 'line1\twith\ttabs\nand\nnewlines',
};
const colsD = M._boundaryColsFromCand(candD);
const t4e = colsD.boundary_notes === 'line1 with tabs and newlines';
console.log('  notes: tabs+newlines stripped:', t4e, JSON.stringify(colsD.boundary_notes));
check('test4', t4a && t4b && t4c && t4d && t4e);

// =============================================================================
// TEST 5: end-to-end TSV row builder
// =============================================================================
console.log('\n--- TEST 5: TSV row end-to-end ---');
// Build a minimal candidate that satisfies _registryRowsForCandidates'
// expectations (it needs locked_labels, K, l2_indices, etc.).
const candFull = {
  id: 100, chrom: 'C_gar_LG28', start_bp: 12000000, end_bp: 14000000,
  start_w: 595, end_w: 710, K: 3, source: 'manual',
  l2_indices: [12, 13, 14], ref_l2: 13, ref_window: 650,
  locked_labels: new Int8Array(115).fill(0),
  qc_status: 'accepted', notes: '', created_at: Date.now(),
  // Boundaries
  boundary_left: {
    zone_start_bp: 11900000, zone_end_bp: 11940000,
    score: 0.82, support: ['pca_drop', 'ghsl_step', 'band_continuity_drop'],
    support_class: 'strong', source: 'auto',
    sv_anchors_in_zone: [], notes: '',
    set_at: '2026-04-28T08:00:00Z', set_by: 'scrubber_auto',
  },
  boundary_right: {
    zone_start_bp: 14080000, zone_end_bp: 14120000,
    score: 0.71, support: ['pca_drop', 'ghsl_step'],
    support_class: 'moderate', source: 'auto',
    sv_anchors_in_zone: [], notes: '',
    set_at: '2026-04-28T08:00:00Z', set_by: 'scrubber_auto',
  },
  breakpoint_status: 'boundary_zone_only',
  boundary_notes: 'auto-detected',
};

let rows;
try {
  rows = M._registryRowsForCandidates([candFull]);
} catch (e) {
  console.log('  FAIL:', e.message);
  rows = [];
}
const t5a = rows.length === 1;
console.log('  row built:', t5a);
const r0 = rows[0] || {};
const t5b = r0.left_boundary_zone_start === '11900000'
         && r0.left_boundary_zone_end === '11940000';
console.log('  left zone bp coords in row:', t5b);
const t5c = r0.left_boundary_score === '0.8200';
console.log('  left score 4dp:', t5c, r0.left_boundary_score);
const t5d = r0.left_boundary_support === 'pca_drop|ghsl_step|band_continuity_drop';
console.log('  left support pipe-separated:', t5d);
const t5e = r0.left_boundary_support_class === 'strong'
         && r0.left_boundary_source === 'auto'
         && r0.right_boundary_support_class === 'moderate'
         && r0.breakpoint_status === 'boundary_zone_only'
         && r0.boundary_notes === 'auto-detected';
console.log('  classes/source/status/notes match:', t5e);
// Format the row as TSV (the actual exporter would do this) and check
// columns appear in the right positions
const tsvLine = M.REGISTRY_TSV_COLUMNS.map(c => r0[c]).join('\t');
const fields = tsvLine.split('\t');
const t5f = fields.length === M.REGISTRY_TSV_COLUMNS.length;
console.log('  TSV line has 45 fields:', t5f, `(got ${fields.length})`);
const _idxLeftStart = M.REGISTRY_TSV_COLUMNS.indexOf('left_boundary_zone_start');
const _idxBoundaryNotes = M.REGISTRY_TSV_COLUMNS.indexOf('boundary_notes');
const t5g = fields[_idxLeftStart] === '11900000'
         && fields[_idxBoundaryNotes] === 'auto-detected';
console.log('  TSV-positional values correct:', t5g);
// Unannotated candidate emits ''
const candEmpty = {
  id: 101, chrom: 'C_gar_LG28', start_bp: 0, end_bp: 1000,
  start_w: 0, end_w: 0, K: 3, source: 'manual',
  l2_indices: [], ref_l2: 0, ref_window: 0,
  locked_labels: new Int8Array(0),
  qc_status: 'accepted', notes: '', created_at: Date.now(),
  // No boundary_* fields
};
let rowsEmpty;
try {
  rowsEmpty = M._registryRowsForCandidates([candEmpty]);
} catch (e) {
  console.log('  FAIL on empty:', e.message);
  rowsEmpty = [];
}
const r1 = rowsEmpty[0] || {};
const t5h = r1.left_boundary_zone_start === ''
         && r1.right_boundary_zone_end === ''
         && r1.left_boundary_support === ''
         && r1.breakpoint_status === ''
         && r1.boundary_notes === '';
console.log('  unannotated candidate emits "" for all 14 fields:', t5h);
const tsvLineE = M.REGISTRY_TSV_COLUMNS.map(c => r1[c]).join('\t');
const fieldsE = tsvLineE.split('\t');
const t5i = fieldsE[_idxLeftStart] === ''
         && fieldsE[_idxBoundaryNotes] === '';
console.log('  empty TSV cells emit as empty string:', t5i);
check('test5', t5a && t5b && t5c && t5d && t5e && t5f && t5g && t5h && t5i);

// =============================================================================
// SUMMARY
// =============================================================================
console.log(`\n--- v3.97 turn 3 tests: ${totalPass}/${totalPass + totalFail} ---`);
if (totalFail > 0) process.exit(1);
