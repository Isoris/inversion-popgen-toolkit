// v3.97 turn 1 tests: boundary zone refinement helpers
//
// What v3.97 turn 1 adds:
//   - Constants: BOUNDARY_DEFAULTS, BOUNDARY_TRACK_WEIGHTS,
//     BOUNDARY_TRACK_NAMES, SUPPORT_CLASS_COLORS
//   - State: _ensureBoundariesState() singleton on state.__boundaries
//   - Pure helpers (testable in node):
//       _bsearchWin(arr, target, mode)
//       _boundaryScanRange(cand, scan_radius_bp, chromLen)
//       _rollingMedian(arr, width)
//       _perTrackMad(arr)
//       _madNormalize(arr, mad)
//       _findSVAnchorsInZone(boundaryEvidenceRow, zoneStartBp, zoneEndBp)
//       _supportClass(score, supportArr)
//       _buildBoundaryTrackScores(cand, scanRange)
//       _computeBoundaryEdges(trackScores, scanRange, weights, opts)
//       _buildBoundaryRecord(edge, side, source, opts)
//   - SCRUBBER_VERSION → 'v3.97'
//
// TESTS (10)
//   1. SCRUBBER_VERSION is v3.97+
//   2. _bsearchWin finds correct lo/hi indices + clamps at edges
//   3. _boundaryScanRange clamps to [0, chromLen] + huge-candidate expansion rule
//   4. _rollingMedian width=3, NA-aware (-1 sentinel, NaN both excluded)
//   5. _perTrackMad + _madNormalize roundtrip
//   6. _findSVAnchorsInZone filters by pos_bp
//   7. _supportClass covers all four classes per schema rule
//   8. _buildBoundaryTrackScores returns only present-layer tracks
//   9. _computeBoundaryEdges on synthetic data with known left/right edges
//      → picks correct windows; support[] populated
//  10. _buildBoundaryRecord shape conforms to schema §12 + state.__boundaries shape

const fs = require('fs');
const html = fs.readFileSync('/home/claude/v3/pca_scrubber_v3.html', 'utf8');
const m = html.match(/<script>([\s\S]+?)<\/script>/);
let js = m[1];

const shim = `
const _byId = new Map();
function _makeEl(tag) {
  const _ownC = new Set();
  const ctxStub = {
    setTransform:()=>{}, clearRect:()=>{}, fillRect:()=>{},
    strokeRect:()=>{}, beginPath:()=>{}, moveTo:()=>{}, lineTo:()=>{}, stroke:()=>{},
    fill:()=>{}, fillText:()=>{}, save:()=>{}, restore:()=>{},
    translate:()=>{}, rotate:()=>{}, setLineDash:()=>{},
    measureText:(s)=>({ width: ((s && s.length) || 0) * 5 }),
    createLinearGradient: () => ({ addColorStop: () => {} }),
    fillStyle: '', strokeStyle: '', lineWidth: 1, font: '', textAlign: '', textBaseline: '',
  };
  const el = {
    tagName: (tag||'').toUpperCase(), id: '', textContent: '', _innerHTML: '',
    disabled: false, value: '', placeholder: '', title: '', checked: false,
    width: 0, height: 0, offsetWidth: 100, offsetHeight: 20, clientWidth: 1000, clientHeight: 400,
    style: { cssText: '', display: '', width: '', height: '', visibility: '', left: '', top: '' },
    classList: { _c: _ownC, add(...a){a.forEach(x=>this._c.add(x));},
      remove(...a){a.forEach(x=>this._c.delete(x));},
      toggle(){}, contains(x){return this._c.has(x);} },
    dataset: {}, _children: [],
    appendChild(c){ this._children.push(c); return c; },
    addEventListener(){}, removeEventListener(){},
    querySelector(){return null;}, querySelectorAll: () => [],
    setAttribute(){}, getAttribute(){return null;}, removeAttribute(){},
    getBoundingClientRect: () => ({ left:0, top:0, width:1000, height:120, right:1000, bottom:120 }),
    contains: () => false, parentNode: null, parentElement: null,
    getContext: () => ctxStub,
  };
  Object.defineProperty(el, 'innerHTML', { get(){return this._innerHTML;}, set(v){this._innerHTML=String(v);} });
  Object.defineProperty(el, 'className', {
    get() { return [...this.classList._c].join(' '); },
    set(v) { this.classList._c.clear();
             String(v||'').split(/\\s+/).filter(Boolean).forEach(x => this.classList._c.add(x)); }
  });
  return el;
}
const _bodyEl = _makeEl('body');
const document = {
  documentElement: _makeEl('html'),
  querySelectorAll: () => [], querySelector: () => null,
  getElementById(id) { if (!_byId.has(id)) { const el = _makeEl('div'); el.id = id; _byId.set(id, el); } return _byId.get(id); },
  createElement: _makeEl, body: _bodyEl,
  addEventListener: () => {}, removeEventListener: () => {},
};
const window = { devicePixelRatio: 1, addEventListener: () => {}, innerWidth: 1024, innerHeight: 768 };
const localStorage = { setItem(){}, getItem(){return null;}, removeItem(){}, clear(){} };
const getComputedStyle = () => ({ getPropertyValue: () => '' });
const FileReader = function() {};
const Blob = function() {};
const URL = { createObjectURL: () => '', revokeObjectURL: () => {} };
const requestAnimationFrame = (fn) => { try { fn(); } catch (e) {} return 1; };
const cancelAnimationFrame = () => {};
const setTimeout = (fn) => { try { fn(); } catch (e) {} return 1; };
const clearTimeout = () => {};
const alert = () => {};
const confirm = () => true;
`;
js = `${shim}\n${js}\nmodule.exports = {
  state,
  BOUNDARY_DEFAULTS, BOUNDARY_TRACK_WEIGHTS, BOUNDARY_TRACK_NAMES, SUPPORT_CLASS_COLORS,
  _ensureBoundariesState,
  _bsearchWin, _boundaryScanRange,
  _rollingMedian, _perTrackMad, _madNormalize,
  _findSVAnchorsInZone, _supportClass,
  _buildBoundaryTrackScores, _computeBoundaryEdges, _buildBoundaryRecord,
};\n`;
fs.writeFileSync('/tmp/scrubber_test_v397.js', js);
delete require.cache[require.resolve('/tmp/scrubber_test_v397.js')];
const M = require('/tmp/scrubber_test_v397.js');

let totalPass = 0, totalFail = 0;
function check(label, ok, detail) {
  if (ok) { totalPass++; console.log(' ', 'PASS'); }
  else    { totalFail++; console.log(' ', 'FAIL', detail || ''); }
}

// =============================================================================
// TEST 1: SCRUBBER_VERSION is v3.97+
// =============================================================================
console.log('--- TEST 1: SCRUBBER_VERSION v3.97+ ---');
const t1 = /const SCRUBBER_VERSION = 'v3\.(9[7-9]|\d{3,})';/.test(html);
console.log('  v3.97+:', t1);
check('test1', t1);

// =============================================================================
// TEST 2: _bsearchWin lo/hi modes + edge clamping
// =============================================================================
console.log('\n--- TEST 2: _bsearchWin ---');
const arr = [100, 200, 300, 400, 500];   // sorted
// lo: first idx with arr[i] >= target
const t2a = M._bsearchWin(arr, 250, 'lo') === 2;   // arr[2]=300
const t2b = M._bsearchWin(arr, 200, 'lo') === 1;   // arr[1]=200
const t2c = M._bsearchWin(arr,  50, 'lo') === 0;   // below all
const t2d = M._bsearchWin(arr, 600, 'lo') === 5;   // above all
// hi: last idx with arr[i] <= target
const t2e = M._bsearchWin(arr, 250, 'hi') === 1;   // arr[1]=200
const t2f = M._bsearchWin(arr, 300, 'hi') === 2;   // arr[2]=300
const t2g = M._bsearchWin(arr,  50, 'hi') === -1;  // below all
const t2h = M._bsearchWin(arr, 600, 'hi') === 4;   // above all
// Empty array
const t2i = M._bsearchWin([], 100, 'lo') === 0;
const t2j = M._bsearchWin([], 100, 'hi') === -1;
console.log('  lo 250 → idx 2:', t2a);
console.log('  lo 200 → idx 1 (exact match):', t2b);
console.log('  lo below all → 0:', t2c);
console.log('  lo above all → length:', t2d);
console.log('  hi 250 → idx 1:', t2e);
console.log('  hi 300 → idx 2 (exact match):', t2f);
console.log('  hi below all → -1:', t2g);
console.log('  hi above all → last idx:', t2h);
console.log('  empty arr lo → 0:', t2i);
console.log('  empty arr hi → -1:', t2j);
check('test2', t2a && t2b && t2c && t2d && t2e && t2f && t2g && t2h && t2i && t2j);

// =============================================================================
// TEST 3: _boundaryScanRange — clamping + huge-candidate expansion
// =============================================================================
console.log('\n--- TEST 3: _boundaryScanRange ---');
// Without state.data.windows, win_lo/win_hi default to 0
M.state.data = null;
const cand1 = { id: 1, start_bp: 5000000, end_bp: 7000000 };   // 2 Mb candidate
const r3a = M._boundaryScanRange(cand1, 1500000, 30000000);
const t3a = r3a.start_bp === 3500000 && r3a.end_bp === 8500000;
// Below-zero clamp
const candEdge = { id: 2, start_bp: 100000, end_bp: 1500000 };
const r3b = M._boundaryScanRange(candEdge, 1500000, 30000000);
const t3b = r3b.start_bp === 0 && r3b.end_bp === 3000000;
// Above-chromLen clamp
const candTail = { id: 3, start_bp: 28000000, end_bp: 29500000 };
const r3c = M._boundaryScanRange(candTail, 1500000, 30000000);
const t3c = r3c.start_bp === 26500000 && r3c.end_bp === 30000000;
// Huge-candidate expansion: span 5 Mb > 3 Mb threshold, radius becomes
// max(1.5 Mb, 5*0.5 Mb) = 2.5 Mb
const candHuge = { id: 4, start_bp: 10000000, end_bp: 15000000 };
const r3d = M._boundaryScanRange(candHuge, 1500000, 30000000);
const t3d = r3d.start_bp === 7500000 && r3d.end_bp === 17500000;
// No chromLen → only lower-bound clamp
const r3e = M._boundaryScanRange(cand1, 1500000, null);
const t3e = r3e.start_bp === 3500000 && r3e.end_bp === 8500000;
console.log('  basic 1.5 Mb radius:', t3a, JSON.stringify({ s: r3a.start_bp, e: r3a.end_bp }));
console.log('  clamps to 0:', t3b);
console.log('  clamps to chromLen:', t3c);
console.log('  huge candidate expansion (2.5 Mb):', t3d, JSON.stringify({ s: r3d.start_bp, e: r3d.end_bp }));
console.log('  null chromLen accepted:', t3e);
check('test3', t3a && t3b && t3c && t3d && t3e);

// =============================================================================
// TEST 4: _rollingMedian width=3 NA-aware
// =============================================================================
console.log('\n--- TEST 4: _rollingMedian ---');
const med1 = M._rollingMedian([1, 5, 3, 7, 5], 3);
// idx 0: window [0,1] = [1,5] → lower median = 1
// idx 1: window [0,1,2] = [1,5,3] sorted [1,3,5] → 3
// idx 2: window [1,2,3] = [5,3,7] sorted [3,5,7] → 5
// idx 3: window [2,3,4] = [3,7,5] sorted [3,5,7] → 5
// idx 4: window [3,4]   = [7,5] → lower median = 5
const t4a = med1[0] === 1 && med1[1] === 3 && med1[2] === 5 && med1[3] === 5 && med1[4] === 5;
// NA handling: -1 and NaN excluded
const med2 = M._rollingMedian([1, -1, 3, NaN, 5], 3);
// idx 0: med([1])=1 (only 1 finite); idx 1: med([1,3])=1 (lower median);
// idx 2: med([3]) = 3 (only 3 is non-NA in window); idx 3: med([3,5])=3;
// idx 4: med([5])=5
const t4b = med2[0] === 1 && med2[1] === 1 && med2[2] === 3 && med2[3] === 3 && med2[4] === 5;
// All-NA window → NaN
const med3 = M._rollingMedian([-1, NaN, -1], 3);
const t4c = Number.isNaN(med3[1]);
// Empty array
const med4 = M._rollingMedian([], 3);
const t4d = med4.length === 0;
// Width 1 → identity (preserving NA → NaN)
const med5 = M._rollingMedian([1, 2, 3], 1);
const t4e = med5[0] === 1 && med5[1] === 2 && med5[2] === 3;
console.log('  basic width=3:', t4a, '[' + Array.from(med1).join(',') + ']');
console.log('  NA-aware:', t4b, '[' + Array.from(med2).join(',') + ']');
console.log('  all-NA → NaN:', t4c);
console.log('  empty array → empty:', t4d);
console.log('  width=1 identity:', t4e);
check('test4', t4a && t4b && t4c && t4d && t4e);

// =============================================================================
// TEST 5: _perTrackMad + _madNormalize
// =============================================================================
console.log('\n--- TEST 5: _perTrackMad + _madNormalize ---');
const mad1 = M._perTrackMad([1, 2, 3, 4, 5]);
// median = 3; abs deviations = [2, 1, 0, 1, 2]; MAD = 1
const t5a = mad1 === 1;
// All-NA → 0
const mad2 = M._perTrackMad([-1, NaN, -1]);
const t5b = mad2 === 0;
// Single value → 0 (need >= 2 finite)
const mad3 = M._perTrackMad([5]);
const t5c = mad3 === 0;
// Round trip via _madNormalize
const norm1 = M._madNormalize([2, 4, 6], 2);
const t5d = norm1[0] === 1 && norm1[1] === 2 && norm1[2] === 3;
// Zero MAD → all zeros
const norm2 = M._madNormalize([1, 2, 3], 0);
const t5e = norm2[0] === 0 && norm2[1] === 0 && norm2[2] === 0;
// NA propagates as 0 in output
const norm3 = M._madNormalize([1, NaN, -1, 4], 1);
const t5f = norm3[0] === 1 && norm3[1] === 0 && norm3[2] === 0 && norm3[3] === 4;
console.log('  MAD([1..5]) = 1:', t5a, mad1);
console.log('  all-NA → 0:', t5b);
console.log('  single value → 0:', t5c);
console.log('  normalize [2,4,6] / 2 = [1,2,3]:', t5d);
console.log('  zero MAD → zeros:', t5e);
console.log('  NA → 0 in output:', t5f);
check('test5', t5a && t5b && t5c && t5d && t5e && t5f);

// =============================================================================
// TEST 6: _findSVAnchorsInZone
// =============================================================================
console.log('\n--- TEST 6: _findSVAnchorsInZone ---');
const beRow = {
  tracks: {
    sv_anchors: [
      { kind: 'DELLY_INV', ct: '3to3', pos_bp: 11842300, qual: 80 },
      { kind: 'Manta_INV5', pos_bp: 14250130, qual: 95 },
      { kind: 'DELLY_DEL', pos_bp: 12000000 },   // no qual
    ],
  },
};
const found1 = M._findSVAnchorsInZone(beRow, 11800000, 12100000);
const t6a = found1.length === 2 && found1[0].kind === 'DELLY_INV' && found1[1].kind === 'DELLY_DEL';
// Anchor exactly at boundary (pos == zoneStartBp) included
const found2 = M._findSVAnchorsInZone(beRow, 11842300, 11842300);
const t6b = found2.length === 1;
// Zone outside any anchor
const found3 = M._findSVAnchorsInZone(beRow, 20000000, 21000000);
const t6c = found3.length === 0;
// Null/empty inputs
const found4 = M._findSVAnchorsInZone(null, 0, 100);
const found5 = M._findSVAnchorsInZone({ tracks: {} }, 0, 100);
const t6d = found4.length === 0 && found5.length === 0;
// Anchor without pos_bp filtered out
const beBad = { tracks: { sv_anchors: [{ kind: 'X' }, { kind: 'Y', pos_bp: 50 }] } };
const found6 = M._findSVAnchorsInZone(beBad, 0, 100);
const t6e = found6.length === 1 && found6[0].pos_bp === 50;
// Output is a copy, not reference
const orig = beRow.tracks.sv_anchors[0];
found1[0].kind = 'MUTATED';
const t6f = orig.kind === 'DELLY_INV';
console.log('  finds 2 anchors in zone:', t6a, JSON.stringify(found1.map(x => x.kind)));
console.log('  inclusive boundary:', t6b);
console.log('  empty zone returns []:', t6c);
console.log('  null inputs → []:', t6d);
console.log('  filters anchors w/o pos_bp:', t6e);
console.log('  output is independent copy:', t6f);
check('test6', t6a && t6b && t6c && t6d && t6e && t6f);

// =============================================================================
// TEST 7: _supportClass — all four classes per schema rule
// =============================================================================
console.log('\n--- TEST 7: _supportClass ---');
// schema: strong if |s|>=3 AND score >=0.60
const t7a = M._supportClass(0.75, ['a', 'b', 'c', 'd']) === 'strong';
const t7b = M._supportClass(0.60, ['a', 'b', 'c']) === 'strong';
// |s|>=3 AND 0.40<=score<0.60 → moderate
const t7c = M._supportClass(0.50, ['a', 'b', 'c']) === 'moderate';
// |s|>=3 AND score<0.40 → weak (since "weak: |s|>=2 AND score<0.40")
const t7d = M._supportClass(0.30, ['a', 'b', 'c']) === 'weak';
// |s|==2 → moderate (the "n==2" rule wins over "weak: n>=2 AND s<0.40"
// by priority order in the schema rule listing)
const t7e = M._supportClass(0.99, ['a', 'b']) === 'moderate';
const t7f = M._supportClass(0.10, ['a', 'b']) === 'moderate';   // n==2 → moderate
// |s|==1 → weak
const t7g = M._supportClass(0.99, ['a']) === 'weak';
const t7h = M._supportClass(0.10, ['a']) === 'weak';
// |s|==0 → ambiguous regardless of score
const t7i = M._supportClass(0.99, []) === 'ambiguous';
const t7j = M._supportClass(0.99, null) === 'ambiguous';
console.log('  strong (n=4, s=0.75):', t7a);
console.log('  strong (n=3, s=0.60):', t7b);
console.log('  moderate (n=3, s=0.50):', t7c);
console.log('  weak (n=3, s=0.30):', t7d);
console.log('  moderate (n=2, s=0.99):', t7e);
console.log('  moderate (n=2, s=0.10):', t7f);
console.log('  weak (n=1, s=0.99):', t7g);
console.log('  weak (n=1, s=0.10):', t7h);
console.log('  ambiguous (n=0):', t7i, t7j);
check('test7', t7a && t7b && t7c && t7d && t7e && t7f && t7g && t7h && t7i && t7j);

// =============================================================================
// TEST 8: _buildBoundaryTrackScores returns only present-layer tracks
// =============================================================================
console.log('\n--- TEST 8: _buildBoundaryTrackScores ---');
// Synthetic state.data with windows + pve1 + ghsl_panel; no boundary_evidence
M.state.__boundaries = null;   // reset
M.state.data = {
  windows: {
    start_bp: [0, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 8000, 9000],
    end_bp:   [999, 1999, 2999, 3999, 4999, 5999, 6999, 7999, 8999, 9999],
    pve1:     [0.10, 0.10, 0.12, 0.50, 0.55, 0.60, 0.55, 0.20, 0.15, 0.12],
    band_continuity_score: [0.9, 0.9, 0.85, 0.50, 0.45, 0.40, 0.45, 0.85, 0.90, 0.92],
  },
  ghsl_panel: { div_median: [0.10, 0.10, 0.12, 0.50, 0.55, 0.60, 0.55, 0.15, 0.10, 0.08] },
};
const cand8 = { id: 8, start_bp: 4000, end_bp: 5999 };
const scan8 = { start_bp: 0, end_bp: 9999, win_lo: 0, win_hi: 9 };
const ts8 = M._buildBoundaryTrackScores(cand8, scan8);
const t8a = ts8.len === 10;
const t8b = ts8.tracks.pca_drop && ts8.tracks.pca_drop.length === 10;
const t8c = ts8.tracks.band_continuity_drop && ts8.tracks.band_continuity_drop.length === 10;
const t8d = ts8.tracks.ghsl_step && ts8.tracks.ghsl_step.length === 10;
const t8e = ts8.tracks.het_transition && ts8.tracks.het_transition.length === 10;
// Tracks for absent layers should be missing
const t8f = !('fst_edge' in ts8.tracks);
const t8g = !('theta_pi_step' in ts8.tracks);
const t8h = !('discordant_pile' in ts8.tracks);
const t8i = !('sv_anchor' in ts8.tracks);
const t8j = !('polarity_change' in ts8.tracks);
const t8k = !('dosage_transition' in ts8.tracks);
console.log('  len matches scan range:', t8a);
console.log('  pca_drop present:', t8b);
console.log('  band_continuity_drop present:', t8c);
console.log('  ghsl_step + het_transition present:', t8d, t8e);
console.log('  no fst_edge / theta_pi / discordant / sv_anchor:', t8f && t8g && t8h && t8i);
console.log('  no polarity_change / dosage_transition:', t8j && t8k);
check('test8', t8a && t8b && t8c && t8d && t8e && t8f && t8g && t8h && t8i && t8j && t8k);

// =============================================================================
// TEST 9: _computeBoundaryEdges on synthetic data — picks correct edges
// =============================================================================
console.log('\n--- TEST 9: _computeBoundaryEdges ---');
// 20-window scan region. Build two tracks, each with a clear rising edge
// at window 5 (left half) and a clear falling edge at window 14 (right half).
// pca_drop: ramps up at 4→5, ramps down at 13→14
// ghsl_step: same shape
const N = 20;
const mkRamp = () => {
  const a = new Array(N);
  for (let i = 0; i < N; i++) {
    if (i < 5) a[i] = 0.1;
    else if (i < 14) a[i] = 0.7;
    else a[i] = 0.1;
  }
  return a;
};
const ts9 = {
  tracks: {
    pca_drop:  mkRamp(),
    ghsl_step: mkRamp(),
    band_continuity_drop: mkRamp().map(v => 1 - v),   // inverted: drops where others rise
  },
  len: N, win_lo: 100, win_hi: 119,
};
// Need state.data.windows for _buildBoundaryRecord, but compute itself doesn't.
// Inject a minimal global windows block aligned with win_lo=100..119.
const windowsForN = { start_bp: [], end_bp: [] };
for (let w = 0; w < 130; w++) {
  windowsForN.start_bp.push(w * 1000);
  windowsForN.end_bp.push(w * 1000 + 999);
}
M.state.data = { windows: windowsForN };
const edges9 = M._computeBoundaryEdges(ts9, null, M.BOUNDARY_TRACK_WEIGHTS, {});
// The step at i=4 is +0.6 (4→5 transition): position of left edge should be at i=4
// The step at i=13 is -0.6 (13→14 transition): position of right edge at i=13
// (Smoothing width=3 may shift slightly; check argmax falls in [3,5] for left,
// [12,14] for right.)
const leftLocal  = edges9.left.window_idx_local;
const rightLocal = edges9.right.window_idx_local;
const t9a = edges9.left !== null && edges9.right !== null;
const t9b = leftLocal >= 3 && leftLocal <= 5;
const t9c = rightLocal >= 12 && rightLocal <= 14;
const t9d = edges9.left.score > 0;
const t9e = edges9.right.score > 0;
// Both edges should have multiple supporting tracks (3 tracks all step together)
const t9f = edges9.left.support.length >= 2 && edges9.right.support.length >= 2;
// Combined arrays exist
const t9g = edges9.combined_left instanceof Float64Array && edges9.combined_left.length === N;
// Empty/short input handled
const tsEmpty = { tracks: {}, len: 0, win_lo: 0, win_hi: 0 };
const edgesEmpty = M._computeBoundaryEdges(tsEmpty, null, M.BOUNDARY_TRACK_WEIGHTS, {});
const t9h = edgesEmpty.left === null && edgesEmpty.right === null;
console.log('  left + right edges found:', t9a);
console.log('  left arg in [3,5]:', t9b, '(got ' + leftLocal + ')');
console.log('  right arg in [12,14]:', t9c, '(got ' + rightLocal + ')');
console.log('  left score > 0:', t9d, edges9.left.score.toFixed(4));
console.log('  right score > 0:', t9e, edges9.right.score.toFixed(4));
console.log('  multi-track support:', t9f, JSON.stringify(edges9.left.support), JSON.stringify(edges9.right.support));
console.log('  combined_left is Float64Array len=N:', t9g);
console.log('  empty input → null edges:', t9h);
check('test9', t9a && t9b && t9c && t9d && t9e && t9f && t9g && t9h);

// =============================================================================
// TEST 10: _buildBoundaryRecord shape + _ensureBoundariesState shape
// =============================================================================
console.log('\n--- TEST 10: record shape + state shape ---');
M.state.__boundaries = null;   // reset
const bs = M._ensureBoundariesState();
const t10a = bs.active_cand_id === null;
const t10b = bs.scan_radius_bp === 1500000;
const t10c = bs.staging && bs.staging.cand_id === null
  && bs.staging.boundary_left === null && bs.staging.boundary_right === null
  && bs.staging.breakpoint_status === 'boundary_zone_only'
  && bs.staging.dirty === false;
const t10d = bs.cache instanceof Map;
// Idempotent
const bs2 = M._ensureBoundariesState();
const t10e = bs === bs2;

// Build record from edges9.left (state.data.windows still set with 130 windows)
const edge = edges9.left;
const rec = M._buildBoundaryRecord(edge, 'left', 'auto', { sv_anchors: [] });
const t10f = rec
  && Number.isFinite(rec.zone_start_bp)
  && Number.isFinite(rec.zone_end_bp)
  && rec.zone_end_bp > rec.zone_start_bp
  && Number.isFinite(rec.score) && rec.score >= 0 && rec.score <= 1
  && Array.isArray(rec.support)
  && ['strong','moderate','weak','ambiguous'].includes(rec.support_class)
  && rec.source === 'auto'
  && Array.isArray(rec.sv_anchors_in_zone)
  && rec.set_by === 'scrubber_auto'
  && typeof rec.set_at === 'string';
// The zone covers ±5 windows around window_idx (=win_lo + window_idx_local)
const expectedLo = Math.max(0, edge.window_idx - 5);
const expectedHi = Math.min(129, edge.window_idx + 5);
const t10g = rec.zone_start_bp === windowsForN.start_bp[expectedLo]
          && rec.zone_end_bp   === windowsForN.end_bp[expectedHi];
// Manual source flips set_by
const recManual = M._buildBoundaryRecord(edge, 'left', 'manual', { sv_anchors: [] });
const t10h = recManual.set_by === 'scrubber_manual';
const recAPM = M._buildBoundaryRecord(edge, 'left', 'auto_plus_manual', { sv_anchors: [] });
const t10i = recAPM.set_by === 'scrubber_manual' && recAPM.source === 'auto_plus_manual';
// Null edge → null record
const t10j = M._buildBoundaryRecord(null, 'left', 'auto', {}) === null;
console.log('  state.active_cand_id null:', t10a);
console.log('  state.scan_radius_bp 1.5 Mb:', t10b);
console.log('  state.staging shape:', t10c);
console.log('  state.cache is Map:', t10d);
console.log('  state idempotent:', t10e);
console.log('  record shape conforms to schema §12:', t10f);
console.log('  zone covers ±5 windows:', t10g);
console.log('  manual source → scrubber_manual:', t10h);
console.log('  auto_plus_manual preserved:', t10i);
console.log('  null edge → null record:', t10j);
check('test10', t10a && t10b && t10c && t10d && t10e && t10f && t10g && t10h && t10i && t10j);

// =============================================================================
// SUMMARY
// =============================================================================
console.log(`\n--- v3.97 turn 1 tests: ${totalPass}/${totalPass + totalFail} ---`);
if (totalFail > 0) process.exit(1);
