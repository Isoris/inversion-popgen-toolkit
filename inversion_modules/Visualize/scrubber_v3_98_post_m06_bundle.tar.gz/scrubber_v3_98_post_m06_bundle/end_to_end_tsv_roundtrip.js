#!/usr/bin/env node
// End-to-end roundtrip: candidate with boundary fields → emit 45-column TSV
// → parse back → verify. Confirms the v3.97 turn-3 export contract.

const fs = require('fs');
const html = fs.readFileSync('/home/claude/v3/pca_scrubber_v3.html', 'utf8');
const m = html.match(/<script>([\s\S]+?)<\/script>/);
let js = m[1];

const shim = `
const _byId = new Map();
function _makeEl(tag) {
  const _ownC = new Set();
  const ctxStub = { setTransform:()=>{}, clearRect:()=>{}, fillRect:()=>{},
    strokeRect:()=>{}, beginPath:()=>{}, moveTo:()=>{}, lineTo:()=>{}, stroke:()=>{},
    fill:()=>{}, fillText:()=>{}, save:()=>{}, restore:()=>{},
    translate:()=>{}, rotate:()=>{}, setLineDash:()=>{},
    measureText:(s)=>({ width:0 }), createLinearGradient:()=>({addColorStop:()=>{}}),
    fillStyle:'',strokeStyle:'',lineWidth:1,font:'',textAlign:'',textBaseline:'' };
  const el = { tagName:(tag||'').toUpperCase(), id:'', textContent:'', _innerHTML:'',
    disabled:false, value:'', placeholder:'', title:'', checked:false,
    width:0, height:0, offsetWidth:100, offsetHeight:20, clientWidth:1000, clientHeight:400,
    style:{cssText:'',display:'',width:'',height:'',visibility:'',left:'',top:''},
    classList: { _c: _ownC, add(...a){a.forEach(x=>this._c.add(x));},
      remove(...a){a.forEach(x=>this._c.delete(x));}, toggle(){}, contains(x){return this._c.has(x);} },
    dataset:{}, _children:[],
    appendChild(c){ this._children.push(c); return c; },
    addEventListener(){}, removeEventListener(){},
    insertAdjacentHTML(){},
    querySelector(){return null;}, querySelectorAll: () => [],
    setAttribute(){}, getAttribute(){return null;}, removeAttribute(){},
    getBoundingClientRect: () => ({left:0,top:0,width:1000,height:120,right:1000,bottom:120}),
    contains: () => false, parentNode: null, parentElement: null,
    getContext: () => ctxStub };
  Object.defineProperty(el,'innerHTML',{get(){return this._innerHTML;},set(v){this._innerHTML=String(v);}});
  Object.defineProperty(el,'className',{get(){return [...this.classList._c].join(' ');},
    set(v){this.classList._c.clear(); String(v||'').split(/\\s+/).filter(Boolean).forEach(x=>this.classList._c.add(x));}});
  return el;
}
const _bodyEl = _makeEl('body');
const document = {
  documentElement: _makeEl('html'),
  querySelectorAll: () => [], querySelector: () => null,
  getElementById(id) { if (!_byId.has(id)) { const el = _makeEl('div'); el.id = id; _byId.set(id, el); } return _byId.get(id); },
  createElement: _makeEl, body: _bodyEl,
  addEventListener: () => {}, removeEventListener: () => {},
  activeElement: { tagName: 'DIV' },
};
const window = { devicePixelRatio: 1, addEventListener: () => {}, innerWidth: 1024, innerHeight: 768 };
const localStorage = { setItem(){}, getItem(){return null;}, removeItem(){}, clear(){} };
const getComputedStyle = () => ({ getPropertyValue: () => '' });
const FileReader = function() {};
const Blob = function() {};
const URL = { createObjectURL: () => '', revokeObjectURL: () => {} };
const requestAnimationFrame = (fn) => { try { fn(); } catch (e) {} return 1; };
const cancelAnimationFrame = () => {};
const setTimeout = (fn) => { try { fn(); } catch (e) {} return 1; };
const clearTimeout = () => {};
const alert = () => {};
const confirm = () => true;
`;
js = `${shim}\n${js}\nmodule.exports = {
  state, REGISTRY_TSV_COLUMNS,
  _boundaryColsFromCand, _registryRowsForCandidates,
};\n`;
fs.writeFileSync('/tmp/scrubber_tsv_roundtrip.js', js);
delete require.cache[require.resolve('/tmp/scrubber_tsv_roundtrip.js')];
const M = require('/tmp/scrubber_tsv_roundtrip.js');

let pass = 0, fail = 0;
function ok(cond, msg) {
  if (cond) { console.log('ok:   ' + msg); pass++; }
  else      { console.log('FAIL: ' + msg); fail++; }
}

// =============================================================================
// state.data.windows is per-window object array (sigma profiling expects this)
// =============================================================================
const N_WIN = 100;
const winArr = new Array(N_WIN);
for (let i = 0; i < N_WIN; i++) {
  winArr[i] = { pc1: 0.0, pc2: 0.0, start_bp: i * 20000, end_bp: i * 20000 + 19999 };
}
M.state.data = {
  windows: winArr,
  fish_names: ['F001', 'F002', 'F003'],
  n_fish: 3,
  samples: [
    { fish_name: 'F001', family_id: 0, ancestry: null },
    { fish_name: 'F002', family_id: 0, ancestry: null },
    { fish_name: 'F003', family_id: 1, ancestry: null },
  ],
};
M.state.flipPC1 = false;
M.state.pc1Sign = null;

// Two candidates
const candA = {
  id: 1, candidate_id: 1, chrom: 'C_gar_LG28',
  start_bp: 12000000, end_bp: 14000000,
  start_w: 0, end_w: 99, K: 3, source: 'manual',
  l2_indices: [10, 11], ref_l2: 10, ref_window: 50,
  locked_labels: new Int8Array([0, 0, 0]),
  qc_status: 'accepted', notes: '', created_at: Date.now(),
  boundary_left: {
    zone_start_bp: 11900000, zone_end_bp: 11940000,
    score: 0.8231,
    support: ['pca_drop', 'ghsl_step', 'band_continuity_drop'],
    support_class: 'strong', source: 'auto',
    sv_anchors_in_zone: [], notes: '',
    set_at: '2026-04-28T10:00:00+0700', set_by: 'scrubber_auto',
  },
  boundary_right: {
    zone_start_bp: 14080000, zone_end_bp: 14120000,
    score: 0.6543,
    support: ['pca_drop', 'ghsl_step'],
    support_class: 'moderate', source: 'manual',
    sv_anchors_in_zone: [], notes: '',
    set_at: '2026-04-28T10:01:00+0700', set_by: 'scrubber_manual',
  },
  breakpoint_status: 'boundary_zone_only',
  boundary_notes: 'auto for left; manual override for right at win 80',
};
const candB = {
  id: 2, candidate_id: 2, chrom: 'C_gar_LG28',
  start_bp: 5000000, end_bp: 6000000,
  start_w: 0, end_w: 99, K: 3, source: 'manual',
  l2_indices: [5], ref_l2: 5, ref_window: 50,
  locked_labels: new Int8Array([0, 0, 0]),
  qc_status: 'accepted', notes: '', created_at: Date.now(),
};

console.log('--- Phase 1: build TSV rows ---');
let rows;
try {
  rows = M._registryRowsForCandidates([candA, candB]);
} catch (e) {
  console.log('FAIL building rows:', e.message);
  process.exit(1);
}
ok(rows.length === 2, 'two rows');

console.log('\n--- Phase 2: emit + parse back ---');
const header = M.REGISTRY_TSV_COLUMNS.join('\t');
const lineA = M.REGISTRY_TSV_COLUMNS.map(c => rows[0][c]).join('\t');
const lineB = M.REGISTRY_TSV_COLUMNS.map(c => rows[1][c]).join('\t');
const tsv = [header, lineA, lineB].join('\n');

const lines = tsv.split('\n');
const parsedHeader = lines[0].split('\t');
const parsedA = lines[1].split('\t');
const parsedB = lines[2].split('\t');

ok(parsedHeader.length === 45, `header has 45 fields (got ${parsedHeader.length})`);
ok(parsedA.length === 45,      `candA row has 45 fields (got ${parsedA.length})`);
ok(parsedB.length === 45,      `candB row has 45 fields (got ${parsedB.length})`);

const colIdx = (name) => parsedHeader.indexOf(name);

console.log('\n--- Phase 3: candA populated cells ---');
ok(parsedA[colIdx('left_boundary_zone_start')] === '11900000', 'left_boundary_zone_start');
ok(parsedA[colIdx('left_boundary_zone_end')]   === '11940000', 'left_boundary_zone_end');
ok(parsedA[colIdx('left_boundary_score')]      === '0.8231',   'left_boundary_score (4dp)');
ok(parsedA[colIdx('left_boundary_support')]    === 'pca_drop|ghsl_step|band_continuity_drop',
   'left_boundary_support pipe-separated');
ok(parsedA[colIdx('left_boundary_support_class')] === 'strong', 'left_boundary_support_class');
ok(parsedA[colIdx('left_boundary_source')]     === 'auto',     'left_boundary_source');
ok(parsedA[colIdx('right_boundary_zone_start')] === '14080000', 'right_boundary_zone_start');
ok(parsedA[colIdx('right_boundary_score')]     === '0.6543',   'right_boundary_score (4dp)');
ok(parsedA[colIdx('right_boundary_support_class')] === 'moderate', 'right_boundary_support_class');
ok(parsedA[colIdx('right_boundary_source')]    === 'manual',   'right_boundary_source');
ok(parsedA[colIdx('breakpoint_status')]        === 'boundary_zone_only', 'breakpoint_status');
ok(parsedA[colIdx('boundary_notes')]           === 'auto for left; manual override for right at win 80',
   'boundary_notes preserved');

console.log('\n--- Phase 4: candB empty cells ---');
const expectEmpty = [
  'left_boundary_zone_start', 'left_boundary_zone_end',
  'left_boundary_score', 'left_boundary_support',
  'left_boundary_support_class', 'left_boundary_source',
  'right_boundary_zone_start', 'right_boundary_zone_end',
  'right_boundary_score', 'right_boundary_support',
  'right_boundary_support_class', 'right_boundary_source',
  'breakpoint_status', 'boundary_notes',
];
let allEmpty = true;
for (const name of expectEmpty) {
  if (parsedB[colIdx(name)] !== '') {
    allEmpty = false;
    console.log(`  FAIL: candB ${name} = "${parsedB[colIdx(name)]}", expected ""`);
    break;
  }
}
ok(allEmpty, 'candB has empty strings in all 14 boundary fields');

console.log('\n--- Phase 5: existing fields unaffected ---');
ok(parsedA[colIdx('candidate_id')] === '1',           'candidate_id');
ok(parsedA[colIdx('chrom')] === 'C_gar_LG28',         'chrom');
ok(parsedA[colIdx('K')] === '3',                       'K');
ok(parsedA[colIdx('qc_status')] === 'accepted',        'qc_status');
ok(/^v3\.(9[7-9]|\d{3,})/.test(parsedA[colIdx('scrubber_version')]),
   `scrubber_version is v3.97+ (got ${parsedA[colIdx('scrubber_version')]})`);
ok(parsedA[colIdx('span_mb')] === '2.000',             'span_mb');

console.log('\n--- Phase 6: column-ORDER positional ---');
const idxNk6Pure = colIdx('n_k6_pure');
const idxLeftStart = colIdx('left_boundary_zone_start');
const idxBoundaryNotes = colIdx('boundary_notes');
const idxQcStatus = colIdx('qc_status');
ok(idxNk6Pure + 1 === idxLeftStart,
   `left_boundary_zone_start immediately follows n_k6_pure: ${idxNk6Pure} → ${idxLeftStart}`);
ok(idxBoundaryNotes + 1 === idxQcStatus,
   `qc_status immediately follows boundary_notes: ${idxBoundaryNotes} → ${idxQcStatus}`);
ok(idxBoundaryNotes - idxLeftStart === 13,
   `14 boundary columns contiguous (13 gaps): ${idxBoundaryNotes - idxLeftStart}`);

console.log(`\n${pass} passed, ${fail} failed`);
if (fail > 0) process.exit(1);
