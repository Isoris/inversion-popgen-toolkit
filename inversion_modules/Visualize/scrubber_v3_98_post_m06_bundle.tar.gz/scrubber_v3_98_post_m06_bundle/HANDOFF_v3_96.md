# Handoff — scrubber v3.96 (2026-04-28)

## Where we are

**Current head:** `pca_scrubber_v3.html` v3.96 (983 KB, 21,559 lines).
**SCHEMA:** `SCHEMA_V2.md` v2.7 (92 KB, 1,595 lines).
**Tests:** 552/552 passing (29 new + 523 carried forward).

This handoff covers v3.96 — the hover-tooltip increment specified in
`SPECS_v3_96_v3_97_v3_98.md` §1 and locked into schema 2.7 §10
"Hover affordances". Prior:

- v3.95 (R-side unblock work, no scrubber changes) in `HANDOFF_v3_95.md`
- v3.94 in `HANDOFF_v3_94.md`
- v3.93 in `HANDOFF_v3_93.md`
- v3.0–v3.80 in `/mnt/transcripts/journal.txt`

## Work shipped this chat (v3.96)

### Hover tooltips on dosage heatmap cells

A one-line tooltip appears next to the cursor when hovering any cell
of the dosage matrix, in both render contexts:

- **Static** (candidate page 2 section)
- **Live** (L3 docked cursor strip)

Format (schema 2.7 §10):

```
CGA037 · M0124 (12,018,473 bp) · dosage=1 · HOMO_1 · core
```

Components are space-`·`-space separated with absent-field omission
(no `null` placeholders, no double separators). Optional segments —
`group`, `quality`, `flipped` — disappear cleanly when their source
returns null/unknown/false. NA dosage cells render `dosage=NA`; the
`-1` sentinel is never exposed.

### Architecture

The renderer already returned `{ matX, matY, matW, matH, cellW, cellH }`
in its layout — entire foundation for hit-testing was in place since
v3.94. This increment is plumbing on top:

1. **Pure helpers** (unit-testable, no DOM):
   - `_heatmapHitTest(layout, mx, my, sample_order, selected_marker_indices)`
     — returns `{ marker_idx, sample_idx, col, row }` or `null`
   - `_heatmapTooltipText(hit, ctx)` — builds the one-line string
   - `_fmtBp(n)` — thousands-separated bp formatting

2. **DOM-touching plumbing**:
   - `_ensureHeatmapTooltipSlot(canvas)` — creates `<div class="dh-tooltip">`
     as a sibling of the canvas inside `.dh-canvas-wrap`; idempotent
   - `_positionDhTooltip(slot, canvas, mx, my)` — +12/+4 px offset,
     flips left/above on overflow, clamps to wrapper bounds with 4 px
     margin
   - `_wireHeatmapHover(canvas, opts)` — attaches `mousemove` +
     `mouseleave`; idempotent via `__dh_hover_off` handle
   - `_resetDhHoverState(hoverState, slot)` — invalidates stale layout
     references on redraw

3. **State extension**: `state.__dosageHm` gained `hover_static` and
   `hover_cursor`, each shaped `{ last_cell, raf_handle }`. Both reset
   on every redraw because the layout `last_cell` referred to is now
   stale.

4. **Render-context stash**: `renderDosageHeatmap` now stashes
   `{ layout, chunk, lk, polarity, selected_marker_indices, sample_order }`
   on `canvas.__dh_render_ctx` after a successful `drawDosageHeatmap`.
   Both wire-in points (`_redrawCandidateHeatmap`,
   `redrawCursorHeatmap`) read from this and pass it to
   `_wireHeatmapHover`. Single source of truth for the hover pipeline.

### Performance contract (locked in schema 2.7)

- **Cell-stable suppression**: cursor staying within a cell across
  multiple `mousemove` events causes zero DOM writes. Check is on
  `(marker_idx, sample_idx)` equality.
- **RAF coalescing**: at most one DOM write per frame. Multiple
  `mousemove` events between frames coalesce via
  `requestAnimationFrame`.
- **Tooltip element reused**: one per canvas, lazily mounted on first
  hover. `pointer-events: none` prevents cell-boundary cursor flicker.

### CSS

- `.dh-canvas-wrap { position: relative }` — was missing, now present.
  Required for the tooltip's `position: absolute`.
- `.dh-tooltip { ... }` — full rule with pointer-events:none, z-index:50,
  monospace, 4 px / 8 px padding, white-space:nowrap, max-width 480 px.

### Tests (10 new in `test_v396.js`)

1. `SCRUBBER_VERSION` is `v3.96+`.
2. `_heatmapHitTest` maps in-bounds px → cell indices using
   `cellW`/`cellH` and `matX`/`matY`. Two synthetic-layout points
   verified.
3. `_heatmapHitTest` returns `null` outside matrix on all four sides
   (left of matX, right of matX+matW, above matY, below matY+matH)
   plus null layout.
4. `_heatmapHitTest` returns `null` when col/row out of selection
   bounds, plus null inputs and `cellW=0` guards.
5. `_heatmapTooltipText` with full data builds the canonical 6-component
   string `sample · marker (bp) · dosage=N · group · quality · flipped`.
6. `_heatmapTooltipText` omits each optional segment cleanly: 5 sub-cases
   covering null group, unknown quality, false polarity, missing lk,
   missing marker_id (→ `pos<bp>` fallback), null hit, null ctx.
7. `_heatmapTooltipText` formats NA dosage as `dosage=NA`; `-1` sentinel
   not exposed.
8. `_fmtBp` formats with thousands separators (`12,018,473`); handles
   `null`/`undefined`/`NaN` → `"?"`.
9. CSS contains `.dh-canvas-wrap { position: relative }` and
   `.dh-tooltip { pointer-events: none; display: none; z-index: ... }`.
10. State extension: `_ensureDosageHmState()` returns object with
    `hover_static` and `hover_cursor` shaped `{ last_cell, raf_handle }`,
    idempotent. Source-grep verifies render-context stash + wire-in
    calls present in HTML.

### End-to-end validation

`end_to_end_hover_check.js` extracts the real `_heatmapHitTest` and
`_heatmapTooltipText` from the HTML via `vm.createContext` and runs them
on chunks produced by `STEP_M04_emit_dosage_chunks.R` (the v3.95 R-side
output). 15/15 checks pass — including:

- Real-chunk hit-test on the center of the first cell returns the
  correct `(marker_idx, sample_idx)` pair.
- Tooltip on a real chunk reads as
  `"S001 · TEST_LG01_404 (404 bp) · dosage=0"`.
- Tooltip on a real NA cell reads as
  `"S002 · TEST_LG01_471 (471 bp) · dosage=NA"`.
- Hits at `matX + matW` (right edge) return null per the half-open
  rectangle rule.

This means: when v3.96 is deployed and the v3.95 R-side outputs are
loaded for the 226-sample LG28 cohort, hovering any cell in the
heatmap will show the contracted tooltip on first try, no further
work needed.

## Notable design decisions

- **Annotation tracks not tooltipped in v3.96.** Hit-tests outside the
  dosage matrix's `[matX, matY, matX+matW, matY+matH)` rectangle return
  null. This keeps v3.96 scope tight; annotation-track tooltips can be
  added later if requested. Schema 2.7 documents this as the v3.96
  behaviour rather than a permanent constraint.
- **Half-open right/bottom edges.** A point exactly at `matX + matW` is
  considered outside the matrix (avoids the off-by-one of including
  cell `n_markers` which doesn't exist). End-to-end test verifies this.
- **`__dh_render_ctx` cleared at the start of every render.** Prevents
  stale-layout hit-tests during a failed render. Wiring only re-attaches
  on success.
- **Idempotent wire-in.** `_wireHeatmapHover` detaches prior listeners
  via `canvas.__dh_hover_off` before attaching new ones. Re-renders of
  the same canvas don't accumulate listeners.
- **Two hover contexts, not one.** Static and cursor heatmaps each get
  their own `hover_static`/`hover_cursor` state. Without this, simultaneous
  hovers on both (mouse over the page-2 heatmap while the cursor strip
  is open) would race for `last_cell`.
- **`requestAnimationFrame` fallback to `setTimeout`.** When `rAF` is
  unavailable (Node test environment), tooltip update fires via
  `setTimeout(cb, 16)`. Tests run cleanly under both paths.

## Outstanding items / open list (post-v3.96)

### Hot — natural next session

1. **Real-data validation on the 226-sample LG28 cohort.** v3.95 R-side
   outputs + v3.96 hover tooltips combined fully exercise the dosage
   heatmap module. The remaining unknowns are visual — how the tooltip
   reads at typical cohort scale (~3 px cells), whether the offset feels
   right, whether 480 px max-width is too much/too little.
2. **Per-candidate filtered TSV export buttons on page 10**
   (`SPECS_v3_96_v3_97_v3_98.md` §2). Still applicable — independent
   of heatmap; ready to implement when phase-13 marker layers ship.

### Medium

- Annotation-track tooltips (left + top tracks) — out of v3.96 scope,
  natural follow-on if user wants per-track info on hover.
- Recompute button for `purity_threshold` on candidate page (v3.81)
- L3 sub-band column captions
- K=6 coalescing UI (manual `g0a + g0b` merge)
- Per-L2 band diagnostics (currently only at ref_l2 anchor)
- Per-L2 het-shape (would re-run compute per supporting L2; opt-in)
- Window-radius UI for live mode (5/10/20 toggle; v3.94 ships fixed ±5)

### Smaller / polish

- v3.80 UI text rewrite (`SPECS_v3_96_v3_97_v3_98.md` §3)
- Slab-mode K=3+6 layout polish
- localStorage persistence of `bandSelection`
- Sample-tracking on band chip click
- Coalescing UI for band selection (g3+g4 from v3.44)
- Fix NULL_CONCORD K=6 hardcoded 0.30 (true ~22%)
- Per-track resize handles for popstats/ancestry stack tracks

### Long-running parked (R-side, blocks scrubber-side validation)

Same as v3.95 handoff:

- `STEP_T06_emit_theta_pi_panel.R` — unlocks θπ pillar (v3.92)
- `STEP_R12_emit_roh_intervals.R` — unlocks ROH pillar (v3.92)
- `STEP_R13_emit_sample_froh.R` — unlocks FROH pillar (v3.92)

## Key v3.96 functions / files (reference for next chat)

### Pure helpers (testable in node)

- `_heatmapHitTest(layout, mx, my, sample_order, selected_marker_indices)`
- `_heatmapTooltipText(hit, ctx)`
- `_fmtBp(n)`

### DOM plumbing

- `_ensureHeatmapTooltipSlot(canvas)`
- `_positionDhTooltip(slot, canvas, mx, my)`
- `_wireHeatmapHover(canvas, opts)`
- `_resetDhHoverState(hoverState, slot)`

### Wire-in points (modified)

- `renderDosageHeatmap` — now stashes `__dh_render_ctx` on canvas
- `_redrawCandidateHeatmap` — wires hover post-render
- `redrawCursorHeatmap` — wires hover post-render

### CSS

- `.dh-canvas-wrap { position: relative }` — added
- `.dh-tooltip { ... }` — new

## SCHEMA_V2.md status

**Bumped to v2.7.** §10 ("Hover affordances") subsection added before
"Cross-references". Documents:

- One-line tooltip format with absent-field omission rule
- Performance contract (cell-stable suppression + RAF coalescing)
- State lifecycle (two hover contexts, reset-on-redraw)
- Position clamping (offset + flip + 4 px margin)
- Annotation-track tooltips noted as v3.96 not-yet (tooltipping the
  matrix only)

## File staging at /mnt/user-data/outputs/

- **pca_scrubber_v3.html** — v3.96, 983 KB, 21,559 lines
- **SCHEMA_V2.md** — v2.7, 92 KB, 1,595 lines
- **test_v396.js** — 10 new tests, 389 lines
- **end_to_end_hover_check.js** — real-chunk validation, 157 lines
- **HANDOFF_v3_96.md** — this file

## Suggested entry point for next chat

Real-data validation on the 226-sample LG28 cohort is the most useful
work — both R-side (v3.95) and tooltips (v3.96) need to be exercised
against actual hatchery cohort dosage. The visual contract is locked,
but ergonomics (cell size at typical scale, tooltip readability,
position offset) only become legible when seen on real data.

If validation flags issues that need fixing, fix them in v3.97. If
validation passes cleanly, **per-candidate filtered TSV export**
(`SPECS_v3_96_v3_97_v3_98.md` §2) is the next ready-to-implement
increment.

## User working style notes

(Unchanged.)

"Continue" = proceed with next agreed item. Pragmatic, multi-session
parallel chats. This chat shipped v3.95 (R-side) + v3.96 (hover
tooltips); both increments unblock real-data validation in different
ways.

Three catfish cohorts that must NEVER be conflated:
1. F1 hybrid (*C. gariepinus* × *C. macrocephalus*) — genome assembly
   paper only
2. 226-sample pure *C. gariepinus* hatchery cohort — current inversion
   work, "MS_Inversions_North_african_catfish" — K clusters reflect
   broodline structure, NOT species admixture
3. Pure *C. macrocephalus* wild cohort — future paper

User's full name is Quentin Andres. Never invent a surname.
